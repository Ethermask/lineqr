package org.chromium.support_lib_boundary;

public interface WebResourceRequestBoundaryInterface {
    boolean isRedirect();
}

package org.chromium.support_lib_boundary;

public interface WebResourceErrorBoundaryInterface {
    CharSequence getDescription();

    int getErrorCode();
}

package org.apache.cordova;

public class CoreAndroidWrapper extends CoreAndroid {
}

package org.apache.cordova;

public class AuthenticationToken {
    public String password;
    public String userName;

    public String getPassword() {
        return this.password;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setPassword(String str) {
        this.password = str;
    }

    public void setUserName(String str) {
        this.userName = str;
    }
}

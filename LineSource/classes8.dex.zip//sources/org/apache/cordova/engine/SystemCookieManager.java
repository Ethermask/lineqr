package org.apache.cordova.engine;

import android.annotation.TargetApi;
import android.webkit.CookieManager;
import android.webkit.WebView;
import org.apache.cordova.ICordovaCookieManager;

public class SystemCookieManager implements ICordovaCookieManager {
    public final CookieManager cookieManager = CookieManager.getInstance();
    public final WebView webView;

    @TargetApi(21)
    public SystemCookieManager(WebView webView2) {
        this.webView = webView2;
        CookieManager.setAcceptFileSchemeCookies(true);
        this.cookieManager.setAcceptThirdPartyCookies(this.webView, true);
    }

    public void clearCookies() {
        this.cookieManager.removeAllCookie();
    }

    public void flush() {
        this.cookieManager.flush();
    }

    public String getCookie(String str) {
        return this.cookieManager.getCookie(str);
    }

    public void setCookie(String str, String str2) {
        this.cookieManager.setCookie(str, str2);
    }

    public void setCookiesEnabled(boolean z) {
        this.cookieManager.setAcceptCookie(z);
    }
}

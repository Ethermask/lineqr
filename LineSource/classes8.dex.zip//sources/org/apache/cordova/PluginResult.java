package org.apache.cordova;

import android.util.Base64;
import e.e.b.a.a;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class PluginResult {
    public static final int MESSAGE_TYPE_ARRAYBUFFER = 6;
    public static final int MESSAGE_TYPE_BINARYSTRING = 7;
    public static final int MESSAGE_TYPE_BOOLEAN = 4;
    public static final int MESSAGE_TYPE_JSON = 2;
    public static final int MESSAGE_TYPE_MULTIPART = 8;
    public static final int MESSAGE_TYPE_NULL = 5;
    public static final int MESSAGE_TYPE_NUMBER = 3;
    public static final int MESSAGE_TYPE_STRING = 1;
    public static String[] StatusMessages = {"No result", "OK", "Class not found", "Illegal access", "Instantiation error", "Malformed url", "IO error", "Invalid action", "JSON error", "Error"};
    public String encodedMessage;
    public boolean keepCallback;
    public final int messageType;
    public List<PluginResult> multipartMessages;
    public final int status;
    public String strMessage;

    public enum Status {
        NO_RESULT,
        OK,
        CLASS_NOT_FOUND_EXCEPTION,
        ILLEGAL_ACCESS_EXCEPTION,
        INSTANTIATION_EXCEPTION,
        MALFORMED_URL_EXCEPTION,
        IO_EXCEPTION,
        INVALID_ACTION,
        JSON_EXCEPTION,
        ERROR
    }

    public PluginResult(Status status2) {
        this(status2, StatusMessages[status2.ordinal()]);
    }

    @Deprecated
    public String getJSONString() {
        StringBuilder V0 = a.V0("{\"status\":");
        V0.append(this.status);
        V0.append(",\"message\":");
        V0.append(getMessage());
        V0.append(",\"keepCallback\":");
        return a.G0(V0, this.keepCallback, "}");
    }

    public boolean getKeepCallback() {
        return this.keepCallback;
    }

    public String getMessage() {
        if (this.encodedMessage == null) {
            this.encodedMessage = JSONObject.quote(this.strMessage);
        }
        return this.encodedMessage;
    }

    public int getMessageType() {
        return this.messageType;
    }

    public PluginResult getMultipartMessage(int i) {
        return this.multipartMessages.get(i);
    }

    public int getMultipartMessagesSize() {
        return this.multipartMessages.size();
    }

    public int getStatus() {
        return this.status;
    }

    public String getStrMessage() {
        return this.strMessage;
    }

    public void setKeepCallback(boolean z) {
        this.keepCallback = z;
    }

    @Deprecated
    public String toCallbackString(String str) {
        int i = this.status;
        Status status2 = Status.NO_RESULT;
        if (i == 0 && this.keepCallback) {
            return null;
        }
        int i2 = this.status;
        Status status3 = Status.OK;
        if (i2 != 1) {
            Status status4 = Status.NO_RESULT;
            if (i2 != 0) {
                return toErrorCallbackString(str);
            }
        }
        return toSuccessCallbackString(str);
    }

    @Deprecated
    public String toErrorCallbackString(String str) {
        StringBuilder h1 = a.h1("cordova.callbackError('", str, "', ");
        h1.append(getJSONString());
        h1.append(");");
        return h1.toString();
    }

    @Deprecated
    public String toSuccessCallbackString(String str) {
        StringBuilder h1 = a.h1("cordova.callbackSuccess('", str, "',");
        h1.append(getJSONString());
        h1.append(");");
        return h1.toString();
    }

    public PluginResult(Status status2, String str) {
        this.keepCallback = false;
        this.status = status2.ordinal();
        this.messageType = str == null ? 5 : 1;
        this.strMessage = str;
    }

    public PluginResult(Status status2, JSONArray jSONArray) {
        this.keepCallback = false;
        this.status = status2.ordinal();
        this.messageType = 2;
        this.encodedMessage = jSONArray.toString();
    }

    public PluginResult(Status status2, JSONObject jSONObject) {
        this.keepCallback = false;
        this.status = status2.ordinal();
        this.messageType = 2;
        this.encodedMessage = jSONObject.toString();
    }

    public PluginResult(Status status2, int i) {
        this.keepCallback = false;
        this.status = status2.ordinal();
        this.messageType = 3;
        this.encodedMessage = a.m("", i);
    }

    public PluginResult(Status status2, float f) {
        this.keepCallback = false;
        this.status = status2.ordinal();
        this.messageType = 3;
        this.encodedMessage = "" + f;
    }

    public PluginResult(Status status2, boolean z) {
        this.keepCallback = false;
        this.status = status2.ordinal();
        this.messageType = 4;
        this.encodedMessage = Boolean.toString(z);
    }

    public PluginResult(Status status2, byte[] bArr) {
        this(status2, bArr, false);
    }

    public PluginResult(Status status2, byte[] bArr, boolean z) {
        this.keepCallback = false;
        this.status = status2.ordinal();
        this.messageType = z ? 7 : 6;
        this.encodedMessage = Base64.encodeToString(bArr, 2);
    }

    public PluginResult(Status status2, List<PluginResult> list) {
        this.keepCallback = false;
        this.status = status2.ordinal();
        this.messageType = 8;
        this.multipartMessages = list;
    }
}

package org.apache.cordova.camera;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import e.e.b.a.a;
import hh.j.f.b;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import okhttp3.internal.http2.Hpack;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.LOG;
import org.apache.cordova.PermissionHelper;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;

public class CameraLauncher extends CordovaPlugin implements MediaScannerConnection.MediaScannerConnectionClient {
    public static final int ALLMEDIA = 2;
    public static final int CAMERA = 1;
    public static final String CROPPED_URI_KEY = "croppedUri";
    public static final int CROP_CAMERA = 100;
    public static final int DATA_URL = 0;
    public static final int FILE_URI = 1;
    public static final String GET_All = "Get All";
    public static final String GET_PICTURE = "Get Picture";
    public static final String GET_VIDEO = "Get Video";
    public static final String IMAGE_URI_KEY = "imageUri";
    public static final int JPEG = 0;
    public static final String JPEG_EXTENSION = ".jpg";
    public static final String JPEG_MIME_TYPE = "image/jpeg";
    public static final String JPEG_TYPE = "jpg";
    public static final String LOG_TAG = "CameraLauncher";
    public static final int NATIVE_URI = 2;
    public static final int PERMISSION_DENIED_ERROR = 20;
    public static final int PHOTOLIBRARY = 0;
    public static final int PICTURE = 0;
    public static final int PNG = 1;
    public static final String PNG_EXTENSION = ".png";
    public static final String PNG_MIME_TYPE = "image/png";
    public static final String PNG_TYPE = "png";
    public static final int SAVEDPHOTOALBUM = 2;
    public static final int SAVE_TO_ALBUM_SEC = 1;
    public static final String TAKE_PICTURE_ACTION = "takePicture";
    public static final int TAKE_PIC_SEC = 0;
    public static final String TIME_FORMAT = "yyyyMMdd_HHmmss";
    public static final int VIDEO = 1;
    public static final String[] permissions = {"android.permission.CAMERA", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"};
    public boolean allowEdit;
    public String applicationId;
    public CallbackContext callbackContext;
    public MediaScannerConnection conn;
    public boolean correctOrientation;
    public String croppedFilePath;
    public Uri croppedUri;
    public int destType;
    public int encodingType;
    public ExifHelper exifData;
    public String imageFilePath;
    public Uri imageUri;
    public int mQuality;
    public int mediaType;
    public int numPics;
    public boolean orientationCorrected;
    public boolean saveToPhotoAlbum;
    public Uri scanMe;
    public int srcType;
    public int targetHeight;
    public int targetWidth;

    public static int calculateSampleSize(int i, int i2, int i3, int i4) {
        if (((float) i) / ((float) i2) > ((float) i3) / ((float) i4)) {
            return i / i3;
        }
        return i2 / i4;
    }

    public int[] calculateAspectRatio(int i, int i2) {
        int i3 = this.targetWidth;
        int i4 = this.targetHeight;
        if (i3 > 0 || i4 > 0) {
            if (i3 <= 0 || i4 > 0) {
                if (i3 > 0 || i4 <= 0) {
                    double d = ((double) i3) / ((double) i4);
                    double d2 = ((double) i) / ((double) i2);
                    if (d2 > d) {
                        i2 = (i2 * i3) / i;
                    } else {
                        i = d2 < d ? (i * i4) / i2 : i3;
                    }
                } else {
                    i = (int) ((((double) i4) / ((double) i2)) * ((double) i));
                }
                i2 = i4;
            } else {
                i2 = (int) ((((double) i3) / ((double) i)) * ((double) i2));
            }
            i = i3;
        }
        return new int[]{i, i2};
    }

    public void callTakePicture(int i, int i2) {
        boolean z = true;
        boolean z2 = PermissionHelper.hasPermission(this, "android.permission.READ_EXTERNAL_STORAGE") && PermissionHelper.hasPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE");
        boolean hasPermission = PermissionHelper.hasPermission(this, "android.permission.CAMERA");
        if (!hasPermission) {
            try {
                String[] strArr = this.cordova.getActivity().getPackageManager().getPackageInfo(this.cordova.getActivity().getPackageName(), Hpack.SETTINGS_HEADER_TABLE_SIZE).requestedPermissions;
                if (strArr != null) {
                    int length = strArr.length;
                    int i3 = 0;
                    while (true) {
                        if (i3 >= length) {
                            break;
                        } else if (strArr[i3].equals("android.permission.CAMERA")) {
                            z = false;
                            break;
                        } else {
                            i3++;
                        }
                    }
                }
            } catch (PackageManager.NameNotFoundException unused) {
            }
        } else {
            z = hasPermission;
        }
        if (z && z2) {
            takePicture(i, i2);
        } else if (z2 && !z) {
            PermissionHelper.requestPermission(this, 0, "android.permission.CAMERA");
        } else if (z2 || !z) {
            PermissionHelper.requestPermissions(this, 0, permissions);
        } else {
            PermissionHelper.requestPermissions(this, 0, new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"});
        }
    }

    public void checkForDuplicateImage(int i) {
        Uri whichContentStore = whichContentStore();
        Cursor queryImgDB = queryImgDB(whichContentStore);
        int count = queryImgDB.getCount();
        int i2 = 1;
        if (i == 1 && this.saveToPhotoAlbum) {
            i2 = 2;
        }
        if (count - this.numPics == i2) {
            queryImgDB.moveToLast();
            int intValue = Integer.valueOf(queryImgDB.getString(queryImgDB.getColumnIndex("_id"))).intValue();
            if (i2 == 2) {
                intValue--;
            }
            this.cordova.getActivity().getContentResolver().delete(Uri.parse(whichContentStore + "/" + intValue), (String) null, (String[]) null);
            queryImgDB.close();
        }
    }

    public void cleanup(int i, Uri uri, Uri uri2, Bitmap bitmap) {
        if (bitmap != null) {
            bitmap.recycle();
        }
        new File(FileHelper.stripFileProtocol(uri.toString())).delete();
        checkForDuplicateImage(i);
        if (this.saveToPhotoAlbum && uri2 != null) {
            scanForGallery(uri2);
        }
        System.gc();
    }

    public File createCaptureFile(int i) {
        return createCaptureFile(i, "");
    }

    public boolean execute(String str, JSONArray jSONArray, CallbackContext callbackContext2) throws JSONException {
        this.callbackContext = callbackContext2;
        this.applicationId = this.cordova.getActivity().getPackageName();
        if (!str.equals(TAKE_PICTURE_ACTION)) {
            return false;
        }
        this.srcType = 1;
        this.destType = 1;
        this.saveToPhotoAlbum = false;
        this.targetHeight = 0;
        this.targetWidth = 0;
        this.encodingType = 0;
        this.mediaType = 0;
        this.mQuality = 50;
        this.destType = jSONArray.getInt(1);
        this.srcType = jSONArray.getInt(2);
        this.mQuality = jSONArray.getInt(0);
        this.targetWidth = jSONArray.getInt(3);
        this.targetHeight = jSONArray.getInt(4);
        this.encodingType = jSONArray.getInt(5);
        this.mediaType = jSONArray.getInt(6);
        this.allowEdit = jSONArray.getBoolean(7);
        this.correctOrientation = jSONArray.getBoolean(8);
        this.saveToPhotoAlbum = jSONArray.getBoolean(9);
        if (this.targetWidth < 1) {
            this.targetWidth = -1;
        }
        if (this.targetHeight < 1) {
            this.targetHeight = -1;
        }
        if (this.targetHeight == -1 && this.targetWidth == -1 && this.mQuality == 100 && !this.correctOrientation && this.encodingType == 1 && this.srcType == 1) {
            this.encodingType = 0;
        }
        try {
            if (this.srcType == 1) {
                callTakePicture(this.destType, this.encodingType);
            } else if (this.srcType == 0 || this.srcType == 2) {
                if (!PermissionHelper.hasPermission(this, "android.permission.READ_EXTERNAL_STORAGE")) {
                    PermissionHelper.requestPermission(this, 1, "android.permission.READ_EXTERNAL_STORAGE");
                } else {
                    getImage(this.srcType, this.destType, this.encodingType);
                }
            }
            PluginResult pluginResult = new PluginResult(PluginResult.Status.NO_RESULT);
            pluginResult.setKeepCallback(true);
            callbackContext2.sendPluginResult(pluginResult);
            return true;
        } catch (IllegalArgumentException unused) {
            callbackContext2.error("Illegal Argument Exception");
            callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.ERROR));
            return true;
        }
    }

    public int exifToDegrees(int i) {
        if (i == 6) {
            return 90;
        }
        if (i == 3) {
            return 180;
        }
        return i == 8 ? 270 : 0;
    }

    public void failPicture(String str) {
        this.callbackContext.error(str);
    }

    /* JADX WARNING: Removed duplicated region for block: B:26:0x0093  */
    /* JADX WARNING: Removed duplicated region for block: B:28:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void getImage(int r6, int r7, int r8) {
        /*
            r5 = this;
            android.content.Intent r8 = new android.content.Intent
            r8.<init>()
            r0 = 0
            r5.croppedUri = r0
            r5.croppedFilePath = r0
            int r0 = r5.mediaType
            java.lang.String r1 = "android.intent.category.OPENABLE"
            java.lang.String r2 = "android.intent.action.GET_CONTENT"
            r3 = 1
            if (r0 != 0) goto L_0x006c
            java.lang.String r0 = "image/*"
            r8.setType(r0)
            boolean r0 = r5.allowEdit
            if (r0 == 0) goto L_0x0065
            java.lang.String r0 = "android.intent.action.PICK"
            r8.setAction(r0)
            java.lang.String r0 = "crop"
            java.lang.String r1 = "true"
            r8.putExtra(r0, r1)
            int r0 = r5.targetWidth
            if (r0 <= 0) goto L_0x0031
            java.lang.String r1 = "outputX"
            r8.putExtra(r1, r0)
        L_0x0031:
            int r0 = r5.targetHeight
            if (r0 <= 0) goto L_0x003a
            java.lang.String r1 = "outputY"
            r8.putExtra(r1, r0)
        L_0x003a:
            int r0 = r5.targetHeight
            if (r0 <= 0) goto L_0x004e
            int r1 = r5.targetWidth
            if (r1 <= 0) goto L_0x004e
            if (r1 != r0) goto L_0x004e
            java.lang.String r0 = "aspectX"
            r8.putExtra(r0, r3)
            java.lang.String r0 = "aspectY"
            r8.putExtra(r0, r3)
        L_0x004e:
            r0 = 0
            java.io.File r0 = r5.createCaptureFile(r0)
            java.lang.String r1 = r0.getAbsolutePath()
            r5.croppedFilePath = r1
            android.net.Uri r0 = android.net.Uri.fromFile(r0)
            r5.croppedUri = r0
            java.lang.String r1 = "output"
            r8.putExtra(r1, r0)
            goto L_0x008d
        L_0x0065:
            r8.setAction(r2)
            r8.addCategory(r1)
            goto L_0x008d
        L_0x006c:
            if (r0 != r3) goto L_0x007c
            java.lang.String r0 = "video/*"
            r8.setType(r0)
            r8.setAction(r2)
            r8.addCategory(r1)
            java.lang.String r0 = "Get Video"
            goto L_0x008f
        L_0x007c:
            r4 = 2
            if (r0 != r4) goto L_0x008d
            java.lang.String r0 = "*/*"
            r8.setType(r0)
            r8.setAction(r2)
            r8.addCategory(r1)
            java.lang.String r0 = "Get All"
            goto L_0x008f
        L_0x008d:
            java.lang.String r0 = "Get Picture"
        L_0x008f:
            org.apache.cordova.CordovaInterface r1 = r5.cordova
            if (r1 == 0) goto L_0x00a4
            java.lang.String r2 = new java.lang.String
            r2.<init>(r0)
            android.content.Intent r8 = android.content.Intent.createChooser(r8, r2)
            int r6 = r6 + r3
            int r6 = r6 * 16
            int r6 = r6 + r7
            int r6 = r6 + r3
            r1.startActivityForResult(r5, r8, r6)
        L_0x00a4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.cordova.camera.CameraLauncher.getImage(int, int, int):void");
    }

    public String getMimetypeForFormat(int i) {
        return i == 1 ? PNG_MIME_TYPE : i == 0 ? JPEG_MIME_TYPE : "";
    }

    public String getPicturesPath() {
        StringBuilder g1 = a.g1("IMG_", new SimpleDateFormat(TIME_FORMAT).format(new Date()));
        g1.append(this.encodingType == 0 ? JPEG_EXTENSION : PNG_EXTENSION);
        String sb = g1.toString();
        File externalStoragePublicDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        externalStoragePublicDirectory.mkdirs();
        return externalStoragePublicDirectory.getAbsolutePath() + "/" + sb;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v4, resolved type: android.graphics.Bitmap} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v28, resolved type: java.io.InputStream} */
    /* JADX WARNING: type inference failed for: r5v0 */
    /* JADX WARNING: type inference failed for: r5v1, types: [java.io.InputStream] */
    /* JADX WARNING: type inference failed for: r5v2 */
    /* JADX WARNING: type inference failed for: r5v3, types: [java.io.InputStream] */
    /* JADX WARNING: type inference failed for: r5v5 */
    /* JADX WARNING: type inference failed for: r2v23 */
    /* JADX WARNING: type inference failed for: r5v6 */
    /* JADX WARNING: type inference failed for: r2v26 */
    /* JADX WARNING: type inference failed for: r5v8 */
    /* JADX WARNING: type inference failed for: r5v9 */
    /* JADX WARNING: type inference failed for: r5v10 */
    /* JADX WARNING: type inference failed for: r5v11 */
    /* JADX WARNING: Code restructure failed: missing block: B:10:0x001f, code lost:
        if (r2 != null) goto L_0x0046;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0044, code lost:
        if (r2 != null) goto L_0x0046;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:125:0x01d2 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:137:0x01e6 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:65:0x0126 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:90:0x017b */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x01d8  */
    /* JADX WARNING: Removed duplicated region for block: B:135:0x01e2 A[SYNTHETIC, Splitter:B:135:0x01e2] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0038 A[Catch:{ OutOfMemoryError -> 0x0039, Exception -> 0x002b, all -> 0x0029, all -> 0x0022 }] */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0050 A[SYNTHETIC, Splitter:B:32:0x0050] */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0122 A[SYNTHETIC, Splitter:B:63:0x0122] */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x012d A[Catch:{ all -> 0x01cb, OutOfMemoryError -> 0x01c2, all -> 0x01ea }] */
    /* JADX WARNING: Removed duplicated region for block: B:88:0x0177 A[SYNTHETIC, Splitter:B:88:0x0177] */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x0180  */
    /* JADX WARNING: Removed duplicated region for block: B:96:0x0186  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.Bitmap getScaledAndRotatedBitmap(java.lang.String r18) throws java.io.IOException {
        /*
            r17 = this;
            r1 = r17
            r0 = r18
            int r2 = r1.targetWidth
            java.lang.String r3 = "Exception while closing file input stream."
            java.lang.String r4 = "CameraLauncher"
            r5 = 0
            if (r2 > 0) goto L_0x0058
            int r2 = r1.targetHeight
            if (r2 > 0) goto L_0x0058
            boolean r2 = r1.correctOrientation
            if (r2 != 0) goto L_0x0058
            org.apache.cordova.CordovaInterface r2 = r1.cordova     // Catch:{ OutOfMemoryError -> 0x0039, Exception -> 0x002b, all -> 0x0029 }
            java.io.InputStream r2 = org.apache.cordova.camera.FileHelper.getInputStreamFromUriString(r0, r2)     // Catch:{ OutOfMemoryError -> 0x0039, Exception -> 0x002b, all -> 0x0029 }
            android.graphics.Bitmap r5 = android.graphics.BitmapFactory.decodeStream(r2)     // Catch:{ OutOfMemoryError -> 0x0027, Exception -> 0x0025 }
            if (r2 == 0) goto L_0x004d
            goto L_0x0046
        L_0x0022:
            r0 = move-exception
            r5 = r2
            goto L_0x004e
        L_0x0025:
            r0 = move-exception
            goto L_0x002d
        L_0x0027:
            r0 = move-exception
            goto L_0x003b
        L_0x0029:
            r0 = move-exception
            goto L_0x004e
        L_0x002b:
            r0 = move-exception
            r2 = r5
        L_0x002d:
            org.apache.cordova.CallbackContext r6 = r1.callbackContext     // Catch:{ all -> 0x0022 }
            java.lang.String r0 = r0.getLocalizedMessage()     // Catch:{ all -> 0x0022 }
            r6.error((java.lang.String) r0)     // Catch:{ all -> 0x0022 }
            if (r2 == 0) goto L_0x004d
            goto L_0x0046
        L_0x0039:
            r0 = move-exception
            r2 = r5
        L_0x003b:
            org.apache.cordova.CallbackContext r6 = r1.callbackContext     // Catch:{ all -> 0x0022 }
            java.lang.String r0 = r0.getLocalizedMessage()     // Catch:{ all -> 0x0022 }
            r6.error((java.lang.String) r0)     // Catch:{ all -> 0x0022 }
            if (r2 == 0) goto L_0x004d
        L_0x0046:
            r2.close()     // Catch:{ IOException -> 0x004a }
            goto L_0x004d
        L_0x004a:
            org.apache.cordova.LOG.d(r4, r3)
        L_0x004d:
            return r5
        L_0x004e:
            if (r5 == 0) goto L_0x0057
            r5.close()     // Catch:{ IOException -> 0x0054 }
            goto L_0x0057
        L_0x0054:
            org.apache.cordova.LOG.d(r4, r3)
        L_0x0057:
            throw r0
        L_0x0058:
            org.apache.cordova.CordovaInterface r2 = r1.cordova     // Catch:{ Exception -> 0x01f1 }
            java.io.InputStream r2 = org.apache.cordova.camera.FileHelper.getInputStreamFromUriString(r0, r2)     // Catch:{ Exception -> 0x01f1 }
            r6 = 0
            if (r2 == 0) goto L_0x0108
            java.text.SimpleDateFormat r7 = new java.text.SimpleDateFormat     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r8 = "yyyyMMdd_HHmmss"
            r7.<init>(r8)     // Catch:{ Exception -> 0x01f1 }
            java.util.Date r8 = new java.util.Date     // Catch:{ Exception -> 0x01f1 }
            r8.<init>()     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r7 = r7.format(r8)     // Catch:{ Exception -> 0x01f1 }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01f1 }
            r8.<init>()     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r9 = "IMG_"
            r8.append(r9)     // Catch:{ Exception -> 0x01f1 }
            r8.append(r7)     // Catch:{ Exception -> 0x01f1 }
            int r7 = r1.encodingType     // Catch:{ Exception -> 0x01f1 }
            if (r7 != 0) goto L_0x0085
            java.lang.String r7 = ".jpg"
            goto L_0x0087
        L_0x0085:
            java.lang.String r7 = ".png"
        L_0x0087:
            r8.append(r7)     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r7 = r8.toString()     // Catch:{ Exception -> 0x01f1 }
            java.io.File r8 = new java.io.File     // Catch:{ Exception -> 0x01f1 }
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01f1 }
            r9.<init>()     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r10 = r17.getTempDirectoryPath()     // Catch:{ Exception -> 0x01f1 }
            r9.append(r10)     // Catch:{ Exception -> 0x01f1 }
            r9.append(r7)     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r7 = r9.toString()     // Catch:{ Exception -> 0x01f1 }
            r8.<init>(r7)     // Catch:{ Exception -> 0x01f1 }
            android.net.Uri r7 = android.net.Uri.fromFile(r8)     // Catch:{ Exception -> 0x01f1 }
            r1.writeUncompressedImage((java.io.InputStream) r2, (android.net.Uri) r7)     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r0 = r18.toString()     // Catch:{ Exception -> 0x00ee }
            org.apache.cordova.CordovaInterface r2 = r1.cordova     // Catch:{ Exception -> 0x00ee }
            java.lang.String r0 = org.apache.cordova.camera.FileHelper.getMimeType(r0, r2)     // Catch:{ Exception -> 0x00ee }
            java.lang.String r2 = "image/jpeg"
            boolean r0 = r2.equalsIgnoreCase(r0)     // Catch:{ Exception -> 0x00ee }
            if (r0 == 0) goto L_0x010a
            java.lang.String r0 = r7.toString()     // Catch:{ Exception -> 0x00ee }
            java.lang.String r2 = "file://"
            java.lang.String r9 = ""
            java.lang.String r0 = r0.replace(r2, r9)     // Catch:{ Exception -> 0x00ee }
            org.apache.cordova.camera.ExifHelper r2 = new org.apache.cordova.camera.ExifHelper     // Catch:{ Exception -> 0x00ee }
            r2.<init>()     // Catch:{ Exception -> 0x00ee }
            r1.exifData = r2     // Catch:{ Exception -> 0x00ee }
            r2.createInFile(r0)     // Catch:{ Exception -> 0x00ee }
            org.apache.cordova.camera.ExifHelper r2 = r1.exifData     // Catch:{ Exception -> 0x00ee }
            r2.readExifData()     // Catch:{ Exception -> 0x00ee }
            boolean r2 = r1.correctOrientation     // Catch:{ Exception -> 0x00ee }
            if (r2 == 0) goto L_0x010a
            android.media.ExifInterface r2 = new android.media.ExifInterface     // Catch:{ Exception -> 0x00ee }
            r2.<init>(r0)     // Catch:{ Exception -> 0x00ee }
            java.lang.String r0 = "Orientation"
            int r0 = r2.getAttributeInt(r0, r6)     // Catch:{ Exception -> 0x00ee }
            int r0 = r1.exifToDegrees(r0)     // Catch:{ Exception -> 0x00ee }
            goto L_0x010b
        L_0x00ee:
            r0 = move-exception
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01f1 }
            r2.<init>()     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r9 = "Unable to read Exif data: "
            r2.append(r9)     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x01f1 }
            r2.append(r0)     // Catch:{ Exception -> 0x01f1 }
            java.lang.String r0 = r2.toString()     // Catch:{ Exception -> 0x01f1 }
            org.apache.cordova.LOG.w((java.lang.String) r4, (java.lang.String) r0)     // Catch:{ Exception -> 0x01f1 }
            goto L_0x010a
        L_0x0108:
            r7 = r5
            r8 = r7
        L_0x010a:
            r0 = r6
        L_0x010b:
            android.graphics.BitmapFactory$Options r2 = new android.graphics.BitmapFactory$Options     // Catch:{ all -> 0x01ea }
            r2.<init>()     // Catch:{ all -> 0x01ea }
            r9 = 1
            r2.inJustDecodeBounds = r9     // Catch:{ all -> 0x01ea }
            java.lang.String r10 = r7.toString()     // Catch:{ all -> 0x01df }
            org.apache.cordova.CordovaInterface r11 = r1.cordova     // Catch:{ all -> 0x01df }
            java.io.InputStream r10 = org.apache.cordova.camera.FileHelper.getInputStreamFromUriString(r10, r11)     // Catch:{ all -> 0x01df }
            android.graphics.BitmapFactory.decodeStream(r10, r5, r2)     // Catch:{ all -> 0x01dc }
            if (r10 == 0) goto L_0x0129
            r10.close()     // Catch:{ IOException -> 0x0126 }
            goto L_0x0129
        L_0x0126:
            org.apache.cordova.LOG.d(r4, r3)     // Catch:{ all -> 0x01ea }
        L_0x0129:
            int r11 = r2.outWidth     // Catch:{ all -> 0x01ea }
            if (r11 == 0) goto L_0x01d6
            int r11 = r2.outHeight     // Catch:{ all -> 0x01ea }
            if (r11 != 0) goto L_0x0133
            goto L_0x01d6
        L_0x0133:
            int r11 = r1.targetWidth     // Catch:{ all -> 0x01ea }
            if (r11 > 0) goto L_0x0143
            int r11 = r1.targetHeight     // Catch:{ all -> 0x01ea }
            if (r11 > 0) goto L_0x0143
            int r11 = r2.outWidth     // Catch:{ all -> 0x01ea }
            r1.targetWidth = r11     // Catch:{ all -> 0x01ea }
            int r11 = r2.outHeight     // Catch:{ all -> 0x01ea }
            r1.targetHeight = r11     // Catch:{ all -> 0x01ea }
        L_0x0143:
            r11 = 90
            if (r0 == r11) goto L_0x0152
            r11 = 270(0x10e, float:3.78E-43)
            if (r0 != r11) goto L_0x014c
            goto L_0x0152
        L_0x014c:
            int r11 = r2.outWidth     // Catch:{ all -> 0x01ea }
            int r12 = r2.outHeight     // Catch:{ all -> 0x01ea }
            r13 = r6
            goto L_0x0157
        L_0x0152:
            int r11 = r2.outHeight     // Catch:{ all -> 0x01ea }
            int r12 = r2.outWidth     // Catch:{ all -> 0x01ea }
            r13 = r9
        L_0x0157:
            int[] r14 = r1.calculateAspectRatio(r11, r12)     // Catch:{ all -> 0x01ea }
            r2.inJustDecodeBounds = r6     // Catch:{ all -> 0x01ea }
            r6 = r14[r6]     // Catch:{ all -> 0x01ea }
            r15 = r14[r9]     // Catch:{ all -> 0x01ea }
            int r6 = calculateSampleSize(r11, r12, r6, r15)     // Catch:{ all -> 0x01ea }
            r2.inSampleSize = r6     // Catch:{ all -> 0x01ea }
            java.lang.String r6 = r7.toString()     // Catch:{ all -> 0x01cb }
            org.apache.cordova.CordovaInterface r7 = r1.cordova     // Catch:{ all -> 0x01cb }
            java.io.InputStream r10 = org.apache.cordova.camera.FileHelper.getInputStreamFromUriString(r6, r7)     // Catch:{ all -> 0x01cb }
            android.graphics.Bitmap r2 = android.graphics.BitmapFactory.decodeStream(r10, r5, r2)     // Catch:{ all -> 0x01cb }
            if (r10 == 0) goto L_0x017e
            r10.close()     // Catch:{ IOException -> 0x017b }
            goto L_0x017e
        L_0x017b:
            org.apache.cordova.LOG.d(r4, r3)     // Catch:{ all -> 0x01ea }
        L_0x017e:
            if (r2 != 0) goto L_0x0186
            if (r8 == 0) goto L_0x0185
            r8.delete()
        L_0x0185:
            return r5
        L_0x0186:
            if (r13 != 0) goto L_0x018c
            r3 = 0
            r3 = r14[r3]     // Catch:{ all -> 0x01ea }
            goto L_0x018e
        L_0x018c:
            r3 = r14[r9]     // Catch:{ all -> 0x01ea }
        L_0x018e:
            if (r13 != 0) goto L_0x0193
            r4 = r14[r9]     // Catch:{ all -> 0x01ea }
            goto L_0x0196
        L_0x0193:
            r4 = 0
            r4 = r14[r4]     // Catch:{ all -> 0x01ea }
        L_0x0196:
            android.graphics.Bitmap r3 = android.graphics.Bitmap.createScaledBitmap(r2, r3, r4, r9)     // Catch:{ all -> 0x01ea }
            if (r3 == r2) goto L_0x019f
            r2.recycle()     // Catch:{ all -> 0x01ea }
        L_0x019f:
            boolean r2 = r1.correctOrientation     // Catch:{ all -> 0x01ea }
            if (r2 == 0) goto L_0x01c5
            if (r0 == 0) goto L_0x01c5
            android.graphics.Matrix r15 = new android.graphics.Matrix     // Catch:{ all -> 0x01ea }
            r15.<init>()     // Catch:{ all -> 0x01ea }
            float r0 = (float) r0     // Catch:{ all -> 0x01ea }
            r15.setRotate(r0)     // Catch:{ all -> 0x01ea }
            r11 = 0
            r12 = 0
            int r13 = r3.getWidth()     // Catch:{ OutOfMemoryError -> 0x01c2 }
            int r14 = r3.getHeight()     // Catch:{ OutOfMemoryError -> 0x01c2 }
            r16 = 1
            r10 = r3
            android.graphics.Bitmap r3 = android.graphics.Bitmap.createBitmap(r10, r11, r12, r13, r14, r15, r16)     // Catch:{ OutOfMemoryError -> 0x01c2 }
            r1.orientationCorrected = r9     // Catch:{ OutOfMemoryError -> 0x01c2 }
            goto L_0x01c5
        L_0x01c2:
            r0 = 0
            r1.orientationCorrected = r0     // Catch:{ all -> 0x01ea }
        L_0x01c5:
            if (r8 == 0) goto L_0x01ca
            r8.delete()
        L_0x01ca:
            return r3
        L_0x01cb:
            r0 = move-exception
            if (r10 == 0) goto L_0x01d5
            r10.close()     // Catch:{ IOException -> 0x01d2 }
            goto L_0x01d5
        L_0x01d2:
            org.apache.cordova.LOG.d(r4, r3)     // Catch:{ all -> 0x01ea }
        L_0x01d5:
            throw r0     // Catch:{ all -> 0x01ea }
        L_0x01d6:
            if (r8 == 0) goto L_0x01db
            r8.delete()
        L_0x01db:
            return r5
        L_0x01dc:
            r0 = move-exception
            r5 = r10
            goto L_0x01e0
        L_0x01df:
            r0 = move-exception
        L_0x01e0:
            if (r5 == 0) goto L_0x01e9
            r5.close()     // Catch:{ IOException -> 0x01e6 }
            goto L_0x01e9
        L_0x01e6:
            org.apache.cordova.LOG.d(r4, r3)     // Catch:{ all -> 0x01ea }
        L_0x01e9:
            throw r0     // Catch:{ all -> 0x01ea }
        L_0x01ea:
            r0 = move-exception
            if (r8 == 0) goto L_0x01f0
            r8.delete()
        L_0x01f0:
            throw r0
        L_0x01f1:
            r0 = move-exception
            java.lang.String r2 = "Exception while getting input stream: "
            java.lang.StringBuilder r2 = e.e.b.a.a.V0(r2)
            java.lang.String r0 = r0.toString()
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            org.apache.cordova.LOG.e(r4, r0)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.cordova.camera.CameraLauncher.getScaledAndRotatedBitmap(java.lang.String):android.graphics.Bitmap");
    }

    public String getTempDirectoryPath() {
        File file;
        if (Environment.getExternalStorageState().equals("mounted")) {
            file = this.cordova.getActivity().getExternalCacheDir();
        } else {
            file = this.cordova.getActivity().getCacheDir();
        }
        file.mkdirs();
        return file.getAbsolutePath();
    }

    public Uri getUriFromMediaStore() {
        ContentValues contentValues = new ContentValues();
        contentValues.put("mime_type", JPEG_MIME_TYPE);
        try {
            return this.cordova.getActivity().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        } catch (RuntimeException unused) {
            LOG.d(LOG_TAG, "Can't write to external media storage.");
            try {
                return this.cordova.getActivity().getContentResolver().insert(MediaStore.Images.Media.INTERNAL_CONTENT_URI, contentValues);
            } catch (RuntimeException unused2) {
                LOG.d(LOG_TAG, "Can't write to internal media storage.");
                return null;
            }
        }
    }

    public void onActivityResult(int i, int i2, final Intent intent) {
        int i3 = (i / 16) - 1;
        final int i4 = (i % 16) - 1;
        if (i >= 100) {
            if (i2 == -1) {
                try {
                    processResultFromCamera(i - 100, intent);
                } catch (IOException unused) {
                    LOG.e(LOG_TAG, "Unable to write to file");
                }
            } else if (i2 == 0) {
                failPicture("No Image Selected");
            } else {
                failPicture("Did not complete!");
            }
        } else if (i3 == 1) {
            if (i2 == -1) {
                try {
                    if (this.allowEdit) {
                        Activity activity = this.cordova.getActivity();
                        performCrop(b.getUriForFile(activity, this.applicationId + ".provider", createCaptureFile(this.encodingType)), i4, intent);
                        return;
                    }
                    processResultFromCamera(i4, intent);
                } catch (IOException unused2) {
                    failPicture("Error capturing image.");
                }
            } else if (i2 == 0) {
                failPicture("No Image Selected");
            } else {
                failPicture("Did not complete!");
            }
        } else if (i3 != 0 && i3 != 2) {
        } else {
            if (i2 == -1 && intent != null) {
                this.cordova.getThreadPool().execute(new Runnable() {
                    public void run() {
                        CameraLauncher.this.processResultFromGallery(i4, intent);
                    }
                });
            } else if (i2 == 0) {
                failPicture("No Image Selected");
            } else {
                failPicture("Selection did not complete!");
            }
        }
    }

    public void onMediaScannerConnected() {
        try {
            this.conn.scanFile(this.scanMe.toString(), "image/*");
        } catch (IllegalStateException unused) {
            LOG.e(LOG_TAG, "Can't scan file in MediaScanner after taking picture");
        }
    }

    public void onRequestPermissionResult(int i, String[] strArr, int[] iArr) throws JSONException {
        for (int i2 : iArr) {
            if (i2 == -1) {
                this.callbackContext.sendPluginResult(new PluginResult(PluginResult.Status.ERROR, 20));
                return;
            }
        }
        if (i == 0) {
            takePicture(this.destType, this.encodingType);
        } else if (i == 1) {
            getImage(this.srcType, this.destType, this.encodingType);
        }
    }

    public void onRestoreStateForActivityResult(Bundle bundle, CallbackContext callbackContext2) {
        this.destType = bundle.getInt("destType");
        this.srcType = bundle.getInt("srcType");
        this.mQuality = bundle.getInt("mQuality");
        this.targetWidth = bundle.getInt("targetWidth");
        this.targetHeight = bundle.getInt("targetHeight");
        this.encodingType = bundle.getInt("encodingType");
        this.mediaType = bundle.getInt("mediaType");
        this.numPics = bundle.getInt("numPics");
        this.allowEdit = bundle.getBoolean("allowEdit");
        this.correctOrientation = bundle.getBoolean("correctOrientation");
        this.saveToPhotoAlbum = bundle.getBoolean("saveToPhotoAlbum");
        if (bundle.containsKey(CROPPED_URI_KEY)) {
            this.croppedUri = Uri.parse(bundle.getString(CROPPED_URI_KEY));
        }
        if (bundle.containsKey(IMAGE_URI_KEY)) {
            this.imageUri = Uri.parse(bundle.getString(IMAGE_URI_KEY));
        }
        this.callbackContext = callbackContext2;
    }

    public Bundle onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putInt("destType", this.destType);
        bundle.putInt("srcType", this.srcType);
        bundle.putInt("mQuality", this.mQuality);
        bundle.putInt("targetWidth", this.targetWidth);
        bundle.putInt("targetHeight", this.targetHeight);
        bundle.putInt("encodingType", this.encodingType);
        bundle.putInt("mediaType", this.mediaType);
        bundle.putInt("numPics", this.numPics);
        bundle.putBoolean("allowEdit", this.allowEdit);
        bundle.putBoolean("correctOrientation", this.correctOrientation);
        bundle.putBoolean("saveToPhotoAlbum", this.saveToPhotoAlbum);
        if (this.croppedUri != null) {
            bundle.putString(CROPPED_URI_KEY, this.croppedFilePath);
        }
        if (this.imageUri != null) {
            bundle.putString(IMAGE_URI_KEY, this.imageFilePath);
        }
        return bundle;
    }

    public void onScanCompleted(String str, Uri uri) {
        this.conn.disconnect();
    }

    public String outputModifiedBitmap(Bitmap bitmap, Uri uri) throws IOException {
        String str;
        Bitmap.CompressFormat compressFormat;
        String realPath = FileHelper.getRealPath(uri, this.cordova);
        if (realPath != null) {
            str = realPath.substring(realPath.lastIndexOf(47) + 1);
        } else {
            StringBuilder V0 = a.V0("modified.");
            V0.append(this.encodingType == 0 ? JPEG_TYPE : PNG_TYPE);
            str = V0.toString();
        }
        new SimpleDateFormat(TIME_FORMAT).format(new Date());
        String str2 = getTempDirectoryPath() + "/" + str;
        FileOutputStream fileOutputStream = new FileOutputStream(str2);
        if (this.encodingType == 0) {
            compressFormat = Bitmap.CompressFormat.JPEG;
        } else {
            compressFormat = Bitmap.CompressFormat.PNG;
        }
        bitmap.compress(compressFormat, this.mQuality, fileOutputStream);
        fileOutputStream.close();
        ExifHelper exifHelper = this.exifData;
        if (exifHelper != null && this.encodingType == 0) {
            try {
                if (this.correctOrientation && this.orientationCorrected) {
                    exifHelper.resetOrientation();
                }
                this.exifData.createOutFile(str2);
                this.exifData.writeExifData();
                this.exifData = null;
            } catch (IOException unused) {
            }
        }
        return str2;
    }

    public void performCrop(Uri uri, int i, Intent intent) {
        try {
            Intent intent2 = new Intent("com.android.camera.action.CROP");
            intent2.setDataAndType(uri, "image/*");
            intent2.putExtra("crop", "true");
            if (this.targetWidth > 0) {
                intent2.putExtra("outputX", this.targetWidth);
            }
            if (this.targetHeight > 0) {
                intent2.putExtra("outputY", this.targetHeight);
            }
            if (this.targetHeight > 0 && this.targetWidth > 0 && this.targetWidth == this.targetHeight) {
                intent2.putExtra("aspectX", 1);
                intent2.putExtra("aspectY", 1);
            }
            int i2 = this.encodingType;
            String absolutePath = createCaptureFile(i2, System.currentTimeMillis() + "").getAbsolutePath();
            this.croppedFilePath = absolutePath;
            this.croppedUri = Uri.parse(absolutePath);
            intent2.addFlags(1);
            intent2.addFlags(2);
            intent2.putExtra("output", this.croppedUri);
            if (this.cordova != null) {
                this.cordova.startActivityForResult(this, intent2, i + 100);
            }
        } catch (ActivityNotFoundException unused) {
            LOG.e(LOG_TAG, "Crop operation not supported on this device");
            try {
                processResultFromCamera(i, intent);
            } catch (IOException unused2) {
                LOG.e(LOG_TAG, "Unable to write to file");
            }
        }
    }

    public void processPicture(Bitmap bitmap, int i) {
        Bitmap.CompressFormat compressFormat;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        if (i == 0) {
            compressFormat = Bitmap.CompressFormat.JPEG;
        } else {
            compressFormat = Bitmap.CompressFormat.PNG;
        }
        try {
            if (bitmap.compress(compressFormat, this.mQuality, byteArrayOutputStream)) {
                this.callbackContext.success(new String(Base64.encode(byteArrayOutputStream.toByteArray(), 2)));
            }
        } catch (Exception unused) {
            failPicture("Error compressing image.");
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v22, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v5, resolved type: android.graphics.Bitmap} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0028  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x004a  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0054  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0086  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void processResultFromCamera(int r13, android.content.Intent r14) throws java.io.IOException {
        /*
            r12 = this;
            org.apache.cordova.camera.ExifHelper r0 = new org.apache.cordova.camera.ExifHelper
            r0.<init>()
            boolean r1 = r12.allowEdit
            if (r1 == 0) goto L_0x0010
            android.net.Uri r1 = r12.croppedUri
            if (r1 == 0) goto L_0x0010
            java.lang.String r1 = r12.croppedFilePath
            goto L_0x0012
        L_0x0010:
            java.lang.String r1 = r12.imageFilePath
        L_0x0012:
            int r2 = r12.encodingType
            r3 = 0
            if (r2 != 0) goto L_0x0022
            r0.createInFile(r1)     // Catch:{ IOException -> 0x0022 }
            r0.readExifData()     // Catch:{ IOException -> 0x0022 }
            int r2 = r0.getOrientation()     // Catch:{ IOException -> 0x0022 }
            goto L_0x0023
        L_0x0022:
            r2 = r3
        L_0x0023:
            boolean r4 = r12.saveToPhotoAlbum
            r5 = 0
            if (r4 == 0) goto L_0x004a
            java.io.File r4 = new java.io.File
            java.lang.String r6 = r12.getPicturesPath()
            r4.<init>(r6)
            android.net.Uri r4 = android.net.Uri.fromFile(r4)
            boolean r6 = r12.allowEdit
            if (r6 == 0) goto L_0x0041
            android.net.Uri r6 = r12.croppedUri
            if (r6 == 0) goto L_0x0041
            r12.writeUncompressedImage((android.net.Uri) r6, (android.net.Uri) r4)
            goto L_0x0046
        L_0x0041:
            android.net.Uri r6 = r12.imageUri
            r12.writeUncompressedImage((android.net.Uri) r6, (android.net.Uri) r4)
        L_0x0046:
            r12.refreshGallery(r4)
            goto L_0x004b
        L_0x004a:
            r4 = r5
        L_0x004b:
            java.lang.String r6 = "Unable to create bitmap!"
            java.lang.String r7 = "I either have a null image path or bitmap"
            java.lang.String r8 = "CameraLauncher"
            r9 = 1
            if (r13 != 0) goto L_0x0086
            android.graphics.Bitmap r13 = r12.getScaledAndRotatedBitmap(r1)
            if (r13 != 0) goto L_0x006e
            android.os.Bundle r13 = r14.getExtras()
            if (r13 == 0) goto L_0x006f
            android.os.Bundle r13 = r14.getExtras()
            java.lang.String r14 = "data"
            java.lang.Object r13 = r13.get(r14)
            r5 = r13
            android.graphics.Bitmap r5 = (android.graphics.Bitmap) r5
            goto L_0x006f
        L_0x006e:
            r5 = r13
        L_0x006f:
            if (r5 != 0) goto L_0x0078
            org.apache.cordova.LOG.d(r8, r7)
            r12.failPicture(r6)
            return
        L_0x0078:
            int r13 = r12.encodingType
            r12.processPicture(r5, r13)
            boolean r13 = r12.saveToPhotoAlbum
            if (r13 != 0) goto L_0x0159
            r12.checkForDuplicateImage(r3)
            goto L_0x0159
        L_0x0086:
            if (r13 == r9) goto L_0x0092
            r14 = 2
            if (r13 != r14) goto L_0x008c
            goto L_0x0092
        L_0x008c:
            java.lang.IllegalStateException r13 = new java.lang.IllegalStateException
            r13.<init>()
            throw r13
        L_0x0092:
            int r13 = r12.targetHeight
            java.lang.String r14 = ""
            r3 = -1
            if (r13 != r3) goto L_0x00f4
            int r13 = r12.targetWidth
            if (r13 != r3) goto L_0x00f4
            int r13 = r12.mQuality
            r3 = 100
            if (r13 != r3) goto L_0x00f4
            boolean r13 = r12.correctOrientation
            if (r13 != 0) goto L_0x00f4
            boolean r13 = r12.saveToPhotoAlbum
            if (r13 == 0) goto L_0x00b6
            org.apache.cordova.CallbackContext r13 = r12.callbackContext
            java.lang.String r14 = r4.toString()
            r13.success((java.lang.String) r14)
            goto L_0x0159
        L_0x00b6:
            int r13 = r12.encodingType
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            long r1 = java.lang.System.currentTimeMillis()
            r0.append(r1)
            r0.append(r14)
            java.lang.String r14 = r0.toString()
            java.io.File r13 = r12.createCaptureFile(r13, r14)
            android.net.Uri r13 = android.net.Uri.fromFile(r13)
            boolean r14 = r12.allowEdit
            if (r14 == 0) goto L_0x00e5
            android.net.Uri r14 = r12.croppedUri
            if (r14 == 0) goto L_0x00e5
            java.lang.String r14 = r12.croppedFilePath
            android.net.Uri r14 = android.net.Uri.parse(r14)
            r12.writeUncompressedImage((android.net.Uri) r14, (android.net.Uri) r13)
            goto L_0x00ea
        L_0x00e5:
            android.net.Uri r14 = r12.imageUri
            r12.writeUncompressedImage((android.net.Uri) r14, (android.net.Uri) r13)
        L_0x00ea:
            org.apache.cordova.CallbackContext r14 = r12.callbackContext
            java.lang.String r13 = r13.toString()
            r14.success((java.lang.String) r13)
            goto L_0x0159
        L_0x00f4:
            int r13 = r12.encodingType
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            long r10 = java.lang.System.currentTimeMillis()
            r3.append(r10)
            r3.append(r14)
            java.lang.String r14 = r3.toString()
            java.io.File r13 = r12.createCaptureFile(r13, r14)
            android.net.Uri r13 = android.net.Uri.fromFile(r13)
            android.graphics.Bitmap r5 = r12.getScaledAndRotatedBitmap(r1)
            if (r5 != 0) goto L_0x011e
            org.apache.cordova.LOG.d(r8, r7)
            r12.failPicture(r6)
            return
        L_0x011e:
            org.apache.cordova.CordovaInterface r14 = r12.cordova
            android.app.Activity r14 = r14.getActivity()
            android.content.ContentResolver r14 = r14.getContentResolver()
            java.io.OutputStream r14 = r14.openOutputStream(r13)
            int r1 = r12.encodingType
            if (r1 != 0) goto L_0x0133
            android.graphics.Bitmap$CompressFormat r1 = android.graphics.Bitmap.CompressFormat.JPEG
            goto L_0x0135
        L_0x0133:
            android.graphics.Bitmap$CompressFormat r1 = android.graphics.Bitmap.CompressFormat.PNG
        L_0x0135:
            int r3 = r12.mQuality
            r5.compress(r1, r3, r14)
            r14.close()
            int r14 = r12.encodingType
            if (r14 != 0) goto L_0x0150
            java.lang.String r14 = r13.getPath()
            if (r2 == r9) goto L_0x014a
            r0.resetOrientation()
        L_0x014a:
            r0.createOutFile(r14)
            r0.writeExifData()
        L_0x0150:
            org.apache.cordova.CallbackContext r14 = r12.callbackContext
            java.lang.String r13 = r13.toString()
            r14.success((java.lang.String) r13)
        L_0x0159:
            android.net.Uri r13 = r12.imageUri
            r12.cleanup(r9, r13, r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.cordova.camera.CameraLauncher.processResultFromCamera(int, android.content.Intent):void");
    }

    public void processResultFromGallery(int i, Intent intent) {
        Uri data = intent.getData();
        if (data == null && (data = this.croppedUri) == null) {
            failPicture("null data from photo library");
            return;
        }
        String realPath = FileHelper.getRealPath(data, this.cordova);
        LOG.d(LOG_TAG, "File location is: " + realPath);
        String uri = data.toString();
        String mimeType = FileHelper.getMimeType(uri, this.cordova);
        if (this.mediaType == 1 || (!JPEG_MIME_TYPE.equalsIgnoreCase(mimeType) && !PNG_MIME_TYPE.equalsIgnoreCase(mimeType))) {
            this.callbackContext.success(realPath);
        } else if (this.targetHeight == -1 && this.targetWidth == -1 && ((i == 1 || i == 2) && !this.correctOrientation && mimeType != null && mimeType.equalsIgnoreCase(getMimetypeForFormat(this.encodingType)))) {
            this.callbackContext.success(uri);
        } else {
            Bitmap bitmap = null;
            try {
                bitmap = getScaledAndRotatedBitmap(uri);
            } catch (IOException unused) {
            }
            if (bitmap == null) {
                LOG.d(LOG_TAG, "I either have a null image path or bitmap");
                failPicture("Unable to create bitmap!");
                return;
            }
            if (i == 0) {
                processPicture(bitmap, this.encodingType);
            } else if (i == 1 || i == 2) {
                if ((this.targetHeight <= 0 || this.targetWidth <= 0) && ((!this.correctOrientation || !this.orientationCorrected) && mimeType.equalsIgnoreCase(getMimetypeForFormat(this.encodingType)))) {
                    this.callbackContext.success(realPath);
                } else {
                    try {
                        String outputModifiedBitmap = outputModifiedBitmap(bitmap, data);
                        CallbackContext callbackContext2 = this.callbackContext;
                        callbackContext2.success("file://" + outputModifiedBitmap + "?" + System.currentTimeMillis());
                    } catch (Exception unused2) {
                        failPicture("Error retrieving image.");
                    }
                }
            }
            bitmap.recycle();
            System.gc();
        }
    }

    public Cursor queryImgDB(Uri uri) {
        return this.cordova.getActivity().getContentResolver().query(uri, new String[]{"_id"}, (String) null, (String[]) null, (String) null);
    }

    public void refreshGallery(Uri uri) {
        Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        intent.setData(uri);
        this.cordova.getActivity().sendBroadcast(intent);
    }

    public void scanForGallery(Uri uri) {
        this.scanMe = uri;
        MediaScannerConnection mediaScannerConnection = this.conn;
        if (mediaScannerConnection != null) {
            mediaScannerConnection.disconnect();
        }
        MediaScannerConnection mediaScannerConnection2 = new MediaScannerConnection(this.cordova.getActivity().getApplicationContext(), this);
        this.conn = mediaScannerConnection2;
        mediaScannerConnection2.connect();
    }

    public void takePicture(int i, int i2) {
        this.numPics = queryImgDB(whichContentStore()).getCount();
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        File createCaptureFile = createCaptureFile(i2);
        this.imageFilePath = createCaptureFile.getAbsolutePath();
        Activity activity = this.cordova.getActivity();
        Uri uriForFile = b.getUriForFile(activity, this.applicationId + ".provider", createCaptureFile);
        this.imageUri = uriForFile;
        intent.putExtra("output", uriForFile);
        intent.addFlags(2);
        CordovaInterface cordovaInterface = this.cordova;
        if (cordovaInterface == null) {
            return;
        }
        if (intent.resolveActivity(cordovaInterface.getActivity().getPackageManager()) != null) {
            this.cordova.startActivityForResult(this, intent, i + 32 + 1);
        } else {
            LOG.d(LOG_TAG, "Error: You don't have a default camera.  Your device may not be CTS complaint.");
        }
    }

    public Uri whichContentStore() {
        if (Environment.getExternalStorageState().equals("mounted")) {
            return MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        }
        return MediaStore.Images.Media.INTERNAL_CONTENT_URI;
    }

    public void writeUncompressedImage(InputStream inputStream, Uri uri) throws FileNotFoundException, IOException {
        OutputStream outputStream = null;
        try {
            OutputStream openOutputStream = this.cordova.getActivity().getContentResolver().openOutputStream(uri);
            byte[] bArr = new byte[Hpack.SETTINGS_HEADER_TABLE_SIZE];
            while (true) {
                int read = inputStream.read(bArr);
                if (read == -1) {
                    break;
                }
                openOutputStream.write(bArr, 0, read);
            }
            openOutputStream.flush();
            try {
                openOutputStream.close();
            } catch (IOException unused) {
                LOG.d(LOG_TAG, "Exception while closing output stream.");
            }
            try {
                inputStream.close();
            } catch (IOException unused2) {
                LOG.d(LOG_TAG, "Exception while closing file input stream.");
            }
        } catch (Throwable th2) {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException unused3) {
                    LOG.d(LOG_TAG, "Exception while closing output stream.");
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException unused4) {
                    LOG.d(LOG_TAG, "Exception while closing file input stream.");
                }
            }
            throw th2;
        }
    }

    public File createCaptureFile(int i, String str) {
        String str2;
        if (str.isEmpty()) {
            str = ".Pic";
        }
        if (i == 0) {
            str2 = a.C(str, JPEG_EXTENSION);
        } else if (i == 1) {
            str2 = a.C(str, PNG_EXTENSION);
        } else {
            throw new IllegalArgumentException(a.m("Invalid Encoding Type: ", i));
        }
        return new File(getTempDirectoryPath(), str2);
    }

    public void writeUncompressedImage(Uri uri, Uri uri2) throws FileNotFoundException, IOException {
        writeUncompressedImage((InputStream) new FileInputStream(FileHelper.stripFileProtocol(uri.toString())), uri2);
    }
}

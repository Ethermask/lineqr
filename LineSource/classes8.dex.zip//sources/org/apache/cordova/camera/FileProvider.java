package org.apache.cordova.camera;

import hh.j.f.b;

public class FileProvider extends b {
}

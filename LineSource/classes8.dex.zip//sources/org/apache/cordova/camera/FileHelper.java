package org.apache.cordova.camera;

import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import org.apache.cordova.CordovaInterface;

public class FileHelper {
    public static final String LOG_TAG = "FileUtils";
    public static final String _DATA = "_data";

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0033  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x003a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String getDataColumn(android.content.Context r8, android.net.Uri r9, java.lang.String r10, java.lang.String[] r11) {
        /*
            java.lang.String r0 = "_data"
            java.lang.String[] r3 = new java.lang.String[]{r0}
            r7 = 0
            android.content.ContentResolver r1 = r8.getContentResolver()     // Catch:{ Exception -> 0x0037, all -> 0x0030 }
            r6 = 0
            r2 = r9
            r4 = r10
            r5 = r11
            android.database.Cursor r8 = r1.query(r2, r3, r4, r5, r6)     // Catch:{ Exception -> 0x0037, all -> 0x0030 }
            if (r8 == 0) goto L_0x002a
            boolean r9 = r8.moveToFirst()     // Catch:{ Exception -> 0x0038, all -> 0x0027 }
            if (r9 == 0) goto L_0x002a
            int r9 = r8.getColumnIndexOrThrow(r0)     // Catch:{ Exception -> 0x0038, all -> 0x0027 }
            java.lang.String r9 = r8.getString(r9)     // Catch:{ Exception -> 0x0038, all -> 0x0027 }
            r8.close()
            return r9
        L_0x0027:
            r9 = move-exception
            r7 = r8
            goto L_0x0031
        L_0x002a:
            if (r8 == 0) goto L_0x002f
            r8.close()
        L_0x002f:
            return r7
        L_0x0030:
            r9 = move-exception
        L_0x0031:
            if (r7 == 0) goto L_0x0036
            r7.close()
        L_0x0036:
            throw r9
        L_0x0037:
            r8 = r7
        L_0x0038:
            if (r8 == 0) goto L_0x003d
            r8.close()
        L_0x003d:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.cordova.camera.FileHelper.getDataColumn(android.content.Context, android.net.Uri, java.lang.String, java.lang.String[]):java.lang.String");
    }

    public static InputStream getInputStreamFromUriString(String str, CordovaInterface cordovaInterface) throws IOException {
        InputStream inputStream;
        if (str.startsWith("content")) {
            return cordovaInterface.getActivity().getContentResolver().openInputStream(Uri.parse(str));
        } else if (!str.startsWith("file://")) {
            return new FileInputStream(str);
        } else {
            int indexOf = str.indexOf("?");
            if (indexOf > -1) {
                str = str.substring(0, indexOf);
            }
            if (str.startsWith("file:///android_asset/")) {
                return cordovaInterface.getActivity().getAssets().open(Uri.parse(str).getPath().substring(15));
            }
            try {
                inputStream = cordovaInterface.getActivity().getContentResolver().openInputStream(Uri.parse(str));
            } catch (Exception unused) {
                inputStream = null;
            }
            if (inputStream == null) {
                inputStream = new FileInputStream(getRealPath(str, cordovaInterface));
            }
            return inputStream;
        }
    }

    public static String getMimeType(String str, CordovaInterface cordovaInterface) {
        Uri parse = Uri.parse(str);
        if (str.startsWith("content://")) {
            return cordovaInterface.getActivity().getContentResolver().getType(parse);
        }
        return getMimeTypeForExtension(parse.getPath());
    }

    public static String getMimeTypeForExtension(String str) {
        int lastIndexOf = str.lastIndexOf(46);
        if (lastIndexOf != -1) {
            str = str.substring(lastIndexOf + 1);
        }
        String lowerCase = str.toLowerCase(Locale.getDefault());
        if (lowerCase.equals("3ga")) {
            return "audio/3gpp";
        }
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(lowerCase);
    }

    public static String getRealPath(Uri uri, CordovaInterface cordovaInterface) {
        return getRealPathFromURI(cordovaInterface.getActivity(), uri);
    }

    @SuppressLint({"NewApi"})
    public static String getRealPathFromURI(Context context, Uri uri) {
        Uri uri2 = null;
        if (DocumentsContract.isDocumentUri(context, uri)) {
            if (isExternalStorageDocument(uri)) {
                String[] split = DocumentsContract.getDocumentId(uri).split(":");
                if ("primary".equalsIgnoreCase(split[0])) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
            } else if (isDownloadsDocument(uri)) {
                String documentId = DocumentsContract.getDocumentId(uri);
                if (documentId != null && documentId.length() > 0) {
                    if (documentId.startsWith("raw:")) {
                        return documentId.replaceFirst("raw:", "");
                    }
                    try {
                        return getDataColumn(context, ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(documentId).longValue()), (String) null, (String[]) null);
                    } catch (NumberFormatException unused) {
                    }
                }
                return null;
            } else if (isMediaDocument(uri)) {
                String[] split2 = DocumentsContract.getDocumentId(uri).split(":");
                String str = split2[0];
                if ("image".equals(str)) {
                    uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(str)) {
                    uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(str)) {
                    uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                return getDataColumn(context, uri2, "_id=?", new String[]{split2[1]});
            }
        } else if ("content".equalsIgnoreCase(uri.getScheme())) {
            if (isGooglePhotosUri(uri)) {
                return uri.getLastPathSegment();
            }
            return getDataColumn(context, uri, (String) null, (String[]) null);
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static String stripFileProtocol(String str) {
        return str.startsWith("file://") ? str.substring(7) : str;
    }

    public static String getRealPath(String str, CordovaInterface cordovaInterface) {
        return getRealPath(Uri.parse(str), cordovaInterface);
    }
}

package org.apache.cordova.dialogs;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.widget.EditText;
import android.widget.TextView;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.LOG;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Notification extends CordovaPlugin {
    public static final String LOG_TAG = "Notification";
    public int confirmResult = -1;
    public ProgressDialog progressDialog = null;
    public ProgressDialog spinnerDialog = null;

    /* access modifiers changed from: private */
    @SuppressLint({"NewApi"})
    public void changeTextDirection(AlertDialog.Builder builder) {
        builder.create();
        ((TextView) builder.show().findViewById(16908299)).setTextDirection(5);
    }

    /* access modifiers changed from: private */
    @SuppressLint({"NewApi"})
    public AlertDialog.Builder createDialog(CordovaInterface cordovaInterface) {
        return new AlertDialog.Builder(cordovaInterface.getActivity(), 5);
    }

    /* access modifiers changed from: private */
    @SuppressLint({"InlinedApi"})
    public ProgressDialog createProgressDialog(CordovaInterface cordovaInterface) {
        return new ProgressDialog(cordovaInterface.getActivity(), 5);
    }

    public synchronized void activityStart(String str, String str2) {
        if (this.spinnerDialog != null) {
            this.spinnerDialog.dismiss();
            this.spinnerDialog = null;
        }
        final CordovaInterface cordovaInterface = this.cordova;
        final String str3 = str;
        final String str4 = str2;
        this.cordova.getActivity().runOnUiThread(new Runnable() {
            public void run() {
                this.spinnerDialog = Notification.this.createProgressDialog(cordovaInterface);
                this.spinnerDialog.setTitle(str3);
                this.spinnerDialog.setMessage(str4);
                this.spinnerDialog.setCancelable(true);
                this.spinnerDialog.setIndeterminate(true);
                this.spinnerDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    public void onCancel(DialogInterface dialogInterface) {
                        this.spinnerDialog = null;
                    }
                });
                this.spinnerDialog.show();
            }
        });
    }

    public synchronized void activityStop() {
        if (this.spinnerDialog != null) {
            this.spinnerDialog.dismiss();
            this.spinnerDialog = null;
        }
    }

    public synchronized void alert(String str, String str2, String str3, CallbackContext callbackContext) {
        final CordovaInterface cordovaInterface = this.cordova;
        final String str4 = str;
        final String str5 = str2;
        final String str6 = str3;
        final CallbackContext callbackContext2 = callbackContext;
        this.cordova.getActivity().runOnUiThread(new Runnable() {
            public void run() {
                AlertDialog.Builder access$000 = Notification.this.createDialog(cordovaInterface);
                access$000.setMessage(str4);
                access$000.setTitle(str5);
                access$000.setCancelable(true);
                access$000.setPositiveButton(str6, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, 0));
                    }
                });
                access$000.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    public void onCancel(DialogInterface dialogInterface) {
                        dialogInterface.dismiss();
                        callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, 0));
                    }
                });
                Notification.this.changeTextDirection(access$000);
            }
        });
    }

    public void beep(final long j) {
        this.cordova.getThreadPool().execute(new Runnable() {
            public void run() {
                Ringtone ringtone = RingtoneManager.getRingtone(Notification.this.cordova.getActivity().getBaseContext(), RingtoneManager.getDefaultUri(2));
                if (ringtone != null) {
                    for (long j = 0; j < j; j++) {
                        ringtone.play();
                        long j2 = 5000;
                        while (ringtone.isPlaying() && j2 > 0) {
                            j2 -= 100;
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException unused) {
                                Thread.currentThread().interrupt();
                            }
                        }
                    }
                }
            }
        });
    }

    public synchronized void confirm(String str, String str2, JSONArray jSONArray, CallbackContext callbackContext) {
        final CordovaInterface cordovaInterface = this.cordova;
        final String str3 = str;
        final String str4 = str2;
        final JSONArray jSONArray2 = jSONArray;
        final CallbackContext callbackContext2 = callbackContext;
        this.cordova.getActivity().runOnUiThread(new Runnable() {
            public void run() {
                AlertDialog.Builder access$000 = Notification.this.createDialog(cordovaInterface);
                access$000.setMessage(str3);
                access$000.setTitle(str4);
                access$000.setCancelable(true);
                if (jSONArray2.length() > 0) {
                    try {
                        access$000.setNegativeButton(jSONArray2.getString(0), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, 1));
                            }
                        });
                    } catch (JSONException unused) {
                        LOG.d(Notification.LOG_TAG, "JSONException on first button.");
                    }
                }
                if (jSONArray2.length() > 1) {
                    try {
                        access$000.setNeutralButton(jSONArray2.getString(1), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, 2));
                            }
                        });
                    } catch (JSONException unused2) {
                        LOG.d(Notification.LOG_TAG, "JSONException on second button.");
                    }
                }
                if (jSONArray2.length() > 2) {
                    try {
                        access$000.setPositiveButton(jSONArray2.getString(2), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, 3));
                            }
                        });
                    } catch (JSONException unused3) {
                        LOG.d(Notification.LOG_TAG, "JSONException on third button.");
                    }
                }
                access$000.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    public void onCancel(DialogInterface dialogInterface) {
                        dialogInterface.dismiss();
                        callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, 0));
                    }
                });
                Notification.this.changeTextDirection(access$000);
            }
        });
    }

    public boolean execute(String str, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        if (this.cordova.getActivity().isFinishing()) {
            return true;
        }
        if (str.equals("beep")) {
            beep(jSONArray.getLong(0));
        } else if (str.equals("alert")) {
            alert(jSONArray.getString(0), jSONArray.getString(1), jSONArray.getString(2), callbackContext);
            return true;
        } else if (str.equals("confirm")) {
            confirm(jSONArray.getString(0), jSONArray.getString(1), jSONArray.getJSONArray(2), callbackContext);
            return true;
        } else if (str.equals("prompt")) {
            prompt(jSONArray.getString(0), jSONArray.getString(1), jSONArray.getJSONArray(2), jSONArray.getString(3), callbackContext);
            return true;
        } else if (str.equals("activityStart")) {
            activityStart(jSONArray.getString(0), jSONArray.getString(1));
        } else if (str.equals("activityStop")) {
            activityStop();
        } else if (str.equals("progressStart")) {
            progressStart(jSONArray.getString(0), jSONArray.getString(1));
        } else if (str.equals("progressValue")) {
            progressValue(jSONArray.getInt(0));
        } else if (!str.equals("progressStop")) {
            return false;
        } else {
            progressStop();
        }
        callbackContext.success();
        return true;
    }

    public synchronized void progressStart(String str, String str2) {
        if (this.progressDialog != null) {
            this.progressDialog.dismiss();
            this.progressDialog = null;
        }
        final CordovaInterface cordovaInterface = this.cordova;
        final String str3 = str;
        final String str4 = str2;
        this.cordova.getActivity().runOnUiThread(new Runnable() {
            public void run() {
                this.progressDialog = Notification.this.createProgressDialog(cordovaInterface);
                this.progressDialog.setProgressStyle(1);
                this.progressDialog.setTitle(str3);
                this.progressDialog.setMessage(str4);
                this.progressDialog.setCancelable(true);
                this.progressDialog.setMax(100);
                this.progressDialog.setProgress(0);
                this.progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    public void onCancel(DialogInterface dialogInterface) {
                        this.progressDialog = null;
                    }
                });
                this.progressDialog.show();
            }
        });
    }

    public synchronized void progressStop() {
        if (this.progressDialog != null) {
            this.progressDialog.dismiss();
            this.progressDialog = null;
        }
    }

    public synchronized void progressValue(int i) {
        if (this.progressDialog != null) {
            this.progressDialog.setProgress(i);
        }
    }

    public synchronized void prompt(String str, String str2, JSONArray jSONArray, String str3, CallbackContext callbackContext) {
        final CordovaInterface cordovaInterface = this.cordova;
        final String str4 = str3;
        final String str5 = str;
        final String str6 = str2;
        final JSONArray jSONArray2 = jSONArray;
        final CallbackContext callbackContext2 = callbackContext;
        this.cordova.getActivity().runOnUiThread(new Runnable() {
            public void run() {
                final EditText editText = new EditText(cordovaInterface.getActivity());
                editText.setTextColor(cordovaInterface.getActivity().getResources().getColor(17170435));
                editText.setText(str4);
                AlertDialog.Builder access$000 = Notification.this.createDialog(cordovaInterface);
                access$000.setMessage(str5);
                access$000.setTitle(str6);
                access$000.setCancelable(true);
                access$000.setView(editText);
                final JSONObject jSONObject = new JSONObject();
                if (jSONArray2.length() > 0) {
                    try {
                        access$000.setNegativeButton(jSONArray2.getString(0), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                try {
                                    jSONObject.put("buttonIndex", 1);
                                    jSONObject.put("input1", editText.getText().toString().trim().length() == 0 ? str4 : editText.getText());
                                } catch (JSONException e2) {
                                    LOG.d(Notification.LOG_TAG, "JSONException on first button.", (Throwable) e2);
                                }
                                callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, jSONObject));
                            }
                        });
                    } catch (JSONException unused) {
                        LOG.d(Notification.LOG_TAG, "JSONException on first button.");
                    }
                }
                if (jSONArray2.length() > 1) {
                    try {
                        access$000.setNeutralButton(jSONArray2.getString(1), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                try {
                                    jSONObject.put("buttonIndex", 2);
                                    jSONObject.put("input1", editText.getText().toString().trim().length() == 0 ? str4 : editText.getText());
                                } catch (JSONException e2) {
                                    LOG.d(Notification.LOG_TAG, "JSONException on second button.", (Throwable) e2);
                                }
                                callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, jSONObject));
                            }
                        });
                    } catch (JSONException unused2) {
                        LOG.d(Notification.LOG_TAG, "JSONException on second button.");
                    }
                }
                if (jSONArray2.length() > 2) {
                    try {
                        access$000.setPositiveButton(jSONArray2.getString(2), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                try {
                                    jSONObject.put("buttonIndex", 3);
                                    jSONObject.put("input1", editText.getText().toString().trim().length() == 0 ? str4 : editText.getText());
                                } catch (JSONException e2) {
                                    LOG.d(Notification.LOG_TAG, "JSONException on third button.", (Throwable) e2);
                                }
                                callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, jSONObject));
                            }
                        });
                    } catch (JSONException unused3) {
                        LOG.d(Notification.LOG_TAG, "JSONException on third button.");
                    }
                }
                access$000.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    public void onCancel(DialogInterface dialogInterface) {
                        dialogInterface.dismiss();
                        try {
                            jSONObject.put("buttonIndex", 0);
                            jSONObject.put("input1", editText.getText().toString().trim().length() == 0 ? str4 : editText.getText());
                        } catch (JSONException unused) {
                        }
                        callbackContext2.sendPluginResult(new PluginResult(PluginResult.Status.OK, jSONObject));
                    }
                });
                Notification.this.changeTextDirection(access$000);
            }
        });
    }
}

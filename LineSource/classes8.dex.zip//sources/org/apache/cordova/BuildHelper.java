package org.apache.cordova;

import android.content.Context;

public class BuildHelper {
    public static String TAG = "BuildHelper";

    public static Object getBuildConfigValue(Context context, String str) {
        try {
            return Class.forName(context.getPackageName() + ".BuildConfig").getField(str).get((Object) null);
        } catch (ClassNotFoundException unused) {
            LOG.d(TAG, "Unable to get the BuildConfig, is this built with ANT?");
            return null;
        } catch (NoSuchFieldException unused2) {
            String str2 = TAG;
            LOG.d(str2, str + " is not a valid field. Check your build.gradle");
            return null;
        } catch (IllegalAccessException unused3) {
            LOG.d(TAG, "Illegal Access Exception: Let's print a stack trace.");
            return null;
        }
    }
}

package org.apache.thrift.protocol;

import e.e.b.a.a;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import net.sqlcipher.database.SQLiteDatabase;
import rh.a.b.l;
import rh.a.b.t.b;
import rh.a.b.t.c;
import rh.a.b.t.e;
import rh.a.b.t.f;
import rh.a.b.t.g;
import rh.a.b.t.j;
import rh.a.b.t.k;
import rh.a.b.v.d;

public class TBinaryProtocol extends f {
    public static final k n = new k();
    public final long b;
    public final long c;
    public boolean d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f112e;
    public byte[] f = new byte[1];
    public byte[] g = new byte[2];
    public byte[] h = new byte[4];
    public byte[] i = new byte[8];
    public byte[] j = new byte[1];
    public byte[] k = new byte[2];
    public byte[] l = new byte[4];
    public byte[] m = new byte[8];

    public TBinaryProtocol(d dVar, long j2, long j3, boolean z, boolean z2) {
        super(dVar);
        this.b = j2;
        this.c = j3;
        this.d = z;
        this.f112e = z2;
    }

    public void A(b bVar) throws l {
        y(bVar.b);
        D(bVar.c);
    }

    public void B() {
    }

    public void C() throws l {
        y((byte) 0);
    }

    public void D(short s) throws l {
        byte[] bArr = this.g;
        bArr[0] = (byte) ((s >> 8) & 255);
        bArr[1] = (byte) (s & 255);
        this.a.i(bArr, 0, 2);
    }

    public void E(int i2) throws l {
        byte[] bArr = this.h;
        bArr[0] = (byte) ((i2 >> 24) & 255);
        bArr[1] = (byte) ((i2 >> 16) & 255);
        bArr[2] = (byte) ((i2 >> 8) & 255);
        bArr[3] = (byte) (i2 & 255);
        this.a.i(bArr, 0, 4);
    }

    public void F(long j2) throws l {
        byte[] bArr = this.i;
        bArr[0] = (byte) ((int) ((j2 >> 56) & 255));
        bArr[1] = (byte) ((int) ((j2 >> 48) & 255));
        bArr[2] = (byte) ((int) ((j2 >> 40) & 255));
        bArr[3] = (byte) ((int) ((j2 >> 32) & 255));
        bArr[4] = (byte) ((int) ((j2 >> 24) & 255));
        bArr[5] = (byte) ((int) ((j2 >> 16) & 255));
        bArr[6] = (byte) ((int) ((j2 >> 8) & 255));
        bArr[7] = (byte) ((int) (j2 & 255));
        this.a.i(bArr, 0, 8);
    }

    public void G(c cVar) throws l {
        y(cVar.a);
        E(cVar.b);
    }

    public void H() {
    }

    public void I(rh.a.b.t.d dVar) throws l {
        y(dVar.a);
        y(dVar.b);
        E(dVar.c);
    }

    public void J() {
    }

    public void K(e eVar) throws l {
        if (this.f112e) {
            E(-2147418112 | eVar.b);
            O(eVar.a);
            E(eVar.c);
            return;
        }
        O(eVar.a);
        y(eVar.b);
        E(eVar.c);
    }

    public void L() {
    }

    public void M(j jVar) throws l {
        y(jVar.a);
        E(jVar.b);
    }

    public void N() {
    }

    public void O(String str) throws l {
        try {
            byte[] bytes = str.getBytes(SQLiteDatabase.KEY_ENCODING);
            E(bytes.length);
            this.a.i(bytes, 0, bytes.length);
        } catch (UnsupportedEncodingException unused) {
            throw new l("JVM DOES NOT SUPPORT UTF-8");
        }
    }

    public void P(k kVar) {
    }

    public void Q() {
    }

    public final void R(int i2) throws g {
        if (i2 >= 0) {
            long j2 = this.c;
            if (j2 != -1 && ((long) i2) > j2) {
                throw new g(3, a.m("Length exceeded max allowed: ", i2));
            }
            return;
        }
        throw new g(2, a.m("Negative length: ", i2));
    }

    public final int S(byte[] bArr, int i2, int i3) throws l {
        return this.a.g(bArr, i2, i3);
    }

    public String T(int i2) throws l {
        try {
            byte[] bArr = new byte[i2];
            this.a.g(bArr, 0, i2);
            return new String(bArr, SQLiteDatabase.KEY_ENCODING);
        } catch (UnsupportedEncodingException unused) {
            throw new l("JVM DOES NOT SUPPORT UTF-8");
        }
    }

    public ByteBuffer b() throws l {
        int i2 = i();
        long j2 = this.b;
        if (j2 > 0 && ((long) i2) > j2) {
            throw new g(3, "Binary field exceeded string size limit");
        } else if (this.a.d() >= i2) {
            ByteBuffer wrap = ByteBuffer.wrap(this.a.b(), this.a.c(), i2);
            this.a.a(i2);
            return wrap;
        } else {
            byte[] bArr = new byte[i2];
            this.a.g(bArr, 0, i2);
            return ByteBuffer.wrap(bArr);
        }
    }

    public boolean c() throws l {
        return d() == 1;
    }

    public byte d() throws l {
        if (this.a.d() >= 1) {
            byte b2 = this.a.b()[this.a.c()];
            this.a.a(1);
            return b2;
        }
        S(this.j, 0, 1);
        return this.j[0];
    }

    public double e() throws l {
        return Double.longBitsToDouble(j());
    }

    public b f() throws l {
        short s;
        byte d2 = d();
        if (d2 == 0) {
            s = 0;
        } else {
            s = h();
        }
        return new b("", d2, s);
    }

    public void g() {
    }

    public short h() throws l {
        byte[] bArr = this.k;
        int i2 = 0;
        if (this.a.d() >= 2) {
            bArr = this.a.b();
            i2 = this.a.c();
            this.a.a(2);
        } else {
            S(this.k, 0, 2);
        }
        return (short) ((bArr[i2 + 1] & 255) | ((bArr[i2] & 255) << 8));
    }

    public int i() throws l {
        byte[] bArr = this.l;
        int i2 = 0;
        if (this.a.d() >= 4) {
            bArr = this.a.b();
            i2 = this.a.c();
            this.a.a(4);
        } else {
            S(this.l, 0, 4);
        }
        return (bArr[i2 + 3] & 255) | ((bArr[i2] & 255) << 24) | ((bArr[i2 + 1] & 255) << 16) | ((bArr[i2 + 2] & 255) << 8);
    }

    public long j() throws l {
        byte[] bArr = this.m;
        int i2 = 0;
        if (this.a.d() >= 8) {
            bArr = this.a.b();
            i2 = this.a.c();
            this.a.a(8);
        } else {
            S(this.m, 0, 8);
        }
        return ((long) (bArr[i2 + 7] & 255)) | (((long) (bArr[i2] & 255)) << 56) | (((long) (bArr[i2 + 1] & 255)) << 48) | (((long) (bArr[i2 + 2] & 255)) << 40) | (((long) (bArr[i2 + 3] & 255)) << 32) | (((long) (bArr[i2 + 4] & 255)) << 24) | (((long) (bArr[i2 + 5] & 255)) << 16) | (((long) (bArr[i2 + 6] & 255)) << 8);
    }

    public c k() throws l {
        c cVar = new c(d(), i());
        R(cVar.b);
        return cVar;
    }

    public void l() {
    }

    public rh.a.b.t.d m() throws l {
        rh.a.b.t.d dVar = new rh.a.b.t.d(d(), d(), i());
        R(dVar.c);
        return dVar;
    }

    public void n() {
    }

    public e o() throws l {
        int i2 = i();
        if (i2 < 0) {
            if ((-65536 & i2) == -2147418112) {
                return new e(s(), (byte) (i2 & 255), i());
            }
            throw new g(4, "Bad version in readMessageBegin");
        } else if (!this.d) {
            return new e(T(i2), d(), i());
        } else {
            throw new g(4, "Missing version in readMessageBegin, old client?");
        }
    }

    public void p() {
    }

    public j q() throws l {
        j jVar = new j(d(), i());
        R(jVar.b);
        return jVar;
    }

    public void r() {
    }

    public String s() throws l {
        int i2 = i();
        if (i2 >= 0) {
            long j2 = this.b;
            if (j2 == -1 || ((long) i2) <= j2) {
                long j3 = this.b;
                if (j3 > 0 && ((long) i2) > j3) {
                    throw new g(3, "String field exceeded string size limit");
                } else if (this.a.d() < i2) {
                    return T(i2);
                } else {
                    try {
                        String str = new String(this.a.b(), this.a.c(), i2, SQLiteDatabase.KEY_ENCODING);
                        this.a.a(i2);
                        return str;
                    } catch (UnsupportedEncodingException unused) {
                        throw new l("JVM DOES NOT SUPPORT UTF-8");
                    }
                }
            } else {
                throw new g(3, a.m("Length exceeded max allowed: ", i2));
            }
        } else {
            throw new g(2, a.m("Negative length: ", i2));
        }
    }

    public k t() {
        return n;
    }

    public void u() {
    }

    public void w(ByteBuffer byteBuffer) throws l {
        int limit = byteBuffer.limit() - byteBuffer.position();
        E(limit);
        this.a.i(byteBuffer.array(), byteBuffer.arrayOffset() + byteBuffer.position(), limit);
    }

    public void x(boolean z) throws l {
        y(z ? (byte) 1 : 0);
    }

    public void y(byte b2) throws l {
        byte[] bArr = this.f;
        bArr[0] = b2;
        this.a.i(bArr, 0, 1);
    }

    public void z(double d2) throws l {
        F(Double.doubleToLongBits(d2));
    }
}

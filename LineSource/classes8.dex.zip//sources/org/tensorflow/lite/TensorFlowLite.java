package org.tensorflow.lite;

public final class TensorFlowLite {
    public static final Throwable a;
    public static volatile boolean b = false;

    static {
        try {
            System.loadLibrary("tensorflowlite_jni");
            e = null;
        } catch (UnsatisfiedLinkError e2) {
            e = e2;
        }
        a = e;
    }

    public static void a() {
        if (!b) {
            try {
                nativeRuntimeVersion();
                b = true;
            } catch (UnsatisfiedLinkError e2) {
                e = e2;
                Throwable th2 = a;
                if (th2 != null) {
                    e = th2;
                }
                throw new UnsatisfiedLinkError("Failed to load native TensorFlow Lite methods. Check that the correct native libraries are present, and, if using a custom native library, have been properly loaded via System.loadLibrary():\n  " + e);
            }
        }
    }

    public static native String nativeRuntimeVersion();

    public static native String nativeSchemaVersion();
}

package org.tensorflow.lite;

import java.lang.reflect.Array;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import rh.g.a.a;

public final class Tensor {
    public long a;
    public final a b;
    public int[] c;

    public Tensor(long j) {
        this.a = j;
        int dtype = dtype(j);
        for (a aVar : a.values) {
            if (aVar.value == dtype) {
                this.b = aVar;
                this.c = shape(j);
                shapeSignature(j);
                quantizationScale(j);
                quantizationZeroPoint(j);
                return;
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("DataType error: DataType ");
        sb.append(dtype);
        sb.append(" is not recognized in Java (version ");
        TensorFlowLite.a();
        sb.append(TensorFlowLite.nativeRuntimeVersion());
        sb.append(")");
        throw new IllegalArgumentException(sb.toString());
    }

    public static int b(Object obj) {
        if (obj == null || !obj.getClass().isArray()) {
            return 0;
        }
        if (Array.getLength(obj) != 0) {
            return b(Array.get(obj, 0)) + 1;
        }
        throw new IllegalArgumentException("Array lengths cannot be 0.");
    }

    public static native ByteBuffer buffer(long j);

    public static int[] c(Object obj) {
        int[] iArr = new int[b(obj)];
        d(obj, 0, iArr);
        return iArr;
    }

    public static native long create(long j, int i);

    public static void d(Object obj, int i, int[] iArr) {
        if (i != iArr.length) {
            int length = Array.getLength(obj);
            if (iArr[i] == 0) {
                iArr[i] = length;
            } else if (iArr[i] != length) {
                throw new IllegalArgumentException(String.format("Mismatched lengths (%d and %d) in dimension %d", new Object[]{Integer.valueOf(iArr[i]), Integer.valueOf(length), Integer.valueOf(i)}));
            }
            for (int i2 = 0; i2 < length; i2++) {
                d(Array.get(obj, i2), i + 1, iArr);
            }
        }
    }

    public static native void delete(long j);

    public static native int dtype(long j);

    public static native boolean hasDelegateBufferHandle(long j);

    public static native int index(long j);

    public static native String name(long j);

    public static native int numBytes(long j);

    public static native float quantizationScale(long j);

    public static native int quantizationZeroPoint(long j);

    public static native void readMultiDimensionalArray(long j, Object obj);

    public static native int[] shape(long j);

    public static native int[] shapeSignature(long j);

    public static native void writeDirectBuffer(long j, Buffer buffer);

    public static native void writeMultiDimensionalArray(long j, Object obj);

    public static native void writeScalar(long j, Object obj);

    public final ByteBuffer a() {
        return buffer(this.a).order(ByteOrder.nativeOrder());
    }

    public String e() {
        return name(this.a);
    }

    /* JADX WARNING: Removed duplicated region for block: B:50:0x00c7 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x00c8  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void f(java.lang.Object r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof java.nio.ByteBuffer
            if (r0 == 0) goto L_0x0005
            return
        L_0x0005:
            java.lang.Class<java.lang.String> r0 = java.lang.String.class
            java.lang.Class r1 = r6.getClass()
            boolean r2 = r1.isArray()
            if (r2 == 0) goto L_0x0055
        L_0x0011:
            boolean r2 = r1.isArray()
            if (r2 == 0) goto L_0x001c
            java.lang.Class r1 = r1.getComponentType()
            goto L_0x0011
        L_0x001c:
            java.lang.Class r2 = java.lang.Float.TYPE
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0028
            rh.g.a.a r0 = rh.g.a.a.FLOAT32
            goto L_0x00b3
        L_0x0028:
            java.lang.Class r2 = java.lang.Integer.TYPE
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0034
            rh.g.a.a r0 = rh.g.a.a.INT32
            goto L_0x00b3
        L_0x0034:
            java.lang.Class r2 = java.lang.Byte.TYPE
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x0040
            rh.g.a.a r0 = rh.g.a.a.UINT8
            goto L_0x00b3
        L_0x0040:
            java.lang.Class r2 = java.lang.Long.TYPE
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x004c
            rh.g.a.a r0 = rh.g.a.a.INT64
            goto L_0x00b3
        L_0x004c:
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L_0x0090
            rh.g.a.a r0 = rh.g.a.a.STRING
            goto L_0x00b3
        L_0x0055:
            java.lang.Class<java.lang.Float> r2 = java.lang.Float.class
            boolean r2 = r2.equals(r1)
            if (r2 != 0) goto L_0x00b1
            boolean r2 = r6 instanceof java.nio.FloatBuffer
            if (r2 == 0) goto L_0x0062
            goto L_0x00b1
        L_0x0062:
            java.lang.Class<java.lang.Integer> r2 = java.lang.Integer.class
            boolean r2 = r2.equals(r1)
            if (r2 != 0) goto L_0x00ae
            boolean r2 = r6 instanceof java.nio.IntBuffer
            if (r2 == 0) goto L_0x006f
            goto L_0x00ae
        L_0x006f:
            java.lang.Class<java.lang.Byte> r2 = java.lang.Byte.class
            boolean r2 = r2.equals(r1)
            if (r2 == 0) goto L_0x007a
            rh.g.a.a r0 = rh.g.a.a.UINT8
            goto L_0x00b3
        L_0x007a:
            java.lang.Class<java.lang.Long> r2 = java.lang.Long.class
            boolean r2 = r2.equals(r1)
            if (r2 != 0) goto L_0x00ab
            boolean r2 = r6 instanceof java.nio.LongBuffer
            if (r2 == 0) goto L_0x0087
            goto L_0x00ab
        L_0x0087:
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L_0x0090
            rh.g.a.a r0 = rh.g.a.a.STRING
            goto L_0x00b3
        L_0x0090:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "DataType error: cannot resolve DataType of "
            java.lang.StringBuilder r1 = e.e.b.a.a.V0(r1)
            java.lang.Class r6 = r6.getClass()
            java.lang.String r6 = r6.getName()
            r1.append(r6)
            java.lang.String r6 = r1.toString()
            r0.<init>(r6)
            throw r0
        L_0x00ab:
            rh.g.a.a r0 = rh.g.a.a.INT64
            goto L_0x00b3
        L_0x00ae:
            rh.g.a.a r0 = rh.g.a.a.INT32
            goto L_0x00b3
        L_0x00b1:
            rh.g.a.a r0 = rh.g.a.a.FLOAT32
        L_0x00b3:
            rh.g.a.a r1 = r5.b
            if (r0 == r1) goto L_0x00ea
            java.lang.String r1 = r0.b()
            rh.g.a.a r2 = r5.b
            java.lang.String r2 = r2.b()
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x00c8
            return
        L_0x00c8:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            r2 = 3
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = 0
            rh.g.a.a r4 = r5.b
            r2[r3] = r4
            r3 = 1
            java.lang.Class r6 = r6.getClass()
            java.lang.String r6 = r6.getName()
            r2[r3] = r6
            r6 = 2
            r2[r6] = r0
            java.lang.String r6 = "Cannot convert between a TensorFlowLite tensor with type %s and a Java object of type %s (which is compatible with the TensorFlowLite type %s)."
            java.lang.String r6 = java.lang.String.format(r6, r2)
            r1.<init>(r6)
            throw r1
        L_0x00ea:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.tensorflow.lite.Tensor.f(java.lang.Object):void");
    }
}

package org.tensorflow.lite.nnapi;

import org.tensorflow.lite.TensorFlowLite;
import rh.g.a.b;

public class NnApiDelegate implements b, AutoCloseable {
    public long a = createDelegate(-1, (String) null, (String) null, (String) null, -1, false, false, false);

    public NnApiDelegate() {
        TensorFlowLite.a();
    }

    public static native long createDelegate(int i, String str, String str2, String str3, int i2, boolean z, boolean z2, boolean z3);

    public static native void deleteDelegate(long j);

    public static native int getNnapiErrno(long j);

    public long a() {
        return this.a;
    }

    public void close() {
        long j = this.a;
        if (j != 0) {
            deleteDelegate(j);
            this.a = 0;
        }
    }
}

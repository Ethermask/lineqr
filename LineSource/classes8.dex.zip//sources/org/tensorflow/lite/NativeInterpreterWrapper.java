package org.tensorflow.lite;

import e.e.b.a.a;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.tensorflow.lite.nnapi.NnApiDelegate;
import rh.g.a.b;
import rh.g.a.c;

public final class NativeInterpreterWrapper implements AutoCloseable {
    public long a;
    public long b;
    public long c;
    public ByteBuffer d;

    /* renamed from: e  reason: collision with root package name */
    public Tensor[] f114e;
    public Tensor[] f;
    public boolean g = false;
    public final List<b> h = new ArrayList();
    public final List<AutoCloseable> i = new ArrayList();
    public long inferenceDurationNanoseconds = -1;

    public NativeInterpreterWrapper(String str, c.a aVar) {
        TensorFlowLite.a();
        long createErrorReporter = createErrorReporter(512);
        b(createErrorReporter, createModel(str, createErrorReporter), aVar);
    }

    public static native long allocateTensors(long j, long j2);

    public static native void allowBufferHandleOutput(long j, boolean z);

    public static native void allowFp16PrecisionForFp32(long j, boolean z);

    public static native void applyDelegate(long j, long j2, long j3);

    public static native long createErrorReporter(int i2);

    public static native long createInterpreter(long j, long j2, int i2);

    public static native long createModel(String str, long j);

    public static native long createModelWithBuffer(ByteBuffer byteBuffer, long j);

    public static native void delete(long j, long j2, long j3);

    public static native int getExecutionPlanLength(long j);

    public static native int getInputCount(long j);

    public static native String[] getInputNames(long j);

    public static native int getInputTensorIndex(long j, int i2);

    public static native int getOutputCount(long j);

    public static native int getOutputDataType(long j, int i2);

    public static native String[] getOutputNames(long j);

    public static native int getOutputTensorIndex(long j, int i2);

    public static native boolean hasUnresolvedFlexOp(long j);

    public static native void numThreads(long j, int i2);

    public static native void resetVariableTensors(long j, long j2);

    public static native boolean resizeInput(long j, long j2, int i2, int[] iArr, boolean z);

    public static native void run(long j, long j2);

    public static native void useNNAPI(long j, boolean z);

    public static native void useXNNPACK(long j, long j2, boolean z, int i2);

    public Tensor a(int i2) {
        if (i2 >= 0) {
            Tensor[] tensorArr = this.f114e;
            if (i2 < tensorArr.length) {
                Tensor tensor = tensorArr[i2];
                if (tensor != null) {
                    return tensor;
                }
                long j = this.b;
                Tensor tensor2 = new Tensor(Tensor.create(j, getInputTensorIndex(j, i2)));
                tensorArr[i2] = tensor2;
                return tensor2;
            }
        }
        throw new IllegalArgumentException(a.m("Invalid input Tensor index: ", i2));
    }

    public final void b(long j, long j2, c.a aVar) {
        if (aVar == null) {
            aVar = new c.a();
        }
        this.a = j;
        this.c = j2;
        long createInterpreter = createInterpreter(j2, j, aVar.a);
        this.b = createInterpreter;
        this.f114e = new Tensor[getInputCount(createInterpreter)];
        this.f = new Tensor[getOutputCount(this.b)];
        Boolean bool = aVar.c;
        if (bool != null) {
            allowFp16PrecisionForFp32(this.b, bool.booleanValue());
        }
        Boolean bool2 = aVar.d;
        if (bool2 != null) {
            allowBufferHandleOutput(this.b, bool2.booleanValue());
        }
        boolean hasUnresolvedFlexOp = hasUnresolvedFlexOp(this.b);
        boolean z = false;
        if (hasUnresolvedFlexOp) {
            List<b> list = aVar.f;
            b bVar = null;
            try {
                Class<?> cls = Class.forName("org.tensorflow.lite.flex.FlexDelegate");
                Iterator<b> it = list.iterator();
                while (true) {
                    if (it.hasNext()) {
                        if (cls.isInstance(it.next())) {
                            break;
                        }
                    } else {
                        bVar = (b) cls.getConstructor(new Class[0]).newInstance(new Object[0]);
                        break;
                    }
                }
            } catch (Exception unused) {
            }
            if (bVar != null) {
                this.i.add((AutoCloseable) bVar);
                applyDelegate(this.b, this.a, bVar.a());
            }
        }
        try {
            for (b next : aVar.f) {
                applyDelegate(this.b, this.a, next.a());
                this.h.add(next);
            }
            if (aVar.b != null && aVar.b.booleanValue()) {
                NnApiDelegate nnApiDelegate = new NnApiDelegate();
                this.i.add(nnApiDelegate);
                applyDelegate(this.b, this.a, nnApiDelegate.a);
            }
        } catch (IllegalArgumentException e2) {
            if (hasUnresolvedFlexOp && !hasUnresolvedFlexOp(this.b)) {
                z = true;
            }
            if (z) {
                System.err.println("Ignoring failed delegate application: " + e2);
            } else {
                throw e2;
            }
        }
        Boolean bool3 = aVar.f161e;
        if (bool3 != null) {
            useXNNPACK(this.b, j, bool3.booleanValue(), aVar.a);
        }
        allocateTensors(this.b, j);
        this.g = true;
    }

    public void close() {
        int i2 = 0;
        while (true) {
            Tensor[] tensorArr = this.f114e;
            if (i2 >= tensorArr.length) {
                break;
            }
            if (tensorArr[i2] != null) {
                Tensor tensor = tensorArr[i2];
                Tensor.delete(tensor.a);
                tensor.a = 0;
                this.f114e[i2] = null;
            }
            i2++;
        }
        int i3 = 0;
        while (true) {
            Tensor[] tensorArr2 = this.f;
            if (i3 >= tensorArr2.length) {
                break;
            }
            if (tensorArr2[i3] != null) {
                Tensor tensor2 = tensorArr2[i3];
                Tensor.delete(tensor2.a);
                tensor2.a = 0;
                this.f[i3] = null;
            }
            i3++;
        }
        delete(this.a, this.c, this.b);
        this.a = 0;
        this.c = 0;
        this.b = 0;
        this.d = null;
        this.g = false;
        this.h.clear();
        for (AutoCloseable close : this.i) {
            try {
                close.close();
            } catch (Exception e2) {
                System.err.println("Failed to close flex delegate: " + e2);
            }
        }
        this.i.clear();
    }

    public NativeInterpreterWrapper(ByteBuffer byteBuffer, c.a aVar) {
        TensorFlowLite.a();
        if (byteBuffer == null || (!(byteBuffer instanceof MappedByteBuffer) && (!byteBuffer.isDirect() || byteBuffer.order() != ByteOrder.nativeOrder()))) {
            throw new IllegalArgumentException("Model ByteBuffer should be either a MappedByteBuffer of the model file, or a direct ByteBuffer using ByteOrder.nativeOrder() which contains bytes of model content.");
        }
        this.d = byteBuffer;
        long createErrorReporter = createErrorReporter(512);
        b(createErrorReporter, createModelWithBuffer(this.d, createErrorReporter), aVar);
    }
}

package org.jboss.netty.util.internal;

import java.util.concurrent.BlockingQueue;
import rh.d.a.e.a;
import rh.d.a.e.b;
import rh.d.a.f.i.g;
import rh.d.a.f.i.h;

public final class QueueFactory {
    public static final a LOGGER = new b();
    public static final boolean useUnsafe = g.HAS_UNSAFE;

    public static <T> BlockingQueue createQueue() {
        return new h();
    }
}

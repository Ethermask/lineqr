package org.jboss.netty.channel;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.RejectedExecutionException;
import rh.d.a.c.d;
import rh.d.a.c.e;
import rh.d.a.c.h;
import rh.d.a.c.k;
import rh.d.a.c.l;
import rh.d.a.c.m;
import rh.d.a.c.m0;
import rh.d.a.c.n;
import rh.d.a.c.n0;
import rh.d.a.c.o;
import rh.d.a.c.p0;
import rh.d.a.c.q;
import rh.d.a.c.t;
import rh.d.a.c.v0;

public class DefaultChannelPipeline implements n {
    public static final rh.d.a.e.a b = new rh.d.a.e.b();
    public static final q c = new b();
    public final Map<String, a> a = new HashMap(4);
    public volatile rh.d.a.c.b channel;
    public volatile a head;
    public volatile q sink;
    public volatile a tail;

    public final class a implements l {
        public final String a;
        public final k b;
        public final boolean c;
        public final boolean d;

        /* renamed from: e  reason: collision with root package name */
        public volatile a f113e;
        public volatile a f;
        public volatile Object g;

        public a(a aVar, a aVar2, String str, k kVar) {
            if (str == null) {
                throw new NullPointerException("name");
            } else if (kVar != null) {
                boolean z = kVar instanceof t;
                this.c = z;
                boolean z2 = kVar instanceof d;
                this.d = z2;
                if (z || z2) {
                    this.f = aVar;
                    this.f113e = null;
                    this.a = str;
                    this.b = kVar;
                    return;
                }
                StringBuilder V0 = e.e.b.a.a.V0("handler must be either ");
                V0.append(t.class.getName());
                V0.append(" or ");
                V0.append(d.class.getName());
                V0.append('.');
                throw new IllegalArgumentException(V0.toString());
            } else {
                throw new NullPointerException("handler");
            }
        }

        public void a(e eVar) {
            DefaultChannelPipeline defaultChannelPipeline = DefaultChannelPipeline.this;
            a aVar = this.f;
            a aVar2 = null;
            if (defaultChannelPipeline != null) {
                if (aVar != null) {
                    while (true) {
                        if (aVar.d) {
                            aVar2 = aVar;
                            break;
                        }
                        aVar = aVar.f;
                        if (aVar == null) {
                            break;
                        }
                    }
                }
                if (aVar2 == null) {
                    try {
                        DefaultChannelPipeline.this.g().f(DefaultChannelPipeline.this, eVar);
                    } catch (Throwable th2) {
                        DefaultChannelPipeline.this.h(eVar, th2);
                    }
                } else {
                    DefaultChannelPipeline.this.k(aVar2, eVar);
                }
            } else {
                throw null;
            }
        }

        public void b(e eVar) {
            DefaultChannelPipeline defaultChannelPipeline = DefaultChannelPipeline.this;
            a aVar = this.f113e;
            a aVar2 = null;
            if (defaultChannelPipeline != null) {
                if (aVar != null) {
                    while (true) {
                        if (aVar.c) {
                            aVar2 = aVar;
                            break;
                        }
                        aVar = aVar.f113e;
                        if (aVar == null) {
                            break;
                        }
                    }
                }
                if (aVar2 != null) {
                    DefaultChannelPipeline.this.m(aVar2, eVar);
                    return;
                }
                return;
            }
            throw null;
        }
    }

    public static final class b implements q {
        public void f(n nVar, e eVar) {
        }

        public h h(n nVar, Runnable runnable) {
            return new n0(((DefaultChannelPipeline) nVar).channel, new RejectedExecutionException("Not attached yet"));
        }

        public void i(n nVar, e eVar, o oVar) throws Exception {
            throw oVar;
        }
    }

    public static void d(l lVar) {
        k kVar = ((a) lVar).b;
        if (kVar instanceof p0) {
            p0 p0Var = (p0) kVar;
            try {
                p0Var.g(lVar);
            } catch (Throwable th2) {
                throw new m(p0Var.getClass().getName() + ".afterRemove() has thrown an exception.", th2);
            }
        }
    }

    public static void e(l lVar) {
        k kVar = ((a) lVar).b;
        if (kVar instanceof p0) {
            p0 p0Var = (p0) kVar;
            try {
                p0Var.a(lVar);
            } catch (Throwable th2) {
                throw new m(p0Var.getClass().getName() + ".beforeAdd() has thrown an exception; not adding.", th2);
            }
        }
    }

    public static void f(l lVar) {
        k kVar = ((a) lVar).b;
        if (kVar instanceof p0) {
            p0 p0Var = (p0) kVar;
            try {
                p0Var.e(lVar);
            } catch (Throwable th2) {
                throw new m(p0Var.getClass().getName() + ".beforeRemove() has thrown an exception; not removing.", th2);
            }
        }
    }

    public synchronized void a(String str, k kVar) {
        if (this.a.isEmpty()) {
            a aVar = new a((a) null, (a) null, str, kVar);
            e(aVar);
            this.tail = aVar;
            this.head = aVar;
            this.a.clear();
            this.a.put(str, aVar);
            c(aVar);
        } else if (!this.a.containsKey(str)) {
            a aVar2 = this.tail;
            a aVar3 = new a(aVar2, (a) null, str, kVar);
            e(aVar3);
            aVar2.f113e = aVar3;
            this.tail = aVar3;
            this.a.put(str, aVar3);
            c(aVar3);
        } else {
            throw new IllegalArgumentException("Duplicate handler name: " + str);
        }
    }

    public void b(rh.d.a.c.b bVar, q qVar) {
        if (qVar == null) {
            throw new NullPointerException("sink");
        } else if (this.channel == null && this.sink == null) {
            this.channel = bVar;
            this.sink = qVar;
        } else {
            throw new IllegalStateException("attached already");
        }
    }

    public final void c(l lVar) {
        p0 p0Var;
        boolean z;
        k kVar = ((a) lVar).b;
        if (kVar instanceof p0) {
            p0Var = (p0) kVar;
            try {
                p0Var.b(lVar);
                return;
            } catch (Throwable unused) {
            }
        } else {
            return;
        }
        if (z) {
            throw new m(p0Var.getClass().getName() + ".afterAdd() has thrown an exception; removed.", th);
        }
        throw new m(p0Var.getClass().getName() + ".afterAdd() has thrown an exception; also failed to remove.", th);
    }

    public q g() {
        q qVar = this.sink;
        return qVar == null ? c : qVar;
    }

    public void h(e eVar, Throwable th2) {
        o oVar;
        if (!(eVar instanceof m0)) {
            if (th2 instanceof o) {
                oVar = (o) th2;
            } else {
                oVar = new o(th2);
            }
            try {
                this.sink.i(this, eVar, oVar);
            } catch (Exception unused) {
            }
        }
    }

    public final a i(a aVar) {
        if (this.head == this.tail) {
            this.tail = null;
            this.head = null;
            this.a.clear();
        } else if (aVar == this.head) {
            synchronized (this) {
                if (!this.a.isEmpty()) {
                    a aVar2 = this.head;
                    if (aVar2 != null) {
                        f(aVar2);
                        if (aVar2.f113e == null) {
                            this.tail = null;
                            this.head = null;
                            this.a.clear();
                        } else {
                            aVar2.f113e.f = null;
                            this.head = aVar2.f113e;
                            this.a.remove(aVar2.a);
                        }
                        d(aVar2);
                    } else {
                        throw new NoSuchElementException();
                    }
                } else {
                    throw new NoSuchElementException();
                }
            }
        } else if (aVar == this.tail) {
            synchronized (this) {
                if (!this.a.isEmpty()) {
                    a aVar3 = this.tail;
                    if (aVar3 != null) {
                        f(aVar3);
                        if (aVar3.f == null) {
                            this.tail = null;
                            this.head = null;
                            this.a.clear();
                        } else {
                            aVar3.f.f113e = null;
                            this.tail = aVar3.f;
                            this.a.remove(aVar3.a);
                        }
                        f(aVar3);
                    } else {
                        throw new NoSuchElementException();
                    }
                } else {
                    throw new NoSuchElementException();
                }
            }
        } else {
            f(aVar);
            a aVar4 = aVar.f;
            a aVar5 = aVar.f113e;
            aVar4.f113e = aVar5;
            aVar5.f = aVar4;
            this.a.remove(aVar.a);
            d(aVar);
        }
        return aVar;
    }

    public void j(e eVar) {
        a aVar = this.tail;
        if (aVar == null) {
            aVar = null;
        } else {
            while (true) {
                if (!aVar.d) {
                    aVar = aVar.f;
                    if (aVar == null) {
                        break;
                    }
                } else {
                    break;
                }
            }
            aVar = null;
        }
        if (aVar == null) {
            try {
                g().f(this, eVar);
            } catch (Throwable th2) {
                h(eVar, th2);
            }
        } else {
            k(aVar, eVar);
        }
    }

    public void k(a aVar, e eVar) {
        if (!(eVar instanceof v0)) {
            try {
                ((d) aVar.b).c(aVar, eVar);
            } catch (Throwable th2) {
                eVar.c().d(th2);
                h(eVar, th2);
            }
        } else {
            throw new IllegalArgumentException("cannot send an upstream event to downstream");
        }
    }

    public void l(e eVar) {
        a aVar = this.head;
        if (aVar == null) {
            aVar = null;
        } else {
            while (true) {
                if (!aVar.c) {
                    aVar = aVar.f113e;
                    if (aVar == null) {
                        break;
                    }
                } else {
                    break;
                }
            }
            aVar = null;
        }
        if (aVar != null) {
            try {
                ((t) aVar.b).d(aVar, eVar);
            } catch (Throwable th2) {
                h(eVar, th2);
            }
        }
    }

    public void m(a aVar, e eVar) {
        try {
            ((t) aVar.b).d(aVar, eVar);
        } catch (Throwable th2) {
            h(eVar, th2);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append('{');
        a aVar = this.head;
        while (true) {
            sb.append('(');
            sb.append(aVar.a);
            sb.append(" = ");
            sb.append(aVar.b.getClass().getName());
            sb.append(')');
            aVar = aVar.f113e;
            if (aVar == null) {
                sb.append('}');
                return sb.toString();
            }
            sb.append(", ");
        }
    }
}

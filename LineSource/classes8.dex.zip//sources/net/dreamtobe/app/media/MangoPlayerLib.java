package net.dreamtobe.app.media;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.view.SurfaceHolder;
import java.io.IOException;
import net.dreamtobe.common.log.DtbLog;
import net.dreamtobe.protocol.http.httprelay.HttpRelay;
import net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelay;

public class MangoPlayerLib extends MediaPlayer implements RtspRelay.OnMangoRTSPRelayServerDisconnectListener, HttpRelay.OnMangoHTTPRelayServerDisconnectListener {
    public static final int DTB_DEFAULT_LISTEN_PORT = 55544;
    public boolean m_bIsHTTP;
    public boolean m_bIsRTSP;
    public boolean m_bIsTCP;
    public HttpRelay m_cHttpRelay;
    public RtspRelay m_cRtspRelay;
    public OnMangoPlayerServerDisconnectListener m_iMangoPlayerServerDisconnectListener;
    public long m_nCompatibleflag;
    public String m_szCookie;
    public String m_szExtHeader;
    public String m_szURL;

    public interface OnMangoPlayerServerDisconnectListener {
        void OnMangoPlayerServerDisconnect(int i);
    }

    public MangoPlayerLib() {
        this.m_cRtspRelay = null;
        this.m_cHttpRelay = null;
        this.m_szURL = null;
        this.m_szCookie = null;
        this.m_szExtHeader = null;
        this.m_bIsRTSP = false;
        this.m_bIsTCP = true;
        this.m_iMangoPlayerServerDisconnectListener = null;
        this.m_nCompatibleflag = 0;
        setAtrixCompatibleInner();
    }

    private void setAtrixCompatibleInner() {
        DtbLog.cLogPrn(16, "modelName is : %s", Build.MODEL);
        DtbLog.cLogPrn(16, "device is : %s", Build.DEVICE);
        DtbLog.cLogPrn(16, "ProductName is : %s", Build.PRODUCT);
        DtbLog.cLogPrn(16, "SDK version is : %d", Integer.valueOf(Build.VERSION.SDK_INT));
        if (Build.MODEL.indexOf("MB861") == 0) {
            this.m_nCompatibleflag |= 1;
        }
    }

    public void OnMangoHTTPRelayServerDisconnect(int i) {
        if (this.m_bIsHTTP) {
            DtbLog.cLogPrn(16, "HTTP server is disconneted", new Object[0]);
            OnMangoPlayerServerDisconnectListener onMangoPlayerServerDisconnectListener = this.m_iMangoPlayerServerDisconnectListener;
            if (onMangoPlayerServerDisconnectListener != null) {
                onMangoPlayerServerDisconnectListener.OnMangoPlayerServerDisconnect(i);
            }
        }
    }

    public void OnMangoRTSPRelayServerDisconnect(int i) {
        DtbLog.cLogPrn(16, "server is disconneted", new Object[0]);
        if (this.m_bIsRTSP) {
            DtbLog.cLogPrn(16, "RTSP server is disconneted", new Object[0]);
            OnMangoPlayerServerDisconnectListener onMangoPlayerServerDisconnectListener = this.m_iMangoPlayerServerDisconnectListener;
            if (onMangoPlayerServerDisconnectListener != null) {
                onMangoPlayerServerDisconnectListener.OnMangoPlayerServerDisconnect(i);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r1.m_cRtspRelay;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getVideoHeight() {
        /*
            r1 = this;
            boolean r0 = r1.m_bIsRTSP
            if (r0 == 0) goto L_0x000d
            net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelay r0 = r1.m_cRtspRelay
            if (r0 == 0) goto L_0x000d
            int r0 = r0.getVideoHeight()
            goto L_0x000e
        L_0x000d:
            r0 = 0
        L_0x000e:
            if (r0 != 0) goto L_0x0014
            int r0 = super.getVideoHeight()
        L_0x0014:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.app.media.MangoPlayerLib.getVideoHeight():int");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r1.m_cRtspRelay;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getVideoWidth() {
        /*
            r1 = this;
            boolean r0 = r1.m_bIsRTSP
            if (r0 == 0) goto L_0x000d
            net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelay r0 = r1.m_cRtspRelay
            if (r0 == 0) goto L_0x000d
            int r0 = r0.getVideoWidth()
            goto L_0x000e
        L_0x000d:
            r0 = 0
        L_0x000e:
            if (r0 != 0) goto L_0x0014
            int r0 = super.getVideoWidth()
        L_0x0014:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.app.media.MangoPlayerLib.getVideoWidth():int");
    }

    public void prepare() throws IOException, IllegalStateException {
        if (this.m_cRtspRelay == null && this.m_bIsRTSP) {
            RtspRelay rtspRelay = new RtspRelay(this.m_szURL, DTB_DEFAULT_LISTEN_PORT, false, this.m_szCookie, this.m_szExtHeader);
            this.m_cRtspRelay = rtspRelay;
            rtspRelay.setOnMangoRTSPRelayServerDisconnectListener(this);
            int ExecReady = this.m_cRtspRelay.ExecReady(this.m_nCompatibleflag);
            this.m_cRtspRelay.start();
            int indexOf = this.m_szURL.indexOf("/", 8);
            try {
                super.reset();
                super.setDataSource("rtsp://127.0.0.1:" + ExecReady + this.m_szURL.substring(indexOf));
            } catch (IllegalArgumentException unused) {
                RtspRelay rtspRelay2 = this.m_cRtspRelay;
                if (rtspRelay2 != null) {
                    rtspRelay2.setStop(true);
                }
                this.m_cRtspRelay = null;
                throw new IllegalStateException("setDataSource error");
            } catch (IllegalStateException unused2) {
                RtspRelay rtspRelay3 = this.m_cRtspRelay;
                if (rtspRelay3 != null) {
                    rtspRelay3.setStop(true);
                }
                this.m_cRtspRelay = null;
                throw new IllegalStateException("setDataSource error");
            } catch (IOException unused3) {
                RtspRelay rtspRelay4 = this.m_cRtspRelay;
                if (rtspRelay4 != null) {
                    rtspRelay4.setStop(true);
                }
                this.m_cRtspRelay = null;
                throw new IOException("setDataSource error");
            }
        } else if (this.m_cHttpRelay == null && this.m_bIsHTTP) {
            HttpRelay httpRelay = new HttpRelay(this.m_szURL, DTB_DEFAULT_LISTEN_PORT, this.m_szCookie, this.m_szExtHeader);
            this.m_cHttpRelay = httpRelay;
            int listenPort = httpRelay.getListenPort();
            this.m_cHttpRelay.setOnMangoHTTPRelayServerDisconnectListener(this);
            this.m_cHttpRelay.setDaemon(true);
            this.m_cHttpRelay.start();
            int indexOf2 = this.m_szURL.indexOf("/", 8);
            try {
                super.reset();
                super.setDataSource("http://127.0.0.1:" + listenPort + this.m_szURL.substring(indexOf2));
            } catch (IllegalArgumentException unused4) {
                HttpRelay httpRelay2 = this.m_cHttpRelay;
                if (httpRelay2 != null) {
                    httpRelay2.setStop(true);
                }
                this.m_cHttpRelay = null;
                throw new IllegalStateException("setDataSource error");
            } catch (IllegalStateException unused5) {
                HttpRelay httpRelay3 = this.m_cHttpRelay;
                if (httpRelay3 != null) {
                    httpRelay3.setStop(true);
                }
                this.m_cHttpRelay = null;
                throw new IllegalStateException("setDataSource error");
            } catch (IOException unused6) {
                HttpRelay httpRelay4 = this.m_cHttpRelay;
                if (httpRelay4 != null) {
                    httpRelay4.setStop(true);
                }
                this.m_cHttpRelay = null;
                throw new IOException("setDataSource error");
            }
        }
        super.prepare();
    }

    public void prepareAsync() throws IllegalStateException {
        boolean z;
        int i;
        int i2;
        if (this.m_cRtspRelay == null && (z = this.m_bIsRTSP)) {
            if (z) {
                RtspRelay rtspRelay = new RtspRelay(this.m_szURL, DTB_DEFAULT_LISTEN_PORT, false, this.m_szCookie, this.m_szExtHeader);
                this.m_cRtspRelay = rtspRelay;
                rtspRelay.setOnMangoRTSPRelayServerDisconnectListener(this);
                i2 = this.m_cRtspRelay.ExecReady(this.m_nCompatibleflag);
                this.m_cRtspRelay.start();
                i = this.m_szURL.indexOf("/", 8);
            } else {
                i2 = 554;
                i = 0;
            }
            try {
                if (this.m_bIsRTSP) {
                    super.reset();
                    super.setDataSource("rtsp://127.0.0.1:" + i2 + this.m_szURL.substring(i));
                }
            } catch (IllegalArgumentException unused) {
                if (this.m_bIsRTSP) {
                    RtspRelay rtspRelay2 = this.m_cRtspRelay;
                    if (rtspRelay2 != null) {
                        rtspRelay2.setStop(true);
                    }
                    this.m_cRtspRelay = null;
                }
                throw new IllegalStateException("setDataSource error");
            } catch (IllegalStateException unused2) {
                if (this.m_bIsRTSP) {
                    RtspRelay rtspRelay3 = this.m_cRtspRelay;
                    if (rtspRelay3 != null) {
                        rtspRelay3.setStop(true);
                    }
                    this.m_cRtspRelay = null;
                }
                throw new IllegalStateException("setDataSource error");
            } catch (IOException unused3) {
                if (this.m_bIsRTSP) {
                    RtspRelay rtspRelay4 = this.m_cRtspRelay;
                    if (rtspRelay4 != null) {
                        rtspRelay4.setStop(true);
                    }
                    this.m_cRtspRelay = null;
                }
                throw new IllegalStateException("setDataSource error");
            }
        } else if (this.m_cHttpRelay == null && this.m_bIsHTTP) {
            try {
                HttpRelay httpRelay = new HttpRelay(this.m_szURL, DTB_DEFAULT_LISTEN_PORT, this.m_szCookie, this.m_szExtHeader);
                this.m_cHttpRelay = httpRelay;
                int listenPort = httpRelay.getListenPort();
                this.m_cHttpRelay.setOnMangoHTTPRelayServerDisconnectListener(this);
                this.m_cHttpRelay.setDaemon(true);
                this.m_cHttpRelay.start();
                int indexOf = this.m_szURL.indexOf("/", 8);
                try {
                    super.reset();
                    super.setDataSource("http://127.0.0.1:" + listenPort + this.m_szURL.substring(indexOf));
                } catch (IllegalArgumentException unused4) {
                    HttpRelay httpRelay2 = this.m_cHttpRelay;
                    if (httpRelay2 != null) {
                        httpRelay2.setStop(true);
                    }
                    this.m_cHttpRelay = null;
                    throw new IllegalStateException("setDataSource error");
                } catch (IllegalStateException unused5) {
                    HttpRelay httpRelay3 = this.m_cHttpRelay;
                    if (httpRelay3 != null) {
                        httpRelay3.setStop(true);
                    }
                    this.m_cHttpRelay = null;
                    throw new IllegalStateException("setDataSource error");
                } catch (IOException unused6) {
                    HttpRelay httpRelay4 = this.m_cHttpRelay;
                    if (httpRelay4 != null) {
                        httpRelay4.setStop(true);
                    }
                    this.m_cHttpRelay = null;
                    throw new IllegalStateException("setDataSource error");
                }
            } catch (IOException unused7) {
                throw new IllegalStateException("setDataSource error");
            }
        }
        super.prepareAsync();
    }

    public void release() {
        super.release();
        if (this.m_bIsRTSP) {
            DtbLog.cLogPrn(16, "RtspRelay release is called", new Object[0]);
            RtspRelay rtspRelay = this.m_cRtspRelay;
            if (rtspRelay != null) {
                rtspRelay.setStop(true);
            }
            this.m_cRtspRelay = null;
        } else if (this.m_bIsHTTP) {
            DtbLog.cLogPrn(16, "HttpRelay release is called", new Object[0]);
            HttpRelay httpRelay = this.m_cHttpRelay;
            if (httpRelay != null) {
                httpRelay.setStop(true);
            }
            this.m_cHttpRelay = null;
        }
    }

    public void reset() {
        super.reset();
        if (this.m_bIsRTSP) {
            DtbLog.cLogPrn(16, "RtspRelay reset is called", new Object[0]);
            RtspRelay rtspRelay = this.m_cRtspRelay;
            if (rtspRelay != null) {
                rtspRelay.setStop(true);
            }
            this.m_cRtspRelay = null;
        } else if (this.m_bIsHTTP) {
            DtbLog.cLogPrn(16, "HttpRelay reset is called", new Object[0]);
            HttpRelay httpRelay = this.m_cHttpRelay;
            if (httpRelay != null) {
                httpRelay.setStop(true);
            }
            this.m_cHttpRelay = null;
        }
    }

    public void setAtrixCompatible() {
        this.m_nCompatibleflag |= 1;
    }

    public void setCookieHeader(String str) {
        this.m_szCookie = str;
    }

    public void setDataSource(String str) throws IllegalStateException, IOException {
        int i;
        int i2;
        if (str.indexOf("rtsp://") == 0) {
            if (this.m_bIsTCP) {
                this.m_bIsRTSP = true;
            } else {
                this.m_bIsRTSP = false;
            }
        } else if (str.indexOf("http://") == 0) {
            this.m_bIsHTTP = true;
        } else {
            this.m_bIsRTSP = false;
        }
        this.m_szURL = str;
        if (this.m_bIsRTSP) {
            RtspRelay rtspRelay = new RtspRelay(this.m_szURL, DTB_DEFAULT_LISTEN_PORT, false, this.m_szCookie, this.m_szExtHeader);
            this.m_cRtspRelay = rtspRelay;
            rtspRelay.setOnMangoRTSPRelayServerDisconnectListener(this);
            i = this.m_cRtspRelay.ExecReady(this.m_nCompatibleflag);
            this.m_cRtspRelay.start();
            i2 = this.m_szURL.indexOf("/", 8);
        } else if (this.m_bIsHTTP) {
            HttpRelay httpRelay = new HttpRelay(this.m_szURL, DTB_DEFAULT_LISTEN_PORT, this.m_szCookie, this.m_szExtHeader);
            this.m_cHttpRelay = httpRelay;
            i = httpRelay.getListenPort();
            this.m_cHttpRelay.setOnMangoHTTPRelayServerDisconnectListener(this);
            this.m_cHttpRelay.setDaemon(true);
            this.m_cHttpRelay.start();
            i2 = this.m_szURL.indexOf("/", 8);
        } else {
            i = 554;
            i2 = 0;
        }
        try {
            if (this.m_bIsRTSP) {
                super.setDataSource("rtsp://127.0.0.1:" + i + this.m_szURL.substring(i2));
            } else if (this.m_bIsHTTP) {
                super.setDataSource("http://127.0.0.1:" + i + this.m_szURL.substring(i2));
            } else {
                super.setDataSource(this.m_szURL);
            }
        } catch (IllegalArgumentException unused) {
            DtbLog.cLogPrn(2, "IllegalArgumentException is occoured in setDataSource", new Object[0]);
            if (this.m_bIsRTSP) {
                RtspRelay rtspRelay2 = this.m_cRtspRelay;
                if (rtspRelay2 != null) {
                    rtspRelay2.setStop(true);
                }
                this.m_cRtspRelay = null;
            }
            throw new IllegalStateException("setDataSource error");
        } catch (IllegalStateException unused2) {
            DtbLog.cLogPrn(2, "IllegalStateException is occoured in setDataSource", new Object[0]);
            if (this.m_bIsRTSP) {
                RtspRelay rtspRelay3 = this.m_cRtspRelay;
                if (rtspRelay3 != null) {
                    rtspRelay3.setStop(true);
                }
                this.m_cRtspRelay = null;
            }
            throw new IllegalStateException("setDataSource error");
        } catch (IOException unused3) {
            DtbLog.cLogPrn(2, "IOException is occoured in setDataSource", new Object[0]);
            if (this.m_bIsRTSP) {
                RtspRelay rtspRelay4 = this.m_cRtspRelay;
                if (rtspRelay4 != null) {
                    rtspRelay4.setStop(true);
                }
                this.m_cRtspRelay = null;
            }
            throw new IOException("setDataSource error");
        }
    }

    public void setExtensionHeader(String str) {
        this.m_szExtHeader = str;
    }

    public void setOnMangoRelayServerDisconnectListener(OnMangoPlayerServerDisconnectListener onMangoPlayerServerDisconnectListener) {
        this.m_iMangoPlayerServerDisconnectListener = onMangoPlayerServerDisconnectListener;
    }

    public void setTCPStreaming(boolean z) {
        this.m_bIsTCP = z;
    }

    public void stop() throws IllegalStateException {
        super.stop();
        if (this.m_bIsRTSP) {
            DtbLog.cLogPrn(16, "RtspRelay stop is called", new Object[0]);
            RtspRelay rtspRelay = this.m_cRtspRelay;
            if (rtspRelay != null) {
                rtspRelay.setStop(true);
            }
            this.m_cRtspRelay = null;
        } else if (this.m_bIsHTTP) {
            DtbLog.cLogPrn(16, "HttpRelay stop is called", new Object[0]);
            HttpRelay httpRelay = this.m_cHttpRelay;
            if (httpRelay != null) {
                httpRelay.setStop(true);
            }
            this.m_cHttpRelay = null;
        }
    }

    public static MangoPlayerLib create(Context context, Uri uri) {
        MangoPlayerLib mangoPlayerLib = new MangoPlayerLib();
        try {
            mangoPlayerLib.setDataSource(context, uri);
            try {
                mangoPlayerLib.prepare();
                return mangoPlayerLib;
            } catch (IllegalStateException unused) {
                mangoPlayerLib.release();
                return null;
            } catch (IOException unused2) {
                mangoPlayerLib.release();
                return null;
            }
        } catch (IllegalArgumentException unused3) {
            mangoPlayerLib.release();
            return null;
        } catch (SecurityException unused4) {
            mangoPlayerLib.release();
            return null;
        } catch (IllegalStateException unused5) {
            mangoPlayerLib.release();
            return null;
        } catch (IOException unused6) {
            mangoPlayerLib.release();
            return null;
        }
    }

    public MangoPlayerLib(boolean z) {
        this.m_cRtspRelay = null;
        this.m_cHttpRelay = null;
        this.m_szURL = null;
        this.m_szCookie = null;
        this.m_szExtHeader = null;
        this.m_bIsRTSP = false;
        this.m_bIsHTTP = false;
        this.m_bIsTCP = z;
        this.m_iMangoPlayerServerDisconnectListener = null;
        this.m_nCompatibleflag = 0;
        setAtrixCompatibleInner();
    }

    public static MangoPlayerLib create(Context context, Uri uri, SurfaceHolder surfaceHolder) {
        MangoPlayerLib mangoPlayerLib = new MangoPlayerLib();
        mangoPlayerLib.setDisplay(surfaceHolder);
        try {
            mangoPlayerLib.setDataSource(context, uri);
            try {
                mangoPlayerLib.prepare();
                return mangoPlayerLib;
            } catch (IllegalStateException unused) {
                mangoPlayerLib.release();
                return null;
            } catch (IOException unused2) {
                mangoPlayerLib.release();
                return null;
            }
        } catch (IllegalArgumentException unused3) {
            mangoPlayerLib.release();
            return null;
        } catch (SecurityException unused4) {
            mangoPlayerLib.release();
            return null;
        } catch (IllegalStateException unused5) {
            mangoPlayerLib.release();
            return null;
        } catch (IOException unused6) {
            mangoPlayerLib.release();
            return null;
        }
    }

    public static MediaPlayer create(Context context, int i) throws IllegalArgumentException {
        throw new IllegalArgumentException("These arguments are not supported");
    }

    public MangoPlayerLib(String str, String str2) {
        this.m_cRtspRelay = null;
        this.m_cHttpRelay = null;
        this.m_szURL = null;
        this.m_szCookie = str;
        this.m_szExtHeader = str2;
        this.m_bIsRTSP = false;
        this.m_bIsHTTP = false;
        this.m_bIsTCP = true;
        this.m_iMangoPlayerServerDisconnectListener = null;
        this.m_nCompatibleflag = 0;
        setAtrixCompatibleInner();
    }

    public MangoPlayerLib(String str, String str2, boolean z) {
        this.m_cRtspRelay = null;
        this.m_cHttpRelay = null;
        this.m_szURL = null;
        this.m_szCookie = str;
        this.m_szExtHeader = str2;
        this.m_bIsRTSP = false;
        this.m_bIsHTTP = false;
        this.m_bIsTCP = z;
        this.m_iMangoPlayerServerDisconnectListener = null;
        this.m_nCompatibleflag = 0;
        setAtrixCompatibleInner();
    }

    public void setDataSource(Context context, Uri uri) throws IllegalStateException, IOException {
        int i;
        int i2;
        String uri2 = uri.toString();
        if (uri2.indexOf("rtsp://") == 0) {
            if (this.m_bIsTCP) {
                this.m_bIsRTSP = true;
            } else {
                this.m_bIsRTSP = false;
            }
        } else if (uri2.indexOf("http://") == 0) {
            this.m_bIsHTTP = true;
        } else {
            this.m_bIsRTSP = false;
        }
        this.m_szURL = uri2;
        if (this.m_bIsRTSP) {
            RtspRelay rtspRelay = new RtspRelay(this.m_szURL, DTB_DEFAULT_LISTEN_PORT, false, this.m_szCookie, this.m_szExtHeader);
            this.m_cRtspRelay = rtspRelay;
            rtspRelay.setOnMangoRTSPRelayServerDisconnectListener(this);
            i = this.m_cRtspRelay.ExecReady(this.m_nCompatibleflag);
            this.m_cRtspRelay.start();
            i2 = this.m_szURL.indexOf("/", 8);
        } else if (this.m_bIsHTTP) {
            HttpRelay httpRelay = new HttpRelay(this.m_szURL, DTB_DEFAULT_LISTEN_PORT, this.m_szCookie, this.m_szExtHeader);
            this.m_cHttpRelay = httpRelay;
            i = httpRelay.getListenPort();
            this.m_cHttpRelay.setOnMangoHTTPRelayServerDisconnectListener(this);
            this.m_cHttpRelay.setDaemon(true);
            this.m_cHttpRelay.start();
            i2 = this.m_szURL.indexOf("/", 8);
        } else {
            i = 554;
            i2 = 0;
        }
        try {
            if (this.m_bIsRTSP) {
                super.setDataSource("rtsp://127.0.0.1:" + i + this.m_szURL.substring(i2));
            } else if (this.m_bIsHTTP) {
                super.setDataSource("http://127.0.0.1:" + i + this.m_szURL.substring(i2));
            } else {
                super.setDataSource(this.m_szURL);
            }
        } catch (IllegalArgumentException unused) {
            DtbLog.cLogPrn(2, "IllegalArgumentException is occoured in setDataSource", new Object[0]);
            if (this.m_bIsRTSP) {
                RtspRelay rtspRelay2 = this.m_cRtspRelay;
                if (rtspRelay2 != null) {
                    rtspRelay2.setStop(true);
                }
                this.m_cRtspRelay = null;
            }
            throw new IllegalStateException("setDataSource error");
        } catch (IllegalStateException unused2) {
            DtbLog.cLogPrn(2, "IllegalStateException is occoured in setDataSource", new Object[0]);
            if (this.m_bIsRTSP) {
                RtspRelay rtspRelay3 = this.m_cRtspRelay;
                if (rtspRelay3 != null) {
                    rtspRelay3.setStop(true);
                }
                this.m_cRtspRelay = null;
            }
            throw new IllegalStateException("setDataSource error");
        } catch (IOException unused3) {
            DtbLog.cLogPrn(2, "IOException is occoured in setDataSource", new Object[0]);
            if (this.m_bIsRTSP) {
                RtspRelay rtspRelay4 = this.m_cRtspRelay;
                if (rtspRelay4 != null) {
                    rtspRelay4.setStop(true);
                }
                this.m_cRtspRelay = null;
            }
            throw new IOException("setDataSource error");
        }
    }
}

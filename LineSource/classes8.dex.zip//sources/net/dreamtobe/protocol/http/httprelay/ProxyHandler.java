package net.dreamtobe.protocol.http.httprelay;

import java.io.IOException;
import java.io.PrintStream;
import net.dreamtobe.common.log.DtbLog;
import org.apache.http.ConnectionReuseStrategy;
import org.apache.http.HttpClientConnection;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.message.BufferedHeader;
import org.apache.http.protocol.HttpContext;
import org.apache.http.protocol.HttpProcessor;
import org.apache.http.protocol.HttpRequestExecutor;
import org.apache.http.protocol.HttpRequestHandler;
import org.apache.http.util.CharArrayBuffer;

public class ProxyHandler implements HttpRequestHandler {
    public static final String HTTP_CONN_KEEPALIVE = "http.proxy.conn-keepalive";
    public static final String HTTP_IN_CONN = "http.proxy.in-conn";
    public static final String HTTP_OUT_CONN = "http.proxy.out-conn";
    public final ConnectionReuseStrategy m_ConnStrategy = new DefaultConnectionReuseStrategy();
    public final HttpRequestExecutor m_HttpExecutor;
    public final HttpProcessor m_HttpProc;
    public final HttpHost m_TargetHost;
    public final String m_szCookie;
    public final String m_szExtHeader;

    public ProxyHandler(HttpHost httpHost, HttpProcessor httpProcessor, HttpRequestExecutor httpRequestExecutor, String str, String str2) {
        this.m_TargetHost = httpHost;
        this.m_HttpProc = httpProcessor;
        this.m_HttpExecutor = httpRequestExecutor;
        this.m_szCookie = str;
        this.m_szExtHeader = str2;
    }

    public void handle(HttpRequest httpRequest, HttpResponse httpResponse, HttpContext httpContext) throws HttpException, IOException {
        HttpClientConnection httpClientConnection = (HttpClientConnection) httpContext.getAttribute("http.proxy.out-conn");
        httpContext.setAttribute("http.connection", httpClientConnection);
        httpContext.setAttribute("http.target_host", this.m_TargetHost);
        DtbLog.cLogPrn(8, ">> Request URI: %s", httpRequest.getRequestLine().getUri());
        httpRequest.removeHeaders("Content-Length");
        httpRequest.removeHeaders("Transfer-Encoding");
        httpRequest.removeHeaders("Connection");
        httpRequest.removeHeaders("Host");
        httpRequest.removeHeaders("Keep-Alive");
        httpRequest.removeHeaders("Proxy-Authenticate");
        httpRequest.removeHeaders("TE");
        httpRequest.removeHeaders("Trailers");
        httpRequest.removeHeaders("Upgrade");
        httpRequest.addHeader("Host", String.valueOf(this.m_TargetHost.getHostName()) + ":" + this.m_TargetHost.getPort());
        if (this.m_szCookie != null) {
            CharArrayBuffer charArrayBuffer = new CharArrayBuffer(this.m_szCookie.length() + 50);
            charArrayBuffer.append(this.m_szCookie);
            httpRequest.setHeader(new BufferedHeader(charArrayBuffer));
        }
        if (this.m_szExtHeader != null) {
            CharArrayBuffer charArrayBuffer2 = new CharArrayBuffer(this.m_szExtHeader.length() + 50);
            charArrayBuffer2.append(this.m_szExtHeader);
            httpRequest.addHeader(new BufferedHeader(charArrayBuffer2));
        }
        if (httpRequest.getLastHeader("Range") != null) {
            DtbLog.cLogPrn(16, "Request range = %s", httpRequest.getLastHeader("Range").getValue());
        }
        this.m_HttpExecutor.preProcess(httpRequest, this.m_HttpProc, httpContext);
        HttpResponse execute = this.m_HttpExecutor.execute(httpRequest, httpClientConnection, httpContext);
        this.m_HttpExecutor.postProcess(httpResponse, this.m_HttpProc, httpContext);
        execute.removeHeaders("Transfer-Encoding");
        execute.removeHeaders("Connection");
        execute.removeHeaders("TE");
        execute.removeHeaders("Trailers");
        execute.removeHeaders("Upgrade");
        httpResponse.setStatusLine(execute.getStatusLine());
        httpResponse.setHeaders(execute.getAllHeaders());
        httpResponse.setEntity(execute.getEntity());
        PrintStream printStream = System.out;
        printStream.println("<< Response: " + httpResponse.getStatusLine());
        DtbLog.cLogPrn(8, "<< Response: %s", httpResponse.getStatusLine());
        boolean keepAlive = this.m_ConnStrategy.keepAlive(httpResponse, httpContext);
        httpContext.setAttribute("http.proxy.conn-keepalive", new Boolean(keepAlive));
        Object[] objArr = new Object[1];
        objArr[0] = keepAlive ? "true" : "false";
        DtbLog.cLogPrn(16, "KeepAlive is %s", objArr);
    }
}

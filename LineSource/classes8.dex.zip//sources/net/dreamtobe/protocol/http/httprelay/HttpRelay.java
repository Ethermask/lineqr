package net.dreamtobe.protocol.http.httprelay;

import java.io.IOException;
import java.net.ServerSocket;
import net.dreamtobe.common.log.DtbLog;
import net.dreamtobe.protocol.http.httprelay.ProxyThread;
import net.dreamtobe.protocol.rtsp.util.UrlString;
import org.apache.http.HttpHost;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.DefaultHttpResponseFactory;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpProcessor;
import org.apache.http.protocol.HttpRequestExecutor;
import org.apache.http.protocol.HttpRequestHandlerRegistry;
import org.apache.http.protocol.HttpService;
import org.apache.http.protocol.RequestConnControl;
import org.apache.http.protocol.RequestContent;
import org.apache.http.protocol.RequestExpectContinue;
import org.apache.http.protocol.RequestTargetHost;
import org.apache.http.protocol.RequestUserAgent;
import org.apache.http.protocol.ResponseConnControl;
import org.apache.http.protocol.ResponseContent;
import org.apache.http.protocol.ResponseDate;
import org.apache.http.protocol.ResponseServer;

public class HttpRelay extends Thread implements ProxyThread.OnMangoHTTPServerDisconnectListener {
    public static final int DTB_ACCEPT_TIMEOUT = 2000;
    public final HttpService m_HttpService;
    public final HttpParams m_Params;
    public final ServerSocket m_Serversocket;
    public final HttpHost m_Target;
    public boolean m_bIsStop;
    public OnMangoHTTPRelayServerDisconnectListener m_iRelayServerDisconnectListener;
    public final int m_nDestPort;
    public final int m_nListenPort;
    public final String m_szCookie;
    public final String m_szDestAddr;
    public final String m_szExtHeader;
    public final String m_szURL;

    public interface OnMangoHTTPRelayServerDisconnectListener {
        void OnMangoHTTPRelayServerDisconnect(int i);
    }

    public HttpRelay(String str, int i, String str2, String str3) throws IOException {
        this.m_szURL = str;
        this.m_szCookie = str2;
        this.m_szExtHeader = str3;
        this.m_szDestAddr = UrlString.UtilURLGetAddr(str);
        this.m_nDestPort = UrlString.UtilURLGetPort(this.m_szURL) == 0 ? 80 : UrlString.UtilURLGetPort(this.m_szURL);
        this.m_Target = new HttpHost(this.m_szDestAddr, this.m_nDestPort);
        ServerSocket serverSocket = new ServerSocket(0);
        this.m_Serversocket = serverSocket;
        serverSocket.setReuseAddress(true);
        this.m_Serversocket.setSoTimeout(2000);
        this.m_nListenPort = this.m_Serversocket.getLocalPort();
        this.m_iRelayServerDisconnectListener = null;
        this.m_bIsStop = false;
        BasicHttpParams basicHttpParams = new BasicHttpParams();
        this.m_Params = basicHttpParams;
        basicHttpParams.setIntParameter("http.socket.timeout", 5000).setIntParameter("http.socket.buffer-size", 8192).setBooleanParameter("http.connection.stalecheck", false).setBooleanParameter("http.tcp.nodelay", true).setParameter("http.origin-server", "MangoPlayerLib/1.1");
        BasicHttpProcessor basicHttpProcessor = new BasicHttpProcessor();
        basicHttpProcessor.addInterceptor(new RequestContent());
        basicHttpProcessor.addInterceptor(new RequestTargetHost());
        basicHttpProcessor.addInterceptor(new RequestConnControl());
        basicHttpProcessor.addInterceptor(new RequestUserAgent());
        basicHttpProcessor.addInterceptor(new RequestExpectContinue());
        BasicHttpProcessor basicHttpProcessor2 = new BasicHttpProcessor();
        basicHttpProcessor2.addInterceptor(new ResponseDate());
        basicHttpProcessor2.addInterceptor(new ResponseServer());
        basicHttpProcessor2.addInterceptor(new ResponseContent());
        basicHttpProcessor2.addInterceptor(new ResponseConnControl());
        HttpRequestExecutor httpRequestExecutor = new HttpRequestExecutor();
        HttpRequestHandlerRegistry httpRequestHandlerRegistry = new HttpRequestHandlerRegistry();
        httpRequestHandlerRegistry.register("*", new ProxyHandler(this.m_Target, basicHttpProcessor2, httpRequestExecutor, this.m_szCookie, this.m_szExtHeader));
        HttpService httpService = new HttpService(basicHttpProcessor, new DefaultConnectionReuseStrategy(), new DefaultHttpResponseFactory());
        this.m_HttpService = httpService;
        httpService.setHandlerResolver(httpRequestHandlerRegistry);
        this.m_HttpService.setParams(this.m_Params);
        DtbLog.cLogPrn(8, "URL = %s, Target Address = %s, Target Port = %d, ListenPort = %d\n", this.m_szURL, this.m_szDestAddr, Integer.valueOf(this.m_nDestPort), Integer.valueOf(this.m_nListenPort));
    }

    public void OnMangoHTTPServerDisconnect() {
        DtbLog.cLogPrn(8, "HTTP Server is disconnected", new Object[0]);
        OnMangoHTTPRelayServerDisconnectListener onMangoHTTPRelayServerDisconnectListener = this.m_iRelayServerDisconnectListener;
        if (onMangoHTTPRelayServerDisconnectListener != null) {
            onMangoHTTPRelayServerDisconnectListener.OnMangoHTTPRelayServerDisconnect(1);
        }
    }

    public int getListenPort() {
        return this.m_nListenPort;
    }

    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:50:0x00e5 */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00ca A[SYNTHETIC, Splitter:B:42:0x00ca] */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00de  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x0102 A[SYNTHETIC, Splitter:B:57:0x0102] */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x001d A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r13 = this;
            java.lang.String r0 = "The socket for client is closed"
            java.lang.String r1 = "Proxy termination is checked"
            r2 = 1
            java.lang.Object[] r3 = new java.lang.Object[r2]
            java.net.ServerSocket r4 = r13.m_Serversocket
            int r4 = r4.getLocalPort()
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r5 = 0
            r3[r5] = r4
            r4 = 8
            java.lang.String r6 = "Listening on port %d"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r4, r6, r3)
            r3 = 0
            r6 = r3
        L_0x001d:
            boolean r7 = r13.m_bIsStop
            if (r7 == 0) goto L_0x0023
            r3 = r6
            goto L_0x0054
        L_0x0023:
            if (r6 == 0) goto L_0x006e
            r7 = 100
            r6.join(r7)     // Catch:{ InterruptedException -> 0x003a }
            boolean r7 = r6.isAlive()
            if (r7 == 0) goto L_0x0031
            goto L_0x001d
        L_0x0031:
            java.lang.Object[] r6 = new java.lang.Object[r5]
            net.dreamtobe.common.log.DtbLog.cLogPrn(r4, r1, r6)
            r6 = r3
            goto L_0x006e
        L_0x0038:
            r7 = move-exception
            goto L_0x0061
        L_0x003a:
            r7 = move-exception
            java.lang.String r8 = "HttpRelay is interrupted : %s"
            java.lang.Object[] r9 = new java.lang.Object[r2]     // Catch:{ all -> 0x0038 }
            java.lang.String r7 = r7.getMessage()     // Catch:{ all -> 0x0038 }
            r9[r5] = r7     // Catch:{ all -> 0x0038 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r4, r8, r9)     // Catch:{ all -> 0x0038 }
            boolean r7 = r6.isAlive()
            if (r7 == 0) goto L_0x004f
            goto L_0x001d
        L_0x004f:
            java.lang.Object[] r0 = new java.lang.Object[r5]
            net.dreamtobe.common.log.DtbLog.cLogPrn(r4, r1, r0)
        L_0x0054:
            if (r3 == 0) goto L_0x0059
            r3.setStop(r2)
        L_0x0059:
            java.lang.Object[] r0 = new java.lang.Object[r5]
            java.lang.String r1 = "HttpRelay End"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r4, r1, r0)
            return
        L_0x0061:
            boolean r8 = r6.isAlive()
            if (r8 == 0) goto L_0x0068
            goto L_0x001d
        L_0x0068:
            java.lang.Object[] r0 = new java.lang.Object[r5]
            net.dreamtobe.common.log.DtbLog.cLogPrn(r4, r1, r0)
            throw r7
        L_0x006e:
            r7 = 16
            java.net.ServerSocket r8 = r13.m_Serversocket     // Catch:{ IOException -> 0x00f1 }
            java.net.Socket r8 = r8.accept()     // Catch:{ IOException -> 0x00f1 }
            org.apache.http.impl.DefaultHttpServerConnection r9 = new org.apache.http.impl.DefaultHttpServerConnection     // Catch:{ IOException -> 0x00ef }
            r9.<init>()     // Catch:{ IOException -> 0x00ef }
            java.lang.String r10 = "Incoming connection from %s"
            java.lang.Object[] r11 = new java.lang.Object[r2]     // Catch:{ IOException -> 0x00ef }
            java.net.InetAddress r12 = r8.getInetAddress()     // Catch:{ IOException -> 0x00ef }
            r11[r5] = r12     // Catch:{ IOException -> 0x00ef }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r4, r10, r11)     // Catch:{ IOException -> 0x00ef }
            org.apache.http.params.HttpParams r10 = r13.m_Params     // Catch:{ IOException -> 0x00ef }
            r9.bind(r8, r10)     // Catch:{ IOException -> 0x00ef }
            java.net.Socket r8 = new java.net.Socket     // Catch:{ IOException -> 0x00c7 }
            org.apache.http.HttpHost r10 = r13.m_Target     // Catch:{ IOException -> 0x00c7 }
            java.lang.String r10 = r10.getHostName()     // Catch:{ IOException -> 0x00c7 }
            org.apache.http.HttpHost r11 = r13.m_Target     // Catch:{ IOException -> 0x00c7 }
            int r11 = r11.getPort()     // Catch:{ IOException -> 0x00c7 }
            r8.<init>(r10, r11)     // Catch:{ IOException -> 0x00c7 }
            org.apache.http.impl.DefaultHttpClientConnection r10 = new org.apache.http.impl.DefaultHttpClientConnection     // Catch:{ IOException -> 0x00c8 }
            r10.<init>()     // Catch:{ IOException -> 0x00c8 }
            org.apache.http.params.HttpParams r11 = r13.m_Params     // Catch:{ IOException -> 0x00c8 }
            r10.bind(r8, r11)     // Catch:{ IOException -> 0x00c8 }
            java.lang.Object[] r6 = new java.lang.Object[r2]
            java.net.InetAddress r7 = r8.getInetAddress()
            r6[r5] = r7
            java.lang.String r7 = "Outgoing connection to %s"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r4, r7, r6)
            net.dreamtobe.protocol.http.httprelay.ProxyThread r6 = new net.dreamtobe.protocol.http.httprelay.ProxyThread
            org.apache.http.protocol.HttpService r7 = r13.m_HttpService
            r6.<init>(r7, r9, r10)
            r6.setDaemon(r2)
            r6.setOnMangoHTTPServerDisconnectListener(r13)
            r6.start()
            goto L_0x001d
        L_0x00c7:
            r8 = r3
        L_0x00c8:
            if (r8 == 0) goto L_0x00de
            net.dreamtobe.protocol.http.httprelay.HttpRelay$OnMangoHTTPRelayServerDisconnectListener r10 = r13.m_iRelayServerDisconnectListener     // Catch:{ IOException -> 0x00e5 }
            if (r10 == 0) goto L_0x00d3
            net.dreamtobe.protocol.http.httprelay.HttpRelay$OnMangoHTTPRelayServerDisconnectListener r10 = r13.m_iRelayServerDisconnectListener     // Catch:{ IOException -> 0x00e5 }
            r10.OnMangoHTTPRelayServerDisconnect(r2)     // Catch:{ IOException -> 0x00e5 }
        L_0x00d3:
            r8.close()     // Catch:{ IOException -> 0x00e5 }
            java.lang.String r8 = "The socket for server is closed"
            java.lang.Object[] r10 = new java.lang.Object[r5]     // Catch:{ IOException -> 0x00e5 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r7, r8, r10)     // Catch:{ IOException -> 0x00e5 }
            goto L_0x00e5
        L_0x00de:
            net.dreamtobe.protocol.http.httprelay.HttpRelay$OnMangoHTTPRelayServerDisconnectListener r8 = r13.m_iRelayServerDisconnectListener
            if (r8 == 0) goto L_0x00e5
            r8.OnMangoHTTPRelayServerDisconnect(r5)
        L_0x00e5:
            r9.close()     // Catch:{ IOException -> 0x001d }
            java.lang.Object[] r8 = new java.lang.Object[r5]     // Catch:{ IOException -> 0x001d }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r7, r0, r8)     // Catch:{ IOException -> 0x001d }
            goto L_0x001d
        L_0x00ef:
            r9 = move-exception
            goto L_0x00f3
        L_0x00f1:
            r9 = move-exception
            r8 = r3
        L_0x00f3:
            java.lang.Object[] r10 = new java.lang.Object[r2]
            java.lang.String r9 = r9.getMessage()
            r10[r5] = r9
            java.lang.String r9 = "IOException %s"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r7, r9, r10)
            if (r8 == 0) goto L_0x001d
            r8.close()     // Catch:{ IOException -> 0x001d }
            java.lang.Object[] r8 = new java.lang.Object[r5]     // Catch:{ IOException -> 0x001d }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r7, r0, r8)     // Catch:{ IOException -> 0x001d }
            goto L_0x001d
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.http.httprelay.HttpRelay.run():void");
    }

    public void setOnMangoHTTPRelayServerDisconnectListener(OnMangoHTTPRelayServerDisconnectListener onMangoHTTPRelayServerDisconnectListener) {
        this.m_iRelayServerDisconnectListener = onMangoHTTPRelayServerDisconnectListener;
    }

    public void setStop(boolean z) {
        this.m_bIsStop = z;
    }
}

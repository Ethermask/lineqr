package net.dreamtobe.protocol.http.httprelay;

import org.apache.http.HttpClientConnection;
import org.apache.http.HttpServerConnection;
import org.apache.http.protocol.HttpService;

public class ProxyThread extends Thread {
    public static final String HTTP_CONN_KEEPALIVE = "http.proxy.conn-keepalive";
    public static final String HTTP_IN_CONN = "http.proxy.in-conn";
    public static final String HTTP_OUT_CONN = "http.proxy.out-conn";
    public final HttpService m_HttpService;
    public final HttpServerConnection m_InConn;
    public final HttpClientConnection m_OutConn;
    public boolean m_bIsStop = false;
    public OnMangoHTTPServerDisconnectListener m_iServerDisconnectListener = null;

    public interface OnMangoHTTPServerDisconnectListener {
        void OnMangoHTTPServerDisconnect();
    }

    public ProxyThread(HttpService httpService, HttpServerConnection httpServerConnection, HttpClientConnection httpClientConnection) {
        this.m_HttpService = httpService;
        this.m_InConn = httpServerConnection;
        this.m_OutConn = httpClientConnection;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(8:0|(4:1|2|3|(2:44|5)(2:6|(2:46|8)(2:9|(2:45|11))))|12|13|14|15|35|37) */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x005f */
    /* JADX WARNING: Missing exception handler attribute for start block: B:40:0x00a9 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r6 = this;
            r0 = 0
            java.lang.Object[] r1 = new java.lang.Object[r0]
            r2 = 8
            java.lang.String r3 = "New connection thread"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r3, r1)
            org.apache.http.protocol.BasicHttpContext r1 = new org.apache.http.protocol.BasicHttpContext
            r3 = 0
            r1.<init>(r3)
            org.apache.http.HttpServerConnection r3 = r6.m_InConn
            java.lang.String r4 = "http.proxy.in-conn"
            r1.setAttribute(r4, r3)
            org.apache.http.HttpClientConnection r3 = r6.m_OutConn
            java.lang.String r4 = "http.proxy.out-conn"
            r1.setAttribute(r4, r3)
        L_0x001e:
            r3 = 1
            boolean r4 = r6.m_bIsStop     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            if (r4 == 0) goto L_0x0024
            goto L_0x005a
        L_0x0024:
            org.apache.http.HttpServerConnection r4 = r6.m_InConn     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            boolean r4 = r4.isOpen()     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            if (r4 != 0) goto L_0x0032
            org.apache.http.HttpClientConnection r1 = r6.m_OutConn     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            r1.close()     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            goto L_0x005a
        L_0x0032:
            org.apache.http.protocol.HttpService r4 = r6.m_HttpService     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            org.apache.http.HttpServerConnection r5 = r6.m_InConn     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            r4.handleRequest(r5, r1)     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            java.lang.String r4 = "http.proxy.conn-keepalive"
            java.lang.Object r4 = r1.getAttribute(r4)     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            java.lang.Boolean r4 = (java.lang.Boolean) r4     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            java.lang.Boolean r5 = java.lang.Boolean.TRUE     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            boolean r4 = r5.equals(r4)     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            if (r4 != 0) goto L_0x001e
            org.apache.http.HttpClientConnection r1 = r6.m_OutConn     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            r1.close()     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            org.apache.http.HttpServerConnection r1 = r6.m_InConn     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            r1.close()     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            java.lang.String r1 = "Request handle complete on non keep-alive"
            java.lang.Object[] r4 = new java.lang.Object[r0]     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r1, r4)     // Catch:{ ConnectionClosedException -> 0x008f, IOException -> 0x007b, HttpException -> 0x0067 }
        L_0x005a:
            org.apache.http.HttpServerConnection r1 = r6.m_InConn     // Catch:{ IOException -> 0x005f }
            r1.shutdown()     // Catch:{ IOException -> 0x005f }
        L_0x005f:
            org.apache.http.HttpClientConnection r1 = r6.m_OutConn     // Catch:{ IOException -> 0x009c }
            r1.shutdown()     // Catch:{ IOException -> 0x009c }
            goto L_0x009c
        L_0x0065:
            r0 = move-exception
            goto L_0x00a4
        L_0x0067:
            r1 = move-exception
            java.lang.String r4 = "Unrecoverable HTTP protocol violation: %s"
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ all -> 0x0065 }
            java.lang.String r1 = r1.getMessage()     // Catch:{ all -> 0x0065 }
            r3[r0] = r1     // Catch:{ all -> 0x0065 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r4, r3)     // Catch:{ all -> 0x0065 }
            org.apache.http.HttpServerConnection r1 = r6.m_InConn     // Catch:{ IOException -> 0x005f }
            r1.shutdown()     // Catch:{ IOException -> 0x005f }
            goto L_0x005f
        L_0x007b:
            r1 = move-exception
            java.lang.String r4 = "I/O error: %s"
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ all -> 0x0065 }
            java.lang.String r1 = r1.getMessage()     // Catch:{ all -> 0x0065 }
            r3[r0] = r1     // Catch:{ all -> 0x0065 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r4, r3)     // Catch:{ all -> 0x0065 }
            org.apache.http.HttpServerConnection r1 = r6.m_InConn     // Catch:{ IOException -> 0x005f }
            r1.shutdown()     // Catch:{ IOException -> 0x005f }
            goto L_0x005f
        L_0x008f:
            java.lang.String r1 = "Client closed connection"
            java.lang.Object[] r3 = new java.lang.Object[r0]     // Catch:{ all -> 0x0065 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r1, r3)     // Catch:{ all -> 0x0065 }
            org.apache.http.HttpServerConnection r1 = r6.m_InConn     // Catch:{ IOException -> 0x005f }
            r1.shutdown()     // Catch:{ IOException -> 0x005f }
            goto L_0x005f
        L_0x009c:
            java.lang.Object[] r0 = new java.lang.Object[r0]
            java.lang.String r1 = "Close connection thread"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r1, r0)
            return
        L_0x00a4:
            org.apache.http.HttpServerConnection r1 = r6.m_InConn     // Catch:{ IOException -> 0x00a9 }
            r1.shutdown()     // Catch:{ IOException -> 0x00a9 }
        L_0x00a9:
            org.apache.http.HttpClientConnection r1 = r6.m_OutConn     // Catch:{ IOException -> 0x00ae }
            r1.shutdown()     // Catch:{ IOException -> 0x00ae }
        L_0x00ae:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.http.httprelay.ProxyThread.run():void");
    }

    public void setOnMangoHTTPServerDisconnectListener(OnMangoHTTPServerDisconnectListener onMangoHTTPServerDisconnectListener) {
        this.m_iServerDisconnectListener = onMangoHTTPServerDisconnectListener;
    }

    public void setStop(boolean z) {
        this.m_bIsStop = z;
    }
}

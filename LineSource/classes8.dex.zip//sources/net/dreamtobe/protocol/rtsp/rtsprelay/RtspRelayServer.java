package net.dreamtobe.protocol.rtsp.rtsprelay;

import e.e.b.a.a;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.DatagramSocket;
import java.net.Socket;
import net.dreamtobe.common.log.DtbLog;
import net.dreamtobe.protocol.rtsp.util.RtpChannel;
import net.dreamtobe.protocol.rtsp.util.RtpMessage;
import net.dreamtobe.protocol.rtsp.util.RtspInfo;
import net.dreamtobe.protocol.rtsp.util.RtspMessageQueue;
import net.dreamtobe.protocol.rtsp.util.RtspParser;
import net.dreamtobe.protocol.rtsp.util.RtspStatus;
import net.dreamtobe.protocol.rtsp.util.UrlString;
import net.sqlcipher.database.SQLiteDatabase;

public class RtspRelayServer extends Thread {
    public static /* synthetic */ int[] $SWITCH_TABLE$net$dreamtobe$protocol$rtsp$util$RtspMethod = null;
    public static final int DTB_UDP_PORT_RANGE = 40000;
    public static final int DTB_UDP_PORT_START = 20000;
    public static final int RTSP_BUFFER_SIZE = 81960;
    public int m_TmpCount;
    public RtpMessage m_TmpRtpPacket;
    public int m_TmpRtpid;
    public int m_TmpRtpsize;
    public char m_TmpRtptoken;
    public RtpChannel m_TmphChannelHandle;
    public int m_TmpnTrackID;
    public byte[] m_arrTmpReturn;
    public boolean m_bIsStop;
    public boolean m_bUDP;
    public RtspMessageQueue m_cMessageQueue;
    public Socket m_cRTSPSock;
    public InputStream m_cRTSPin;
    public OutputStream m_cRTSPout;
    public RtspParser m_cServer;
    public RtspStatus m_eStatus;
    public OnMangoServerDisconnectListener m_iServerDisconnectListener;
    public long m_nCompatibleflag;
    public int m_nDestPort;
    public long m_nPrivateKey;
    public long m_nPublicKey;
    public int m_nSvrMsg;
    public int m_nTmpSize;
    public byte[] m_pPacket;
    public byte[] m_pSvrMsg;
    public byte[] m_pTmpMsg;
    public String m_szCookie;
    public String m_szDestAddr;
    public String m_szExtHeader;
    public String m_szLocalAddr;
    public String m_szTmpMessage;

    public interface OnMangoServerDisconnectListener {
        void OnMangoServerDisconnect();
    }

    public RtspRelayServer(RtspMessageQueue rtspMessageQueue, String str, boolean z, String str2, String str3, long j) throws RtspServerException {
        RtspInfo rtspInfo = new RtspInfo();
        rtspInfo.m_b3GP = true;
        rtspInfo.m_bUDP = false;
        rtspInfo.m_bServer = false;
        this.m_cServer = new RtspParser(rtspInfo);
        this.m_pSvrMsg = new byte[RTSP_BUFFER_SIZE];
        this.m_nSvrMsg = 0;
        this.m_pTmpMsg = new byte[RTSP_BUFFER_SIZE];
        this.m_nSvrMsg = 0;
        this.m_pPacket = new byte[1500];
        this.m_szCookie = str2;
        this.m_szExtHeader = str3;
        this.m_iServerDisconnectListener = null;
        this.m_nCompatibleflag = j;
        this.m_nPublicKey = (long) ((Math.random() * 4.294967295E12d) % 4.294967295E9d);
        this.m_nPrivateKey = 522157951;
        this.m_eStatus = RtspStatus.SS_NONE;
        this.m_cMessageQueue = rtspMessageQueue;
        this.m_szDestAddr = UrlString.UtilURLGetAddr(str);
        int UtilURLGetPort = UrlString.UtilURLGetPort(str);
        this.m_nDestPort = UtilURLGetPort;
        if (UtilURLGetPort == 0) {
            this.m_nDestPort = 554;
        }
        this.m_bUDP = z;
        this.m_bIsStop = false;
        DtbLog.cLogPrn(8, "Destination %s:%d", this.m_szDestAddr, Integer.valueOf(this.m_nDestPort));
        try {
            Socket socket = new Socket(this.m_szDestAddr, this.m_nDestPort);
            this.m_cRTSPSock = socket;
            socket.setSoTimeout(10);
            this.m_cRTSPin = this.m_cRTSPSock.getInputStream();
            this.m_cRTSPout = this.m_cRTSPSock.getOutputStream();
            String str4 = this.m_cRTSPSock.getLocalAddress().toString().split("[ ]*/[ ]*")[1];
            this.m_szLocalAddr = str4;
            DtbLog.cLogPrn(8, "Contructor execute Local Address %s", str4);
        } catch (Exception e2) {
            DtbLog.cLogPrn(1, "RtspServer Contructor Error : %s\n", e2.getMessage());
            throw new RtspServerException("RtspServer Contructor Error : " + e2.getMessage());
        }
    }

    private boolean ParseSvrMessage() {
        int i = this.m_nSvrMsg;
        if (i == 0) {
            return false;
        }
        byte[] bArr = this.m_pSvrMsg;
        if (bArr[0] == 36) {
            int ProcessSvrEmbeddedPakcet = ProcessSvrEmbeddedPakcet(bArr, i);
            this.m_nTmpSize = ProcessSvrEmbeddedPakcet;
            if (ProcessSvrEmbeddedPakcet != -1) {
                int i2 = this.m_nSvrMsg;
                if (i2 > ProcessSvrEmbeddedPakcet) {
                    DtbLog.cLogPrn(64, "Binary Data Remapping (%d)", Integer.valueOf(i2 - ProcessSvrEmbeddedPakcet));
                    byte[] bArr2 = this.m_pSvrMsg;
                    int i3 = this.m_nTmpSize;
                    System.arraycopy(bArr2, i3, this.m_pTmpMsg, 0, this.m_nSvrMsg - i3);
                    System.arraycopy(this.m_pTmpMsg, 0, this.m_pSvrMsg, 0, this.m_nSvrMsg - this.m_nTmpSize);
                    this.m_nSvrMsg -= this.m_nTmpSize;
                } else {
                    DtbLog.cLogPrn(64, "Binary Data all used", new Object[0]);
                    this.m_nSvrMsg = 0;
                }
            }
            return false;
        }
        byte[] RTSPParsingMessage = this.m_cServer.RTSPParsingMessage(new String(this.m_pSvrMsg, 0, this.m_nSvrMsg));
        this.m_arrTmpReturn = RTSPParsingMessage;
        if (RTSPParsingMessage == null) {
            DtbLog.cLogPrn(32, "RTSPParsingMessage returned null", new Object[0]);
            this.m_nSvrMsg = 0;
        } else {
            try {
                if (RTSPParsingMessage.length != 0) {
                    DtbLog.cLogPrn(32, "Received Data Remapping (%d)", Integer.valueOf(this.m_nSvrMsg - this.m_cServer.RTSPGetMessage().length()));
                    System.arraycopy(this.m_pSvrMsg, this.m_cServer.RTSPGetMessage().length(), this.m_pTmpMsg, 0, this.m_nSvrMsg - this.m_cServer.RTSPGetMessage().length());
                    System.arraycopy(this.m_pTmpMsg, 0, this.m_pSvrMsg, 0, this.m_nSvrMsg - this.m_cServer.RTSPGetMessage().length());
                    this.m_nSvrMsg -= this.m_cServer.RTSPGetMessage().length();
                } else {
                    DtbLog.cLogPrn(32, "RTSPParsingMessage returned size 0", new Object[0]);
                    this.m_nSvrMsg = 0;
                }
                return true;
            } catch (Exception e2) {
                DtbLog.cLogPrn(16, "arrReturn.length(%d): %s", Integer.valueOf(this.m_arrTmpReturn.length), e2.getMessage());
            }
        }
        return false;
    }

    private void ProcessCliEmbeddedPakcet() {
        this.m_TmpCount = 0;
        while (this.m_TmpCount < this.m_cServer.RTSPGetTrackCnt()) {
            RtpChannel RTSPGetChannel = this.m_cServer.RTSPGetChannel(this.m_TmpCount);
            this.m_TmphChannelHandle = RTSPGetChannel;
            int GetTrackID = RTSPGetChannel.GetTrackID();
            this.m_TmpnTrackID = GetTrackID;
            RtpMessage PopRtcpRx = this.m_cMessageQueue.PopRtcpRx(GetTrackID);
            this.m_TmpRtpPacket = PopRtcpRx;
            if (PopRtcpRx != null) {
                byte[] bArr = this.m_pPacket;
                bArr[0] = 36;
                bArr[1] = (byte) this.m_cServer.RTSPGetRTCPRemotePort(this.m_TmphChannelHandle.GetTrackID());
                byte[] bArr2 = this.m_pPacket;
                RtpMessage rtpMessage = this.m_TmpRtpPacket;
                int i = rtpMessage.m_nSize;
                bArr2[2] = (byte) (i >> 16);
                bArr2[3] = (byte) (i & 255);
                try {
                    System.arraycopy(rtpMessage.m_pBuffer, 0, bArr2, 4, i);
                    this.m_cRTSPout.write(this.m_pPacket, 0, this.m_TmpRtpPacket.m_nSize + 4);
                    DtbLog.cLogPrn(64, "Send Packet to server Info : ID(%d), Size(%d:%x:%x)", Integer.valueOf(this.m_cServer.RTSPGetRTCPRemotePort(this.m_TmphChannelHandle.GetTrackID())), Integer.valueOf(this.m_TmpRtpPacket.m_nSize), Byte.valueOf(this.m_pPacket[2]), Byte.valueOf(this.m_pPacket[3]));
                } catch (Exception e2) {
                    DtbLog.cLogPrn(64, "[ProcessCliEmbeddedPakcet]: Error Track %d %s", Integer.valueOf(this.m_TmpnTrackID), e2.getMessage());
                }
            }
            this.m_TmpCount++;
        }
    }

    private void ProcessCliMessage(String str) {
        this.m_szTmpMessage = str;
        int i = a()[this.m_cServer.RTSPGetReqMethod().ordinal()];
        if (i == 3) {
            this.m_eStatus = RtspStatus.SS_INIT;
            this.m_szTmpMessage = ProcessDescribe(str);
        } else if (i == 4) {
            this.m_eStatus = RtspStatus.SS_READY;
            this.m_szTmpMessage = ProcessSetup(str);
        } else if (i == 5) {
            this.m_eStatus = RtspStatus.SS_PLAY;
        } else if (i == 6) {
            this.m_eStatus = RtspStatus.SS_PAUSE;
        } else if (i == 7) {
            this.m_eStatus = RtspStatus.SS_CLOSE;
        }
        DtbLog.cLogPrn(8, "Server IP : %s:%d , Dest IP %s:%d", this.m_cServer.RTSPGetAddress(), Integer.valueOf(this.m_cServer.RTSPGetPort()), this.m_szDestAddr, Integer.valueOf(this.m_nDestPort));
        String replaceAll = this.m_szTmpMessage.replaceAll(this.m_cServer.RTSPGetAddress(), this.m_szDestAddr);
        this.m_szTmpMessage = replaceAll;
        String replaceAll2 = replaceAll.replaceAll(String.format(":%d", new Object[]{Integer.valueOf(this.m_cServer.RTSPGetPort())}), String.format(":%d", new Object[]{Integer.valueOf(this.m_nDestPort)}));
        this.m_szTmpMessage = replaceAll2;
        DtbLog.cLogPrn(8, "Send Message to server :\n%s", replaceAll2);
        try {
            this.m_cRTSPout.write(this.m_szTmpMessage.getBytes(SQLiteDatabase.KEY_ENCODING));
        } catch (UnsupportedEncodingException unused) {
        } catch (Exception e2) {
            DtbLog.cLogPrn(64, "[RTSPClient]:Write Message error %s", e2.getMessage());
        }
    }

    private String ProcessDescribe(String str) {
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        int i = 0;
        while (length != 0) {
            String UtilStrGetLine = UrlString.UtilStrGetLine(str, i);
            int length2 = UtilStrGetLine.length();
            if (UtilStrGetLine.indexOf("CSeq") == 0) {
                sb.append(UtilStrGetLine);
                sb.append(String.format("x-dtb-key: %d\r\n", new Object[]{Long.valueOf(this.m_nPublicKey)}));
                String str2 = this.m_szCookie;
                if (str2 != null) {
                    sb.append(str2);
                    if (this.m_szCookie.indexOf("\r\n") == -1) {
                        sb.append("\r\n");
                    }
                }
                String str3 = this.m_szExtHeader;
                if (str3 != null) {
                    sb.append(str3);
                    if (this.m_szExtHeader.indexOf("\r\n") == -1) {
                        sb.append("\r\n");
                    }
                }
            } else {
                sb.append(UtilStrGetLine);
            }
            i += length2;
            length -= UtilStrGetLine.length();
        }
        return sb.toString();
    }

    private String ProcessDescribeResponse(String str) {
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        int i = 0;
        boolean z = true;
        int i2 = 0;
        while (true) {
            if (length == 0) {
                break;
            }
            String UtilStrGetLine = UrlString.UtilStrGetLine(str, i2);
            int length2 = UtilStrGetLine.length();
            if (UtilStrGetLine.indexOf("x-dtb-key") != 0) {
                sb.append(UtilStrGetLine);
            } else if ((this.m_cServer.RTSPGetKey() ^ this.m_nPrivateKey) != this.m_nPublicKey) {
                DtbLog.cLogPrn(8, "Invalide Key received", new Object[0]);
                break;
            } else {
                z = false;
            }
            i2 += length2;
            length -= UtilStrGetLine.length();
        }
        if (z) {
            DtbLog.cLogPrn(8, "Not Dreamtobe Streaming Server", new Object[0]);
            int length3 = str.length();
            a.I2(sb, 0, "RTSP/1.0 401 Unauthorized\r\n");
            while (length3 != 0) {
                String UtilStrGetLine2 = UrlString.UtilStrGetLine(str, i);
                int length4 = UtilStrGetLine2.length();
                if (UtilStrGetLine2.indexOf("CSeq") == 0) {
                    sb.append(UtilStrGetLine2);
                } else if (UtilStrGetLine2.indexOf("Date") == 0) {
                    sb.append(UtilStrGetLine2);
                } else if (UtilStrGetLine2.indexOf("Server") == 0) {
                    sb.append(UtilStrGetLine2);
                }
                i += length4;
                length3 -= UtilStrGetLine2.length();
            }
            sb.append("\r\n");
        }
        return sb.toString();
    }

    private String ProcessSetup(String str) {
        int i;
        int i2;
        StringBuilder sb = new StringBuilder();
        if (this.m_bUDP) {
            DatagramSocket datagramSocket = null;
            int i3 = 0;
            int i4 = 0;
            int i5 = 0;
            boolean z = true;
            while (true) {
                if (i3 >= 10000) {
                    i = i4;
                    i2 = i5;
                    break;
                }
                while (z && i3 < 10000) {
                    i3++;
                    i4 = ((((int) Math.random()) * 100000) % 40000) + 20000;
                    if (i4 % 2 != 0) {
                        i4++;
                    }
                    try {
                        z = false;
                        datagramSocket = new DatagramSocket(i4);
                    } catch (Exception e2) {
                        DtbLog.cLogPrn(64, "[Error] ProcessSetup : %s for port number (%d)\n", e2.getMessage(), Integer.valueOf(i4));
                    }
                }
                int i6 = i4 + 1;
                try {
                    new DatagramSocket(i6);
                    i = i4;
                    i2 = i6;
                    break;
                } catch (Exception e3) {
                    DtbLog.cLogPrn(64, "[Error] ProcessSetup : %s for port number (%d)\n", e3.getMessage(), Integer.valueOf(i6));
                    datagramSocket.close();
                    i5 = i6;
                }
            }
            int RTSPGetReqIndex = this.m_cServer.RTSPGetReqIndex();
            this.m_cServer.RTSPSetRTPLocalPort(RTSPGetReqIndex, i);
            this.m_cServer.RTSPSetRTCPLocalPort(RTSPGetReqIndex, i2);
            int length = str.length();
            int i7 = 0;
            while (length != 0) {
                String UtilStrGetLine = UrlString.UtilStrGetLine(str, i7);
                int length2 = UtilStrGetLine.length();
                if (UtilStrGetLine.indexOf("Transport") == 0) {
                    sb.append(String.format("Transport: RTP/AVP;unicast;client_port=%d-%d;mode=play\r\n", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)}));
                } else {
                    sb.append(UtilStrGetLine);
                }
                i7 += length2;
                length -= UtilStrGetLine.length();
            }
        } else {
            int RTSPGetReqIndex2 = this.m_cServer.RTSPGetReqIndex();
            int i8 = (RTSPGetReqIndex2 - 1) * 2;
            int i9 = i8 + 1;
            int length3 = str.length();
            int i10 = 0;
            while (length3 != 0) {
                String UtilStrGetLine2 = UrlString.UtilStrGetLine(str, i10);
                int length4 = UtilStrGetLine2.length();
                if (UtilStrGetLine2.indexOf("Transport") == 0) {
                    sb.append(String.format("Transport: RTP/AVP/TCP;unicast;interleaved=%d-%d;mode=play\r\n", new Object[]{Integer.valueOf(i8), Integer.valueOf(i9)}));
                } else {
                    sb.append(UtilStrGetLine2);
                }
                i10 += length4;
                length3 -= UtilStrGetLine2.length();
            }
            this.m_cServer.RTSPSetRTPLocalPort(RTSPGetReqIndex2, i8);
            this.m_cServer.RTSPSetRTCPLocalPort(RTSPGetReqIndex2, i9);
        }
        return sb.toString();
    }

    private int ProcessSvrEmbeddedPakcet(byte[] bArr, int i) {
        int i2;
        char c = (char) bArr[0];
        this.m_TmpRtptoken = c;
        byte b = bArr[1];
        this.m_TmpRtpid = b;
        byte b2 = bArr[2] & 255;
        this.m_TmpRtpsize = b2;
        int i3 = b2 << 8;
        this.m_TmpRtpsize = i3;
        this.m_TmpRtpsize = i3 + (bArr[3] & 255);
        if (c != '$') {
            DtbLog.cLogPrn(64, "Not RTP Paket", new Object[0]);
            return -1;
        }
        DtbLog.cLogPrn(64, "Receive Packet from server Info : ID(%d), Size(%d:%x:%x)", Integer.valueOf(b), Integer.valueOf(this.m_TmpRtpsize), Byte.valueOf(bArr[2]), Byte.valueOf(bArr[3]));
        if (this.m_TmpRtpsize + 4 > i) {
            DtbLog.cLogPrn(64, "[ProcessEmbeddedPakcet]Not entire packet (%d:%d:%d)\n", Integer.valueOf(this.m_TmpRtpid), Integer.valueOf(this.m_TmpRtpsize), Integer.valueOf(i));
            return -1;
        }
        this.m_TmpCount = 0;
        while (this.m_TmpCount < this.m_cServer.RTSPGetTrackCnt()) {
            int RTSPGetTrackIDFromRTPPort = this.m_cServer.RTSPGetTrackIDFromRTPPort(this.m_TmpRtpid);
            this.m_TmpnTrackID = RTSPGetTrackIDFromRTPPort;
            if (RTSPGetTrackIDFromRTPPort != -1) {
                this.m_cMessageQueue.PushRtp(bArr, 4, this.m_TmpRtpsize, RTSPGetTrackIDFromRTPPort);
                i2 = this.m_TmpRtpsize;
            } else {
                int RTSPGetTrackIDFromRTCPPort = this.m_cServer.RTSPGetTrackIDFromRTCPPort(this.m_TmpRtpid);
                this.m_TmpnTrackID = RTSPGetTrackIDFromRTCPPort;
                if (RTSPGetTrackIDFromRTCPPort != -1) {
                    this.m_cMessageQueue.PushRtcpTx(bArr, 4, this.m_TmpRtpsize, RTSPGetTrackIDFromRTCPPort);
                    i2 = this.m_TmpRtpsize;
                } else {
                    this.m_TmpCount++;
                }
            }
            return i2 + 4;
        }
        return -1;
    }

    private int ProcessSvrMessage() {
        String RTSPGetMessage = this.m_cServer.RTSPGetMessage();
        if (RTSPGetMessage.length() == 0) {
            return -1;
        }
        this.m_szTmpMessage = RTSPGetMessage;
        DtbLog.cLogPrn(1, "Message is passed from server side to client side for rtsp message", new Object[0]);
        if (a()[this.m_cServer.RTSPGetReqMethod().ordinal()] == 3 && this.m_cServer.RTSPGetErrorCode() == 0) {
            this.m_szTmpMessage = ProcessDescribeResponse(RTSPGetMessage);
        }
        this.m_cMessageQueue.PushMsg(this.m_szTmpMessage, false);
        if (this.m_eStatus != RtspStatus.SS_CLOSE) {
            return -1;
        }
        DtbLog.cLogPrn(16, "SS_CLOSE", new Object[0]);
        return -2;
    }

    private String ReadCliMessage() {
        this.m_szTmpMessage = null;
        String GetMsg = this.m_cMessageQueue.GetMsg(false);
        this.m_szTmpMessage = GetMsg;
        if (GetMsg != null) {
            this.m_cServer.RTSPParsingMessage(GetMsg);
        }
        return this.m_szTmpMessage;
    }

    private int ReadSvrMessage() {
        int i = this.m_nSvrMsg;
        if (i > 81960) {
            return -3;
        }
        this.m_nTmpSize = -1;
        try {
            int read = this.m_cRTSPin.read(this.m_pSvrMsg, i, RTSP_BUFFER_SIZE - i);
            this.m_nTmpSize = read;
            if (read == -1) {
                DtbLog.cLogPrn(1, "Read returns -1", new Object[0]);
                return -2;
            }
            this.m_nSvrMsg += read;
            DtbLog.cLogPrn(64, "%d data received now", Integer.valueOf(read));
            DtbLog.cLogPrn(64, "%d data received until", Integer.valueOf(this.m_nSvrMsg));
            return this.m_nTmpSize;
        } catch (IOException e2) {
            DtbLog.cLogPrn(32, "%s", e2.getMessage());
            return -1;
        } catch (NullPointerException e3) {
            DtbLog.cLogPrn(1, "%s", e3.getMessage());
            return -2;
        } catch (IndexOutOfBoundsException e4) {
            DtbLog.cLogPrn(1, "%s", e4.getMessage());
            return -2;
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(27:3|4|5|6|(2:8|9)|10|12|13|(2:14|15)|16|(2:18|19)|20|22|23|24|26|27|28|29|30|31|32|33|34|35|36|38) */
    /* JADX WARNING: Can't wrap try/catch for region: R(28:3|4|5|6|(2:8|9)|10|12|13|(2:14|15)|16|18|19|20|22|23|24|26|27|28|29|30|31|32|33|34|35|36|38) */
    /* JADX WARNING: Can't wrap try/catch for region: R(29:3|4|5|6|8|9|10|12|13|(2:14|15)|16|18|19|20|22|23|24|26|27|28|29|30|31|32|33|34|35|36|38) */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x0020 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:28:0x0038 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:30:0x003c */
    /* JADX WARNING: Missing exception handler attribute for start block: B:32:0x0040 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:34:0x0044 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ int[] a() {
        /*
            int[] r0 = $SWITCH_TABLE$net$dreamtobe$protocol$rtsp$util$RtspMethod
            if (r0 == 0) goto L_0x0005
            return r0
        L_0x0005:
            net.dreamtobe.protocol.rtsp.util.RtspMethod[] r0 = net.dreamtobe.protocol.rtsp.util.RtspMethod.values()
            int r0 = r0.length
            int[] r0 = new int[r0]
            r1 = 1
            net.dreamtobe.protocol.rtsp.util.RtspMethod r2 = net.dreamtobe.protocol.rtsp.util.RtspMethod.ANNOUNCE_METHOD     // Catch:{ NoSuchFieldError -> 0x0012 }
            r2 = 0
            r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
        L_0x0012:
            r2 = 3
            r3 = 2
            net.dreamtobe.protocol.rtsp.util.RtspMethod r4 = net.dreamtobe.protocol.rtsp.util.RtspMethod.DESCRIBE_METHOD     // Catch:{ NoSuchFieldError -> 0x0018 }
            r0[r3] = r2     // Catch:{ NoSuchFieldError -> 0x0018 }
        L_0x0018:
            r4 = 10
            r5 = 9
            net.dreamtobe.protocol.rtsp.util.RtspMethod r6 = net.dreamtobe.protocol.rtsp.util.RtspMethod.GET_PARAMETER_METHOD     // Catch:{ NoSuchFieldError -> 0x0020 }
            r0[r5] = r4     // Catch:{ NoSuchFieldError -> 0x0020 }
        L_0x0020:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r6 = net.dreamtobe.protocol.rtsp.util.RtspMethod.NOT_METHOD     // Catch:{ NoSuchFieldError -> 0x0026 }
            r6 = 11
            r0[r4] = r6     // Catch:{ NoSuchFieldError -> 0x0026 }
        L_0x0026:
            r4 = 8
            r6 = 7
            net.dreamtobe.protocol.rtsp.util.RtspMethod r7 = net.dreamtobe.protocol.rtsp.util.RtspMethod.OPTIONS_METHOD     // Catch:{ NoSuchFieldError -> 0x002d }
            r0[r6] = r4     // Catch:{ NoSuchFieldError -> 0x002d }
        L_0x002d:
            r7 = 6
            r8 = 5
            net.dreamtobe.protocol.rtsp.util.RtspMethod r9 = net.dreamtobe.protocol.rtsp.util.RtspMethod.PAUSE_METHOD     // Catch:{ NoSuchFieldError -> 0x0033 }
            r0[r8] = r7     // Catch:{ NoSuchFieldError -> 0x0033 }
        L_0x0033:
            r9 = 4
            net.dreamtobe.protocol.rtsp.util.RtspMethod r10 = net.dreamtobe.protocol.rtsp.util.RtspMethod.PLAY_METHOD     // Catch:{ NoSuchFieldError -> 0x0038 }
            r0[r9] = r8     // Catch:{ NoSuchFieldError -> 0x0038 }
        L_0x0038:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r8 = net.dreamtobe.protocol.rtsp.util.RtspMethod.REDIRECT_METHOD     // Catch:{ NoSuchFieldError -> 0x003c }
            r0[r1] = r3     // Catch:{ NoSuchFieldError -> 0x003c }
        L_0x003c:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r1 = net.dreamtobe.protocol.rtsp.util.RtspMethod.SETUP_METHOD     // Catch:{ NoSuchFieldError -> 0x0040 }
            r0[r2] = r9     // Catch:{ NoSuchFieldError -> 0x0040 }
        L_0x0040:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r1 = net.dreamtobe.protocol.rtsp.util.RtspMethod.SET_PARAMETER_METHOD     // Catch:{ NoSuchFieldError -> 0x0044 }
            r0[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0044 }
        L_0x0044:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r1 = net.dreamtobe.protocol.rtsp.util.RtspMethod.TEARDOWN_METHOD     // Catch:{ NoSuchFieldError -> 0x0048 }
            r0[r7] = r6     // Catch:{ NoSuchFieldError -> 0x0048 }
        L_0x0048:
            $SWITCH_TABLE$net$dreamtobe$protocol$rtsp$util$RtspMethod = r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayServer.a():int[]");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
        net.dreamtobe.common.log.DtbLog.cLogPrn(16, "Teardown is not received", new java.lang.Object[0]);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0029, code lost:
        if (r5.m_iServerDisconnectListener == null) goto L_0x0030;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x002b, code lost:
        r5.m_iServerDisconnectListener.OnMangoServerDisconnect();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0030, code lost:
        net.dreamtobe.common.log.DtbLog.cLogPrn(16, "Server is disconnected", new java.lang.Object[0]);
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:26:0x0044 */
    /* JADX WARNING: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:26:0x0044=Splitter:B:26:0x0044, B:39:0x006e=Splitter:B:39:0x006e} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r5 = this;
        L_0x0000:
            r0 = 0
            boolean r1 = r5.m_bIsStop     // Catch:{ Exception -> 0x0054 }
            if (r1 == 0) goto L_0x0006
            goto L_0x0044
        L_0x0006:
            java.lang.String r1 = r5.ReadCliMessage()     // Catch:{ Exception -> 0x0054 }
            if (r1 == 0) goto L_0x000f
            r5.ProcessCliMessage(r1)     // Catch:{ Exception -> 0x0054 }
        L_0x000f:
            int r1 = r5.ReadSvrMessage()     // Catch:{ Exception -> 0x0054 }
            r2 = -1
            if (r1 != r2) goto L_0x001b
            r2 = 10
            java.lang.Thread.sleep(r2)     // Catch:{ Exception -> 0x0044 }
        L_0x001b:
            r2 = -2
            if (r1 != r2) goto L_0x0038
            java.lang.String r1 = "Teardown is not received"
            java.lang.Object[] r2 = new java.lang.Object[r0]     // Catch:{ Exception -> 0x0054 }
            r3 = 16
            net.dreamtobe.common.log.DtbLog.cLogPrn(r3, r1, r2)     // Catch:{ Exception -> 0x0054 }
            net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayServer$OnMangoServerDisconnectListener r1 = r5.m_iServerDisconnectListener     // Catch:{ Exception -> 0x0054 }
            if (r1 == 0) goto L_0x0030
            net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayServer$OnMangoServerDisconnectListener r1 = r5.m_iServerDisconnectListener     // Catch:{ Exception -> 0x0054 }
            r1.OnMangoServerDisconnect()     // Catch:{ Exception -> 0x0054 }
        L_0x0030:
            java.lang.String r1 = "Server is disconnected"
            java.lang.Object[] r2 = new java.lang.Object[r0]     // Catch:{ Exception -> 0x0054 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r3, r1, r2)     // Catch:{ Exception -> 0x0054 }
            goto L_0x0044
        L_0x0038:
            boolean r1 = r5.ParseSvrMessage()     // Catch:{ Exception -> 0x0054 }
            if (r1 == 0) goto L_0x004e
            int r1 = r5.ProcessSvrMessage()     // Catch:{ Exception -> 0x0054 }
            if (r1 != r2) goto L_0x004e
        L_0x0044:
            java.net.Socket r0 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0073 }
            if (r0 == 0) goto L_0x0073
        L_0x0048:
            java.net.Socket r0 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0073 }
            r0.close()     // Catch:{ Exception -> 0x0073 }
            goto L_0x0073
        L_0x004e:
            r5.ProcessCliEmbeddedPakcet()     // Catch:{ Exception -> 0x0054 }
            goto L_0x0000
        L_0x0052:
            r0 = move-exception
            goto L_0x0074
        L_0x0054:
            r1 = move-exception
            r2 = 64
            java.lang.String r3 = "%s"
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x0052 }
            java.lang.String r1 = r1.getMessage()     // Catch:{ all -> 0x0052 }
            r4[r0] = r1     // Catch:{ all -> 0x0052 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r3, r4)     // Catch:{ all -> 0x0052 }
            net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayServer$OnMangoServerDisconnectListener r0 = r5.m_iServerDisconnectListener     // Catch:{ all -> 0x0052 }
            if (r0 == 0) goto L_0x006e
            net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayServer$OnMangoServerDisconnectListener r0 = r5.m_iServerDisconnectListener     // Catch:{ all -> 0x0052 }
            r0.OnMangoServerDisconnect()     // Catch:{ all -> 0x0052 }
        L_0x006e:
            java.net.Socket r0 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0073 }
            if (r0 == 0) goto L_0x0073
            goto L_0x0048
        L_0x0073:
            return
        L_0x0074:
            java.net.Socket r1 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x007d }
            if (r1 == 0) goto L_0x007d
            java.net.Socket r1 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x007d }
            r1.close()     // Catch:{ Exception -> 0x007d }
        L_0x007d:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayServer.run():void");
    }

    public void setOnMangoServerDisconnectListener(OnMangoServerDisconnectListener onMangoServerDisconnectListener) {
        this.m_iServerDisconnectListener = onMangoServerDisconnectListener;
    }

    public void setStop(boolean z) {
        this.m_bIsStop = z;
    }
}

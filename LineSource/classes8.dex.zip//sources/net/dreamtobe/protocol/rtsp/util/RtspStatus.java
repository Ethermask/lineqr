package net.dreamtobe.protocol.rtsp.util;

public enum RtspStatus {
    SS_NONE,
    SS_WAIT,
    SS_INIT,
    SS_READY,
    SS_PLAY,
    SS_PAUSE,
    SS_PAUSING,
    SS_CLOSE
}

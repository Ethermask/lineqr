package net.dreamtobe.protocol.rtsp.rtsprelay;

public class RtspServerException extends Exception {
    public static final long serialVersionUID = -3658912549898550420L;

    public RtspServerException() {
        super("Rtsp server exception");
    }

    public RtspServerException(String str) {
        super(str);
    }
}

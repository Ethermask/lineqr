package net.dreamtobe.protocol.rtsp.rtsprelay;

import android.util.Base64;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import net.dreamtobe.common.log.DtbLog;
import net.dreamtobe.common.util.UtilBit;
import net.dreamtobe.protocol.rtsp.util.RtspInfo;
import net.dreamtobe.protocol.rtsp.util.RtspMessageQueue;
import net.dreamtobe.protocol.rtsp.util.RtspParser;
import net.dreamtobe.protocol.rtsp.util.RtspStatus;
import net.dreamtobe.protocol.rtsp.util.UrlString;
import net.sqlcipher.database.SQLiteDatabase;

public class RtspRelayClient extends Thread {
    public static /* synthetic */ int[] $SWITCH_TABLE$net$dreamtobe$protocol$rtsp$util$RtspMethod = null;
    public static final int DTB_UDP_PORT_RANGE = 40000;
    public static final int DTB_UDP_PORT_START = 20000;
    public byte[] m_arrTmpReturn;
    public boolean m_bIsStop;
    public boolean m_bWaitResponse;
    public RtspParser m_cClient;
    public RtspMessageQueue m_cMessageQueue;
    public InetAddress m_cPeerAddress;
    public Socket m_cRTSPSock;
    public InputStream m_cRTSPin;
    public OutputStream m_cRTSPout;
    public RtpRelayThread m_cRtpRelayThread;
    public RtspStatus m_eStatus = RtspStatus.SS_NONE;
    public int m_nCliMsg = 0;
    public long m_nCompatibleflag;
    public int m_nLocalPort;
    public int m_nTmpSize;
    public int m_nVideoHeight;
    public int m_nVideoWidth;
    public byte[] m_pCliMsg = new byte[8196];
    public String m_szLocalAddr;
    public String m_szTmpMessage;

    public RtspRelayClient(Socket socket, RtspMessageQueue rtspMessageQueue, String str, long j) throws RtspClientException {
        RtspInfo rtspInfo = new RtspInfo();
        rtspInfo.m_b3GP = true;
        rtspInfo.m_bUDP = true;
        rtspInfo.m_bServer = true;
        this.m_cClient = new RtspParser(rtspInfo);
        this.m_cMessageQueue = rtspMessageQueue;
        this.m_bWaitResponse = false;
        this.m_nCompatibleflag = j;
        this.m_nVideoWidth = 0;
        this.m_nVideoHeight = 0;
        this.m_bIsStop = false;
        try {
            this.m_cRTSPSock = socket;
            socket.setSoTimeout(10);
            this.m_cRTSPin = socket.getInputStream();
            this.m_cRTSPout = socket.getOutputStream();
            this.m_cPeerAddress = socket.getInetAddress();
            this.m_szLocalAddr = this.m_cRTSPSock.getLocalAddress().toString().split("[ ]*/[ ]*")[1];
            this.m_nLocalPort = this.m_cRTSPSock.getLocalPort();
            this.m_cRtpRelayThread = new RtpRelayThread(this.m_cPeerAddress, this.m_cMessageQueue);
            DtbLog.cLogPrn(8, "Contructor execute Local Address %s", this.m_szLocalAddr);
        } catch (Exception e2) {
            DtbLog.cLogPrn(1, "RtspClient Contructor Error : %s\n", e2.getMessage());
            throw new RtspClientException("RtspClient Contructor Error : " + e2.getMessage());
        }
    }

    private void DecodeSPS(byte[] bArr) {
        DtbLog.cLogPrn(16, "DecodeSPS Start", new Object[0]);
        UtilBit utilBit = new UtilBit(bArr);
        DtbLog.cLogPrn(16, "NAL header = %x", Integer.valueOf(utilBit.GetBits(8)));
        DtbLog.cLogPrn(16, "Profile_IDC = %d", Integer.valueOf(utilBit.GetBits(8)));
        utilBit.GetBits(1);
        utilBit.GetBits(1);
        utilBit.GetBits(1);
        utilBit.GetBits(5);
        DtbLog.cLogPrn(16, "Level_IDC = %d", Integer.valueOf(utilBit.GetBits(8)));
        DtbLog.cLogPrn(16, "Seq_parameter_set_id = %d", Integer.valueOf(utilBit.GetUnsignedExpGolombCode()));
        int GetUnsignedExpGolombCode = utilBit.GetUnsignedExpGolombCode();
        DtbLog.cLogPrn(16, "Log_max_frame_num_minus4 = %d, MaxFrameNum = %d", Integer.valueOf(GetUnsignedExpGolombCode), Integer.valueOf(1 << (GetUnsignedExpGolombCode + 4)));
        int GetUnsignedExpGolombCode2 = utilBit.GetUnsignedExpGolombCode();
        DtbLog.cLogPrn(16, "Pic_order_cnt_type = %d", Integer.valueOf(GetUnsignedExpGolombCode2));
        if (GetUnsignedExpGolombCode2 == 0) {
            int GetUnsignedExpGolombCode3 = utilBit.GetUnsignedExpGolombCode();
            DtbLog.cLogPrn(16, "Log2_max_pic_order_cnt_lab_minus4 = %d, MaxPicOrderCntLsb = %d", Integer.valueOf(GetUnsignedExpGolombCode3), Integer.valueOf(1 << (GetUnsignedExpGolombCode3 + 4)));
        } else if (GetUnsignedExpGolombCode2 == 1) {
            DtbLog.cLogPrn(16, "Delta_pic_order_always_zero_flag = %d", Integer.valueOf(utilBit.GetBits(1)));
            DtbLog.cLogPrn(16, "Offset_for_non_ref_pic = %d", Integer.valueOf(utilBit.GetSignedExpGolombCode()));
            DtbLog.cLogPrn(16, "Offset_for_top_to_bottom_field = %d", Integer.valueOf(utilBit.GetSignedExpGolombCode()));
            int GetUnsignedExpGolombCode4 = utilBit.GetUnsignedExpGolombCode();
            DtbLog.cLogPrn(16, "Num_ref_frame_in_pic_order_cnt_cycle = %d", Integer.valueOf(GetUnsignedExpGolombCode4));
            for (int i = 0; i < GetUnsignedExpGolombCode4; i++) {
                DtbLog.cLogPrn(16, "Offset_for_ref_frame[%d] = %d", Integer.valueOf(i), Integer.valueOf(utilBit.GetSignedExpGolombCode()));
            }
        }
        DtbLog.cLogPrn(16, "Num_ref_frames = %d", Integer.valueOf(utilBit.GetUnsignedExpGolombCode()));
        DtbLog.cLogPrn(16, "Gaps_in_frame_num_value_allowed_flag = %d", Integer.valueOf(utilBit.GetBits(1)));
        int GetUnsignedExpGolombCode5 = utilBit.GetUnsignedExpGolombCode();
        this.m_nVideoWidth = (GetUnsignedExpGolombCode5 + 1) * 16;
        DtbLog.cLogPrn(16, "Pic_width_in_mbs_minus1 = %d, Video width = %d", Integer.valueOf(GetUnsignedExpGolombCode5), Integer.valueOf(this.m_nVideoWidth));
        int GetUnsignedExpGolombCode6 = utilBit.GetUnsignedExpGolombCode();
        this.m_nVideoHeight = (GetUnsignedExpGolombCode6 + 1) * 16;
        DtbLog.cLogPrn(16, "Pic_height_in_mbs_minus1 = %d, Video height = %d", Integer.valueOf(GetUnsignedExpGolombCode6), Integer.valueOf(this.m_nVideoHeight));
        int GetBits = utilBit.GetBits(1);
        DtbLog.cLogPrn(16, "Frame_mbs_only_flag = %d", Integer.valueOf(GetBits));
        if (GetBits == 0) {
            DtbLog.cLogPrn(16, "Mb_adaptive_frame_field_flag = %d", Integer.valueOf(utilBit.GetBits(1)));
        }
        DtbLog.cLogPrn(16, "Direct_8x8_inference_flag = %d", Integer.valueOf(utilBit.GetBits(1)));
        int GetBits2 = utilBit.GetBits(1);
        DtbLog.cLogPrn(16, "Frame_cropping_flag = %d", Integer.valueOf(GetBits2));
        if (GetBits2 == 1) {
            int GetUnsignedExpGolombCode7 = utilBit.GetUnsignedExpGolombCode();
            this.m_nVideoWidth -= GetUnsignedExpGolombCode7 * 2;
            DtbLog.cLogPrn(16, "Frame_crop_left_offset = %d, Adjust Video width = %d", Integer.valueOf(GetUnsignedExpGolombCode7), Integer.valueOf(this.m_nVideoWidth));
            int GetUnsignedExpGolombCode8 = utilBit.GetUnsignedExpGolombCode();
            this.m_nVideoWidth -= GetUnsignedExpGolombCode8 * 2;
            DtbLog.cLogPrn(16, "Frame_crop_right_offset = %d, Adjust Video width = %d", Integer.valueOf(GetUnsignedExpGolombCode8), Integer.valueOf(this.m_nVideoWidth));
            int GetUnsignedExpGolombCode9 = utilBit.GetUnsignedExpGolombCode();
            this.m_nVideoHeight -= GetUnsignedExpGolombCode9 * 2;
            DtbLog.cLogPrn(16, "Frame_crop_top_offset = %d, Adjust Video height = %d", Integer.valueOf(GetUnsignedExpGolombCode9), Integer.valueOf(this.m_nVideoHeight));
            int GetUnsignedExpGolombCode10 = utilBit.GetUnsignedExpGolombCode();
            this.m_nVideoHeight -= GetUnsignedExpGolombCode10 * 2;
            DtbLog.cLogPrn(16, "Frame_crop_bottom_offset = %d, Adjust Video height = %d", Integer.valueOf(GetUnsignedExpGolombCode10), Integer.valueOf(this.m_nVideoHeight));
        }
    }

    private boolean ParseCliMessage() {
        this.m_arrTmpReturn = null;
        byte[] RTSPParsingMessage = this.m_cClient.RTSPParsingMessage(new String(this.m_pCliMsg, 0, this.m_nCliMsg));
        this.m_arrTmpReturn = RTSPParsingMessage;
        if (RTSPParsingMessage == null) {
            this.m_nCliMsg = 0;
        } else {
            try {
                if (RTSPParsingMessage.length != 0) {
                    System.arraycopy(RTSPParsingMessage, 0, this.m_pCliMsg, 0, RTSPParsingMessage.length);
                }
                this.m_nCliMsg = this.m_arrTmpReturn.length;
                return true;
            } catch (Exception e2) {
                DtbLog.cLogPrn(1, "%s", e2.getMessage());
            }
        }
        return false;
    }

    private void ParseSPS(String str) {
        int indexOf = str.indexOf("sprop-parameter-sets=");
        if (indexOf == -1) {
            DtbLog.cLogPrn(16, "ParseSPS : can't find sprop-parameter-sets=", new Object[0]);
            return;
        }
        int i = indexOf + 21;
        int indexOf2 = str.indexOf("\r\n", i);
        if (indexOf2 == -1) {
            DtbLog.cLogPrn(16, "ParseSPS : can't find carriage return", new Object[0]);
            return;
        }
        String str2 = str.substring(i, indexOf2).split(",")[0];
        DtbLog.cLogPrn(16, "ParseSPS : SPS = %s", str2);
        byte[] decode = Base64.decode(str2, 0);
        DtbLog.cLogPrn(16, "ParseSPS : decodedByte length = %d", Integer.valueOf(decode.length));
        DecodeSPS(decode);
    }

    private void ProcessCliMessage() {
        String str;
        this.m_bWaitResponse = true;
        switch (a()[this.m_cClient.RTSPGetReqMethod().ordinal()]) {
            case 1:
                str = "ANNOUNCE_METHOD";
                break;
            case 2:
                str = "REDIRECT_METHOD";
                break;
            case 3:
                this.m_eStatus = RtspStatus.SS_INIT;
                str = "DESCRIBE_METHOD";
                break;
            case 4:
                ProcessSetup();
                this.m_eStatus = RtspStatus.SS_READY;
                str = "SETUP_METHOD";
                break;
            case 5:
                ProcessPlay();
                this.m_eStatus = RtspStatus.SS_PLAY;
                str = "PLAY_METHOD";
                break;
            case 6:
                this.m_eStatus = RtspStatus.SS_PAUSE;
                str = "PAUSE_METHOD";
                break;
            case 7:
                this.m_eStatus = RtspStatus.SS_CLOSE;
                str = "TEARDOWN_METHOD";
                break;
            case 8:
                str = "OPTIONS_METHOD";
                break;
            case 9:
                str = "SET_PARAMETER_METHOD";
                break;
            case 10:
                str = "GET_PARAMETER_METHOD";
                break;
            default:
                str = "No Method";
                break;
        }
        this.m_cMessageQueue.PushMsg(this.m_cClient.RTSPGetMessage(), true);
        DtbLog.cLogPrn(16, "Message is passed from client side to server side for rtsp %s message", str);
    }

    private String ProcessDescribeResponse(String str) {
        String[] strArr;
        boolean z;
        boolean z2;
        StringBuilder sb = new StringBuilder();
        if (this.m_cClient.RTSPGetErrorCode() != 0) {
            return str;
        }
        int length = str.length();
        int i = 0;
        while (true) {
            if (length == 0) {
                strArr = null;
                z = true;
                break;
            }
            String UtilStrGetLine = UrlString.UtilStrGetLine(str, i);
            int length2 = UtilStrGetLine.length();
            if (UtilStrGetLine.indexOf("Content-Base:") == 0) {
                String[] split = UtilStrGetLine.split("[ ]*/[ ]*");
                DtbLog.cLogPrn(16, "szArg[0]=%s szArg[1]=%s szArg[2]=%s szArg[3]=%s", split[0], split[1], split[2], split[3]);
                String str2 = split[2];
                if (str2.indexOf(58) == -1) {
                    str2 = String.format("%s:554", new Object[]{split[2]});
                    z2 = false;
                } else {
                    z2 = true;
                }
                String[] split2 = str2.split("[ ]*:[ ]*");
                DtbLog.cLogPrn(16, "szArg[0]=%s szArg[1]=%s", split2[0], split2[1]);
                String[] strArr2 = split2;
                z = z2;
                strArr = strArr2;
            } else {
                i += length2;
                length -= length2;
            }
        }
        if (length != 0) {
            DtbLog.cLogPrn(16, "szArg[0] = %s", strArr[0]);
            String str3 = strArr[0];
            DtbLog.cLogPrn(16, "szSrcAddress = %s", str3);
            if (z) {
                str = str.replaceAll(str3, this.m_szLocalAddr).replaceAll(String.format(":%s/", new Object[]{strArr[1]}), String.format(":%d/", new Object[]{Integer.valueOf(this.m_nLocalPort)}));
            } else {
                str = str.replaceAll(str3, this.m_szLocalAddr);
            }
        }
        String str4 = str;
        String substring = str4.substring(str4.indexOf("\r\n\r\n") + 4);
        DtbLog.cLogPrn(16, "szSDP = %s", substring);
        ParseSPS(substring);
        int length3 = str4.length();
        int i2 = 0;
        while (length3 != 0) {
            String UtilStrGetLine2 = UrlString.UtilStrGetLine(str4, i2);
            int length4 = UtilStrGetLine2.length();
            if (UtilStrGetLine2.indexOf("Content-Length:") == 0) {
                sb.append(String.format("Content-Length: %d\r\n", new Object[]{Integer.valueOf(substring.length())}));
            } else {
                sb.append(UtilStrGetLine2);
            }
            i2 += length4;
            length3 -= length4;
        }
        return sb.toString();
    }

    private void ProcessPlay() {
        if (this.m_eStatus == RtspStatus.SS_READY) {
            try {
                this.m_cRtpRelayThread.start();
            } catch (Exception unused) {
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x001a, code lost:
        r6 = true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.lang.String ProcessPlayResponse(java.lang.String r11) {
        /*
            r10 = this;
            net.dreamtobe.protocol.rtsp.util.RtspParser r0 = r10.m_cClient
            long r0 = r0.RTSPGetErrorCode()
            r2 = 0
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 == 0) goto L_0x000d
            return r11
        L_0x000d:
            int r0 = r11.length()
            r1 = 0
            r2 = r1
        L_0x0013:
            r3 = 16
            r4 = 2
            r5 = 1
            if (r0 != 0) goto L_0x001c
            r2 = 0
        L_0x001a:
            r6 = r5
            goto L_0x0083
        L_0x001c:
            java.lang.String r6 = net.dreamtobe.protocol.rtsp.util.UrlString.UtilStrGetLine(r11, r2)
            int r7 = r6.length()
            java.lang.String r8 = "RTP-Info:"
            int r8 = r6.indexOf(r8)
            if (r8 != 0) goto L_0x00ce
            java.lang.String r2 = "[ ]*/[ ]*"
            java.lang.String[] r2 = r6.split(r2)
            int r6 = r2.length
            r7 = 4
            r8 = 3
            if (r6 < r7) goto L_0x004e
            java.lang.Object[] r6 = new java.lang.Object[r7]
            r7 = r2[r1]
            r6[r1] = r7
            r7 = r2[r5]
            r6[r5] = r7
            r7 = r2[r4]
            r6[r4] = r7
            r7 = r2[r8]
            r6[r8] = r7
            java.lang.String r7 = "szArg[0]=%s szArg[1]=%s szArg[2]=%s szArg[3]=%s"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r3, r7, r6)
        L_0x004e:
            int r6 = r2.length
            if (r6 < r8) goto L_0x001a
            r6 = r2[r4]
            r7 = 58
            int r7 = r6.indexOf(r7)
            r8 = -1
            if (r7 != r8) goto L_0x006a
            java.lang.Object[] r6 = new java.lang.Object[r5]
            r2 = r2[r4]
            r6[r1] = r2
            java.lang.String r2 = "%s:554"
            java.lang.String r6 = java.lang.String.format(r2, r6)
            r2 = r1
            goto L_0x006b
        L_0x006a:
            r2 = r5
        L_0x006b:
            java.lang.String r7 = "[ ]*:[ ]*"
            java.lang.String[] r6 = r6.split(r7)
            java.lang.Object[] r7 = new java.lang.Object[r4]
            r8 = r6[r1]
            r7[r1] = r8
            r8 = r6[r5]
            r7[r5] = r8
            java.lang.String r8 = "szArg[0]=%s szArg[1]=%s"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r3, r8, r7)
            r9 = r6
            r6 = r2
            r2 = r9
        L_0x0083:
            if (r0 == 0) goto L_0x00cd
            int r0 = r2.length
            if (r0 < r4) goto L_0x00cd
            java.lang.Object[] r0 = new java.lang.Object[r5]
            r4 = r2[r1]
            r0[r1] = r4
            java.lang.String r4 = "szArg[0] = %s"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r3, r4, r0)
            r0 = r2[r1]
            java.lang.Object[] r4 = new java.lang.Object[r5]
            r4[r1] = r0
            java.lang.String r7 = "szSrcAddress = %s"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r3, r7, r4)
            if (r6 == 0) goto L_0x00c7
            java.lang.String r3 = r10.m_szLocalAddr
            java.lang.String r11 = r11.replaceAll(r0, r3)
            java.lang.Object[] r0 = new java.lang.Object[r5]
            r2 = r2[r5]
            r0[r1] = r2
            java.lang.String r2 = ":%s/"
            java.lang.String r0 = java.lang.String.format(r2, r0)
            java.lang.Object[] r2 = new java.lang.Object[r5]
            int r3 = r10.m_nLocalPort
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r2[r1] = r3
            java.lang.String r1 = ":%d/"
            java.lang.String r1 = java.lang.String.format(r1, r2)
            java.lang.String r11 = r11.replaceAll(r0, r1)
            goto L_0x00cd
        L_0x00c7:
            java.lang.String r1 = r10.m_szLocalAddr
            java.lang.String r11 = r11.replaceAll(r0, r1)
        L_0x00cd:
            return r11
        L_0x00ce:
            int r2 = r2 + r7
            int r0 = r0 - r7
            goto L_0x0013
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayClient.ProcessPlayResponse(java.lang.String):java.lang.String");
    }

    private void ProcessSetup() {
        DatagramSocket datagramSocket;
        DatagramSocket datagramSocket2;
        DatagramSocket datagramSocket3 = null;
        boolean z = true;
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i >= 10000) {
                datagramSocket = null;
                datagramSocket2 = datagramSocket3;
                break;
            }
            int i4 = i2;
            int i5 = i;
            while (z && i5 < 10000) {
                i5++;
                i4 = (((int) (Math.random() * 100000.0d)) % 40000) + 20000;
                if (i4 % 2 != 0) {
                    i4++;
                }
                DtbLog.cLogPrn(16, "nRTPPort = %d", Integer.valueOf(i4));
                try {
                    datagramSocket3 = new DatagramSocket(i4);
                    z = false;
                } catch (Exception e2) {
                    DtbLog.cLogPrn(32, "[Error] ProcessSetup : %s for port number (%d)\n", e2.getMessage(), Integer.valueOf(i4));
                }
            }
            int i6 = i4 + 1;
            DtbLog.cLogPrn(16, "nRTCPPort = %d", Integer.valueOf(i6));
            try {
                datagramSocket = new DatagramSocket(i6);
                i2 = i4;
                datagramSocket2 = datagramSocket3;
                i3 = i6;
                break;
            } catch (Exception e3) {
                DtbLog.cLogPrn(32, "[Error] ProcessSetup : %s for port number (%d)\n", e3.getMessage(), Integer.valueOf(i6));
                datagramSocket3.close();
                i = i5;
                i2 = i4;
                i3 = i6;
            }
        }
        int RTSPGetReqIndex = this.m_cClient.RTSPGetReqIndex();
        this.m_cClient.RTSPSetRTPLocalPort(RTSPGetReqIndex, i2);
        this.m_cClient.RTSPSetRTCPLocalPort(RTSPGetReqIndex, i3);
        this.m_cRtpRelayThread.SetRtpRtcpInfo(RTSPGetReqIndex, datagramSocket2, datagramSocket, this.m_cClient.RTSPGetRTPRemotePort(RTSPGetReqIndex), i2);
        this.m_cMessageQueue.MakeChannelInfo(RTSPGetReqIndex);
    }

    private String ProcessSetupResponse(String str) {
        StringBuilder sb = new StringBuilder();
        if (this.m_cClient.RTSPGetErrorCode() != 0) {
            return str;
        }
        int RTSPGetReqIndex = this.m_cClient.RTSPGetReqIndex();
        int length = str.length();
        int i = 0;
        while (length != 0) {
            String UtilStrGetLine = UrlString.UtilStrGetLine(str, i);
            int length2 = UtilStrGetLine.length();
            if (UtilStrGetLine.indexOf("Transport") == 0) {
                int RTSPGetRTPRemotePort = this.m_cClient.RTSPGetRTPRemotePort(RTSPGetReqIndex);
                int RTSPGetRTPLocalPort = this.m_cClient.RTSPGetRTPLocalPort(RTSPGetReqIndex);
                sb.append(String.format("Transport: RTP/AVP;unicast;source=%s;client_port=%d-%d;server_port=%d-%d;ssrc=%x\r\n", new Object[]{this.m_szLocalAddr, Integer.valueOf(RTSPGetRTPRemotePort), Integer.valueOf(RTSPGetRTPRemotePort + 1), Integer.valueOf(RTSPGetRTPLocalPort), Integer.valueOf(RTSPGetRTPLocalPort + 1), Long.valueOf(this.m_cClient.RTSPGetSSRC(RTSPGetReqIndex))}));
            } else {
                sb.append(UtilStrGetLine);
            }
            i += length2;
            length -= UtilStrGetLine.length();
        }
        return sb.toString();
    }

    private int ProcessSvrMessage(String str) {
        String str2;
        this.m_nTmpSize = -1;
        this.m_szTmpMessage = str;
        this.m_bWaitResponse = false;
        switch (a()[this.m_cClient.RTSPGetReqMethod().ordinal()]) {
            case 1:
                str2 = "ANNOUNCE_METHOD";
                break;
            case 2:
                str2 = "REDIRECT_METHOD";
                break;
            case 3:
                this.m_szTmpMessage = ProcessDescribeResponse(str);
                str2 = "DESCRIBE_METHOD";
                break;
            case 4:
                this.m_szTmpMessage = ProcessSetupResponse(str);
                str2 = "SETUP_METHOD";
                break;
            case 5:
                this.m_szTmpMessage = ProcessPlayResponse(str);
                str2 = "PLAY_METHOD";
                break;
            case 6:
                str2 = "PAUSE_METHOD";
                break;
            case 7:
                str2 = "TEARDOWN_METHOD";
                break;
            case 8:
                str2 = "OPTIONS_METHOD";
                break;
            case 9:
                str2 = "SET_PARAMETER_METHOD";
                break;
            case 10:
                str2 = "GET_PARAMETER_METHOD";
                break;
            default:
                str2 = "No Method";
                break;
        }
        try {
            DtbLog.cLogPrn(16, "Send Message to client for %s : %s", str2, this.m_szTmpMessage);
            this.m_cRTSPout.write(this.m_szTmpMessage.getBytes(SQLiteDatabase.KEY_ENCODING));
            if ((1 & this.m_nCompatibleflag) != 0) {
                this.m_cRtpRelayThread.SetRtpRleayPause(false);
                DtbLog.cLogPrn(16, "m_cRtpRelayThread.SetRtpRleayPause(false)", new Object[0]);
            }
        } catch (UnsupportedEncodingException unused) {
            if ((1 & this.m_nCompatibleflag) != 0) {
                this.m_cRtpRelayThread.SetRtpRleayPause(false);
                DtbLog.cLogPrn(16, "m_cRtpRelayThread.SetRtpRleayPause(false)", new Object[0]);
            }
        } catch (Exception e2) {
            DtbLog.cLogPrn(1, "[RTSPClient]:Write Message error %s", e2.getMessage());
        } catch (Throwable th2) {
            if ((1 & this.m_nCompatibleflag) != 0) {
                this.m_cRtpRelayThread.SetRtpRleayPause(false);
                DtbLog.cLogPrn(16, "m_cRtpRelayThread.SetRtpRleayPause(false)", new Object[0]);
            }
            throw th2;
        }
        return this.m_nTmpSize;
    }

    private int ReadCliMessage() {
        this.m_nTmpSize = -1;
        try {
            int read = this.m_cRTSPin.read(this.m_pCliMsg, this.m_nCliMsg, 8196 - this.m_nCliMsg);
            this.m_nTmpSize = read;
            this.m_nCliMsg += read;
            if (read == -1) {
                DtbLog.cLogPrn(1, "Read returns -1", new Object[0]);
                return -2;
            }
            if ((this.m_nCompatibleflag & 1) != 0) {
                this.m_cRtpRelayThread.SetRtpRleayPause(true);
                DtbLog.cLogPrn(16, "m_cRtpRelayThread.SetRtpRleayPause(true)", new Object[0]);
            }
            return this.m_nTmpSize;
        } catch (IOException unused) {
        } catch (NullPointerException e2) {
            DtbLog.cLogPrn(1, "%s", e2.getMessage());
            this.m_nTmpSize = -2;
        } catch (IndexOutOfBoundsException e3) {
            DtbLog.cLogPrn(1, "%s", e3.getMessage());
        } catch (Exception e4) {
            DtbLog.cLogPrn(1, "%s", e4.getMessage());
        }
    }

    private String ReadSvrMessage() {
        this.m_szTmpMessage = null;
        String GetMsg = this.m_cMessageQueue.GetMsg(true);
        this.m_szTmpMessage = GetMsg;
        if (GetMsg != null) {
            DtbLog.cLogPrn(8, "Received Server Response (%d) :\n%s", Integer.valueOf(GetMsg.length()), this.m_szTmpMessage);
            this.m_cClient.RTSPParsingMessage(this.m_szTmpMessage);
        }
        return this.m_szTmpMessage;
    }

    private void SendOptionResponse() {
        String format = String.format("RTSP/1.0 200 OK\r\nCSeq: %d\r\nServer: XEPEG Streamer/2.0\r\nPublic: DESCRIBE, SETUP, TEARDOWN, PLAY, PAUSE\r\nSession: %d\r\n", new Object[]{Long.valueOf(this.m_cClient.RTSPGetCSeq()), Long.valueOf(this.m_cClient.RTSPGetSession())});
        DtbLog.cLogPrn(16, "Send Message to client for %s", format);
        try {
            this.m_cRTSPout.write(format.getBytes(SQLiteDatabase.KEY_ENCODING));
        } catch (IOException | UnsupportedEncodingException unused) {
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(27:3|4|5|6|(2:8|9)|10|12|13|(2:14|15)|16|(2:18|19)|20|22|23|24|26|27|28|29|30|31|32|33|34|35|36|38) */
    /* JADX WARNING: Can't wrap try/catch for region: R(28:3|4|5|6|(2:8|9)|10|12|13|(2:14|15)|16|18|19|20|22|23|24|26|27|28|29|30|31|32|33|34|35|36|38) */
    /* JADX WARNING: Can't wrap try/catch for region: R(29:3|4|5|6|8|9|10|12|13|(2:14|15)|16|18|19|20|22|23|24|26|27|28|29|30|31|32|33|34|35|36|38) */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x0020 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:28:0x0038 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:30:0x003c */
    /* JADX WARNING: Missing exception handler attribute for start block: B:32:0x0040 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:34:0x0044 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ int[] a() {
        /*
            int[] r0 = $SWITCH_TABLE$net$dreamtobe$protocol$rtsp$util$RtspMethod
            if (r0 == 0) goto L_0x0005
            return r0
        L_0x0005:
            net.dreamtobe.protocol.rtsp.util.RtspMethod[] r0 = net.dreamtobe.protocol.rtsp.util.RtspMethod.values()
            int r0 = r0.length
            int[] r0 = new int[r0]
            r1 = 1
            net.dreamtobe.protocol.rtsp.util.RtspMethod r2 = net.dreamtobe.protocol.rtsp.util.RtspMethod.ANNOUNCE_METHOD     // Catch:{ NoSuchFieldError -> 0x0012 }
            r2 = 0
            r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
        L_0x0012:
            r2 = 3
            r3 = 2
            net.dreamtobe.protocol.rtsp.util.RtspMethod r4 = net.dreamtobe.protocol.rtsp.util.RtspMethod.DESCRIBE_METHOD     // Catch:{ NoSuchFieldError -> 0x0018 }
            r0[r3] = r2     // Catch:{ NoSuchFieldError -> 0x0018 }
        L_0x0018:
            r4 = 10
            r5 = 9
            net.dreamtobe.protocol.rtsp.util.RtspMethod r6 = net.dreamtobe.protocol.rtsp.util.RtspMethod.GET_PARAMETER_METHOD     // Catch:{ NoSuchFieldError -> 0x0020 }
            r0[r5] = r4     // Catch:{ NoSuchFieldError -> 0x0020 }
        L_0x0020:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r6 = net.dreamtobe.protocol.rtsp.util.RtspMethod.NOT_METHOD     // Catch:{ NoSuchFieldError -> 0x0026 }
            r6 = 11
            r0[r4] = r6     // Catch:{ NoSuchFieldError -> 0x0026 }
        L_0x0026:
            r4 = 8
            r6 = 7
            net.dreamtobe.protocol.rtsp.util.RtspMethod r7 = net.dreamtobe.protocol.rtsp.util.RtspMethod.OPTIONS_METHOD     // Catch:{ NoSuchFieldError -> 0x002d }
            r0[r6] = r4     // Catch:{ NoSuchFieldError -> 0x002d }
        L_0x002d:
            r7 = 6
            r8 = 5
            net.dreamtobe.protocol.rtsp.util.RtspMethod r9 = net.dreamtobe.protocol.rtsp.util.RtspMethod.PAUSE_METHOD     // Catch:{ NoSuchFieldError -> 0x0033 }
            r0[r8] = r7     // Catch:{ NoSuchFieldError -> 0x0033 }
        L_0x0033:
            r9 = 4
            net.dreamtobe.protocol.rtsp.util.RtspMethod r10 = net.dreamtobe.protocol.rtsp.util.RtspMethod.PLAY_METHOD     // Catch:{ NoSuchFieldError -> 0x0038 }
            r0[r9] = r8     // Catch:{ NoSuchFieldError -> 0x0038 }
        L_0x0038:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r8 = net.dreamtobe.protocol.rtsp.util.RtspMethod.REDIRECT_METHOD     // Catch:{ NoSuchFieldError -> 0x003c }
            r0[r1] = r3     // Catch:{ NoSuchFieldError -> 0x003c }
        L_0x003c:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r1 = net.dreamtobe.protocol.rtsp.util.RtspMethod.SETUP_METHOD     // Catch:{ NoSuchFieldError -> 0x0040 }
            r0[r2] = r9     // Catch:{ NoSuchFieldError -> 0x0040 }
        L_0x0040:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r1 = net.dreamtobe.protocol.rtsp.util.RtspMethod.SET_PARAMETER_METHOD     // Catch:{ NoSuchFieldError -> 0x0044 }
            r0[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0044 }
        L_0x0044:
            net.dreamtobe.protocol.rtsp.util.RtspMethod r1 = net.dreamtobe.protocol.rtsp.util.RtspMethod.TEARDOWN_METHOD     // Catch:{ NoSuchFieldError -> 0x0048 }
            r0[r7] = r6     // Catch:{ NoSuchFieldError -> 0x0048 }
        L_0x0048:
            $SWITCH_TABLE$net$dreamtobe$protocol$rtsp$util$RtspMethod = r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayClient.a():int[]");
    }

    public int getVideoHeight() {
        return this.m_nVideoHeight;
    }

    public int getVideoWidth() {
        return this.m_nVideoWidth;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(10:0|(4:1|2|3|(2:57|5)(5:6|7|(3:9|10|11)|12|(11:14|15|(1:19)|20|(1:22)|23|(1:27)|1|2|3|(0)(0))(0)))|27|28|29|(1:31)|32|(1:60)|34|62) */
    /* JADX WARNING: Code restructure failed: missing block: B:59:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:28:0x004f */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0053 A[Catch:{ Exception -> 0x0080 }] */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x000f A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:60:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:6:0x0010 A[Catch:{ Exception -> 0x0064, all -> 0x0062 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r5 = this;
            r0 = 0
            java.lang.Object[] r1 = new java.lang.Object[r0]
            r2 = 8
            java.lang.String r3 = "Start RTSP Client Thread"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r3, r1)
        L_0x000a:
            r1 = 1
            boolean r2 = r5.m_bIsStop     // Catch:{ Exception -> 0x0064 }
            if (r2 == 0) goto L_0x0010
            goto L_0x004f
        L_0x0010:
            int r2 = r5.ReadCliMessage()     // Catch:{ Exception -> 0x0064 }
            r3 = -1
            if (r2 != r3) goto L_0x001c
            r3 = 10
            java.lang.Thread.sleep(r3)     // Catch:{ Exception -> 0x004f }
        L_0x001c:
            r3 = -2
            if (r2 != r3) goto L_0x0020
            goto L_0x004f
        L_0x0020:
            boolean r2 = r5.m_bWaitResponse     // Catch:{ Exception -> 0x0064 }
            if (r2 != 0) goto L_0x002d
            boolean r2 = r5.ParseCliMessage()     // Catch:{ Exception -> 0x0064 }
            if (r2 == 0) goto L_0x002d
            r5.ProcessCliMessage()     // Catch:{ Exception -> 0x0064 }
        L_0x002d:
            java.lang.String r2 = r5.ReadSvrMessage()     // Catch:{ Exception -> 0x0064 }
            if (r2 == 0) goto L_0x0036
            r5.ProcessSvrMessage(r2)     // Catch:{ Exception -> 0x0064 }
        L_0x0036:
            java.net.Socket r2 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0064 }
            boolean r2 = r2.isInputShutdown()     // Catch:{ Exception -> 0x0064 }
            if (r2 != 0) goto L_0x0046
            java.net.Socket r2 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0064 }
            boolean r2 = r2.isOutputShutdown()     // Catch:{ Exception -> 0x0064 }
            if (r2 == 0) goto L_0x000a
        L_0x0046:
            r2 = 16
            java.lang.String r3 = "Socket is closed"
            java.lang.Object[] r4 = new java.lang.Object[r0]     // Catch:{ Exception -> 0x0064 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r3, r4)     // Catch:{ Exception -> 0x0064 }
        L_0x004f:
            net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread r0 = r5.m_cRtpRelayThread     // Catch:{ Exception -> 0x0080 }
            if (r0 == 0) goto L_0x0058
            net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread r0 = r5.m_cRtpRelayThread     // Catch:{ Exception -> 0x0080 }
            r0.setStop(r1)     // Catch:{ Exception -> 0x0080 }
        L_0x0058:
            java.net.Socket r0 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0080 }
            if (r0 == 0) goto L_0x0080
        L_0x005c:
            java.net.Socket r0 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0080 }
            r0.close()     // Catch:{ Exception -> 0x0080 }
            goto L_0x0080
        L_0x0062:
            r0 = move-exception
            goto L_0x0081
        L_0x0064:
            r2 = move-exception
            java.lang.String r3 = "%s"
            java.lang.Object[] r4 = new java.lang.Object[r1]     // Catch:{ all -> 0x0062 }
            java.lang.String r2 = r2.getMessage()     // Catch:{ all -> 0x0062 }
            r4[r0] = r2     // Catch:{ all -> 0x0062 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r1, r3, r4)     // Catch:{ all -> 0x0062 }
            net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread r0 = r5.m_cRtpRelayThread     // Catch:{ Exception -> 0x0080 }
            if (r0 == 0) goto L_0x007b
            net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread r0 = r5.m_cRtpRelayThread     // Catch:{ Exception -> 0x0080 }
            r0.setStop(r1)     // Catch:{ Exception -> 0x0080 }
        L_0x007b:
            java.net.Socket r0 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0080 }
            if (r0 == 0) goto L_0x0080
            goto L_0x005c
        L_0x0080:
            return
        L_0x0081:
            net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread r2 = r5.m_cRtpRelayThread     // Catch:{ Exception -> 0x0093 }
            if (r2 == 0) goto L_0x008a
            net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread r2 = r5.m_cRtpRelayThread     // Catch:{ Exception -> 0x0093 }
            r2.setStop(r1)     // Catch:{ Exception -> 0x0093 }
        L_0x008a:
            java.net.Socket r1 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0093 }
            if (r1 == 0) goto L_0x0093
            java.net.Socket r1 = r5.m_cRTSPSock     // Catch:{ Exception -> 0x0093 }
            r1.close()     // Catch:{ Exception -> 0x0093 }
        L_0x0093:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayClient.run():void");
    }

    public void setStop(boolean z) {
        this.m_bIsStop = z;
        Object[] objArr = new Object[1];
        objArr[0] = z ? "treu" : "false";
        DtbLog.cLogPrn(16, "RtspClient setStop(%s)", objArr);
    }
}

package net.dreamtobe.protocol.rtsp.rtsprelay;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import net.dreamtobe.common.log.DtbLog;
import net.dreamtobe.protocol.rtsp.util.RtpMessage;
import net.dreamtobe.protocol.rtsp.util.RtspMessageQueue;

public class RtpRelayThread extends Thread {
    public ArrayList<MediaInfo> a = new ArrayList<>();
    public boolean m_bIsStop = false;
    public boolean m_bPause = false;
    public InetAddress m_cClientAddr;
    public RtspMessageQueue m_cMessageQueue;
    public DatagramPacket m_cPacket = new DatagramPacket(new byte[2048], 2048, this.m_cClientAddr, 0);
    public MediaInfo m_cTmpMediaInfo;
    public RtpMessage m_cTmpRtpMessage;
    public int m_nRet;

    public class MediaInfo {
        public DatagramSocket m_cRTCPSocket;
        public DatagramSocket m_cRTPSocket;
        public int m_nLocalRTCPPort;
        public int m_nLocalRTPPort;
        public int m_nRemoteRTCPPort;
        public int m_nRemoteRTPPort;
        public int m_nTrackID;

        public MediaInfo(RtpRelayThread rtpRelayThread, int i, DatagramSocket datagramSocket, DatagramSocket datagramSocket2, int i2, int i3) {
            this.m_nTrackID = i;
            this.m_cRTPSocket = datagramSocket;
            this.m_cRTCPSocket = datagramSocket2;
            this.m_nLocalRTPPort = i3;
            this.m_nLocalRTCPPort = i3 + 1;
            this.m_nRemoteRTPPort = i2;
            this.m_nRemoteRTCPPort = i2 + 1;
        }
    }

    public RtpRelayThread(InetAddress inetAddress, RtspMessageQueue rtspMessageQueue) {
        this.m_cClientAddr = inetAddress;
        this.m_cMessageQueue = rtspMessageQueue;
    }

    private int ReadCliRtcp() {
        this.m_nRet = -1;
        for (int i = 0; i < this.a.size(); i++) {
            MediaInfo mediaInfo = this.a.get(i);
            this.m_cTmpMediaInfo = mediaInfo;
            try {
                mediaInfo.m_cRTCPSocket.receive(this.m_cPacket);
                if (this.m_cPacket.getLength() > 0) {
                    this.m_cMessageQueue.PushRtcpRx(this.m_cPacket.getData(), 0, this.m_cPacket.getLength(), this.m_cTmpMediaInfo.m_nTrackID);
                }
                this.m_nRet = 0;
                DtbLog.cLogPrn(64, "Track %d Receive %d rtcp data\n", Integer.valueOf(this.m_cTmpMediaInfo.m_nTrackID), Integer.valueOf(this.m_cPacket.getLength()));
            } catch (Exception unused) {
            }
        }
        return this.m_nRet;
    }

    private int ReadSvrRtcp() {
        this.m_nRet = -1;
        for (int i = 0; i < this.a.size(); i++) {
            MediaInfo mediaInfo = this.a.get(i);
            this.m_cTmpMediaInfo = mediaInfo;
            RtpMessage PopRtcpTx = this.m_cMessageQueue.PopRtcpTx(mediaInfo.m_nTrackID);
            this.m_cTmpRtpMessage = PopRtcpTx;
            if (PopRtcpTx != null) {
                try {
                    this.m_cPacket.setData(PopRtcpTx.m_pBuffer, 0, PopRtcpTx.m_nSize);
                    this.m_cPacket.setPort(this.m_cTmpMediaInfo.m_nRemoteRTCPPort);
                    this.m_cTmpMediaInfo.m_cRTCPSocket.send(this.m_cPacket);
                    this.m_nRet = 0;
                    DtbLog.cLogPrn(32, "Track %d Rtcp Send Success %d data", Integer.valueOf(this.m_cTmpMediaInfo.m_nTrackID), Integer.valueOf(this.m_cPacket.getLength()));
                    DtbLog.cLogPrn(128, "[RTCP SR Info]Sequence = %d, Timestamp = %d", Long.valueOf((((((((long) (this.m_cTmpRtpMessage.m_pBuffer[20] & 255)) << 8) + ((long) (this.m_cTmpRtpMessage.m_pBuffer[21] & 255))) << 8) + ((long) (this.m_cTmpRtpMessage.m_pBuffer[22] & 255))) << 8) + ((long) (this.m_cTmpRtpMessage.m_pBuffer[23] & 255))), Long.valueOf((((((((long) (this.m_cTmpRtpMessage.m_pBuffer[16] & 255)) << 8) + ((long) (this.m_cTmpRtpMessage.m_pBuffer[17] & 255))) << 8) + ((long) (this.m_cTmpRtpMessage.m_pBuffer[18] & 255))) << 8) + ((long) (this.m_cTmpRtpMessage.m_pBuffer[19] & 255))));
                } catch (Exception e2) {
                    DtbLog.cLogPrn(16, "Track %d Send Error : %s\n", Integer.valueOf(this.m_cTmpMediaInfo.m_nTrackID), e2.getMessage());
                }
            }
        }
        return this.m_nRet;
    }

    private int ReadSvrRtp() {
        this.m_nRet = -1;
        for (int i = 0; i < this.a.size(); i++) {
            MediaInfo mediaInfo = this.a.get(i);
            this.m_cTmpMediaInfo = mediaInfo;
            RtpMessage PopRtp = this.m_cMessageQueue.PopRtp(mediaInfo.m_nTrackID);
            this.m_cTmpRtpMessage = PopRtp;
            if (PopRtp != null) {
                try {
                    this.m_cPacket.setData(PopRtp.m_pBuffer, 0, PopRtp.m_nSize);
                    this.m_cPacket.setPort(this.m_cTmpMediaInfo.m_nRemoteRTPPort);
                    DtbLog.cLogPrn(64, "Packet Address = %s", this.m_cPacket.getAddress().getHostAddress());
                    this.m_cTmpMediaInfo.m_cRTPSocket.send(this.m_cPacket);
                    this.m_nRet = 0;
                    DtbLog.cLogPrn(32, "Track %d Send %d rtp data\n", Integer.valueOf(this.m_cTmpMediaInfo.m_nTrackID), Integer.valueOf(this.m_cPacket.getLength()));
                    DtbLog.cLogPrn(128, "[RTP Info]Payload = %d, Sequence = %d, Timestamp = %d, Size = %d", Integer.valueOf(this.m_cTmpRtpMessage.m_pBuffer[1] & Byte.MAX_VALUE), Integer.valueOf(((this.m_cTmpRtpMessage.m_pBuffer[2] & 255) << 8) + (this.m_cTmpRtpMessage.m_pBuffer[3] & 255)), Long.valueOf((((((((long) (this.m_cTmpRtpMessage.m_pBuffer[4] & 255)) << 8) + ((long) (this.m_cTmpRtpMessage.m_pBuffer[5] & 255))) << 8) + ((long) (this.m_cTmpRtpMessage.m_pBuffer[6] & 255))) << 8) + ((long) (this.m_cTmpRtpMessage.m_pBuffer[7] & 255))), Integer.valueOf(this.m_cTmpRtpMessage.m_nSize));
                } catch (Exception e2) {
                    DtbLog.cLogPrn(64, "Track %d %s\n", Integer.valueOf(this.m_cTmpMediaInfo.m_nTrackID), e2.getMessage());
                    return this.m_nRet;
                }
            }
        }
        return this.m_nRet;
    }

    public void SetRtpRleayPause(boolean z) {
        this.m_bPause = z;
    }

    public int SetRtpRtcpInfo(int i, DatagramSocket datagramSocket, DatagramSocket datagramSocket2, int i2, int i3) {
        this.m_nRet = -1;
        try {
            datagramSocket2.setSoTimeout(1);
            this.m_nRet = 0;
            MediaInfo mediaInfo = new MediaInfo(this, i, datagramSocket, datagramSocket2, i2, i3);
            this.m_cTmpMediaInfo = mediaInfo;
            this.a.add(mediaInfo);
            return this.m_nRet;
        } catch (Exception e2) {
            DtbLog.cLogPrn(64, "%s", e2.getMessage());
            return this.m_nRet;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0077, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0078, code lost:
        r3 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x007f, code lost:
        if (r3 < r14.a.size()) goto L_0x0081;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0081, code lost:
        r5 = r14.a.get(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:?, code lost:
        r5.m_cRTPSocket.close();
        net.dreamtobe.common.log.DtbLog.cLogPrn(64, "Track %d Socket is closed for rtp data", java.lang.Integer.valueOf(r5.m_nTrackID));
        r5.m_cRTCPSocket.close();
        net.dreamtobe.common.log.DtbLog.cLogPrn(64, "Track %d Socket is closed for rtcp data", java.lang.Integer.valueOf(r5.m_nTrackID));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00b0, code lost:
        throw r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x00b1, code lost:
        r2 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00b8, code lost:
        if (r2 < r14.a.size()) goto L_0x00bb;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x00bb, code lost:
        r3 = r14.a.get(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:?, code lost:
        r3.m_cRTPSocket.close();
        net.dreamtobe.common.log.DtbLog.cLogPrn(64, "Track %d Socket is closed for rtp data", java.lang.Integer.valueOf(r3.m_nTrackID));
        r3.m_cRTCPSocket.close();
        net.dreamtobe.common.log.DtbLog.cLogPrn(64, "Track %d Socket is closed for rtcp data", java.lang.Integer.valueOf(r3.m_nTrackID));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x00e7, code lost:
        r2 = r2 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x0077 A[ExcHandler: all (r2v6 'th' java.lang.Throwable A[CUSTOM_DECLARE]), Splitter:B:3:0x000d] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r14 = this;
            java.lang.String r0 = "Track %d Socket is closed for rtcp data"
            java.lang.String r1 = "Track %d Socket is closed for rtp data"
            long r2 = java.lang.System.currentTimeMillis()
            r4 = 0
        L_0x0009:
            r5 = r4
        L_0x000a:
            r6 = 64
            r7 = 1
            boolean r8 = r14.m_bIsStop     // Catch:{ Exception -> 0x00b1, all -> 0x0077 }
            if (r8 == 0) goto L_0x0012
            goto L_0x003e
        L_0x0012:
            long r8 = java.lang.System.currentTimeMillis()     // Catch:{ Exception -> 0x00b1, all -> 0x0077 }
            long r10 = r8 - r2
            r12 = 1000(0x3e8, double:4.94E-321)
            int r10 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r10 <= 0) goto L_0x0025
            r14.ReadCliRtcp()     // Catch:{ Exception -> 0x00b1, all -> 0x0077 }
            r14.ReadSvrRtcp()     // Catch:{ Exception -> 0x00b1, all -> 0x0077 }
            r2 = r8
        L_0x0025:
            boolean r8 = r14.m_bPause     // Catch:{ Exception -> 0x00b1, all -> 0x0077 }
            r9 = 10
            if (r8 == 0) goto L_0x002f
            java.lang.Thread.sleep(r9)     // Catch:{ Exception -> 0x00b1, all -> 0x0077 }
            goto L_0x000a
        L_0x002f:
            int r8 = r14.ReadSvrRtp()     // Catch:{ Exception -> 0x00b1, all -> 0x0077 }
            r11 = -1
            if (r8 != r11) goto L_0x0038
            int r5 = r5 + 1
        L_0x0038:
            if (r5 != r7) goto L_0x000a
            java.lang.Thread.sleep(r9)     // Catch:{ Exception -> 0x003e, all -> 0x0077 }
            goto L_0x0009
        L_0x003e:
            r2 = r4
        L_0x003f:
            java.util.ArrayList<net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread$MediaInfo> r3 = r14.a
            int r3 = r3.size()
            if (r2 < r3) goto L_0x0048
            goto L_0x00ba
        L_0x0048:
            java.util.ArrayList<net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread$MediaInfo> r3 = r14.a
            java.lang.Object r3 = r3.get(r2)
            net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread$MediaInfo r3 = (net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread.MediaInfo) r3
            java.net.DatagramSocket r5 = r3.m_cRTPSocket     // Catch:{ Exception -> 0x0074 }
            r5.close()     // Catch:{ Exception -> 0x0074 }
            java.lang.Object[] r5 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x0074 }
            int r8 = r3.m_nTrackID     // Catch:{ Exception -> 0x0074 }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ Exception -> 0x0074 }
            r5[r4] = r8     // Catch:{ Exception -> 0x0074 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r6, r1, r5)     // Catch:{ Exception -> 0x0074 }
            java.net.DatagramSocket r5 = r3.m_cRTCPSocket     // Catch:{ Exception -> 0x0074 }
            r5.close()     // Catch:{ Exception -> 0x0074 }
            java.lang.Object[] r5 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x0074 }
            int r3 = r3.m_nTrackID     // Catch:{ Exception -> 0x0074 }
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x0074 }
            r5[r4] = r3     // Catch:{ Exception -> 0x0074 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r6, r0, r5)     // Catch:{ Exception -> 0x0074 }
        L_0x0074:
            int r2 = r2 + 1
            goto L_0x003f
        L_0x0077:
            r2 = move-exception
            r3 = r4
        L_0x0079:
            java.util.ArrayList<net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread$MediaInfo> r5 = r14.a
            int r5 = r5.size()
            if (r3 >= r5) goto L_0x00b0
            java.util.ArrayList<net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread$MediaInfo> r5 = r14.a
            java.lang.Object r5 = r5.get(r3)
            net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread$MediaInfo r5 = (net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread.MediaInfo) r5
            java.net.DatagramSocket r8 = r5.m_cRTPSocket     // Catch:{ Exception -> 0x00ad }
            r8.close()     // Catch:{ Exception -> 0x00ad }
            java.lang.Object[] r8 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x00ad }
            int r9 = r5.m_nTrackID     // Catch:{ Exception -> 0x00ad }
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch:{ Exception -> 0x00ad }
            r8[r4] = r9     // Catch:{ Exception -> 0x00ad }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r6, r1, r8)     // Catch:{ Exception -> 0x00ad }
            java.net.DatagramSocket r8 = r5.m_cRTCPSocket     // Catch:{ Exception -> 0x00ad }
            r8.close()     // Catch:{ Exception -> 0x00ad }
            java.lang.Object[] r8 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x00ad }
            int r5 = r5.m_nTrackID     // Catch:{ Exception -> 0x00ad }
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ Exception -> 0x00ad }
            r8[r4] = r5     // Catch:{ Exception -> 0x00ad }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r6, r0, r8)     // Catch:{ Exception -> 0x00ad }
        L_0x00ad:
            int r3 = r3 + 1
            goto L_0x0079
        L_0x00b0:
            throw r2
        L_0x00b1:
            r2 = r4
        L_0x00b2:
            java.util.ArrayList<net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread$MediaInfo> r3 = r14.a
            int r3 = r3.size()
            if (r2 < r3) goto L_0x00bb
        L_0x00ba:
            return
        L_0x00bb:
            java.util.ArrayList<net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread$MediaInfo> r3 = r14.a
            java.lang.Object r3 = r3.get(r2)
            net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread$MediaInfo r3 = (net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread.MediaInfo) r3
            java.net.DatagramSocket r5 = r3.m_cRTPSocket     // Catch:{ Exception -> 0x00e7 }
            r5.close()     // Catch:{ Exception -> 0x00e7 }
            java.lang.Object[] r5 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x00e7 }
            int r8 = r3.m_nTrackID     // Catch:{ Exception -> 0x00e7 }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ Exception -> 0x00e7 }
            r5[r4] = r8     // Catch:{ Exception -> 0x00e7 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r6, r1, r5)     // Catch:{ Exception -> 0x00e7 }
            java.net.DatagramSocket r5 = r3.m_cRTCPSocket     // Catch:{ Exception -> 0x00e7 }
            r5.close()     // Catch:{ Exception -> 0x00e7 }
            java.lang.Object[] r5 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x00e7 }
            int r3 = r3.m_nTrackID     // Catch:{ Exception -> 0x00e7 }
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x00e7 }
            r5[r4] = r3     // Catch:{ Exception -> 0x00e7 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r6, r0, r5)     // Catch:{ Exception -> 0x00e7 }
        L_0x00e7:
            int r2 = r2 + 1
            goto L_0x00b2
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.rtsprelay.RtpRelayThread.run():void");
    }

    public void setStop(boolean z) {
        this.m_bIsStop = z;
    }
}

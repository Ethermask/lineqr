package net.dreamtobe.protocol.rtsp.util;

import net.dreamtobe.common.literal.CommonMacro;

public final class UrlString {
    /* JADX WARNING: Removed duplicated region for block: B:10:0x001d A[LOOP:1: B:10:0x001d->B:13:0x002e, LOOP_START, PHI: r0 
      PHI: (r0v2 int) = (r0v1 int), (r0v4 int) binds: [B:9:0x001c, B:13:0x002e] A[DONT_GENERATE, DONT_INLINE]] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String UtilStrGetAddress(java.lang.String r6) {
        /*
            r0 = 0
            if (r6 != 0) goto L_0x0004
            return r0
        L_0x0004:
            java.lang.String r1 = "://"
            int r1 = r6.indexOf(r1)
            r2 = -1
            r3 = 0
            if (r1 == r2) goto L_0x0011
            int r1 = r1 + 3
            goto L_0x0012
        L_0x0011:
            r1 = r3
        L_0x0012:
            char r2 = r6.charAt(r1)
            boolean r2 = net.dreamtobe.common.literal.CommonMacro.ISADDR(r2)
            if (r2 == 0) goto L_0x0035
            r0 = r1
        L_0x001d:
            char r2 = r6.charAt(r0)
            boolean r2 = net.dreamtobe.common.literal.CommonMacro.ISADDR(r2)
            if (r2 != 0) goto L_0x0028
            goto L_0x0030
        L_0x0028:
            int r0 = r0 + 1
            int r2 = r6.length()
            if (r0 < r2) goto L_0x001d
        L_0x0030:
            java.lang.String r6 = r6.substring(r1, r0)
            return r6
        L_0x0035:
            char r2 = r6.charAt(r1)
            boolean r2 = net.dreamtobe.common.literal.CommonMacro.ISENDLINE(r2)
            if (r2 == 0) goto L_0x0040
            return r0
        L_0x0040:
            r2 = 64
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]
            char r5 = r6.charAt(r1)
            java.lang.Character r5 = java.lang.Character.valueOf(r5)
            r4[r3] = r5
            java.lang.String r5 = "%d"
            net.dreamtobe.common.log.DtbLog.cLogPrn(r2, r5, r4)
            int r1 = r1 + 1
            goto L_0x0012
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.util.UrlString.UtilStrGetAddress(java.lang.String):java.lang.String");
    }

    public static int UtilStrGetDecNumber(String str, int i) {
        if (str == null) {
            return -1;
        }
        while (!CommonMacro.ISDIGIT(str.charAt(i))) {
            if (CommonMacro.ISENDLINE(str.charAt(i))) {
                return -1;
            }
            i++;
        }
        int i2 = i;
        while (CommonMacro.ISDIGIT(str.charAt(i2))) {
            i2++;
        }
        String substring = str.substring(i, i2);
        if (substring != null) {
            return Integer.decode(substring).intValue();
        }
        return -1;
    }

    public static String UtilStrGetLine(String str, int i) {
        if (str.length() == 0) {
            return str;
        }
        while (CommonMacro.ISSPACE(str.charAt(i))) {
            i++;
        }
        int indexOf = str.indexOf("\r\n", i);
        if (indexOf == -1) {
            return null;
        }
        return str.substring(i, indexOf + 2);
    }

    public static String UtilURLGetAddr(String str) {
        if (str == null) {
            return null;
        }
        return UtilStrGetAddress(str);
    }

    public static String UtilURLGetContentLocation(String str) {
        if (str == null) {
            return null;
        }
        int indexOf = str.indexOf(47);
        if (indexOf == -1) {
            indexOf = str.indexOf(92);
        }
        if (indexOf == -1) {
            return null;
        }
        return str.substring(indexOf);
    }

    public static String UtilURLGetFilename(String str) {
        if (str == null) {
            return null;
        }
        int indexOf = str.indexOf(47);
        if (indexOf == -1) {
            indexOf = str.indexOf(92);
        }
        if (indexOf == -1) {
            return null;
        }
        int i = indexOf + 1;
        int indexOf2 = str.indexOf(63);
        if (indexOf2 == -1 || indexOf2 <= i) {
            return str.substring(i);
        }
        return str.substring(i, indexOf2 - 1);
    }

    public static int UtilURLGetPort(String str) {
        String UtilStrGetAddress;
        int indexOf;
        int UtilStrGetDecNumber;
        if (str == null || (UtilStrGetAddress = UtilStrGetAddress(str)) == null || (indexOf = str.indexOf(UtilStrGetAddress)) == -1) {
            return 0;
        }
        int length = UtilStrGetAddress.length() + indexOf;
        if (str.charAt(length) != ':' || (UtilStrGetDecNumber = UtilStrGetDecNumber(str, length)) == -1) {
            return 0;
        }
        return UtilStrGetDecNumber;
    }
}

package net.dreamtobe.protocol.rtsp.util;

public class RtpMessage {
    public int m_nSize = 0;
    public byte[] m_pBuffer;

    public RtpMessage(byte[] bArr) {
        this.m_pBuffer = bArr;
    }
}

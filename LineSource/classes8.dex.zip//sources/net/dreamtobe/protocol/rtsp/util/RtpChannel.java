package net.dreamtobe.protocol.rtsp.util;

import java.net.DatagramSocket;

public class RtpChannel {
    public DatagramSocket m_cRTCPSocket = null;
    public DatagramSocket m_cRTPSocket = null;
    public int m_dwIndex = -1;
    public long m_dwRTPSSRC = 0;
    public long m_dwRTPTime = 0;
    public long m_dwSampleRate = 0;
    public String m_szControl = null;
    public int m_wLocalRTCPPort = 0;
    public int m_wLocalRTPPort = 0;
    public int m_wMultiRTCPPort = 0;
    public int m_wMultiRTPPort = 0;
    public int m_wRemoteRTCPPort = 0;
    public int m_wRemoteRTPPort = 0;
    public int m_wSeq = 0;

    public int GetTrackID() {
        return this.m_dwIndex;
    }
}

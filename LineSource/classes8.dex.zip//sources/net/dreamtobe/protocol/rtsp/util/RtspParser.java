package net.dreamtobe.protocol.rtsp.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import net.dreamtobe.common.literal.CommonMacro;
import net.dreamtobe.common.log.DtbLog;
import net.sqlcipher.database.SQLiteDatabase;

public class RtspParser {
    public static final String RTSP_VERSION = "RTSP/1.0";
    public StringBuilder a = new StringBuilder();
    public ArrayList<RtpChannel> m_aryChannelInfo = new ArrayList<>();
    public boolean m_bResponse = false;
    public boolean m_bServer;
    public boolean m_bUDP;
    public int m_dwChannelNum = 0;
    public long m_dwKey;
    public int m_dwSDPLength = 0;
    public long m_dwSeq = 0;
    public long m_dwSession = 0;
    public int m_dwStatusCode = 0;
    public RtspMethod m_eMethod = RtspMethod.NOT_METHOD;
    public RtpChannel m_hReqChannel = null;
    public int m_nURLPort = 0;
    public String m_szContentBase = null;
    public String m_szContentURL = null;
    public String m_szControl = null;
    public String m_szSDP = null;
    public String m_szURLAddress;

    public RtspParser(RtspInfo rtspInfo) {
        this.m_bServer = rtspInfo.m_bServer;
        this.m_bUDP = rtspInfo.m_bUDP;
        String str = rtspInfo.m_szURL;
        if (str != null) {
            this.m_szContentURL = str;
        }
    }

    private String RTSPGetURL(int i, boolean z) {
        String str;
        if (z) {
            String str2 = this.m_szControl;
            if (str2 == null || str2.indexOf("rtsp://") != 0) {
                String str3 = this.m_szContentBase;
                if (str3 != null) {
                    return String.format("%s %s\r\n", new Object[]{str3, RTSP_VERSION});
                }
                return String.format("%s %s\r\n", new Object[]{this.m_szContentURL, RTSP_VERSION});
            }
            return String.format("%s %s\r\n", new Object[]{this.m_szControl, RTSP_VERSION});
        }
        int i2 = 0;
        while (i2 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i2).m_dwIndex != i) {
            i2++;
        }
        if (i2 == this.m_aryChannelInfo.size()) {
            return null;
        }
        String str4 = this.m_aryChannelInfo.get(i2).m_szControl;
        if (str4 == null) {
            if (this.m_dwChannelNum != 1) {
                return null;
            }
            return String.format("%s %s\r\n", new Object[]{this.m_szContentURL, RTSP_VERSION});
        } else if (str4.indexOf("rtsp://") == 0) {
            return String.format("%s %s\r\n", new Object[]{str4, RTSP_VERSION});
        } else {
            if (this.m_szControl.indexOf("rtsp://") == 0) {
                str = this.m_szControl;
            } else {
                str = this.m_szContentBase;
                if (str == null) {
                    str = this.m_szContentURL;
                }
            }
            if (str.indexOf(47) == str.length() - 1) {
                return String.format("%s%s %s\r\n", new Object[]{str, str4, RTSP_VERSION});
            }
            return String.format("%s/%s %s\r\n", new Object[]{str, str4, RTSP_VERSION});
        }
    }

    private boolean RTSPParseBooleanValue(String str) {
        return str.indexOf("TRUE") == 0;
    }

    private boolean RTSPParseContentBase(String str) {
        if (this.m_szContentBase != null) {
            return true;
        }
        this.m_szContentBase = str;
        return true;
    }

    private boolean RTSPParseTrack(String str) {
        String[] split = str.split("[ ]*=[ ]*");
        if (split.length != 2) {
            DtbLog.cLogPrn(64, "[RTSP] RTSPParseTrack - Invalid URL (%s)", str);
        }
        RtpChannel rtpChannel = new RtpChannel();
        rtpChannel.m_szControl = str;
        rtpChannel.m_dwIndex = Integer.decode(split[split.length - 1]).intValue();
        this.m_aryChannelInfo.add(rtpChannel);
        this.m_dwChannelNum = this.m_aryChannelInfo.size();
        DtbLog.cLogPrn(1, "Track ID(%d) : szControl(%s)", Integer.valueOf(rtpChannel.m_dwIndex), rtpChannel.m_szControl);
        this.m_hReqChannel = rtpChannel;
        return true;
    }

    private boolean RTSPParseTransport(String str) {
        String[] split = str.split(";");
        for (int i = 0; i < split.length; i++) {
            if (split[i].compareToIgnoreCase("rtp/avp") == 0 || split[i].compareToIgnoreCase("rtp/avp/udp") == 0) {
                DtbLog.cLogPrn(16, "[RTSP] RTSPParseTransport - Transport UDP", new Object[0]);
            } else if (split[i].compareToIgnoreCase("rtp/avp/tcp") == 0) {
                DtbLog.cLogPrn(16, "[RTSP] RTSPParseTransport - Transport TCP", new Object[0]);
            } else if (split[i].indexOf("client_port") == 0) {
                String[] split2 = split[i].substring(split[i].indexOf("=") + 1).split("[ ]*-[ ]*");
                if (this.m_bServer) {
                    this.m_hReqChannel.m_wRemoteRTPPort = Integer.decode(split2[0]).intValue();
                    this.m_hReqChannel.m_wRemoteRTCPPort = Integer.decode(split2[1]).intValue();
                    DtbLog.cLogPrn(16, "[RTSP] RTSPParseTransport - Transport client_port : %d - %d", Integer.valueOf(this.m_hReqChannel.m_wRemoteRTPPort), Integer.valueOf(this.m_hReqChannel.m_wRemoteRTCPPort));
                }
            } else if (split[i].indexOf("server_port") == 0) {
                String[] split3 = split[i].substring(split[i].indexOf("=") + 1).split("[ ]*-[ ]*");
                if (!this.m_bServer) {
                    this.m_hReqChannel.m_wRemoteRTPPort = Integer.decode(split3[0]).intValue();
                    this.m_hReqChannel.m_wRemoteRTCPPort = Integer.decode(split3[1]).intValue();
                    DtbLog.cLogPrn(16, "[RTSP] RTSPParseTransport - Transport server_port: %d - %d", Integer.valueOf(this.m_hReqChannel.m_wRemoteRTPPort), Integer.valueOf(this.m_hReqChannel.m_wRemoteRTCPPort));
                }
            } else if (split[i].indexOf("interleaved") == 0) {
                String[] split4 = split[i].substring(split[i].indexOf("=") + 1).split("[ ]*-[ ]*");
                if (!this.m_bUDP) {
                    this.m_hReqChannel.m_wRemoteRTPPort = Integer.decode(split4[0]).intValue();
                    this.m_hReqChannel.m_wRemoteRTCPPort = Integer.decode(split4[1]).intValue();
                }
                DtbLog.cLogPrn(16, "[RTSP] RTSPParseTransport - Transport interleaved : %d - %d", Integer.valueOf(this.m_hReqChannel.m_wRemoteRTPPort), Integer.valueOf(this.m_hReqChannel.m_wRemoteRTCPPort));
            } else if (split[i].indexOf("ssrc") == 0) {
                String substring = split[i].substring(split[i].indexOf("=") + 1);
                this.m_hReqChannel.m_dwRTPSSRC = Long.decode("#" + substring).longValue();
                DtbLog.cLogPrn(16, "[RTSP] RTSPParseTransport - Transport ssrc %d", Long.valueOf(this.m_hReqChannel.m_dwRTPSSRC));
            }
        }
        return true;
    }

    private boolean RTSPParseURL(String str) {
        this.m_szContentURL = str;
        this.m_szURLAddress = UrlString.UtilURLGetAddr(str);
        int indexOf = this.m_szContentURL.indexOf(":", 7);
        if (indexOf != -1) {
            int indexOf2 = this.m_szContentURL.indexOf(47, indexOf);
            if (indexOf2 == -1) {
                indexOf2 = this.m_szContentURL.indexOf(92, indexOf);
            }
            if (indexOf2 == -1) {
                return false;
            }
            this.m_nURLPort = Integer.decode(this.m_szContentURL.substring(indexOf + 1, indexOf2)).intValue();
            DtbLog.cLogPrn(32, "nPos = %d, nPort = %d", Integer.valueOf(indexOf2), Integer.valueOf(indexOf));
            StringBuilder sb = new StringBuilder(this.m_szContentURL);
            sb.delete(indexOf, indexOf2);
            this.m_szContentBase = sb.toString();
        } else {
            DtbLog.cLogPrn(32, "Port Infomation not exist", new Object[0]);
            this.m_szContentBase = this.m_szContentURL;
        }
        DtbLog.cLogPrn(32, "RTSPParseURL : m_szContentURL = %s, m_szURLAddress = %s, m_nURLPort = %d, m_szContentBase= %s", this.m_szContentURL, this.m_szURLAddress, Integer.valueOf(this.m_nURLPort), this.m_szContentBase);
        return true;
    }

    public String RTSPGetAddress() {
        return this.m_szURLAddress;
    }

    public long RTSPGetCSeq() {
        return this.m_dwSeq;
    }

    public RtpChannel RTSPGetChannel(int i) {
        return this.m_aryChannelInfo.get(i);
    }

    public long RTSPGetErrorCode() {
        DtbLog.cLogPrn(32, "[RTSP]\tdwStatus=%d", Integer.valueOf(this.m_dwStatusCode));
        int i = this.m_dwStatusCode;
        if (i == 200) {
            return 0;
        }
        if (i < 400 || i >= 500) {
            if (this.m_dwStatusCode >= 500) {
                return CommonMacro.COMMON_ERR_SERVER;
            }
            return 2147483648L;
        } else if (i == 400) {
            return 2164261888L;
        } else {
            if (i == 401) {
                return CommonMacro.COMMON_ERR_UNAUTHORIZED;
            }
            if (i == 403) {
                return CommonMacro.COMMON_ERR_FORBIDDEN;
            }
            if (i == 404) {
                return CommonMacro.COMMON_ERR_FOPEN;
            }
            if (i == 405) {
                return CommonMacro.COMMON_ERR_NOTALLOWED;
            }
            if (i == 406) {
                return CommonMacro.COMMON_ERR_NOTACCEPT;
            }
            if (i == 407) {
                return CommonMacro.COMMON_ERR_NEEDPROXYAUTH;
            }
            if (i == 408) {
                return CommonMacro.COMMON_ERR_TIMEOUT;
            }
            if (i == 409) {
                return CommonMacro.COMMON_ERR_CONFLICT;
            }
            if (i == 410) {
                return CommonMacro.COMMON_ERR_GONE;
            }
            if (i == 411) {
                return CommonMacro.COMMON_ERR_NEEDLENGTH;
            }
            if (i == 412) {
                return CommonMacro.COMMON_ERR_PRECONDITION;
            }
            if (i == 413) {
                return CommonMacro.COMMON_ERR_ENTITYBIG;
            }
            if (i == 414) {
                return CommonMacro.COMMON_ERR_URL;
            }
            if (i == 415) {
                return CommonMacro.COMMON_ERR_MEDIATYPE;
            }
            if (i == 455) {
                return CommonMacro.COMMON_ERR_FUNCTION;
            }
            if (i == 457) {
                return CommonMacro.COMMON_ERR_INVALID_RANGE;
            }
            return i == 461 ? CommonMacro.COMMON_ERR_UNSUPPORT_TRASNPORT : ((long) i) + CommonMacro.HTTP_ERR_BASE;
        }
    }

    public long RTSPGetKey() {
        return this.m_dwKey;
    }

    public String RTSPGetMessage() {
        return this.a.toString();
    }

    public int RTSPGetPort() {
        return this.m_nURLPort;
    }

    public int RTSPGetRTCPLocalPort(int i) {
        int i2 = 0;
        while (i2 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i2).m_dwIndex != i) {
            i2++;
        }
        if (i2 == this.m_aryChannelInfo.size()) {
            return -1;
        }
        return this.m_aryChannelInfo.get(i2).m_wLocalRTCPPort;
    }

    public int RTSPGetRTCPRemotePort(int i) {
        int i2 = 0;
        while (i2 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i2).m_dwIndex != i) {
            i2++;
        }
        if (i2 == this.m_aryChannelInfo.size()) {
            return -1;
        }
        return this.m_aryChannelInfo.get(i2).m_wRemoteRTCPPort;
    }

    public int RTSPGetRTPLocalPort(int i) {
        int i2 = 0;
        while (i2 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i2).m_dwIndex != i) {
            i2++;
        }
        if (i2 == this.m_aryChannelInfo.size()) {
            return -1;
        }
        return this.m_aryChannelInfo.get(i2).m_wLocalRTPPort;
    }

    public int RTSPGetRTPRemotePort(int i) {
        int i2 = 0;
        while (i2 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i2).m_dwIndex != i) {
            i2++;
        }
        if (i2 == this.m_aryChannelInfo.size()) {
            return -1;
        }
        return this.m_aryChannelInfo.get(i2).m_wRemoteRTPPort;
    }

    public int RTSPGetReqIndex() {
        return this.m_hReqChannel.m_dwIndex;
    }

    public RtspMethod RTSPGetReqMethod() {
        return this.m_eMethod;
    }

    public String RTSPGetSDP() {
        return this.m_szSDP;
    }

    public int RTSPGetSDPLength() {
        return this.m_dwSDPLength;
    }

    public long RTSPGetSSRC(int i) {
        int i2 = 0;
        while (i2 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i2).m_dwIndex != i) {
            i2++;
        }
        if (i2 == this.m_aryChannelInfo.size()) {
            return -1;
        }
        return this.m_aryChannelInfo.get(i2).m_dwRTPSSRC;
    }

    public long RTSPGetSession() {
        return this.m_dwSession;
    }

    public int RTSPGetTrackCnt() {
        return this.m_dwChannelNum;
    }

    public int RTSPGetTrackIDFromRTCPPort(int i) {
        int i2 = 0;
        while (i2 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i2).m_wLocalRTCPPort != i) {
            i2++;
        }
        if (i2 == this.m_aryChannelInfo.size()) {
            return -1;
        }
        return this.m_aryChannelInfo.get(i2).m_dwIndex;
    }

    public int RTSPGetTrackIDFromRTPPort(int i) {
        int i2 = 0;
        while (i2 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i2).m_wLocalRTPPort != i) {
            i2++;
        }
        if (i2 == this.m_aryChannelInfo.size()) {
            return -1;
        }
        return this.m_aryChannelInfo.get(i2).m_dwIndex;
    }

    public String RTSPMakeTeardownRequest() {
        StringBuilder sb = new StringBuilder();
        String RTSPGetURL = RTSPGetURL(0, true);
        if (RTSPGetURL == null) {
            return null;
        }
        sb.append(String.format("TEARDOWN %sCSeq: 10\r\n", new Object[]{RTSPGetURL}));
        sb.append("Connection: close\r\n");
        sb.append("\r\n");
        return sb.toString();
    }

    public byte[] RTSPParsingMessage(String str) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        char c;
        long j;
        byte[] bArr;
        byte[] bArr2;
        byte[] bArr3;
        byte[] bArr4;
        byte[] bArr5;
        byte[] bArr6;
        String str2 = str;
        int length = str.length();
        StringBuilder sb = this.a;
        sb.delete(0, sb.length());
        byte[] bArr7 = null;
        if (length <= 0) {
            return null;
        }
        int i6 = 1;
        int i7 = 16;
        DtbLog.cLogPrn(16, "Parsing Message Size (%d)", Integer.valueOf(str.length()));
        int i8 = length;
        int i9 = 0;
        while (CommonMacro.ISCRLF(str2.charAt(i9))) {
            i9 += 2;
            i8 = i - 2;
            bArr7 = null;
            i6 = 1;
        }
        int indexOf = str2.indexOf("\r\n\r\n", i9);
        if (indexOf == -1) {
            try {
                return str2.substring(0).getBytes(SQLiteDatabase.KEY_ENCODING);
            } catch (UnsupportedEncodingException unused) {
                return bArr7;
            }
        } else {
            int i10 = indexOf + 4;
            int i11 = i2;
            int i12 = 0;
            boolean z = false;
            while (true) {
                if (i == 0) {
                    break;
                }
                String UtilStrGetLine = UrlString.UtilStrGetLine(str2, i9);
                this.a.append(UtilStrGetLine);
                Object[] objArr = new Object[i2];
                objArr[0] = UtilStrGetLine;
                DtbLog.cLogPrn(i7, "Received Message Line Add (%s)", objArr);
                if (CommonMacro.ISCRLF(UtilStrGetLine.charAt(0))) {
                    i -= 2;
                    i9 += 2;
                    DtbLog.cLogPrn(32, "ISCRLF (%s:%d)", UtilStrGetLine, 0);
                    break;
                }
                i -= UtilStrGetLine.length();
                i9 = UtilStrGetLine.length() + i9;
                if (i11 != 0) {
                    String[] split = UtilStrGetLine.split("\\s");
                    if (split[0].indexOf("RTSP") == 0) {
                        this.m_dwStatusCode = Integer.parseInt(split[1]);
                        this.m_bResponse = true;
                        DtbLog.cLogPrn(i7, "RTSP Response recv", new Object[0]);
                    } else {
                        if (split[0].indexOf("DESCRIBE") == 0) {
                            this.m_eMethod = RtspMethod.DESCRIBE_METHOD;
                            if (!RTSPParseURL(split[1])) {
                                try {
                                    bArr6 = str2.substring(0).getBytes(SQLiteDatabase.KEY_ENCODING);
                                } catch (UnsupportedEncodingException unused2) {
                                    bArr6 = null;
                                }
                                StringBuilder sb2 = this.a;
                                sb2.delete(0, sb2.length());
                                return bArr6;
                            }
                            DtbLog.cLogPrn(i7, "RTSPParsingMessage : Describe Check", new Object[0]);
                        } else if (split[0].indexOf("SETUP") == 0) {
                            this.m_eMethod = RtspMethod.SETUP_METHOD;
                            if (!RTSPParseTrack(split[1])) {
                                try {
                                    bArr5 = str2.substring(0).getBytes(SQLiteDatabase.KEY_ENCODING);
                                } catch (UnsupportedEncodingException unused3) {
                                    bArr5 = null;
                                }
                                StringBuilder sb3 = this.a;
                                sb3.delete(0, sb3.length());
                                return bArr5;
                            }
                            DtbLog.cLogPrn(i7, "RTSPParsingMessage : Setup Check", new Object[0]);
                        } else if (split[0].indexOf("PLAY") == 0) {
                            this.m_eMethod = RtspMethod.PLAY_METHOD;
                            DtbLog.cLogPrn(i7, "RTSPParsingMessage : Play Check", new Object[0]);
                        } else if (split[0].indexOf("PAUSE") == 0) {
                            this.m_eMethod = RtspMethod.PAUSE_METHOD;
                            DtbLog.cLogPrn(i7, "RTSPParsingMessage : Play Check", new Object[0]);
                        } else if (split[0].indexOf("TEARDOWN") == 0) {
                            this.m_eMethod = RtspMethod.TEARDOWN_METHOD;
                            DtbLog.cLogPrn(64, "[RTSP] RTSPParsingMessage - Teardown recv", new Object[0]);
                        } else if (split[0].indexOf("OPTIONS") == 0) {
                            if (this.m_szURLAddress != null || RTSPParseURL(split[1])) {
                                this.m_eMethod = RtspMethod.OPTIONS_METHOD;
                                DtbLog.cLogPrn(64, "[RTSP]\tRTSPParsingMessage - Options recv", new Object[0]);
                            } else {
                                try {
                                    bArr4 = str2.substring(0).getBytes(SQLiteDatabase.KEY_ENCODING);
                                } catch (UnsupportedEncodingException unused4) {
                                    bArr4 = null;
                                }
                                StringBuilder sb4 = this.a;
                                sb4.delete(0, sb4.length());
                                DtbLog.cLogPrn(32, "RTSPParseURL process failed", new Object[0]);
                                return bArr4;
                            }
                        } else if (split[0].indexOf("SET_PARAMETER") == 0) {
                            this.m_eMethod = RtspMethod.SET_PARAMETER_METHOD;
                            DtbLog.cLogPrn(64, "[RTSP]\tRTSPParsingMessage - Set Patameter recv", new Object[0]);
                        } else if (split[0].indexOf("GET_PARAMETER") == 0) {
                            this.m_eMethod = RtspMethod.GET_PARAMETER_METHOD;
                            DtbLog.cLogPrn(64, "[RTSP]\tRTSPParsingMessage - Get Patameter recv", new Object[0]);
                        } else {
                            this.m_eMethod = RtspMethod.NOT_METHOD;
                            DtbLog.cLogPrn(64, "[RTSP]\tRTSPParsingMessage - NotMethod recv", new Object[0]);
                        }
                        this.m_dwStatusCode = 200;
                        this.m_bResponse = false;
                    }
                    i11 = 0;
                } else {
                    String[] split2 = UtilStrGetLine.split("[ ]*[:\r\n][ ]*");
                    if (split2.length < 2) {
                        DtbLog.cLogPrn(i7, "szLineArg.legnth(%d) is not 2", Integer.valueOf(split2.length));
                    } else if (split2[0].indexOf("Transport") == 0) {
                        if (!RTSPParseTransport(split2[1])) {
                            DtbLog.cLogPrn(i7, "Transport Parsing Error", new Object[0]);
                            try {
                                bArr3 = str2.substring(0).getBytes(SQLiteDatabase.KEY_ENCODING);
                            } catch (UnsupportedEncodingException unused5) {
                                bArr3 = null;
                            }
                            StringBuilder sb5 = this.a;
                            sb5.delete(0, sb5.length());
                            return bArr3;
                        }
                    } else if (split2[0].indexOf("Content-Base") == 0) {
                        DtbLog.cLogPrn(i7, "Content-Base Processing", new Object[0]);
                        if (!RTSPParseContentBase(split2[1])) {
                            DtbLog.cLogPrn(i7, "Content-Base Parsing Error", new Object[0]);
                            try {
                                bArr2 = str2.substring(0).getBytes(SQLiteDatabase.KEY_ENCODING);
                            } catch (UnsupportedEncodingException unused6) {
                                bArr2 = null;
                            }
                            StringBuilder sb6 = this.a;
                            sb6.delete(0, sb6.length());
                            return bArr2;
                        }
                    } else {
                        if (split2[0].indexOf("Content-Type") == 0) {
                            if (split2[1].indexOf("sdp") != -1) {
                                DtbLog.cLogPrn(i7, "Content-Type is SDP", new Object[0]);
                                i2 = 1;
                                z = true;
                            } else {
                                i4 = i7;
                                i5 = i;
                                c = 65535;
                            }
                        } else if (split2[0].indexOf("Content-Length") == 0) {
                            i12 = Integer.decode(split2[1]).intValue();
                            DtbLog.cLogPrn(i7, "Content-Length is %d bytes", Integer.valueOf(i12));
                            if (i12 != 0 && i12 > length - i10) {
                                DtbLog.cLogPrn(i7, "RTSPParsingMessage - Content Body is not received", new Object[0]);
                                try {
                                    bArr = str2.substring(0).getBytes(SQLiteDatabase.KEY_ENCODING);
                                } catch (UnsupportedEncodingException unused7) {
                                    bArr = null;
                                }
                                StringBuilder sb7 = this.a;
                                sb7.delete(0, sb7.length());
                                return bArr;
                            }
                        } else {
                            if (split2[0].indexOf("x-dtb-key") == 0) {
                                i5 = i;
                                long longValue = Long.decode(split2[1]).longValue();
                                DtbLog.cLogPrn(16, "x-dtb-key is %d bytes", Long.valueOf(longValue));
                                this.m_dwKey = longValue;
                            } else {
                                i5 = i;
                                if (split2[0].indexOf("CSeq") == 0) {
                                    if (!this.m_bResponse) {
                                        long longValue2 = Long.decode(split2[1]).longValue();
                                        DtbLog.cLogPrn(16, "CSeq is %d", Long.valueOf(longValue2));
                                        this.m_dwSeq = longValue2;
                                    }
                                } else if (split2[0].indexOf("Session") == 0 && this.m_bResponse) {
                                    int indexOf2 = split2[1].indexOf(";");
                                    c = 65535;
                                    if (indexOf2 == -1) {
                                        j = Long.decode(split2[1]).longValue();
                                    } else {
                                        j = Long.decode(split2[1].substring(0, indexOf2)).longValue();
                                    }
                                    long j2 = j;
                                    i4 = 16;
                                    DtbLog.cLogPrn(16, "Session is %d", Long.valueOf(j2));
                                    this.m_dwSession = j2;
                                }
                            }
                            c = 65535;
                            i4 = 16;
                        }
                        i7 = i4;
                        i2 = 1;
                        int i13 = i5;
                        char c2 = c;
                        i = i13;
                    }
                    i4 = i7;
                    i5 = i;
                    c = 65535;
                    i7 = i4;
                    i2 = 1;
                    int i132 = i5;
                    char c22 = c;
                    i = i132;
                }
                i2 = 1;
            }
            if (i12 != 0) {
                i9 += i12;
                if (i - i12 != 0) {
                    DtbLog.cLogPrn(i7, "ContentLength Error!", new Object[0]);
                }
                if (z) {
                    String substring = str2.substring(i10);
                    this.m_szSDP = substring;
                    this.m_dwSDPLength = i12;
                    this.a.append(substring);
                    i3 = 1;
                    DtbLog.cLogPrn(i7, "SDP Length = %d", Integer.valueOf(this.m_dwSDPLength));
                    Object[] objArr2 = new Object[i3];
                    objArr2[0] = this.a.toString();
                    DtbLog.cLogPrn(8, "Parsing Message : \n%s", objArr2);
                    Object[] objArr3 = new Object[4];
                    objArr3[0] = Integer.valueOf(i9);
                    objArr3[i3] = Integer.valueOf(length);
                    objArr3[2] = Integer.valueOf(str.length());
                    objArr3[3] = Integer.valueOf(this.a.length());
                    DtbLog.cLogPrn(i7, "nIndex = %d, dwMessage = %d, length = %d, szMessage = %d", objArr3);
                    return str2.substring(i9).getBytes(SQLiteDatabase.KEY_ENCODING);
                }
            }
            i3 = 1;
            Object[] objArr22 = new Object[i3];
            objArr22[0] = this.a.toString();
            DtbLog.cLogPrn(8, "Parsing Message : \n%s", objArr22);
            Object[] objArr32 = new Object[4];
            objArr32[0] = Integer.valueOf(i9);
            objArr32[i3] = Integer.valueOf(length);
            objArr32[2] = Integer.valueOf(str.length());
            objArr32[3] = Integer.valueOf(this.a.length());
            DtbLog.cLogPrn(i7, "nIndex = %d, dwMessage = %d, length = %d, szMessage = %d", objArr32);
            try {
                return str2.substring(i9).getBytes(SQLiteDatabase.KEY_ENCODING);
            } catch (UnsupportedEncodingException unused8) {
                return null;
            }
        }
    }

    public void RTSPSetRTCPLocalPort(int i, int i2) {
        int i3 = 0;
        while (i3 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i3).m_dwIndex != i) {
            i3++;
        }
        if (i3 != this.m_aryChannelInfo.size()) {
            this.m_aryChannelInfo.get(i3).m_wLocalRTCPPort = i2;
        }
    }

    public void RTSPSetRTPLocalPort(int i, int i2) {
        int i3 = 0;
        while (i3 < this.m_aryChannelInfo.size() && this.m_aryChannelInfo.get(i3).m_dwIndex != i) {
            i3++;
        }
        if (i3 != this.m_aryChannelInfo.size()) {
            this.m_aryChannelInfo.get(i3).m_wLocalRTPPort = i2;
        }
    }
}

package net.dreamtobe.protocol.rtsp.util;

public class RtspInfo {
    public boolean m_b3GP = false;
    public boolean m_bMulti = false;
    public boolean m_bServer = false;
    public boolean m_bTS = false;
    public boolean m_bUDP = false;
    public int m_dwEndDate = 0;
    public int m_dwEndTime = 0;
    public int m_dwSession = 0;
    public int m_dwStartDate = 0;
    public int m_dwStartTime = 0;
    public String m_szURL = null;
    public String m_szUserAgent = null;
    public String m_szUserName = null;
}

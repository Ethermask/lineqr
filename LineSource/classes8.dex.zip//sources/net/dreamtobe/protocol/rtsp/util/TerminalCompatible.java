package net.dreamtobe.protocol.rtsp.util;

public class TerminalCompatible {
    public static final int COMPATIBLE_MT_ATRIX = 1;
    public static final int COMPATIBLE_NONE = 0;
}

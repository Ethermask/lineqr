package net.dreamtobe.protocol.rtsp.rtsprelay;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import net.dreamtobe.common.log.DtbLog;
import net.dreamtobe.protocol.rtsp.rtsprelay.RtspRelayServer;
import net.dreamtobe.protocol.rtsp.util.RtspMessageQueue;
import net.dreamtobe.protocol.rtsp.util.UrlString;

public class RtspRelay extends Thread implements RtspRelayServer.OnMangoServerDisconnectListener {
    public static final int DTB_ACCEPT_TIMEOUT = 2000;
    public static RtspRelayClient a;
    public static RtspRelayServer b;
    public boolean m_bIsStop;
    public boolean m_bUDP;
    public Socket m_cRTSPClientSocket;
    public ServerSocket m_cRTSPServerSocket;
    public RtspMessageQueue m_cSharedObj = new RtspMessageQueue();
    public OnMangoRTSPRelayServerDisconnectListener m_iRelayServerDisconnectListener = null;
    public long m_nCompatibleflag;
    public int m_nDestPort;
    public int m_nListenPort;
    public String m_szCookie;
    public String m_szDestAddr;
    public String m_szExtHeader;
    public String m_szURL;

    public interface OnMangoRTSPRelayServerDisconnectListener {
        void OnMangoRTSPRelayServerDisconnect(int i);
    }

    public RtspRelay(String str, int i, boolean z) {
        this.m_szURL = str;
        this.m_szDestAddr = UrlString.UtilURLGetAddr(str);
        int UtilURLGetPort = UrlString.UtilURLGetPort(this.m_szURL);
        this.m_nDestPort = UtilURLGetPort;
        this.m_bUDP = z;
        DtbLog.cLogPrn(8, "URL = %s, Address = %s, Port = %d\n", this.m_szURL, this.m_szDestAddr, Integer.valueOf(UtilURLGetPort));
        this.m_nListenPort = i;
        DtbLog.cLogPrn(8, "Listen Port = %d\n", Integer.valueOf(i));
        a = null;
        b = null;
        this.m_nCompatibleflag = 0;
        this.m_bIsStop = false;
    }

    public int ExecReady(long j) {
        int i = this.m_nListenPort;
        this.m_nCompatibleflag = j;
        int i2 = 0;
        while (i2 < 100) {
            i2++;
            try {
                int random = (((int) (Math.random() * 100000.0d)) % (60000 - this.m_nListenPort)) + this.m_nListenPort;
                DtbLog.cLogPrn(16, "Listen Port = %d\n", Integer.valueOf(random));
                ServerSocket serverSocket = new ServerSocket();
                this.m_cRTSPServerSocket = serverSocket;
                serverSocket.setReuseAddress(true);
                this.m_cRTSPServerSocket.setSoTimeout(2000);
                this.m_cRTSPServerSocket.bind(new InetSocketAddress(random));
                i = random;
                if (random != -1) {
                    break;
                }
            } catch (Exception e2) {
                DtbLog.cLogPrn(1, "%s", e2.getMessage());
                try {
                    this.m_cRTSPServerSocket.close();
                } catch (Exception unused) {
                }
                i = -1;
            } catch (Throwable th2) {
                if (i == -1) {
                    throw th2;
                }
            }
        }
        return i;
    }

    public void OnMangoServerDisconnect() {
        DtbLog.cLogPrn(8, "Server is disconnected", new Object[0]);
        RtspRelayClient rtspRelayClient = a;
        if (rtspRelayClient != null) {
            rtspRelayClient.setStop(true);
        }
        RtspRelayServer rtspRelayServer = b;
        if (rtspRelayServer != null) {
            rtspRelayServer.setStop(true);
        }
        OnMangoRTSPRelayServerDisconnectListener onMangoRTSPRelayServerDisconnectListener = this.m_iRelayServerDisconnectListener;
        if (onMangoRTSPRelayServerDisconnectListener != null) {
            onMangoRTSPRelayServerDisconnectListener.OnMangoRTSPRelayServerDisconnect(1);
        }
    }

    public int getVideoHeight() {
        RtspRelayClient rtspRelayClient = a;
        if (rtspRelayClient != null) {
            return rtspRelayClient.getVideoHeight();
        }
        return 0;
    }

    public int getVideoWidth() {
        RtspRelayClient rtspRelayClient = a;
        if (rtspRelayClient != null) {
            return rtspRelayClient.getVideoWidth();
        }
        return 0;
    }

    public void run() {
        int i = 0;
        while (true) {
            try {
                if (this.m_bIsStop || i * 2000 >= 5000) {
                    break;
                }
                DtbLog.cLogPrn(32, "m_cClient is accepting", new Object[0]);
                try {
                    Socket accept = this.m_cRTSPServerSocket.accept();
                    this.m_cRTSPClientSocket = accept;
                    if (accept == null) {
                        continue;
                    } else if (!accept.isConnected()) {
                        DtbLog.cLogPrn(32, "accept fail", new Object[0]);
                    } else {
                        if (!(a == null || b == null)) {
                            a.setStop(true);
                            b.setStop(true);
                            a.join();
                            DtbLog.cLogPrn(1, "m_cClient is terminated", new Object[0]);
                            b.join();
                            DtbLog.cLogPrn(1, "m_cServer is terminated", new Object[0]);
                        }
                        DtbLog.cLogPrn(1, "Client is connected", new Object[0]);
                        RtspRelayClient rtspRelayClient = new RtspRelayClient(this.m_cRTSPClientSocket, this.m_cSharedObj, this.m_szURL, this.m_nCompatibleflag);
                        a = rtspRelayClient;
                        rtspRelayClient.start();
                        RtspRelayServer rtspRelayServer = new RtspRelayServer(this.m_cSharedObj, this.m_szURL, this.m_bUDP, this.m_szCookie, this.m_szExtHeader, this.m_nCompatibleflag);
                        b = rtspRelayServer;
                        rtspRelayServer.setOnMangoServerDisconnectListener(this);
                        b.start();
                    }
                } catch (IOException e2) {
                    DtbLog.cLogPrn(16, "IOException %s", e2.getMessage());
                    i++;
                    if (this.m_cRTSPClientSocket != null && !this.m_cRTSPClientSocket.isConnected()) {
                        DtbLog.cLogPrn(32, "accept fail", new Object[0]);
                    }
                }
            } catch (Exception e3) {
                DtbLog.cLogPrn(1, "%s", e3.getMessage());
                RtspRelayClient rtspRelayClient2 = a;
                if (rtspRelayClient2 != null && rtspRelayClient2.isAlive()) {
                    a.setStop(true);
                }
                RtspRelayServer rtspRelayServer2 = b;
                if (rtspRelayServer2 != null && rtspRelayServer2.isAlive()) {
                    b.setStop(true);
                }
                if (this.m_iRelayServerDisconnectListener != null) {
                    DtbLog.cLogPrn(16, "m_iRelayServerDisconnectListener isn't null", new Object[0]);
                    this.m_iRelayServerDisconnectListener.OnMangoRTSPRelayServerDisconnect(0);
                    return;
                }
                DtbLog.cLogPrn(16, "m_iRelayServerDisconnectListener = null", new Object[0]);
                return;
            } catch (Throwable th2) {
                if (this.m_cRTSPClientSocket == null) {
                    continue;
                } else if (!this.m_cRTSPClientSocket.isConnected()) {
                    DtbLog.cLogPrn(32, "accept fail", new Object[0]);
                } else {
                    throw th2;
                }
            }
        }
        while (!this.m_bIsStop) {
            try {
                Thread.sleep(1000);
            } catch (Exception unused) {
            }
        }
        DtbLog.cLogPrn(1, "m_cClient is interrupted", new Object[0]);
        if (a != null && a.isAlive()) {
            a.setStop(true);
        }
        if (b != null && b.isAlive()) {
            b.setStop(true);
        }
        a.join();
        DtbLog.cLogPrn(1, "m_cClient is terminated", new Object[0]);
        b.join();
        DtbLog.cLogPrn(1, "m_cServer is terminated", new Object[0]);
    }

    public void setOnMangoRTSPRelayServerDisconnectListener(OnMangoRTSPRelayServerDisconnectListener onMangoRTSPRelayServerDisconnectListener) {
        this.m_iRelayServerDisconnectListener = onMangoRTSPRelayServerDisconnectListener;
    }

    public void setStop(boolean z) {
        this.m_bIsStop = z;
    }

    public RtspRelay(String str, int i, boolean z, String str2, String str3) {
        this.m_szURL = str;
        this.m_szDestAddr = UrlString.UtilURLGetAddr(str);
        int UtilURLGetPort = UrlString.UtilURLGetPort(this.m_szURL);
        this.m_nDestPort = UtilURLGetPort;
        this.m_bUDP = z;
        this.m_szCookie = str2;
        this.m_szExtHeader = str3;
        DtbLog.cLogPrn(8, "URL = %s, Address = %s, Port = %d\n", this.m_szURL, this.m_szDestAddr, Integer.valueOf(UtilURLGetPort));
        this.m_nListenPort = i;
        DtbLog.cLogPrn(8, "Listen Port = %d\n", Integer.valueOf(i));
        a = null;
        b = null;
        this.m_nCompatibleflag = 0;
        this.m_bIsStop = false;
    }
}

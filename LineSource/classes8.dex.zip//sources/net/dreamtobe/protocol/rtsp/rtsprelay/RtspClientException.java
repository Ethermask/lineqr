package net.dreamtobe.protocol.rtsp.rtsprelay;

public class RtspClientException extends Exception {
    public static final long serialVersionUID = -3810298543752420076L;

    public RtspClientException() {
        super("Rtsp cleint exception");
    }

    public RtspClientException(String str) {
        super(str);
    }
}

package net.dreamtobe.protocol.rtsp.util;

import java.util.LinkedList;

public class RtspMessageQueue {
    public static final int MAX_MESSAGE_SIZE = 2000;
    public static final int MAX_RTCP_QUEUE_SIZE = 10;
    public static final int MAX_RTP_QUEUE_SIZE = 500;
    public static final int MAX_RTSP_QUEUE_SIZE = 1;
    public LinkedList<RtpMessageQueue> a = new LinkedList<>();
    public LinkedList<StringBuilder> b = new LinkedList<>();
    public int c;
    public int d;

    /* renamed from: e  reason: collision with root package name */
    public int f55e;
    public LinkedList<StringBuilder> f = new LinkedList<>();
    public int g;
    public int h;
    public int i;

    public class RtpMessageQueue {
        public int a;
        public LinkedList<RtpMessage> b = new LinkedList<>();
        public int c;
        public int d;

        /* renamed from: e  reason: collision with root package name */
        public int f56e;
        public LinkedList<RtpMessage> f = new LinkedList<>();
        public int g;
        public int h;
        public int i;
        public LinkedList<RtpMessage> j = new LinkedList<>();
        public int k;
        public int l;
        public int m;

        public RtpMessageQueue(RtspMessageQueue rtspMessageQueue) {
            this.c = 0;
            this.g = 0;
            this.k = 0;
            this.d = 0;
            this.h = 0;
            this.l = 0;
            this.f56e = RtspMessageQueue.MAX_RTP_QUEUE_SIZE;
            this.i = 10;
            this.m = 10;
            for (int i2 = 0; i2 < 500; i2++) {
                this.b.add(new RtpMessage(new byte[2000]));
            }
            for (int i3 = 0; i3 < 10; i3++) {
                this.f.add(new RtpMessage(new byte[2000]));
                this.j.add(new RtpMessage(new byte[2000]));
            }
        }
    }

    public RtspMessageQueue() {
        this.c = 0;
        this.d = 0;
        this.f55e = 1;
        this.g = 0;
        this.h = 0;
        this.i = 1;
        for (int i2 = 0; i2 < 1; i2++) {
            this.b.add(new StringBuilder());
            this.f.add(new StringBuilder());
        }
    }

    public String GetMsg(boolean z) {
        StringBuilder sb;
        StringBuilder sb2;
        String str = null;
        if (z) {
            synchronized (this.f) {
                if (!(this.i == 1 || (sb2 = this.f.get(this.g)) == null)) {
                    str = sb2.toString();
                    sb2.delete(0, sb2.length());
                    this.g = (this.g + 1) % 1;
                    this.i++;
                    this.f.notify();
                }
            }
        } else {
            synchronized (this.b) {
                if (!(this.f55e == 1 || (sb = this.b.get(this.c)) == null)) {
                    str = sb.toString();
                    sb.delete(0, sb.length());
                    this.c = (this.c + 1) % 1;
                    this.f55e++;
                    this.b.notify();
                }
            }
        }
        return str;
    }

    public boolean MakeChannelInfo(int i2) {
        RtpMessageQueue rtpMessageQueue = new RtpMessageQueue(this);
        rtpMessageQueue.a = i2;
        this.a.add(rtpMessageQueue);
        return true;
    }

    public RtpMessage PopRtcpRx(int i2) {
        RtpMessage rtpMessage = null;
        int i3 = 0;
        RtpMessageQueue rtpMessageQueue = null;
        while (i3 < this.a.size()) {
            rtpMessageQueue = this.a.get(i3);
            if (rtpMessageQueue.a == i2) {
                break;
            }
            i3++;
        }
        if (!(i3 == this.a.size() || rtpMessageQueue == null)) {
            synchronized (rtpMessageQueue.f) {
                if (!(rtpMessageQueue.i == 10 || (rtpMessage = rtpMessageQueue.f.get(rtpMessageQueue.g)) == null)) {
                    rtpMessageQueue.g = (rtpMessageQueue.g + 1) % 10;
                    rtpMessageQueue.i++;
                    rtpMessageQueue.f.notify();
                }
            }
        }
        return rtpMessage;
    }

    public RtpMessage PopRtcpTx(int i2) {
        RtpMessage rtpMessage = null;
        int i3 = 0;
        RtpMessageQueue rtpMessageQueue = null;
        while (i3 < this.a.size()) {
            rtpMessageQueue = this.a.get(i3);
            if (rtpMessageQueue.a == i2) {
                break;
            }
            i3++;
        }
        if (!(i3 == this.a.size() || rtpMessageQueue == null)) {
            synchronized (rtpMessageQueue.j) {
                if (!(rtpMessageQueue.m == 10 || (rtpMessage = rtpMessageQueue.j.get(rtpMessageQueue.k)) == null)) {
                    rtpMessageQueue.k = (rtpMessageQueue.k + 1) % 10;
                    rtpMessageQueue.m++;
                    rtpMessageQueue.j.notify();
                }
            }
        }
        return rtpMessage;
    }

    public RtpMessage PopRtp(int i2) {
        RtpMessage rtpMessage = null;
        int i3 = 0;
        RtpMessageQueue rtpMessageQueue = null;
        while (i3 < this.a.size()) {
            rtpMessageQueue = this.a.get(i3);
            if (rtpMessageQueue.a == i2) {
                break;
            }
            i3++;
        }
        if (!(i3 == this.a.size() || rtpMessageQueue == null)) {
            synchronized (rtpMessageQueue.b) {
                if (!(rtpMessageQueue.f56e == 500 || (rtpMessage = rtpMessageQueue.b.get(rtpMessageQueue.c)) == null)) {
                    rtpMessageQueue.c = (rtpMessageQueue.c + 1) % MAX_RTP_QUEUE_SIZE;
                    int i4 = rtpMessageQueue.f56e + 1;
                    rtpMessageQueue.f56e = i4;
                    if (i4 == 1) {
                        rtpMessageQueue.b.notify();
                    }
                }
            }
        }
        return rtpMessage;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(5:21|22|(2:24|(2:26|27))(2:28|29)|30|31) */
    /* JADX WARNING: Can't wrap try/catch for region: R(5:4|5|(2:7|(2:9|10))(2:11|12)|13|14) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x002e */
    /* JADX WARNING: Missing exception handler attribute for start block: B:30:0x005b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean PushMsg(java.lang.String r6, boolean r7) {
        /*
            r5 = this;
            r0 = 3000(0xbb8, double:1.482E-320)
            r2 = 0
            r3 = 1
            if (r7 == 0) goto L_0x0033
            java.util.LinkedList<java.lang.StringBuilder> r7 = r5.b
            monitor-enter(r7)
            int r4 = r5.f55e     // Catch:{ all -> 0x0030 }
            if (r4 == 0) goto L_0x0029
            java.util.LinkedList<java.lang.StringBuilder> r0 = r5.b     // Catch:{ all -> 0x0030 }
            int r1 = r5.d     // Catch:{ all -> 0x0030 }
            java.lang.Object r0 = r0.get(r1)     // Catch:{ all -> 0x0030 }
            java.lang.StringBuilder r0 = (java.lang.StringBuilder) r0     // Catch:{ all -> 0x0030 }
            if (r0 == 0) goto L_0x002e
            r0.insert(r2, r6)     // Catch:{ all -> 0x0030 }
            int r6 = r5.d     // Catch:{ all -> 0x0030 }
            int r6 = r6 + r3
            int r6 = r6 % r3
            r5.d = r6     // Catch:{ all -> 0x0030 }
            int r6 = r5.f55e     // Catch:{ all -> 0x0030 }
            int r6 = r6 - r3
            r5.f55e = r6     // Catch:{ all -> 0x0030 }
            r2 = r3
            goto L_0x002e
        L_0x0029:
            java.util.LinkedList<java.lang.StringBuilder> r6 = r5.b     // Catch:{ InterruptedException -> 0x002e }
            r6.wait(r0)     // Catch:{ InterruptedException -> 0x002e }
        L_0x002e:
            monitor-exit(r7)     // Catch:{ all -> 0x0030 }
            goto L_0x005c
        L_0x0030:
            r6 = move-exception
            monitor-exit(r7)     // Catch:{ all -> 0x0030 }
            throw r6
        L_0x0033:
            java.util.LinkedList<java.lang.StringBuilder> r7 = r5.f
            monitor-enter(r7)
            int r4 = r5.i     // Catch:{ all -> 0x005d }
            if (r4 == 0) goto L_0x0056
            java.util.LinkedList<java.lang.StringBuilder> r0 = r5.f     // Catch:{ all -> 0x005d }
            int r1 = r5.h     // Catch:{ all -> 0x005d }
            java.lang.Object r0 = r0.get(r1)     // Catch:{ all -> 0x005d }
            java.lang.StringBuilder r0 = (java.lang.StringBuilder) r0     // Catch:{ all -> 0x005d }
            if (r0 == 0) goto L_0x005b
            r0.insert(r2, r6)     // Catch:{ all -> 0x005d }
            int r6 = r5.h     // Catch:{ all -> 0x005d }
            int r6 = r6 + r3
            int r6 = r6 % r3
            r5.h = r6     // Catch:{ all -> 0x005d }
            int r6 = r5.i     // Catch:{ all -> 0x005d }
            int r6 = r6 - r3
            r5.i = r6     // Catch:{ all -> 0x005d }
            r2 = r3
            goto L_0x005b
        L_0x0056:
            java.util.LinkedList<java.lang.StringBuilder> r6 = r5.f     // Catch:{ InterruptedException -> 0x005b }
            r6.wait(r0)     // Catch:{ InterruptedException -> 0x005b }
        L_0x005b:
            monitor-exit(r7)     // Catch:{ all -> 0x005d }
        L_0x005c:
            return r2
        L_0x005d:
            r6 = move-exception
            monitor-exit(r7)     // Catch:{ all -> 0x005d }
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.util.RtspMessageQueue.PushMsg(java.lang.String, boolean):boolean");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(5:10|11|(2:13|(2:15|16))(3:17|18|19)|20|21) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:20:0x0057 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean PushRtcpRx(byte[] r6, int r7, int r8, int r9) {
        /*
            r5 = this;
            r0 = 0
            r1 = 0
            r2 = r0
        L_0x0003:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue> r3 = r5.a
            int r3 = r3.size()
            if (r2 < r3) goto L_0x000c
            goto L_0x0018
        L_0x000c:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue> r1 = r5.a
            java.lang.Object r1 = r1.get(r2)
            net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue r1 = (net.dreamtobe.protocol.rtsp.util.RtspMessageQueue.RtpMessageQueue) r1
            int r3 = r1.a
            if (r3 != r9) goto L_0x005d
        L_0x0018:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue> r9 = r5.a
            int r9 = r9.size()
            if (r2 == r9) goto L_0x005c
            if (r1 == 0) goto L_0x005c
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtpMessage> r9 = r1.f
            monitor-enter(r9)
            int r2 = r1.i     // Catch:{ all -> 0x0059 }
            r3 = 1
            if (r2 == 0) goto L_0x004b
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtpMessage> r2 = r1.f     // Catch:{ all -> 0x0059 }
            int r4 = r1.h     // Catch:{ all -> 0x0059 }
            java.lang.Object r2 = r2.get(r4)     // Catch:{ all -> 0x0059 }
            net.dreamtobe.protocol.rtsp.util.RtpMessage r2 = (net.dreamtobe.protocol.rtsp.util.RtpMessage) r2     // Catch:{ all -> 0x0059 }
            if (r2 == 0) goto L_0x0057
            byte[] r4 = r2.m_pBuffer     // Catch:{ all -> 0x0059 }
            java.lang.System.arraycopy(r6, r7, r4, r0, r8)     // Catch:{ all -> 0x0059 }
            r2.m_nSize = r8     // Catch:{ all -> 0x0059 }
            int r6 = r1.h     // Catch:{ all -> 0x0059 }
            int r6 = r6 + r3
            int r6 = r6 % 10
            r1.h = r6     // Catch:{ all -> 0x0059 }
            int r6 = r1.i     // Catch:{ all -> 0x0059 }
            int r6 = r6 - r3
            r1.i = r6     // Catch:{ all -> 0x0059 }
            r0 = r3
            goto L_0x0057
        L_0x004b:
            r6 = 1
            java.lang.Thread.sleep(r6)     // Catch:{ InterruptedException -> 0x0057 }
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtpMessage> r6 = r1.f     // Catch:{ InterruptedException -> 0x0057 }
            r7 = 300(0x12c, double:1.48E-321)
            r6.wait(r7)     // Catch:{ InterruptedException -> 0x0057 }
        L_0x0057:
            monitor-exit(r9)     // Catch:{ all -> 0x0059 }
            goto L_0x005c
        L_0x0059:
            r6 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x0059 }
            throw r6
        L_0x005c:
            return r0
        L_0x005d:
            int r2 = r2 + 1
            goto L_0x0003
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.util.RtspMessageQueue.PushRtcpRx(byte[], int, int, int):boolean");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(5:10|11|(2:13|(2:15|16))(3:17|18|19)|20|21) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:20:0x0057 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean PushRtcpTx(byte[] r6, int r7, int r8, int r9) {
        /*
            r5 = this;
            r0 = 0
            r1 = 0
            r2 = r0
        L_0x0003:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue> r3 = r5.a
            int r3 = r3.size()
            if (r2 < r3) goto L_0x000c
            goto L_0x0018
        L_0x000c:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue> r1 = r5.a
            java.lang.Object r1 = r1.get(r2)
            net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue r1 = (net.dreamtobe.protocol.rtsp.util.RtspMessageQueue.RtpMessageQueue) r1
            int r3 = r1.a
            if (r3 != r9) goto L_0x005d
        L_0x0018:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue> r9 = r5.a
            int r9 = r9.size()
            if (r2 == r9) goto L_0x005c
            if (r1 == 0) goto L_0x005c
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtpMessage> r9 = r1.j
            monitor-enter(r9)
            int r2 = r1.m     // Catch:{ all -> 0x0059 }
            r3 = 1
            if (r2 == 0) goto L_0x004b
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtpMessage> r2 = r1.j     // Catch:{ all -> 0x0059 }
            int r4 = r1.l     // Catch:{ all -> 0x0059 }
            java.lang.Object r2 = r2.get(r4)     // Catch:{ all -> 0x0059 }
            net.dreamtobe.protocol.rtsp.util.RtpMessage r2 = (net.dreamtobe.protocol.rtsp.util.RtpMessage) r2     // Catch:{ all -> 0x0059 }
            if (r2 == 0) goto L_0x0057
            byte[] r4 = r2.m_pBuffer     // Catch:{ all -> 0x0059 }
            java.lang.System.arraycopy(r6, r7, r4, r0, r8)     // Catch:{ all -> 0x0059 }
            r2.m_nSize = r8     // Catch:{ all -> 0x0059 }
            int r6 = r1.l     // Catch:{ all -> 0x0059 }
            int r6 = r6 + r3
            int r6 = r6 % 10
            r1.l = r6     // Catch:{ all -> 0x0059 }
            int r6 = r1.m     // Catch:{ all -> 0x0059 }
            int r6 = r6 - r3
            r1.m = r6     // Catch:{ all -> 0x0059 }
            r0 = r3
            goto L_0x0057
        L_0x004b:
            r6 = 1
            java.lang.Thread.sleep(r6)     // Catch:{ InterruptedException -> 0x0057 }
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtpMessage> r6 = r1.j     // Catch:{ InterruptedException -> 0x0057 }
            r7 = 300(0x12c, double:1.48E-321)
            r6.wait(r7)     // Catch:{ InterruptedException -> 0x0057 }
        L_0x0057:
            monitor-exit(r9)     // Catch:{ all -> 0x0059 }
            goto L_0x005c
        L_0x0059:
            r6 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x0059 }
            throw r6
        L_0x005c:
            return r0
        L_0x005d:
            int r2 = r2 + 1
            goto L_0x0003
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.util.RtspMessageQueue.PushRtcpTx(byte[], int, int, int):boolean");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(5:27|28|29|30|31) */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x002a, code lost:
        r2 = r1.b.get(r1.d);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0034, code lost:
        if (r2 == null) goto L_0x0064;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0038, code lost:
        if (r8 <= 2000) goto L_0x003b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x003a, code lost:
        r8 = 2000;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:?, code lost:
        java.lang.System.arraycopy(r6, r7, r2.m_pBuffer, 0, r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:?, code lost:
        net.dreamtobe.common.log.DtbLog.cLogPrn(1, "nOffset(%d), nSize(%d)", java.lang.Integer.valueOf(r7), java.lang.Integer.valueOf(r8));
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:31:0x0072 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean PushRtp(byte[] r6, int r7, int r8, int r9) {
        /*
            r5 = this;
            r0 = 0
            r1 = 0
            r2 = r0
        L_0x0003:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue> r3 = r5.a
            int r3 = r3.size()
            if (r2 < r3) goto L_0x000c
            goto L_0x0018
        L_0x000c:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue> r1 = r5.a
            java.lang.Object r1 = r1.get(r2)
            net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue r1 = (net.dreamtobe.protocol.rtsp.util.RtspMessageQueue.RtpMessageQueue) r1
            int r3 = r1.a
            if (r3 != r9) goto L_0x0078
        L_0x0018:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtspMessageQueue$RtpMessageQueue> r9 = r5.a
            int r9 = r9.size()
            if (r2 == r9) goto L_0x0077
            if (r1 == 0) goto L_0x0077
        L_0x0022:
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtpMessage> r9 = r1.b
            monitor-enter(r9)
            int r2 = r1.f56e     // Catch:{ all -> 0x0074 }
            r3 = 1
            if (r2 == 0) goto L_0x0066
            java.util.LinkedList<net.dreamtobe.protocol.rtsp.util.RtpMessage> r2 = r1.b     // Catch:{ all -> 0x0074 }
            int r4 = r1.d     // Catch:{ all -> 0x0074 }
            java.lang.Object r2 = r2.get(r4)     // Catch:{ all -> 0x0074 }
            net.dreamtobe.protocol.rtsp.util.RtpMessage r2 = (net.dreamtobe.protocol.rtsp.util.RtpMessage) r2     // Catch:{ all -> 0x0074 }
            if (r2 == 0) goto L_0x0064
            r4 = 2000(0x7d0, float:2.803E-42)
            if (r8 <= r4) goto L_0x003b
            r8 = r4
        L_0x003b:
            byte[] r4 = r2.m_pBuffer     // Catch:{ ArrayIndexOutOfBoundsException -> 0x0041 }
            java.lang.System.arraycopy(r6, r7, r4, r0, r8)     // Catch:{ ArrayIndexOutOfBoundsException -> 0x0041 }
            goto L_0x0055
        L_0x0041:
            java.lang.String r6 = "nOffset(%d), nSize(%d)"
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ all -> 0x0074 }
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ all -> 0x0074 }
            r4[r0] = r7     // Catch:{ all -> 0x0074 }
            java.lang.Integer r7 = java.lang.Integer.valueOf(r8)     // Catch:{ all -> 0x0074 }
            r4[r3] = r7     // Catch:{ all -> 0x0074 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r3, r6, r4)     // Catch:{ all -> 0x0074 }
        L_0x0055:
            r2.m_nSize = r8     // Catch:{ all -> 0x0074 }
            int r6 = r1.d     // Catch:{ all -> 0x0074 }
            int r6 = r6 + r3
            int r6 = r6 % 500
            r1.d = r6     // Catch:{ all -> 0x0074 }
            int r6 = r1.f56e     // Catch:{ all -> 0x0074 }
            int r6 = r6 - r3
            r1.f56e = r6     // Catch:{ all -> 0x0074 }
            r0 = r3
        L_0x0064:
            monitor-exit(r9)     // Catch:{ all -> 0x0074 }
            goto L_0x0077
        L_0x0066:
            java.lang.String r2 = "Push Queue overflow"
            java.lang.Object[] r4 = new java.lang.Object[r0]     // Catch:{ all -> 0x0074 }
            net.dreamtobe.common.log.DtbLog.cLogPrn(r3, r2, r4)     // Catch:{ all -> 0x0074 }
            r2 = 10
            java.lang.Thread.sleep(r2)     // Catch:{ InterruptedException -> 0x0072 }
        L_0x0072:
            monitor-exit(r9)     // Catch:{ all -> 0x0074 }
            goto L_0x0022
        L_0x0074:
            r6 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x0074 }
            throw r6
        L_0x0077:
            return r0
        L_0x0078:
            int r2 = r2 + 1
            goto L_0x0003
        */
        throw new UnsupportedOperationException("Method not decompiled: net.dreamtobe.protocol.rtsp.util.RtspMessageQueue.PushRtp(byte[], int, int, int):boolean");
    }
}

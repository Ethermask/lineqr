package net.dreamtobe.common.log;

public class LogLevel {
    public static final int LOG_CRI = 1;
    public static final int LOG_DB0 = 16;
    public static final int LOG_DB1 = 32;
    public static final int LOG_DB2 = 64;
    public static final int LOG_DB3 = 128;
    public static final int LOG_INF = 8;
    public static final int LOG_MAJ = 2;
    public static final int LOG_MIN = 4;
}

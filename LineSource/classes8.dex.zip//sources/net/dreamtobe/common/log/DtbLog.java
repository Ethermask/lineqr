package net.dreamtobe.common.log;

import java.util.GregorianCalendar;

public class DtbLog {
    public static int a = 255;

    public static void cLogInit(int i) {
        a = i;
    }

    public static void cLogPrn(int i, String str, Object... objArr) {
        if ((a & i) != 0) {
            GregorianCalendar gregorianCalendar = new GregorianCalendar();
            Object[] objArr2 = new Object[9];
            objArr2[0] = Integer.valueOf(gregorianCalendar.get(1));
            objArr2[1] = Integer.valueOf(gregorianCalendar.get(2));
            objArr2[2] = Integer.valueOf(gregorianCalendar.get(5));
            objArr2[3] = Integer.valueOf(gregorianCalendar.get(11));
            objArr2[4] = Integer.valueOf(gregorianCalendar.get(12));
            objArr2[5] = Integer.valueOf(gregorianCalendar.get(13));
            objArr2[6] = Integer.valueOf(gregorianCalendar.get(14));
            objArr2[7] = getLineInfo();
            objArr2[8] = i != 1 ? i != 2 ? i != 4 ? i != 8 ? i != 16 ? i != 32 ? i != 64 ? i != 128 ? "[???]" : "[DB3]" : "[DB2]" : "[DB1]" : "[DB0]" : "[INF]" : "[MIN]" : "[MAJ]" : "[CRI]";
            String.format("[%04d%02d%02d:%02d%02d%02d:%d](%s) %s", objArr2);
            String.format(str, objArr);
        }
    }

    public static String getLineInfo() {
        StackTraceElement stackTraceElement = new Throwable().getStackTrace()[2];
        return String.format("%-14s,%4d", new Object[]{stackTraceElement.getFileName(), Integer.valueOf(stackTraceElement.getLineNumber())});
    }
}

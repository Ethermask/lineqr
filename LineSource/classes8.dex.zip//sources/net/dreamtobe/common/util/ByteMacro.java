package net.dreamtobe.common.util;

public class ByteMacro {
}

package net.dreamtobe.common.util;

import java.util.BitSet;
import net.dreamtobe.common.log.DtbLog;

public class UtilBit {
    public BitSet a;
    public int b;
    public int c;

    public UtilBit(byte[] bArr) {
        DtbLog.cLogPrn(16, "Array length = %d", Integer.valueOf(bArr.length));
        BitSet bitSet = new BitSet(bArr.length * 8);
        this.a = bitSet;
        DtbLog.cLogPrn(16, "BitSet length = %d", Integer.valueOf(bitSet.size()));
        for (int i = 0; i < bArr.length * 8; i++) {
            int i2 = i / 8;
            int i3 = 7 - (i % 8);
            DtbLog.cLogPrn(128, "%d, %x, %d, %d", Integer.valueOf(i2), Integer.valueOf(bArr[i2] & 255), Integer.valueOf(i3), Integer.valueOf(((bArr[i2] & 255) >> i3) & 1));
            this.a.set(i, (((bArr[i2] & 255) >> i3) & 1) == 1);
        }
        this.b = bArr.length * 8;
        this.c = 0;
    }

    public int GetBits(int i) {
        int i2 = this.c;
        if (i2 + i >= this.b) {
            DtbLog.cLogPrn(16, "GetBits error : exceed range [%d:%d:%d]", Integer.valueOf(i2), Integer.valueOf(i), Integer.valueOf(this.b));
            return -1;
        }
        int i3 = 0;
        for (int i4 = 0; i4 < i; i4++) {
            i3 += (this.a.get(this.c + i4) ? 1 : 0) << ((i - i4) - 1);
        }
        this.c += i;
        return i3;
    }

    public int GetSignedExpGolombCode() {
        int nextSetBit = this.a.nextSetBit(this.c);
        int i = -1;
        if (nextSetBit == -1) {
            DtbLog.cLogPrn(16, "Signed GetExpGolombCode error : not exist on bit", new Object[0]);
            return -1;
        }
        int i2 = nextSetBit - this.c;
        if (i2 == 0) {
            return 0;
        }
        int i3 = 0;
        for (int i4 = 1; i4 < i2; i4++) {
            i3 += 1 << (i4 - 1);
        }
        DtbLog.cLogPrn(16, "Signed ExpGolombCode : Length(%d), Temporary Code(%d)", Integer.valueOf(i2), Integer.valueOf(i3));
        this.c = i2 + 1 + this.c;
        int GetBits = GetBits(i2 - 1) + 1 + i3;
        if (GetBits(1) != 1) {
            i = 1;
        }
        int i5 = GetBits * i;
        DtbLog.cLogPrn(16, "Signed ExpGolombCode : Length(%d), Final Code(%d)", Integer.valueOf(i2), Integer.valueOf(i5));
        return i5;
    }

    public int GetUnsignedExpGolombCode() {
        int nextSetBit = this.a.nextSetBit(this.c);
        if (nextSetBit == -1) {
            DtbLog.cLogPrn(16, "Unsigned GetExpGolombCode error : not exist on bit", new Object[0]);
            return -1;
        }
        int i = nextSetBit - this.c;
        int i2 = 0;
        for (int i3 = 1; i3 < i; i3++) {
            i2 += 1 << i3;
        }
        DtbLog.cLogPrn(16, "Unsigned ExpGolombCode : Length(%d), Temporary Code(%d)", Integer.valueOf(i), Integer.valueOf(i2));
        this.c = i + 1 + this.c;
        if (i != 0) {
            i2 += GetBits(i) + 1;
        }
        DtbLog.cLogPrn(16, "Unsigned ExpGolombCode : Length(%d), Final Code(%d)", Integer.valueOf(i), Integer.valueOf(i2));
        return i2;
    }
}

package net.dreamtobe.common.literal;

public class CommonMacro {
    public static final long ADECFILTER_ERR_BASE = 2153906176L;
    public static final long AENCFILTER_ERR_BASE = 2154037248L;
    public static final long ARENFILTER_ERR_BASE = 2154168320L;
    public static final long COMMON_ERR_AUDIOCODEC = 2147483683L;
    public static final long COMMON_ERR_AUDIODEC = 2147483686L;
    public static final long COMMON_ERR_AUDIODEVIN = 2147483692L;
    public static final long COMMON_ERR_AUDIODEVOUT = 2147483694L;
    public static final long COMMON_ERR_AUDIOENC = 2147483689L;
    public static final long COMMON_ERR_BADREQUEST = 2164261888L;
    public static final long COMMON_ERR_BASE = 2147483648L;
    public static final long COMMON_ERR_CLIENT = 2147483706L;
    public static final long COMMON_ERR_CLI_ACCEPT = 2147483707L;
    public static final long COMMON_ERR_CLI_DISCONNECT = 2147483708L;
    public static final long COMMON_ERR_CLI_NOREQUEST = 2147483709L;
    public static final long COMMON_ERR_CONFLICT = 2164261897L;
    public static final long COMMON_ERR_DLLOPEN = 2147483744L;
    public static final long COMMON_ERR_ENCRYPTION = 2147483667L;
    public static final long COMMON_ERR_ENDOFDATA = 2147483670L;
    public static final long COMMON_ERR_ENTITYBIG = 2164261907L;
    public static final long COMMON_ERR_EXPIRED_DATA = 2147483668L;
    public static final long COMMON_ERR_FCREATE = 2147483665L;
    public static final long COMMON_ERR_FILETYPE = 2147483680L;
    public static final long COMMON_ERR_FOPEN = 2147483664L;
    public static final long COMMON_ERR_FORBIDDEN = 2164261891L;
    public static final long COMMON_ERR_FREAD = 2147483677L;
    public static final long COMMON_ERR_FUNCTION = 2147483675L;
    public static final long COMMON_ERR_GONE = 2164261904L;
    public static final long COMMON_ERR_HTTPTIMEOUT = 2164261896L;
    public static final long COMMON_ERR_HTTP_REQUEST_400 = 2164261888L;
    public static final long COMMON_ERR_HTTP_REQUEST_499 = 2164262041L;
    public static final long COMMON_ERR_INTERNALSVR = 2164262144L;
    public static final long COMMON_ERR_INVALID_PROTOCOL = 2147483697L;
    public static final long COMMON_ERR_INVALID_RANGE = 2147483676L;
    public static final long COMMON_ERR_MEDIAPARAM = 2147483682L;
    public static final long COMMON_ERR_MEDIATYPE = 2164261909L;
    public static final long COMMON_ERR_MEM = 2147483649L;
    public static final long COMMON_ERR_MUSTNOTSUPPORT = 2147483653L;
    public static final long COMMON_ERR_NAS_ALIVE = 2147483729L;
    public static final long COMMON_ERR_NAS_CONNECT = 2147483731L;
    public static final long COMMON_ERR_NAS_DISCONNECT = 2147483730L;
    public static final long COMMON_ERR_NAS_PERFORMANCE = 2147483728L;
    public static final long COMMON_ERR_NEEDDATA = 2147483671L;
    public static final long COMMON_ERR_NEEDLENGTH = 2164261905L;
    public static final long COMMON_ERR_NEEDPROXYAUTH = 2164261895L;
    public static final long COMMON_ERR_NETWORK = 2147483652L;
    public static final long COMMON_ERR_NODATA = 2147483669L;
    public static final long COMMON_ERR_NOMEDIA = 2147483674L;
    public static final long COMMON_ERR_NONEEDDATA = 2147483672L;
    public static final long COMMON_ERR_NOTACCEPT = 2164261894L;
    public static final long COMMON_ERR_NOTALLOWED = 2164261893L;
    public static final long COMMON_ERR_NOTFOUND = 2164261892L;
    public static final long COMMON_ERR_NOTMATCH_SCID = 2147483711L;
    public static final long COMMON_ERR_NOTMATCH_SSRC = 2147483710L;
    public static final long COMMON_ERR_NOTSENDGET = 2147483727L;
    public static final long COMMON_ERR_PRECONDITION = 2164261906L;
    public static final long COMMON_ERR_RECV = 2147483699L;
    public static final long COMMON_ERR_REDIRECT = 2147483726L;
    public static final long COMMON_ERR_SEND = 2147483698L;
    public static final long COMMON_ERR_SERVER = 2147483701L;
    public static final long COMMON_ERR_SOCKET = 2147483696L;
    public static final long COMMON_ERR_STREAMSYNTAX = 2147483681L;
    public static final long COMMON_ERR_SVR_CONNECT = 2147483702L;
    public static final long COMMON_ERR_SVR_DISCONNECT = 2147483703L;
    public static final long COMMON_ERR_SVR_NODATA = 2147483705L;
    public static final long COMMON_ERR_SVR_NORESPONSE = 2147483704L;
    public static final long COMMON_ERR_SYSTEM = 2147483651L;
    public static final long COMMON_ERR_TEXTCODEC = 2147483685L;
    public static final long COMMON_ERR_TEXTDEC = 2147483688L;
    public static final long COMMON_ERR_TEXTENC = 2147483691L;
    public static final long COMMON_ERR_THREAD = 2147483650L;
    public static final long COMMON_ERR_TIMEOUT = 2147483700L;
    public static final long COMMON_ERR_UNAUTHORIZED = 2164261889L;
    public static final long COMMON_ERR_UNSUPPORT_TRASNPORT = 2147483712L;
    public static final long COMMON_ERR_URL = 2147483666L;
    public static final long COMMON_ERR_URLLONG = 2164261908L;
    public static final long COMMON_ERR_VIDEOCODEC = 2147483684L;
    public static final long COMMON_ERR_VIDEODEC = 2147483687L;
    public static final long COMMON_ERR_VIDEODEVIN = 2147483693L;
    public static final long COMMON_ERR_VIDEODEVOUT = 2147483695L;
    public static final long COMMON_ERR_VIDEOENC = 2147483690L;
    public static final long COMMON_ERR_WAITDATA = 2147483673L;
    public static final long FILTERGRAPH_ERR_BASE = 2153775104L;
    public static final long HTTP_ERR_BASE = 2164260864L;
    public static final long INFINITE = 4294967295L;
    public static final long MAX_DWORD = 4294967295L;
    public static final long MC_FAIL = 2147483648L;
    public static final long MC_OK = 0;
    public static final long SRCFILTER_ERR_BASE = 2153840640L;
    public static final long VDECFILTER_ERR_BASE = 2153971712L;
    public static final long VENCFILTER_ERR_BASE = 2154102784L;
    public static final long VRENFILTER_ERR_BASE = 2154233856L;

    public static boolean ISADDR(char c) {
        return ISALNUM(c) || ISDOT(c) || ISHIPON(c);
    }

    public static boolean ISALNUM(char c) {
        return ISDIGIT(c) || ISALPHA(c);
    }

    public static boolean ISALPHA(char c) {
        return ISALPHALOW(c) || ISALPHAHIGH(c);
    }

    public static boolean ISALPHAHIGH(char c) {
        return c + 65471 < 26 && c + 65439 >= 0;
    }

    public static boolean ISALPHALOW(char c) {
        int i = c - 'a';
        return i < 26 && i >= 0;
    }

    public static boolean ISANGLE(char c) {
        return c == '<' || c == '>';
    }

    public static boolean ISBACKSLASH(char c) {
        return c == '\\';
    }

    public static boolean ISBASE64(char c) {
        return ISALNUM(c) || c == '/' || c == '+' || ISEQUAL(c) || ISCOMMA(c);
    }

    public static boolean ISCHAR(char c) {
        return ISALNUM(c) || ISDOT(c) || c == '-' || c == '_';
    }

    public static boolean ISCOLON(char c) {
        return c == ':';
    }

    public static boolean ISCOMMA(char c) {
        return c == ',';
    }

    public static boolean ISCRLF(char c) {
        return ISRETURN(c) || ISLINEFEED(c);
    }

    public static boolean ISDIGIT(char c) {
        int i = c - '0';
        return i < 10 && i >= 0;
    }

    public static boolean ISDOT(char c) {
        return c == '.';
    }

    public static boolean ISENDLINE(char c) {
        return ISRETURN(c) || ISLINEFEED(c) || ISNULL(c);
    }

    public static boolean ISEQUAL(char c) {
        return c == '=';
    }

    public static boolean ISFLOAT(char c) {
        return ISDIGIT(c) || ISDOT(c);
    }

    public static boolean ISHEXDIGIT(char c) {
        return ISDIGIT(c) || ISHEXLOW(c) || ISHEXHIGH(c);
    }

    public static boolean ISHEXHIGH(char c) {
        return (c | ' ') + 65471 < 6;
    }

    public static boolean ISHEXLOW(char c) {
        return (c | ' ') + 65439 < 26;
    }

    public static boolean ISHIPON(char c) {
        return c == '-';
    }

    public static boolean ISLINEFEED(char c) {
        return c == 10;
    }

    public static boolean ISNOFILENAME(char c) {
        return ISWILDCARD(c) || ISQUESTION(c) || ISANGLE(c) || ISBACKSLASH(c) || ISNULL(c) || ISCRLF(c) || ISENDLINE(c);
    }

    public static boolean ISNULL(char c) {
        return c == 0;
    }

    public static boolean ISQUESTION(char c) {
        return c == '?';
    }

    public static boolean ISRETURN(char c) {
        return c == 13;
    }

    public static boolean ISSAFE(char c) {
        return ISALNUM(c) || c == '\'' || c == '`' || c == '-' || c == '.' || c == '/' || c == ':' || c == '?' || c == '\"' || c == '#' || c == '$' || c == '&' || c == '*' || c == ',' || c == '=' || c == '@' || c == '[' || c == ']' || c == '^' || c == '_' || c == '{' || c == '|' || c == '}' || c == '+' || c == '~';
    }

    public static boolean ISSAFEFIRSTCHAR(char c) {
        return ISALNUM(c) || ISDOT(c) || c == '_';
    }

    public static boolean ISSEMICOLON(char c) {
        return c == ';';
    }

    public static boolean ISSPACE(char c) {
        return c == ' ';
    }

    public static boolean ISTIME(char c) {
        return ISDIGIT(c) || ISDOT(c) || ISCOLON(c);
    }

    public static boolean ISWILDCARD(char c) {
        return c == '*';
    }

    public static boolean ISWSPACE(char c) {
        return c == 9 || c == ' ' || c == 13 || c == 10;
    }

    public static boolean MCFAILED(long j) {
        return (j & 2147483648L) != 0;
    }

    public static boolean MCSUCCEEDED(long j) {
        return (j & 2147483648L) == 0;
    }
}

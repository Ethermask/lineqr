package net.sqlcipher;

import e.e.b.a.a;

public class CursorIndexOutOfBoundsException extends IndexOutOfBoundsException {
    public CursorIndexOutOfBoundsException(int i, int i2) {
        super(a.q("Index ", i, " requested, with a size of ", i2));
    }

    public CursorIndexOutOfBoundsException(String str) {
        super(str);
    }
}

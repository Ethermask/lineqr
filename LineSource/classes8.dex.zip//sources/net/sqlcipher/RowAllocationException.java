package net.sqlcipher;

public class RowAllocationException extends RuntimeException {
    public RowAllocationException() {
    }

    public RowAllocationException(String str) {
        super(str);
    }
}

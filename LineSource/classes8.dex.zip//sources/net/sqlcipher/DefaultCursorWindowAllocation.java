package net.sqlcipher;

public class DefaultCursorWindowAllocation implements CursorWindowAllocation {
    public long WindowAllocationUnbounded = 0;
    public long initialAllocationSize = 1048576;

    public long getGrowthPaddingSize() {
        return this.initialAllocationSize;
    }

    public long getInitialAllocationSize() {
        return this.initialAllocationSize;
    }

    public long getMaxAllocationSize() {
        return this.WindowAllocationUnbounded;
    }
}

package net.sqlcipher;

public final class R {

    public static final class string {
        public static final int library_android_database_sqlcipher_author = 2131955717;
        public static final int library_android_database_sqlcipher_authorWebsite = 2131955718;
        public static final int library_android_database_sqlcipher_isOpenSource = 2131955719;
        public static final int library_android_database_sqlcipher_libraryDescription = 2131955720;
        public static final int library_android_database_sqlcipher_libraryName = 2131955721;
        public static final int library_android_database_sqlcipher_libraryVersion = 2131955722;
        public static final int library_android_database_sqlcipher_libraryWebsite = 2131955723;
        public static final int library_android_database_sqlcipher_licenseLink = 2131955724;
        public static final int library_android_database_sqlcipher_repositoryLink = 2131955725;
    }
}

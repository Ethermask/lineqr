package net.sqlcipher.database;

import e.e.b.a.a;

public class SQLiteCompiledSql {
    public static final String TAG = "SQLiteCompiledSql";
    public SQLiteDatabase mDatabase;
    public boolean mInUse = false;
    public String mSqlStmt = null;
    public long nHandle = 0;
    public long nStatement = 0;

    public SQLiteCompiledSql(SQLiteDatabase sQLiteDatabase, String str) {
        if (sQLiteDatabase.isOpen()) {
            this.mDatabase = sQLiteDatabase;
            this.mSqlStmt = str;
            this.nHandle = sQLiteDatabase.mNativeHandle;
            compile(str, true);
            return;
        }
        StringBuilder V0 = a.V0("database ");
        V0.append(sQLiteDatabase.getPath());
        V0.append(" already closed");
        throw new IllegalStateException(V0.toString());
    }

    private void compile(String str, boolean z) {
        if (!this.mDatabase.isOpen()) {
            StringBuilder V0 = a.V0("database ");
            V0.append(this.mDatabase.getPath());
            V0.append(" already closed");
            throw new IllegalStateException(V0.toString());
        } else if (z) {
            this.mDatabase.lock();
            try {
                native_compile(str);
            } finally {
                this.mDatabase.unlock();
            }
        }
    }

    private final native void native_compile(String str);

    private final native void native_finalize();

    public synchronized boolean acquire() {
        if (this.mInUse) {
            return false;
        }
        this.mInUse = true;
        boolean z = SQLiteDebug.DEBUG_ACTIVE_CURSOR_FINALIZATION;
        return true;
    }

    public void finalize() throws Throwable {
        try {
            if (this.nStatement != 0) {
                boolean z = SQLiteDebug.DEBUG_ACTIVE_CURSOR_FINALIZATION;
                releaseSqlStatement();
                super.finalize();
            }
        } finally {
            super.finalize();
        }
    }

    public synchronized void release() {
        boolean z = SQLiteDebug.DEBUG_ACTIVE_CURSOR_FINALIZATION;
        this.mInUse = false;
    }

    public void releaseSqlStatement() {
        if (this.nStatement != 0) {
            boolean z = SQLiteDebug.DEBUG_ACTIVE_CURSOR_FINALIZATION;
            try {
                this.mDatabase.lock();
                native_finalize();
                this.nStatement = 0;
            } finally {
                this.mDatabase.unlock();
            }
        }
    }
}

package uh.a.a.a.b;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;

public class b implements SensorEventListener, AutoCloseable {
    public WeakReference<Context> a;
    public Semaphore b = new Semaphore(1);
    public ArrayList<a> c = new ArrayList<>();
    public ArrayList<a> d = new ArrayList<>();

    /* renamed from: e  reason: collision with root package name */
    public ArrayList<a> f186e = new ArrayList<>();
    public ArrayList<a> f = new ArrayList<>();
    public ArrayList<a> g = new ArrayList<>();
    public Sensor h;
    public Sensor i;
    public Sensor j;
    public Sensor k;
    public Sensor l;
    public boolean m = false;
    public boolean n = false;

    public static class a {
        public float[] a;
        public long b;

        public a() {
        }

        public String toString() {
            StringBuffer Q0 = e.e.b.a.a.Q0("timestamp:");
            Q0.append(this.b);
            Q0.append("\n");
            if (this.a != null) {
                int i = 0;
                while (true) {
                    float[] fArr = this.a;
                    if (i >= fArr.length) {
                        break;
                    }
                    Q0.append(fArr[i]);
                    Q0.append(";");
                    i++;
                }
            } else {
                Q0.append("null");
            }
            return Q0.toString();
        }

        public a(float[] fArr, long j) {
            this.a = (float[]) fArr.clone();
            this.b = j;
        }
    }

    public b(Context context) {
        this.a = new WeakReference<>(context);
    }

    public final void a(ArrayList<a> arrayList, a aVar) {
        if (arrayList.size() >= 30) {
            for (int i2 = 0; i2 <= arrayList.size() - 30; i2++) {
                arrayList.remove(0);
            }
        }
        arrayList.add(aVar);
    }

    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x00be */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void b(java.util.List<uh.a.a.a.b.b.a> r4, java.util.List<uh.a.a.a.b.b.a> r5, uh.a.a.a.b.b.a r6, uh.a.a.a.b.b.a r7, long r8) {
        /*
            r3 = this;
            r4.clear()
            r5.clear()
            r0 = 0
            r6.a = r0
            r1 = -1
            r6.b = r1
            r7.a = r0
            r7.b = r1
            java.util.concurrent.Semaphore r0 = r3.b     // Catch:{ InterruptedException -> 0x00be }
            r0.acquire()     // Catch:{ InterruptedException -> 0x00be }
            android.hardware.Sensor r0 = r3.l     // Catch:{ InterruptedException -> 0x00be }
            if (r0 == 0) goto L_0x004b
            java.util.ArrayList<uh.a.a.a.b.b$a> r0 = r3.g     // Catch:{ InterruptedException -> 0x00be }
            int r0 = r0.size()     // Catch:{ InterruptedException -> 0x00be }
            if (r0 <= 0) goto L_0x004b
            java.util.ArrayList<uh.a.a.a.b.b$a> r4 = r3.g     // Catch:{ InterruptedException -> 0x00be }
            java.util.ArrayList<uh.a.a.a.b.b$a> r5 = r3.g     // Catch:{ InterruptedException -> 0x00be }
            int r5 = r5.size()     // Catch:{ InterruptedException -> 0x00be }
            int r5 = r5 + -1
            java.lang.Object r4 = r4.get(r5)     // Catch:{ InterruptedException -> 0x00be }
            uh.a.a.a.b.b$a r4 = (uh.a.a.a.b.b.a) r4     // Catch:{ InterruptedException -> 0x00be }
            float[] r4 = r4.a     // Catch:{ InterruptedException -> 0x00be }
            r7.a = r4     // Catch:{ InterruptedException -> 0x00be }
            java.util.ArrayList<uh.a.a.a.b.b$a> r4 = r3.g     // Catch:{ InterruptedException -> 0x00be }
            java.util.ArrayList<uh.a.a.a.b.b$a> r5 = r3.g     // Catch:{ InterruptedException -> 0x00be }
            int r5 = r5.size()     // Catch:{ InterruptedException -> 0x00be }
            int r5 = r5 + -1
            java.lang.Object r4 = r4.get(r5)     // Catch:{ InterruptedException -> 0x00be }
            uh.a.a.a.b.b$a r4 = (uh.a.a.a.b.b.a) r4     // Catch:{ InterruptedException -> 0x00be }
            long r4 = r4.b     // Catch:{ InterruptedException -> 0x00be }
            r7.b = r4     // Catch:{ InterruptedException -> 0x00be }
            goto L_0x00b6
        L_0x004b:
            java.util.ArrayList<uh.a.a.a.b.b$a> r0 = r3.c     // Catch:{ InterruptedException -> 0x00be }
            java.util.List r0 = r3.d(r0, r8)     // Catch:{ InterruptedException -> 0x00be }
            r4.addAll(r0)     // Catch:{ InterruptedException -> 0x00be }
            java.util.ArrayList<uh.a.a.a.b.b$a> r4 = r3.d     // Catch:{ InterruptedException -> 0x00be }
            java.util.List r4 = r3.d(r4, r8)     // Catch:{ InterruptedException -> 0x00be }
            r5.addAll(r4)     // Catch:{ InterruptedException -> 0x00be }
            java.util.ArrayList<uh.a.a.a.b.b$a> r4 = r3.f186e     // Catch:{ InterruptedException -> 0x00be }
            java.util.List r4 = r3.c(r4, r8)     // Catch:{ InterruptedException -> 0x00be }
            r5 = 0
            r0 = r5
        L_0x0065:
            int r0 = r0 + 1
            r1 = r4
            java.util.ArrayList r1 = (java.util.ArrayList) r1
            int r2 = r1.size()     // Catch:{ InterruptedException -> 0x00be }
            if (r0 >= r2) goto L_0x0076
            java.util.ArrayList<uh.a.a.a.b.b$a> r1 = r3.f186e     // Catch:{ InterruptedException -> 0x00be }
            r1.remove(r5)     // Catch:{ InterruptedException -> 0x00be }
            goto L_0x0065
        L_0x0076:
            int r4 = r1.size()     // Catch:{ InterruptedException -> 0x00be }
            int r4 = r4 + -1
            java.lang.Object r4 = r1.get(r4)     // Catch:{ InterruptedException -> 0x00be }
            uh.a.a.a.b.b$a r4 = (uh.a.a.a.b.b.a) r4     // Catch:{ InterruptedException -> 0x00be }
            float[] r0 = r4.a     // Catch:{ InterruptedException -> 0x00be }
            r6.a = r0     // Catch:{ InterruptedException -> 0x00be }
            long r0 = r4.b     // Catch:{ InterruptedException -> 0x00be }
            r6.b = r0     // Catch:{ InterruptedException -> 0x00be }
            java.util.ArrayList<uh.a.a.a.b.b$a> r4 = r3.f     // Catch:{ InterruptedException -> 0x00be }
            java.util.List r4 = r3.c(r4, r8)     // Catch:{ InterruptedException -> 0x00be }
            r6 = r5
        L_0x0091:
            int r6 = r6 + 1
            r8 = r4
            java.util.ArrayList r8 = (java.util.ArrayList) r8
            int r9 = r8.size()     // Catch:{ InterruptedException -> 0x00be }
            if (r6 >= r9) goto L_0x00a2
            java.util.ArrayList<uh.a.a.a.b.b$a> r8 = r3.f     // Catch:{ InterruptedException -> 0x00be }
            r8.remove(r5)     // Catch:{ InterruptedException -> 0x00be }
            goto L_0x0091
        L_0x00a2:
            int r4 = r8.size()     // Catch:{ InterruptedException -> 0x00be }
            int r4 = r4 + -1
            java.lang.Object r4 = r8.get(r4)     // Catch:{ InterruptedException -> 0x00be }
            uh.a.a.a.b.b$a r4 = (uh.a.a.a.b.b.a) r4     // Catch:{ InterruptedException -> 0x00be }
            float[] r5 = r4.a     // Catch:{ InterruptedException -> 0x00be }
            r7.a = r5     // Catch:{ InterruptedException -> 0x00be }
            long r4 = r4.b     // Catch:{ InterruptedException -> 0x00be }
            r7.b = r4     // Catch:{ InterruptedException -> 0x00be }
        L_0x00b6:
            java.util.concurrent.Semaphore r4 = r3.b
            r4.release()
            return
        L_0x00bc:
            r4 = move-exception
            goto L_0x00c6
        L_0x00be:
            java.lang.RuntimeException r4 = new java.lang.RuntimeException     // Catch:{ all -> 0x00bc }
            java.lang.String r5 = "Can not acquire IMU lock"
            r4.<init>(r5)     // Catch:{ all -> 0x00bc }
            throw r4     // Catch:{ all -> 0x00bc }
        L_0x00c6:
            java.util.concurrent.Semaphore r5 = r3.b
            r5.release()
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: uh.a.a.a.b.b.b(java.util.List, java.util.List, uh.a.a.a.b.b$a, uh.a.a.a.b.b$a, long):void");
    }

    public final List<a> c(List<a> list, long j2) {
        ArrayList arrayList = new ArrayList();
        int i2 = 0;
        while (i2 < list.size() && list.get(i2).b <= j2) {
            arrayList.add(list.get(i2));
            i2++;
        }
        return arrayList;
    }

    public void close() throws Exception {
        i();
    }

    public final List<a> d(List<a> list, long j2) {
        ArrayList arrayList = new ArrayList();
        while (!list.isEmpty() && list.get(0).b <= j2) {
            arrayList.add(list.get(0));
            list.remove(0);
        }
        return arrayList;
    }

    public void g(List<a> list, List<a> list2) {
        if (!this.m) {
            list2.clear();
            list.clear();
            return;
        }
        int size = list.size() - list2.size();
        if (list.isEmpty()) {
            list2.clear();
        } else if (list2.isEmpty()) {
            list.clear();
        } else {
            if (size > 0) {
                if (Math.abs(list.get(size - 1).b - list2.get(0).b) > Math.abs(list.get((list.size() - 1) - size).b - ((a) e.e.b.a.a.l4(list2, -1)).b)) {
                    for (int i2 = 0; i2 < size; i2++) {
                        list.remove(0);
                    }
                } else {
                    for (int i3 = 0; i3 < size; i3++) {
                        list.remove(list.size() - 1);
                    }
                }
            } else if (size < 0) {
                int i4 = -size;
                if (Math.abs(list2.get(i4 - 1).b - list.get(0).b) > Math.abs(list2.get((list2.size() - 1) - i4).b - ((a) e.e.b.a.a.l4(list, -1)).b)) {
                    for (int i5 = 0; i5 < i4; i5++) {
                        list2.remove(0);
                    }
                } else {
                    for (int i6 = 0; i6 < i4; i6++) {
                        list2.remove(list.size() - 1);
                    }
                }
            }
            for (int i7 = 0; i7 < list.size(); i7++) {
                long j2 = (list.get(i7).b + list2.get(i7).b) / 2;
                list2.get(i7).b = j2;
                list.get(i7).b = j2;
            }
        }
    }

    public void h() {
        this.c.clear();
        this.d.clear();
        this.f186e.clear();
        this.f.clear();
        this.g.clear();
        a aVar = new a();
        aVar.a = new float[]{0.0f, 0.0f, 0.0f, 1.0f};
        aVar.b = 0;
        this.f186e.add(aVar);
        a aVar2 = new a();
        aVar2.a = new float[]{0.0f, 0.0f, 9.8f};
        aVar2.b = 0;
        this.f.add(aVar2);
        SensorManager sensorManager = (SensorManager) ((Context) this.a.get()).getSystemService("sensor");
        this.h = sensorManager.getDefaultSensor(10);
        Sensor defaultSensor = sensorManager.getDefaultSensor(4);
        this.i = defaultSensor;
        if (defaultSensor != null) {
            this.m = true;
        }
        Sensor defaultSensor2 = sensorManager.getDefaultSensor(11);
        this.j = defaultSensor2;
        if (defaultSensor2 == null) {
            this.l = sensorManager.getDefaultSensor(1);
        }
        this.k = sensorManager.getDefaultSensor(9);
        Sensor sensor = this.h;
        if (sensor != null) {
            sensorManager.registerListener(this, sensor, 0);
        }
        Sensor sensor2 = this.i;
        if (sensor2 != null) {
            sensorManager.registerListener(this, sensor2, 0);
        }
        Sensor sensor3 = this.j;
        if (sensor3 != null) {
            sensorManager.registerListener(this, sensor3, 0);
        }
        Sensor sensor4 = this.k;
        if (sensor4 != null) {
            sensorManager.registerListener(this, sensor4, 0);
        }
        Sensor sensor5 = this.l;
        if (sensor5 != null) {
            sensorManager.registerListener(this, sensor5, 0);
        }
        this.n = true;
    }

    public void i() {
        this.n = false;
        ((SensorManager) ((Context) this.a.get()).getSystemService("sensor")).unregisterListener(this);
    }

    public void onAccuracyChanged(Sensor sensor, int i2) {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x004e, code lost:
        r5 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0057, code lost:
        throw new java.lang.RuntimeException("Can not acquire IMU lock");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0058, code lost:
        r4.b.release();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x005d, code lost:
        throw r5;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:20:0x0050 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onSensorChanged(android.hardware.SensorEvent r5) {
        /*
            r4 = this;
            float[] r0 = r5.values
            long r1 = android.os.SystemClock.elapsedRealtime()
            android.hardware.Sensor r5 = r5.sensor
            uh.a.a.a.b.b$a r3 = new uh.a.a.a.b.b$a
            r3.<init>(r0, r1)
            java.util.concurrent.Semaphore r0 = r4.b     // Catch:{ InterruptedException -> 0x0050 }
            r0.acquire()     // Catch:{ InterruptedException -> 0x0050 }
            android.hardware.Sensor r0 = r4.h     // Catch:{ InterruptedException -> 0x0050 }
            if (r5 != r0) goto L_0x001c
            java.util.ArrayList<uh.a.a.a.b.b$a> r5 = r4.c     // Catch:{ InterruptedException -> 0x0050 }
            r4.a(r5, r3)     // Catch:{ InterruptedException -> 0x0050 }
            goto L_0x0048
        L_0x001c:
            android.hardware.Sensor r0 = r4.i     // Catch:{ InterruptedException -> 0x0050 }
            if (r5 != r0) goto L_0x0026
            java.util.ArrayList<uh.a.a.a.b.b$a> r5 = r4.d     // Catch:{ InterruptedException -> 0x0050 }
            r4.a(r5, r3)     // Catch:{ InterruptedException -> 0x0050 }
            goto L_0x0048
        L_0x0026:
            android.hardware.Sensor r0 = r4.j     // Catch:{ InterruptedException -> 0x0050 }
            if (r5 != r0) goto L_0x0030
            java.util.ArrayList<uh.a.a.a.b.b$a> r5 = r4.f186e     // Catch:{ InterruptedException -> 0x0050 }
            r4.a(r5, r3)     // Catch:{ InterruptedException -> 0x0050 }
            goto L_0x0048
        L_0x0030:
            android.hardware.Sensor r0 = r4.k     // Catch:{ InterruptedException -> 0x0050 }
            if (r5 != r0) goto L_0x003a
            java.util.ArrayList<uh.a.a.a.b.b$a> r5 = r4.f     // Catch:{ InterruptedException -> 0x0050 }
            r4.a(r5, r3)     // Catch:{ InterruptedException -> 0x0050 }
            goto L_0x0048
        L_0x003a:
            android.hardware.Sensor r0 = r4.l     // Catch:{ InterruptedException -> 0x0050 }
            if (r5 != r0) goto L_0x0048
            java.util.ArrayList<uh.a.a.a.b.b$a> r5 = r4.g     // Catch:{ InterruptedException -> 0x0050 }
            r5.clear()     // Catch:{ InterruptedException -> 0x0050 }
            java.util.ArrayList<uh.a.a.a.b.b$a> r5 = r4.g     // Catch:{ InterruptedException -> 0x0050 }
            r5.add(r3)     // Catch:{ InterruptedException -> 0x0050 }
        L_0x0048:
            java.util.concurrent.Semaphore r5 = r4.b
            r5.release()
            return
        L_0x004e:
            r5 = move-exception
            goto L_0x0058
        L_0x0050:
            java.lang.RuntimeException r5 = new java.lang.RuntimeException     // Catch:{ all -> 0x004e }
            java.lang.String r0 = "Can not acquire IMU lock"
            r5.<init>(r0)     // Catch:{ all -> 0x004e }
            throw r5     // Catch:{ all -> 0x004e }
        L_0x0058:
            java.util.concurrent.Semaphore r0 = r4.b
            r0.release()
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: uh.a.a.a.b.b.onSensorChanged(android.hardware.SensorEvent):void");
    }
}

package uh.a.a.a.b;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class a {

    /* renamed from: e  reason: collision with root package name */
    public static b f185e;
    public SensorManager a = null;
    public boolean b = false;
    public b c;
    public SensorEventListener d = new C0025a(this);

    /* renamed from: uh.a.a.a.b.a$a  reason: collision with other inner class name */
    public class C0025a implements SensorEventListener {
        public C0025a(a aVar) {
        }

        public void onAccuracyChanged(Sensor sensor, int i) {
        }

        public void onSensorChanged(SensorEvent sensorEvent) {
            if (sensorEvent.sensor.getType() == 1) {
                float[] fArr = sensorEvent.values;
                float f = fArr[0];
                float f2 = fArr[1];
                float f3 = fArr[2];
                if (Math.abs(f) <= 3.0f && Math.abs(f2) <= 3.0f) {
                    return;
                }
                if (Math.abs(f) > Math.abs(f2)) {
                    if (f > 0.0f) {
                        a.f185e = b.Deg0;
                    } else {
                        a.f185e = b.Deg180;
                    }
                } else if (f2 > 0.0f) {
                    a.f185e = b.Deg90;
                } else {
                    a.f185e = b.Deg270;
                }
            }
        }
    }

    public enum b {
        Deg0(0),
        Deg90(1),
        Deg180(2),
        Deg270(3);
        
        public int value;

        /* access modifiers changed from: public */
        b(int i) {
            this.value = i;
        }
    }

    public a(Context context) {
        this.a = (SensorManager) context.getSystemService("sensor");
        b bVar = b.Deg90;
        f185e = bVar;
        this.c = bVar;
    }
}

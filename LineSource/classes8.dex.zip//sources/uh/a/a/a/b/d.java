package uh.a.a.a.b;

import android.content.Context;
import android.content.SharedPreferences;
import com.linecorp.elsa.ElsaKit.common.ElsaFileNative;
import com.linecorp.yuki.sensetime.util.STMobileLog;
import com.sensetime.stmobile.STMobileAuthentificationNative;
import e.e.b.a.a;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import ka.m.r;

public class d {
    public static boolean a(Context context, String str) {
        boolean z;
        String str2 = "SenseME.lic";
        if (b(context, d(true, context, str2))) {
            STMobileLog.v("STLicenseUtils", "succeed with the embedded license");
            return true;
        }
        if (str != null) {
            str2 = str;
        }
        if (!r.H(str2, "asset://", false, 2)) {
            str2 = a.C("asset://", str2);
        }
        String native_readFileByString = ElsaFileNative.native_readFileByString(str2);
        if (native_readFileByString == null) {
            native_readFileByString = "";
        }
        if (native_readFileByString.isEmpty()) {
            z = false;
        } else {
            z = c(context, native_readFileByString);
        }
        if (z) {
            STMobileLog.v("STLicenseUtils", "succeed with the elsa file system: " + str);
            return true;
        }
        STMobileLog.e("STLicenseUtils", "no valid sensetime license at all");
        return false;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v1, resolved type: java.lang.String} */
    /* JADX WARNING: type inference failed for: r2v0 */
    /* JADX WARNING: type inference failed for: r2v3, types: [java.io.InputStreamReader] */
    /* JADX WARNING: type inference failed for: r2v4 */
    /* JADX WARNING: type inference failed for: r2v5 */
    /* JADX WARNING: type inference failed for: r2v6 */
    /* JADX WARNING: type inference failed for: r2v7 */
    /* JADX WARNING: Can't wrap try/catch for region: R(4:12|13|14|15) */
    /* JADX WARNING: Can't wrap try/catch for region: R(7:3|(5:4|5|6|7|(3:8|9|(1:11)(4:12|13|14|15)))|46|47|48|(1:51)(1:52)|(1:58)(2:56|57)) */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x004d, code lost:
        if (r4 == null) goto L_0x0052;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x0026 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:38:0x0045 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:46:0x004f */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x003a A[SYNTHETIC, Splitter:B:28:0x003a] */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x003f A[SYNTHETIC, Splitter:B:32:0x003f] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean b(android.content.Context r6, java.io.InputStream r7) {
        /*
            r0 = 0
            if (r7 != 0) goto L_0x0004
            return r0
        L_0x0004:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r2 = 0
            java.io.InputStreamReader r3 = new java.io.InputStreamReader     // Catch:{ IOException -> 0x0043, all -> 0x0033 }
            r3.<init>(r7)     // Catch:{ IOException -> 0x0043, all -> 0x0033 }
            java.io.BufferedReader r4 = new java.io.BufferedReader     // Catch:{ IOException -> 0x0031, all -> 0x002d }
            r4.<init>(r3)     // Catch:{ IOException -> 0x0031, all -> 0x002d }
        L_0x0014:
            java.lang.String r5 = r4.readLine()     // Catch:{ IOException -> 0x0045, all -> 0x002a }
            if (r5 == 0) goto L_0x0023
            r1.append(r5)     // Catch:{ IOException -> 0x0045, all -> 0x002a }
            java.lang.String r5 = "\n"
            r1.append(r5)     // Catch:{ IOException -> 0x0045, all -> 0x002a }
            goto L_0x0014
        L_0x0023:
            r7.close()     // Catch:{ IOException -> 0x0026 }
        L_0x0026:
            r3.close()     // Catch:{ IOException -> 0x004f }
            goto L_0x004f
        L_0x002a:
            r6 = move-exception
            r2 = r4
            goto L_0x002e
        L_0x002d:
            r6 = move-exception
        L_0x002e:
            r0 = r2
            r2 = r3
            goto L_0x0035
        L_0x0031:
            r4 = r2
            goto L_0x0045
        L_0x0033:
            r6 = move-exception
            r0 = r2
        L_0x0035:
            r7.close()     // Catch:{ IOException -> 0x0038 }
        L_0x0038:
            if (r2 == 0) goto L_0x003d
            r2.close()     // Catch:{ IOException -> 0x003d }
        L_0x003d:
            if (r0 == 0) goto L_0x0042
            r0.close()     // Catch:{ IOException -> 0x0042 }
        L_0x0042:
            throw r6
        L_0x0043:
            r3 = r2
            r4 = r3
        L_0x0045:
            r7.close()     // Catch:{ IOException -> 0x0048 }
        L_0x0048:
            if (r3 == 0) goto L_0x004d
            r3.close()     // Catch:{ IOException -> 0x004d }
        L_0x004d:
            if (r4 == 0) goto L_0x0052
        L_0x004f:
            r4.close()     // Catch:{ IOException -> 0x0052 }
        L_0x0052:
            java.lang.String r7 = r1.toString()
            int r7 = r7.length()
            if (r7 != 0) goto L_0x0064
            java.lang.String r7 = "STLicenseUtils"
            java.lang.String r1 = "read license data error"
            com.linecorp.yuki.sensetime.util.STMobileLog.e(r7, r1)
            goto L_0x0068
        L_0x0064:
            java.lang.String r2 = r1.toString()
        L_0x0068:
            if (r2 == 0) goto L_0x0076
            boolean r7 = r2.isEmpty()
            if (r7 == 0) goto L_0x0071
            goto L_0x0076
        L_0x0071:
            boolean r6 = c(r6, r2)
            return r6
        L_0x0076:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: uh.a.a.a.b.d.b(android.content.Context, java.io.InputStream):boolean");
    }

    public static boolean c(Context context, String str) {
        SharedPreferences sharedPreferences = context.getApplicationContext().getSharedPreferences("activate_code_file", 0);
        String string = sharedPreferences.getString("activate_code", (String) null);
        if (string == null || STMobileAuthentificationNative.checkActiveCodeFromBuffer(context, str, str.length(), string, string.length()) != 0) {
            StringBuilder V0 = a.V0("fail to check the activeCode, no previous one: ");
            V0.append(string == null);
            STMobileLog.d("STLicenseUtils", V0.toString());
            String generateActiveCodeFromBuffer = STMobileAuthentificationNative.generateActiveCodeFromBuffer(context, str, str.length());
            if (generateActiveCodeFromBuffer == null || generateActiveCodeFromBuffer.length() <= 0) {
                STMobileLog.w("STLicenseUtils", "fail to generate license");
                return false;
            }
            SharedPreferences.Editor edit = sharedPreferences.edit();
            edit.putString("activate_code", generateActiveCodeFromBuffer);
            edit.commit();
            STMobileLog.d("STLicenseUtils", "succeed to generate license: " + generateActiveCodeFromBuffer);
            return true;
        }
        STMobileLog.v("STLicenseUtils", "succeed to check the activeCode: " + string);
        return true;
    }

    public static InputStream d(boolean z, Context context, String str) {
        if (!z) {
            return new FileInputStream(new File(str));
        }
        try {
            return context.getResources().getAssets().open(str);
        } catch (IOException unused) {
            STMobileLog.w("STLicenseUtils", "[readInputStream] not supported: " + str);
            return null;
        }
    }
}

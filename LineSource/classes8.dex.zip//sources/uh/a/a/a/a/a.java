package uh.a.a.a.a;

import com.linecorp.elsa.ElsaKit.common.ElsaFileNative;
import ka.m.r;

public final class a {
    public static final ElsaFileNative a = new ElsaFileNative();

    public static final byte[] a(String str) {
        if (!r.H(str, "asset://", false, 2)) {
            str = e.e.b.a.a.C("asset://", str);
        }
        byte[] native_readFileByByteArray = ElsaFileNative.native_readFileByByteArray(str);
        if (native_readFileByByteArray != null) {
            return native_readFileByByteArray;
        }
        return null;
    }
}

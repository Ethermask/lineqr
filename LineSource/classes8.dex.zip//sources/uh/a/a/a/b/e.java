package uh.a.a.a.b;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.Rect;
import android.net.Uri;
import e.e.b.a.a;

public class e {
    public static PointF[] a(PointF[] pointFArr, int i, int i2, int i3, int i4) {
        if (pointFArr == null || pointFArr.length == 0) {
            return null;
        }
        float f = (float) i2;
        float f2 = (float) i;
        float f3 = (float) i4;
        float f4 = (float) i3;
        int i5 = 0;
        if (f / f2 >= f3 / f4) {
            float f5 = f / f3;
            while (i5 < pointFArr.length) {
                float f6 = pointFArr[i5].x;
                PointF pointF = pointFArr[i5];
                pointF.set(a.b(f4 / 2.0f, f6, f5, f2 / 2.0f), pointFArr[i5].y * f5);
                i5++;
            }
        } else {
            float f7 = f2 / f4;
            while (i5 < pointFArr.length) {
                float b = a.b(f3 / 2.0f, pointFArr[i5].y, f7, f / 2.0f);
                pointFArr[i5].set(pointFArr[i5].x * f7, b);
                i5++;
            }
        }
        return pointFArr;
    }

    public static Rect b(Rect rect, int i, int i2, int i3, int i4) {
        float f = (float) i2;
        float f2 = (float) i;
        float f3 = (float) i4;
        float f4 = (float) i3;
        if (f / f2 >= f3 / f4) {
            float f5 = f / f3;
            rect.top = (int) (((float) rect.top) * f5);
            rect.bottom = (int) (((float) rect.bottom) * f5);
            float f6 = f2 / 2.0f;
            float f7 = f4 / 2.0f;
            rect.left = (int) a.b(f7, (float) rect.left, f5, f6);
            rect.right = (int) a.b(f7, (float) rect.right, f5, f6);
        } else {
            float f8 = f2 / f4;
            float f9 = f / 2.0f;
            float f10 = f3 / 2.0f;
            rect.top = (int) a.b(f10, (float) rect.top, f8, f9);
            rect.bottom = (int) a.b(f10, (float) rect.bottom, f8, f9);
            rect.left = (int) (((float) rect.left) * f8);
            rect.right = (int) (((float) rect.right) * f8);
        }
        return rect;
    }

    public static byte[] c(Bitmap bitmap, boolean z) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int i = width * height;
        byte[] bArr = new byte[(i * 3)];
        int[] iArr = new int[i];
        bitmap.getPixels(iArr, 0, width, 0, 0, width, height);
        for (int i2 = 0; i2 < i; i2++) {
            int i3 = iArr[i2];
            int red = Color.red(i3);
            int green = Color.green(i3);
            int blue = Color.blue(i3);
            if (z) {
                int i4 = i2 * 3;
                bArr[i4 + 0] = (byte) red;
                bArr[i4 + 1] = (byte) green;
                bArr[i4 + 2] = (byte) blue;
            } else {
                int i5 = i2 * 3;
                bArr[i5 + 0] = (byte) blue;
                bArr[i5 + 1] = (byte) green;
                bArr[i5 + 2] = (byte) red;
            }
        }
        return bArr;
    }

    public static Bitmap d(Uri uri) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        int i = 1;
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(uri.getPath(), options);
        int i2 = options.outWidth;
        int i3 = options.outHeight;
        if (i2 > 2048 || i3 > 2048) {
            i = 4;
        } else if (i2 > 1024 || i3 > 1024) {
            i = 2;
        }
        options.inSampleSize = i;
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(uri.getPath(), options);
    }
}

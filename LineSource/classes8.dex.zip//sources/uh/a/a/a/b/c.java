package uh.a.a.a.b;

import android.util.Log;
import java.util.regex.Pattern;

public class c {
    public static boolean a = false;

    static {
        Pattern.compile("GMT([-+]\\d{4})$");
    }

    public static int a(String str, Object... objArr) {
        if (a) {
            return Log.d("stSticker", String.format(str, objArr));
        }
        return 0;
    }
}

package ph.a.b;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;

public class a {
    public static final int a = c(new byte[]{102, 114, 101, 101});
    public static final int b = c(new byte[]{106, 117, 110, 107});
    public static final int c = c(new byte[]{109, 100, 97, 116});
    public static final int d = c(new byte[]{109, 111, 111, 118});

    /* renamed from: e  reason: collision with root package name */
    public static final int f115e = c(new byte[]{112, 110, 111, 116});
    public static final int f = c(new byte[]{115, 107, 105, 112});
    public static final int g = c(new byte[]{119, 105, 100, 101});
    public static final int h = c(new byte[]{80, 73, 67, 84});
    public static final int i = c(new byte[]{102, 116, 121, 112});
    public static final int j = c(new byte[]{117, 117, 105, 100});
    public static final int k = c(new byte[]{99, 109, 111, 118});
    public static final int l = c(new byte[]{115, 116, 99, 111});
    public static final int m = c(new byte[]{99, 111, 54, 52});

    public static class b extends c {
        public b(String str, C0009a aVar) {
            super(str, (C0009a) null);
        }
    }

    public static class c extends Exception {
        public c(String str, C0009a aVar) {
            super(str);
        }
    }

    public static class d extends c {
        public d(String str, C0009a aVar) {
            super(str, (C0009a) null);
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: java.io.FileInputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: java.io.FileInputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v2, resolved type: java.io.FileInputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v3, resolved type: java.io.FileInputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v0, resolved type: java.io.FileOutputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v4, resolved type: java.io.FileInputStream} */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x001a */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x001f  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x002f A[SYNTHETIC, Splitter:B:22:0x002f] */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0034 A[SYNTHETIC, Splitter:B:26:0x0034] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean a(java.io.File r4, java.io.File r5) throws java.io.IOException, ph.a.b.a.b, ph.a.b.a.d {
        /*
            r0 = 0
            java.io.FileInputStream r1 = new java.io.FileInputStream     // Catch:{ all -> 0x002b }
            r1.<init>(r4)     // Catch:{ all -> 0x002b }
            java.nio.channels.FileChannel r4 = r1.getChannel()     // Catch:{ all -> 0x0026 }
            java.io.FileOutputStream r2 = new java.io.FileOutputStream     // Catch:{ all -> 0x0026 }
            r2.<init>(r5)     // Catch:{ all -> 0x0026 }
            java.nio.channels.FileChannel r0 = r2.getChannel()     // Catch:{ all -> 0x0023 }
            boolean r4 = b(r4, r0)     // Catch:{ all -> 0x0023 }
            r1.close()     // Catch:{ IOException -> 0x001a }
        L_0x001a:
            r2.close()     // Catch:{ IOException -> 0x001d }
        L_0x001d:
            if (r4 != 0) goto L_0x0022
            r5.delete()
        L_0x0022:
            return r4
        L_0x0023:
            r4 = move-exception
            r0 = r2
            goto L_0x0027
        L_0x0026:
            r4 = move-exception
        L_0x0027:
            r3 = r1
            r1 = r0
            r0 = r3
            goto L_0x002d
        L_0x002b:
            r4 = move-exception
            r1 = r0
        L_0x002d:
            if (r0 == 0) goto L_0x0032
            r0.close()     // Catch:{ IOException -> 0x0032 }
        L_0x0032:
            if (r1 == 0) goto L_0x0037
            r1.close()     // Catch:{ IOException -> 0x0037 }
        L_0x0037:
            r5.delete()
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: ph.a.b.a.a(java.io.File, java.io.File):boolean");
    }

    public static boolean b(FileChannel fileChannel, FileChannel fileChannel2) throws IOException, b, d {
        FileChannel fileChannel3 = fileChannel;
        FileChannel fileChannel4 = fileChannel2;
        int i2 = 8;
        ByteBuffer order = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN);
        int i3 = 0;
        ByteBuffer byteBuffer = null;
        long j2 = 0;
        long j3 = 0;
        while (true) {
            if (!d(fileChannel3, order)) {
                break;
            }
            j2 = ((long) order.getInt()) & 4294967295L;
            i3 = order.getInt();
            if (i3 == i) {
                int e2 = e(j2);
                ByteBuffer order2 = ByteBuffer.allocate(e2).order(ByteOrder.BIG_ENDIAN);
                order.rewind();
                order2.put(order);
                if (fileChannel3.read(order2) < e2 - 8) {
                    byteBuffer = order2;
                    break;
                }
                order2.flip();
                j3 = fileChannel.position();
                byteBuffer = order2;
            } else if (j2 == 1) {
                order.clear();
                if (!d(fileChannel3, order)) {
                    break;
                }
                j2 = order.getLong();
                if (j2 >= 0) {
                    fileChannel3.position((fileChannel.position() + j2) - 16);
                } else {
                    throw new d("uint64 value is too large", (C0009a) null);
                }
            } else {
                fileChannel3.position((fileChannel.position() + j2) - 8);
            }
            if (i3 != a) {
                if (!(i3 == b || i3 == c || i3 == d || i3 == f115e || i3 == f || i3 == g || i3 == h || i3 == j || i3 == i)) {
                    break;
                }
            }
            if (j2 < 8) {
                break;
            }
        }
        if (i3 != d) {
            return false;
        }
        int e3 = e(j2);
        long j4 = (long) e3;
        long size = fileChannel.size() - j4;
        ByteBuffer order3 = ByteBuffer.allocate(e3).order(ByteOrder.BIG_ENDIAN);
        order3.clear();
        int read = fileChannel3.read(order3, size);
        order3.flip();
        if (!(read == order3.capacity())) {
            throw new b("failed to read moov atom", (C0009a) null);
        } else if (order3.getInt(12) != k) {
            while (order3.remaining() >= i2) {
                int position = order3.position();
                int i4 = order3.getInt(position + 4);
                if (i4 == l || i4 == m) {
                    long j5 = size;
                    if ((((long) order3.getInt(position)) & 4294967295L) <= ((long) order3.remaining())) {
                        order3.position(position + 12);
                        if (order3.remaining() >= 4) {
                            int i5 = order3.getInt();
                            if (i5 >= 0) {
                                if (i4 == l) {
                                    if (order3.remaining() >= i5 * 4) {
                                        int i6 = 0;
                                        while (i6 < i5) {
                                            int i7 = order3.getInt(order3.position());
                                            int i8 = i7 + e3;
                                            if (i7 >= 0 || i8 < 0) {
                                                order3.putInt(i8);
                                                i6++;
                                            } else {
                                                throw new d("This is bug in original qt-faststart.c: stco atom should be extended to co64 atom as new offset value overflows uint32, but is not implemented.", (C0009a) null);
                                            }
                                        }
                                    } else {
                                        throw new b("bad atom size/element count", (C0009a) null);
                                    }
                                } else if (i4 == m) {
                                    if (order3.remaining() >= i5 * 8) {
                                        for (int i9 = 0; i9 < i5; i9++) {
                                            order3.putLong(order3.getLong(order3.position()) + j4);
                                        }
                                    } else {
                                        throw new b("bad atom size/element count", (C0009a) null);
                                    }
                                }
                                size = j5;
                                i2 = 8;
                            } else {
                                throw new d("uint32 value is too large", (C0009a) null);
                            }
                        } else {
                            throw new b("malformed atom", (C0009a) null);
                        }
                    } else {
                        throw new b("bad atom size", (C0009a) null);
                    }
                } else {
                    order3.position(order3.position() + 1);
                    i2 = 8;
                }
            }
            long j6 = size;
            fileChannel3.position(j3);
            if (byteBuffer != null) {
                byteBuffer.rewind();
                fileChannel4.write(byteBuffer);
            }
            order3.rewind();
            fileChannel4.write(order3);
            fileChannel.transferTo(j3, j6 - j3, fileChannel2);
            return true;
        } else {
            throw new d("this utility does not support compressed moov atoms yet", (C0009a) null);
        }
    }

    public static int c(byte[] bArr) {
        return ByteBuffer.wrap(bArr).order(ByteOrder.BIG_ENDIAN).getInt();
    }

    public static boolean d(FileChannel fileChannel, ByteBuffer byteBuffer) throws IOException {
        byteBuffer.clear();
        int read = fileChannel.read(byteBuffer);
        byteBuffer.flip();
        return read == byteBuffer.capacity();
    }

    public static int e(long j2) throws d {
        if (j2 <= 2147483647L && j2 >= 0) {
            return (int) j2;
        }
        throw new d("uint32 value is too large", (C0009a) null);
    }
}

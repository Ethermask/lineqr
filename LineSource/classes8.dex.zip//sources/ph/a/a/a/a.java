package ph.a.a.a;

import android.media.MediaFormat;
import e.a.d1.a0.k.a.h.o;

public final class a implements o {
    public boolean a() {
        return true;
    }

    public void b(c cVar) {
    }

    public boolean c() {
        return false;
    }

    public void d() {
    }

    public MediaFormat e() {
        return null;
    }

    public boolean f() {
        return false;
    }

    public long g() {
        return 0;
    }

    public void release() {
    }
}

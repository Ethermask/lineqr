package ph.a.a.a;

public interface c {
}

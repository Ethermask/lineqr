package ph.a.a.a;

import e.a.d1.a0.k.a.h.o;
import ka.h.c.p;

public final class b {
    public long a;
    public final o b;
    public final o c;

    public b(o oVar, o oVar2) {
        p.e(oVar, "videoTrackTranscoder");
        p.e(oVar2, "audioTrackTranscoder");
        this.b = oVar;
        this.c = oVar2;
    }
}

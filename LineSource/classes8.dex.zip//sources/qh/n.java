package qh;

import e.e.b.a.a;
import java.io.EOFException;
import java.io.IOException;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import ka.b.q;
import ka.h.c.p;

public final class n implements a0 {
    public int a;
    public boolean b;
    public final g c;
    public final Inflater d;

    public n(g gVar, Inflater inflater) {
        p.e(gVar, "source");
        p.e(inflater, "inflater");
        this.c = gVar;
        this.d = inflater;
    }

    public final long a(d dVar, long j) throws IOException {
        p.e(dVar, "sink");
        int i = (j > 0 ? 1 : (j == 0 ? 0 : -1));
        if (!(i >= 0)) {
            throw new IllegalArgumentException(a.s("byteCount < 0: ", j).toString());
        } else if (!(!this.b)) {
            throw new IllegalStateException("closed".toString());
        } else if (i == 0) {
            return 0;
        } else {
            try {
                v M = dVar.M(1);
                int min = (int) Math.min(j, (long) (8192 - M.c));
                if (this.d.needsInput()) {
                    if (!this.c.Z()) {
                        v vVar = this.c.getBuffer().a;
                        p.c(vVar);
                        int i2 = vVar.c;
                        int i3 = vVar.b;
                        int i4 = i2 - i3;
                        this.a = i4;
                        this.d.setInput(vVar.a, i3, i4);
                    }
                }
                int inflate = this.d.inflate(M.a, M.c, min);
                int i5 = this.a;
                if (i5 != 0) {
                    int remaining = i5 - this.d.getRemaining();
                    this.a -= remaining;
                    this.c.skip((long) remaining);
                }
                if (inflate > 0) {
                    M.c += inflate;
                    long j2 = (long) inflate;
                    dVar.b += j2;
                    return j2;
                }
                if (M.b == M.c) {
                    dVar.a = M.a();
                    w.a(M);
                }
                return 0;
            } catch (DataFormatException e2) {
                throw new IOException(e2);
            }
        }
    }

    public void close() throws IOException {
        if (!this.b) {
            this.d.end();
            this.b = true;
            this.c.close();
        }
    }

    public long read(d dVar, long j) throws IOException {
        p.e(dVar, "sink");
        do {
            long a2 = a(dVar, j);
            if (a2 > 0) {
                return a2;
            }
            if (this.d.finished() || this.d.needsDictionary()) {
                return -1;
            }
        } while (!this.c.Z());
        throw new EOFException("source exhausted prematurely");
    }

    public b0 timeout() {
        return this.c.timeout();
    }

    public n(a0 a0Var, Inflater inflater) {
        p.e(a0Var, "source");
        p.e(inflater, "inflater");
        g J = q.J(a0Var);
        p.e(J, "source");
        p.e(inflater, "inflater");
        this.c = J;
        this.d = inflater;
    }
}

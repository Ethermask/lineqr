package qh;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import ka.h.c.p;

public class l extends b0 {
    public b0 a;

    public l(b0 b0Var) {
        p.e(b0Var, "delegate");
        this.a = b0Var;
    }

    public b0 clearDeadline() {
        return this.a.clearDeadline();
    }

    public b0 clearTimeout() {
        return this.a.clearTimeout();
    }

    public long deadlineNanoTime() {
        return this.a.deadlineNanoTime();
    }

    public boolean hasDeadline() {
        return this.a.hasDeadline();
    }

    public void throwIfReached() throws IOException {
        this.a.throwIfReached();
    }

    public b0 timeout(long j, TimeUnit timeUnit) {
        p.e(timeUnit, "unit");
        return this.a.timeout(j, timeUnit);
    }

    public long timeoutNanos() {
        return this.a.timeoutNanos();
    }

    public b0 deadlineNanoTime(long j) {
        return this.a.deadlineNanoTime(j);
    }
}

package qh;

import i0.a.a.a.u1.c;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.security.MessageDigest;
import java.util.Arrays;
import ka.b.q;
import ka.h.c.p;
import kotlin.jvm.internal.DefaultConstructorMarker;
import qh.c0.b;

public class h implements Serializable, Comparable<h> {
    public static final h d = new h(new byte[0]);

    /* renamed from: e  reason: collision with root package name */
    public static final a f117e = new a((DefaultConstructorMarker) null);
    public static final long serialVersionUID = 1;
    public transient int a;
    public transient String b;
    public final byte[] c;

    public static final class a {
        public a(DefaultConstructorMarker defaultConstructorMarker) {
        }

        public static h d(a aVar, byte[] bArr, int i, int i2, int i3) {
            if ((i3 & 1) != 0) {
                i = 0;
            }
            if ((i3 & 2) != 0) {
                i2 = bArr.length;
            }
            p.e(bArr, "$this$toByteString");
            q.Z((long) bArr.length, (long) i, (long) i2);
            int i4 = i2 + i;
            p.e(bArr, "$this$copyOfRangeImpl");
            c.E(i4, bArr.length);
            byte[] copyOfRange = Arrays.copyOfRange(bArr, i, i4);
            p.d(copyOfRange, "java.util.Arrays.copyOfR…this, fromIndex, toIndex)");
            return new h(copyOfRange);
        }

        public final h a(String str) {
            p.e(str, "$this$decodeBase64");
            byte[] a = a.a(str);
            if (a != null) {
                return new h(a);
            }
            return null;
        }

        public final h b(String str) {
            p.e(str, "$this$decodeHex");
            if (str.length() % 2 == 0) {
                int length = str.length() / 2;
                byte[] bArr = new byte[length];
                for (int i = 0; i < length; i++) {
                    int i2 = i * 2;
                    bArr[i] = (byte) (b.a(str.charAt(i2 + 1)) + (b.a(str.charAt(i2)) << 4));
                }
                return new h(bArr);
            }
            throw new IllegalArgumentException(e.e.b.a.a.C("Unexpected hex string: ", str).toString());
        }

        public final h c(String str) {
            p.e(str, "$this$encodeUtf8");
            p.e(str, "$this$asUtf8ToByteArray");
            byte[] bytes = str.getBytes(ka.m.a.a);
            p.d(bytes, "(this as java.lang.String).getBytes(charset)");
            h hVar = new h(bytes);
            hVar.b = str;
            return hVar;
        }
    }

    public h(byte[] bArr) {
        p.e(bArr, "data");
        this.c = bArr;
    }

    public static final h b(String str) {
        p.e(str, "$this$decodeHex");
        if (str.length() % 2 == 0) {
            int length = str.length() / 2;
            byte[] bArr = new byte[length];
            for (int i = 0; i < length; i++) {
                int i2 = i * 2;
                bArr[i] = (byte) (b.a(str.charAt(i2 + 1)) + (b.a(str.charAt(i2)) << 4));
            }
            return new h(bArr);
        }
        throw new IllegalArgumentException(e.e.b.a.a.C("Unexpected hex string: ", str).toString());
    }

    public static final h i(String str) {
        p.e(str, "$this$encodeUtf8");
        p.e(str, "$this$asUtf8ToByteArray");
        byte[] bytes = str.getBytes(ka.m.a.a);
        p.d(bytes, "(this as java.lang.String).getBytes(charset)");
        h hVar = new h(bytes);
        hVar.b = str;
        return hVar;
    }

    private final void readObject(ObjectInputStream objectInputStream) throws IOException {
        int readInt = objectInputStream.readInt();
        p.e(objectInputStream, "$this$readByteString");
        int i = 0;
        if (readInt >= 0) {
            byte[] bArr = new byte[readInt];
            while (i < readInt) {
                int read = objectInputStream.read(bArr, i, readInt - i);
                if (read != -1) {
                    i += read;
                } else {
                    throw new EOFException();
                }
            }
            h hVar = new h(bArr);
            Field declaredField = h.class.getDeclaredField("c");
            p.d(declaredField, "field");
            declaredField.setAccessible(true);
            declaredField.set(this, hVar.c);
            return;
        }
        throw new IllegalArgumentException(e.e.b.a.a.m("byteCount < 0: ", readInt).toString());
    }

    private final void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.writeInt(this.c.length);
        objectOutputStream.write(this.c);
    }

    public byte[] H() {
        return this.c;
    }

    public byte J(int i) {
        return this.c[i];
    }

    public boolean K(int i, h hVar, int i2, int i3) {
        p.e(hVar, "other");
        return hVar.M(i2, this.c, i, i3);
    }

    public boolean M(int i, byte[] bArr, int i2, int i3) {
        p.e(bArr, "other");
        if (i >= 0) {
            byte[] bArr2 = this.c;
            return i <= bArr2.length - i3 && i2 >= 0 && i2 <= bArr.length - i3 && q.p(bArr2, i, bArr, i2, i3);
        }
    }

    public final h N() {
        return f("SHA-1");
    }

    public h P() {
        byte b2;
        int i = 0;
        while (true) {
            byte[] bArr = this.c;
            if (i >= bArr.length) {
                return this;
            }
            byte b3 = bArr[i];
            byte b4 = (byte) 65;
            if (b3 < b4 || b3 > (b2 = (byte) 90)) {
                i++;
            } else {
                byte[] copyOf = Arrays.copyOf(bArr, bArr.length);
                p.d(copyOf, "java.util.Arrays.copyOf(this, size)");
                copyOf[i] = (byte) (b3 + 32);
                for (int i2 = i + 1; i2 < copyOf.length; i2++) {
                    byte b5 = copyOf[i2];
                    if (b5 >= b4 && b5 <= b2) {
                        copyOf[i2] = (byte) (b5 + 32);
                    }
                }
                return new h(copyOf);
            }
        }
    }

    public String X() {
        String str = this.b;
        if (str != null) {
            return str;
        }
        byte[] H = H();
        p.e(H, "$this$toUtf8String");
        String str2 = new String(H, ka.m.a.a);
        this.b = str2;
        return str2;
    }

    public String a() {
        return a.b(this.c, (byte[]) null, 1);
    }

    public void a0(d dVar, int i, int i2) {
        p.e(dVar, "buffer");
        p.e(this, "$this$commonWrite");
        p.e(dVar, "buffer");
        dVar.W(this.c, i, i2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0033, code lost:
        return 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:?, code lost:
        return -1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0029, code lost:
        if (r6 < r7) goto L_0x0031;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x002f, code lost:
        if (r0 < r1) goto L_0x0031;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int compareTo(java.lang.Object r9) {
        /*
            r8 = this;
            qh.h r9 = (qh.h) r9
            java.lang.String r0 = "other"
            ka.h.c.p.e(r9, r0)
            int r0 = r8.j()
            int r1 = r9.j()
            int r2 = java.lang.Math.min(r0, r1)
            r3 = 0
            r4 = r3
        L_0x0015:
            r5 = -1
            if (r4 >= r2) goto L_0x002c
            byte r6 = r8.J(r4)
            r6 = r6 & 255(0xff, float:3.57E-43)
            byte r7 = r9.J(r4)
            r7 = r7 & 255(0xff, float:3.57E-43)
            if (r6 != r7) goto L_0x0029
            int r4 = r4 + 1
            goto L_0x0015
        L_0x0029:
            if (r6 >= r7) goto L_0x0033
            goto L_0x0031
        L_0x002c:
            if (r0 != r1) goto L_0x002f
            goto L_0x0034
        L_0x002f:
            if (r0 >= r1) goto L_0x0033
        L_0x0031:
            r3 = r5
            goto L_0x0034
        L_0x0033:
            r3 = 1
        L_0x0034:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: qh.h.compareTo(java.lang.Object):int");
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof h) {
            h hVar = (h) obj;
            int j = hVar.j();
            byte[] bArr = this.c;
            if (j == bArr.length && hVar.M(0, bArr, 0, bArr.length)) {
                return true;
            }
        }
        return false;
    }

    public h f(String str) {
        p.e(str, "algorithm");
        MessageDigest instance = MessageDigest.getInstance(str);
        instance.update(this.c, 0, j());
        byte[] digest = instance.digest();
        p.d(digest, "digestBytes");
        return new h(digest);
    }

    public int hashCode() {
        int i = this.a;
        if (i != 0) {
            return i;
        }
        int hashCode = Arrays.hashCode(this.c);
        this.a = hashCode;
        return hashCode;
    }

    public int j() {
        return this.c.length;
    }

    public String r() {
        byte[] bArr = this.c;
        char[] cArr = new char[(bArr.length * 2)];
        int i = 0;
        for (byte b2 : bArr) {
            int i2 = i + 1;
            char[] cArr2 = b.a;
            cArr[i] = cArr2[(b2 >> 4) & 15];
            i = i2 + 1;
            cArr[i2] = cArr2[b2 & 15];
        }
        return new String(cArr);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:101:0x0129, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:0x0169, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:133:0x017c, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:139:0x018d, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:145:0x019c, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:148:0x01b2, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:151:0x01ba, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:154:0x01c1, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:177:0x01f8, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:178:0x01fb, code lost:
        r5 = -1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x008c, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x009d, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x00a8, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x00ec, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x00ff, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:0x010e, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x0120, code lost:
        if (r4 == 64) goto L_0x01fc;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String toString() {
        /*
            r17 = this;
            r0 = r17
            byte[] r1 = r0.c
            int r1 = r1.length
            if (r1 != 0) goto L_0x0009
            r1 = 1
            goto L_0x000a
        L_0x0009:
            r1 = 0
        L_0x000a:
            if (r1 == 0) goto L_0x0010
            java.lang.String r1 = "[size=0]"
            goto L_0x02cd
        L_0x0010:
            byte[] r1 = r0.c
            int r2 = r1.length
            r3 = 0
            r4 = 0
            r5 = 0
        L_0x0016:
            r6 = 64
            if (r3 >= r2) goto L_0x01fc
            byte r7 = r1[r3]
            r8 = 10
            r9 = 13
            r10 = 159(0x9f, float:2.23E-43)
            r11 = 127(0x7f, float:1.78E-43)
            r12 = 31
            r14 = 65533(0xfffd, float:9.1831E-41)
            r15 = 65536(0x10000, float:9.18355E-41)
            if (r7 < 0) goto L_0x0081
            int r16 = r4 + 1
            if (r4 != r6) goto L_0x0033
            goto L_0x01fc
        L_0x0033:
            if (r7 == r8) goto L_0x0045
            if (r7 == r9) goto L_0x0045
            if (r7 < 0) goto L_0x003b
            if (r12 >= r7) goto L_0x0040
        L_0x003b:
            if (r11 <= r7) goto L_0x003e
            goto L_0x0042
        L_0x003e:
            if (r10 < r7) goto L_0x0042
        L_0x0040:
            r4 = 1
            goto L_0x0043
        L_0x0042:
            r4 = 0
        L_0x0043:
            if (r4 != 0) goto L_0x01fb
        L_0x0045:
            if (r7 != r14) goto L_0x0049
            goto L_0x01fb
        L_0x0049:
            if (r7 >= r15) goto L_0x004d
            r4 = 1
            goto L_0x004e
        L_0x004d:
            r4 = 2
        L_0x004e:
            int r5 = r5 + r4
            int r3 = r3 + 1
        L_0x0051:
            r4 = r16
            if (r3 >= r2) goto L_0x0016
            byte r7 = r1[r3]
            if (r7 < 0) goto L_0x0016
            int r7 = r3 + 1
            byte r3 = r1[r3]
            int r16 = r4 + 1
            if (r4 != r6) goto L_0x0063
            goto L_0x01fc
        L_0x0063:
            if (r3 == r8) goto L_0x0075
            if (r3 == r9) goto L_0x0075
            if (r3 < 0) goto L_0x006b
            if (r12 >= r3) goto L_0x0070
        L_0x006b:
            if (r11 <= r3) goto L_0x006e
            goto L_0x0072
        L_0x006e:
            if (r10 < r3) goto L_0x0072
        L_0x0070:
            r4 = 1
            goto L_0x0073
        L_0x0072:
            r4 = 0
        L_0x0073:
            if (r4 != 0) goto L_0x01fb
        L_0x0075:
            if (r3 != r14) goto L_0x0079
            goto L_0x01fb
        L_0x0079:
            if (r3 >= r15) goto L_0x007d
            r3 = 1
            goto L_0x007e
        L_0x007d:
            r3 = 2
        L_0x007e:
            int r5 = r5 + r3
            r3 = r7
            goto L_0x0051
        L_0x0081:
            int r14 = r7 >> 5
            r15 = -2
            r13 = 128(0x80, float:1.794E-43)
            if (r14 != r15) goto L_0x00de
            int r7 = r3 + 1
            if (r2 > r7) goto L_0x0090
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x0090:
            byte r14 = r1[r3]
            byte r7 = r1[r7]
            r15 = r7 & 192(0xc0, float:2.69E-43)
            if (r15 != r13) goto L_0x009a
            r15 = 1
            goto L_0x009b
        L_0x009a:
            r15 = 0
        L_0x009b:
            if (r15 != 0) goto L_0x00a1
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x00a1:
            r7 = r7 ^ 3968(0xf80, float:5.56E-42)
            int r14 = r14 << 6
            r7 = r7 ^ r14
            if (r7 >= r13) goto L_0x00ac
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x00ac:
            int r13 = r4 + 1
            if (r4 != r6) goto L_0x00b2
            goto L_0x01fc
        L_0x00b2:
            if (r7 == r8) goto L_0x00c4
            if (r7 == r9) goto L_0x00c4
            if (r7 < 0) goto L_0x00ba
            if (r12 >= r7) goto L_0x00bf
        L_0x00ba:
            if (r11 <= r7) goto L_0x00bd
            goto L_0x00c1
        L_0x00bd:
            if (r10 < r7) goto L_0x00c1
        L_0x00bf:
            r4 = 1
            goto L_0x00c2
        L_0x00c1:
            r4 = 0
        L_0x00c2:
            if (r4 != 0) goto L_0x01fb
        L_0x00c4:
            r4 = 65533(0xfffd, float:9.1831E-41)
            if (r7 != r4) goto L_0x00cb
            goto L_0x01fb
        L_0x00cb:
            r4 = 65536(0x10000, float:9.18355E-41)
            if (r7 >= r4) goto L_0x00d3
            r4 = 1
            r16 = r4
            goto L_0x00d5
        L_0x00d3:
            r16 = 2
        L_0x00d5:
            int r5 = r5 + r16
            kotlin.Unit r4 = kotlin.Unit.INSTANCE
            int r3 = r3 + 2
            r4 = r13
            goto L_0x0016
        L_0x00de:
            int r10 = r7 >> 4
            r11 = 55296(0xd800, float:7.7486E-41)
            r12 = 57343(0xdfff, float:8.0355E-41)
            if (r10 != r15) goto L_0x0161
            int r7 = r3 + 2
            if (r2 > r7) goto L_0x00f0
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x00f0:
            byte r10 = r1[r3]
            int r14 = r3 + 1
            byte r14 = r1[r14]
            r15 = r14 & 192(0xc0, float:2.69E-43)
            if (r15 != r13) goto L_0x00fc
            r15 = 1
            goto L_0x00fd
        L_0x00fc:
            r15 = 0
        L_0x00fd:
            if (r15 != 0) goto L_0x0103
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x0103:
            byte r7 = r1[r7]
            r15 = r7 & 192(0xc0, float:2.69E-43)
            if (r15 != r13) goto L_0x010b
            r13 = 1
            goto L_0x010c
        L_0x010b:
            r13 = 0
        L_0x010c:
            if (r13 != 0) goto L_0x0112
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x0112:
            r13 = -123008(0xfffffffffffe1f80, float:NaN)
            r7 = r7 ^ r13
            int r13 = r14 << 6
            r7 = r7 ^ r13
            int r10 = r10 << 12
            r7 = r7 ^ r10
            r10 = 2048(0x800, float:2.87E-42)
            if (r7 >= r10) goto L_0x0124
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x0124:
            if (r11 <= r7) goto L_0x0127
            goto L_0x012d
        L_0x0127:
            if (r12 < r7) goto L_0x012d
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x012d:
            int r10 = r4 + 1
            if (r4 != r6) goto L_0x0133
            goto L_0x01fc
        L_0x0133:
            if (r7 == r8) goto L_0x014b
            if (r7 == r9) goto L_0x014b
            if (r7 < 0) goto L_0x013d
            r4 = 31
            if (r4 >= r7) goto L_0x0146
        L_0x013d:
            r4 = 127(0x7f, float:1.78E-43)
            if (r4 <= r7) goto L_0x0142
            goto L_0x0148
        L_0x0142:
            r4 = 159(0x9f, float:2.23E-43)
            if (r4 < r7) goto L_0x0148
        L_0x0146:
            r4 = 1
            goto L_0x0149
        L_0x0148:
            r4 = 0
        L_0x0149:
            if (r4 != 0) goto L_0x01fb
        L_0x014b:
            r4 = 65533(0xfffd, float:9.1831E-41)
            if (r7 != r4) goto L_0x0152
            goto L_0x01fb
        L_0x0152:
            r4 = 65536(0x10000, float:9.18355E-41)
            if (r7 >= r4) goto L_0x0158
            r13 = 1
            goto L_0x0159
        L_0x0158:
            r13 = 2
        L_0x0159:
            int r5 = r5 + r13
            kotlin.Unit r4 = kotlin.Unit.INSTANCE
            int r3 = r3 + 3
            r4 = r10
            goto L_0x0016
        L_0x0161:
            int r7 = r7 >> 3
            if (r7 != r15) goto L_0x01f8
            int r7 = r3 + 3
            if (r2 > r7) goto L_0x016d
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x016d:
            byte r9 = r1[r3]
            int r10 = r3 + 1
            byte r10 = r1[r10]
            r14 = r10 & 192(0xc0, float:2.69E-43)
            if (r14 != r13) goto L_0x0179
            r14 = 1
            goto L_0x017a
        L_0x0179:
            r14 = 0
        L_0x017a:
            if (r14 != 0) goto L_0x0180
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x0180:
            int r14 = r3 + 2
            byte r14 = r1[r14]
            r15 = r14 & 192(0xc0, float:2.69E-43)
            if (r15 != r13) goto L_0x018a
            r15 = 1
            goto L_0x018b
        L_0x018a:
            r15 = 0
        L_0x018b:
            if (r15 != 0) goto L_0x0191
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x0191:
            byte r7 = r1[r7]
            r15 = r7 & 192(0xc0, float:2.69E-43)
            if (r15 != r13) goto L_0x0199
            r13 = 1
            goto L_0x019a
        L_0x0199:
            r13 = 0
        L_0x019a:
            if (r13 != 0) goto L_0x01a0
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x01a0:
            r13 = 3678080(0x381f80, float:5.154088E-39)
            r7 = r7 ^ r13
            int r13 = r14 << 6
            r7 = r7 ^ r13
            int r10 = r10 << 12
            r7 = r7 ^ r10
            int r9 = r9 << 18
            r7 = r7 ^ r9
            r9 = 1114111(0x10ffff, float:1.561202E-39)
            if (r7 <= r9) goto L_0x01b5
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x01b5:
            if (r11 <= r7) goto L_0x01b8
            goto L_0x01bd
        L_0x01b8:
            if (r12 < r7) goto L_0x01bd
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x01bd:
            r9 = 65536(0x10000, float:9.18355E-41)
            if (r7 >= r9) goto L_0x01c4
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x01c4:
            int r9 = r4 + 1
            if (r4 != r6) goto L_0x01c9
            goto L_0x01fc
        L_0x01c9:
            if (r7 == r8) goto L_0x01e3
            r4 = 13
            if (r7 == r4) goto L_0x01e3
            if (r7 < 0) goto L_0x01d5
            r4 = 31
            if (r4 >= r7) goto L_0x01de
        L_0x01d5:
            r4 = 127(0x7f, float:1.78E-43)
            if (r4 <= r7) goto L_0x01da
            goto L_0x01e0
        L_0x01da:
            r4 = 159(0x9f, float:2.23E-43)
            if (r4 < r7) goto L_0x01e0
        L_0x01de:
            r4 = 1
            goto L_0x01e1
        L_0x01e0:
            r4 = 0
        L_0x01e1:
            if (r4 != 0) goto L_0x01fb
        L_0x01e3:
            r4 = 65533(0xfffd, float:9.1831E-41)
            if (r7 != r4) goto L_0x01e9
            goto L_0x01fb
        L_0x01e9:
            r4 = 65536(0x10000, float:9.18355E-41)
            if (r7 >= r4) goto L_0x01ef
            r13 = 1
            goto L_0x01f0
        L_0x01ef:
            r13 = 2
        L_0x01f0:
            int r5 = r5 + r13
            kotlin.Unit r4 = kotlin.Unit.INSTANCE
            int r3 = r3 + 4
            r4 = r9
            goto L_0x0016
        L_0x01f8:
            if (r4 != r6) goto L_0x01fb
            goto L_0x01fc
        L_0x01fb:
            r5 = -1
        L_0x01fc:
            java.lang.String r1 = "…]"
            r2 = 93
            java.lang.String r3 = "[size="
            r4 = -1
            if (r5 != r4) goto L_0x0280
            byte[] r4 = r0.c
            int r4 = r4.length
            if (r4 > r6) goto L_0x0220
            java.lang.String r1 = "[hex="
            java.lang.StringBuilder r1 = e.e.b.a.a.V0(r1)
            java.lang.String r3 = r17.r()
            r1.append(r3)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            goto L_0x02cd
        L_0x0220:
            java.lang.StringBuilder r2 = e.e.b.a.a.V0(r3)
            byte[] r3 = r0.c
            int r3 = r3.length
            r2.append(r3)
            java.lang.String r3 = " hex="
            r2.append(r3)
            byte[] r3 = r0.c
            int r3 = r3.length
            if (r6 > r3) goto L_0x0236
            r3 = 1
            goto L_0x0237
        L_0x0236:
            r3 = 0
        L_0x0237:
            if (r3 == 0) goto L_0x0267
            byte[] r3 = r0.c
            int r4 = r3.length
            if (r6 != r4) goto L_0x0240
            r4 = r0
            goto L_0x0258
        L_0x0240:
            qh.h r4 = new qh.h
            java.lang.String r5 = "$this$copyOfRangeImpl"
            ka.h.c.p.e(r3, r5)
            int r5 = r3.length
            i0.a.a.a.u1.c.E(r6, r5)
            r5 = 0
            byte[] r3 = java.util.Arrays.copyOfRange(r3, r5, r6)
            java.lang.String r5 = "java.util.Arrays.copyOfR…this, fromIndex, toIndex)"
            ka.h.c.p.d(r3, r5)
            r4.<init>(r3)
        L_0x0258:
            java.lang.String r3 = r4.r()
            r2.append(r3)
            r2.append(r1)
            java.lang.String r1 = r2.toString()
            goto L_0x02cd
        L_0x0267:
            java.lang.String r1 = "endIndex > length("
            java.lang.StringBuilder r1 = e.e.b.a.a.V0(r1)
            byte[] r2 = r0.c
            int r2 = r2.length
            r3 = 41
            java.lang.String r1 = e.e.b.a.a.Y(r1, r2, r3)
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r2.<init>(r1)
            throw r2
        L_0x0280:
            java.lang.String r4 = r17.X()
            r6 = 0
            java.lang.String r7 = r4.substring(r6, r5)
            java.lang.String r8 = "(this as java.lang.Strin…ing(startIndex, endIndex)"
            ka.h.c.p.d(r7, r8)
            java.lang.String r8 = "\\"
            java.lang.String r9 = "\\\\"
            r10 = 4
            java.lang.String r7 = ka.m.r.B(r7, r8, r9, r6, r10)
            java.lang.String r8 = "\n"
            java.lang.String r9 = "\\n"
            java.lang.String r7 = ka.m.r.B(r7, r8, r9, r6, r10)
            java.lang.String r8 = "\r"
            java.lang.String r9 = "\\r"
            java.lang.String r6 = ka.m.r.B(r7, r8, r9, r6, r10)
            int r4 = r4.length()
            if (r5 >= r4) goto L_0x02c7
            java.lang.StringBuilder r2 = e.e.b.a.a.V0(r3)
            byte[] r3 = r0.c
            int r3 = r3.length
            r2.append(r3)
            java.lang.String r3 = " text="
            r2.append(r3)
            r2.append(r6)
            r2.append(r1)
            java.lang.String r1 = r2.toString()
            goto L_0x02cd
        L_0x02c7:
            java.lang.String r1 = "[text="
            java.lang.String r1 = e.e.b.a.a.D(r1, r6, r2)
        L_0x02cd:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: qh.h.toString():java.lang.String");
    }
}

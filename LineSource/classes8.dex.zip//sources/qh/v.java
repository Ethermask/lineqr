package qh;

import ka.b.k;
import ka.h.c.p;

public final class v {
    public final byte[] a;
    public int b;
    public int c;
    public boolean d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f120e;
    public v f;
    public v g;

    public v() {
        this.a = new byte[8192];
        this.f120e = true;
        this.d = false;
    }

    public final v a() {
        v vVar = this.f;
        if (vVar == this) {
            vVar = null;
        }
        v vVar2 = this.g;
        p.c(vVar2);
        vVar2.f = this.f;
        v vVar3 = this.f;
        p.c(vVar3);
        vVar3.g = this.g;
        this.f = null;
        this.g = null;
        return vVar;
    }

    public final v b(v vVar) {
        p.e(vVar, "segment");
        vVar.g = this;
        vVar.f = this.f;
        v vVar2 = this.f;
        p.c(vVar2);
        vVar2.g = vVar;
        this.f = vVar;
        return vVar;
    }

    public final v c() {
        this.d = true;
        return new v(this.a, this.b, this.c, true, false);
    }

    public final void d(v vVar, int i) {
        p.e(vVar, "sink");
        if (vVar.f120e) {
            int i2 = vVar.c;
            if (i2 + i > 8192) {
                if (!vVar.d) {
                    int i3 = vVar.b;
                    if ((i2 + i) - i3 <= 8192) {
                        byte[] bArr = vVar.a;
                        k.g(bArr, bArr, 0, i3, i2, 2);
                        vVar.c -= vVar.b;
                        vVar.b = 0;
                    } else {
                        throw new IllegalArgumentException();
                    }
                } else {
                    throw new IllegalArgumentException();
                }
            }
            byte[] bArr2 = this.a;
            byte[] bArr3 = vVar.a;
            int i4 = vVar.c;
            int i5 = this.b;
            k.e(bArr2, bArr3, i4, i5, i5 + i);
            vVar.c += i;
            this.b += i;
            return;
        }
        throw new IllegalStateException("only owner can write".toString());
    }

    public v(byte[] bArr, int i, int i2, boolean z, boolean z2) {
        p.e(bArr, "data");
        this.a = bArr;
        this.b = i;
        this.c = i2;
        this.d = z;
        this.f120e = z2;
    }
}

package qh;

import java.io.Closeable;
import java.io.IOException;

public interface a0 extends Closeable {
    void close() throws IOException;

    long read(d dVar, long j) throws IOException;

    b0 timeout();
}

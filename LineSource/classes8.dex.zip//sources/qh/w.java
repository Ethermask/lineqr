package qh;

import java.util.concurrent.atomic.AtomicReference;
import ka.h.c.p;

public final class w {
    public static final v a = new v(new byte[0], 0, 0, false, false);
    public static final int b;
    public static final AtomicReference<v>[] c;
    public static final w d = new w();

    static {
        int highestOneBit = Integer.highestOneBit((Runtime.getRuntime().availableProcessors() * 2) - 1);
        b = highestOneBit;
        AtomicReference<v>[] atomicReferenceArr = new AtomicReference[highestOneBit];
        for (int i = 0; i < highestOneBit; i++) {
            atomicReferenceArr[i] = new AtomicReference<>();
        }
        c = atomicReferenceArr;
    }

    public static final void a(v vVar) {
        p.e(vVar, "segment");
        if (!(vVar.f == null && vVar.g == null)) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        } else if (!vVar.d) {
            Thread currentThread = Thread.currentThread();
            p.d(currentThread, "Thread.currentThread()");
            AtomicReference<v> atomicReference = c[(int) (currentThread.getId() & (((long) b) - 1))];
            v vVar2 = atomicReference.get();
            if (vVar2 != a) {
                int i = vVar2 != null ? vVar2.c : 0;
                if (i < 65536) {
                    vVar.f = vVar2;
                    vVar.b = 0;
                    vVar.c = i + 8192;
                    if (!atomicReference.compareAndSet(vVar2, vVar)) {
                        vVar.f = null;
                    }
                }
            }
        }
    }

    public static final v b() {
        Thread currentThread = Thread.currentThread();
        p.d(currentThread, "Thread.currentThread()");
        AtomicReference<v> atomicReference = c[(int) (currentThread.getId() & (((long) b) - 1))];
        v andSet = atomicReference.getAndSet(a);
        if (andSet == a) {
            return new v();
        }
        if (andSet == null) {
            atomicReference.set((Object) null);
            return new v();
        }
        atomicReference.set(andSet.f);
        andSet.f = null;
        andSet.c = 0;
        return andSet;
    }
}

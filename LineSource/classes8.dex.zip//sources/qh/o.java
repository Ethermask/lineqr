package qh;

import e.e.b.a.a;
import java.io.IOException;
import java.io.InputStream;
import ka.h.c.p;

public final class o implements a0 {
    public final InputStream a;
    public final b0 b;

    public o(InputStream inputStream, b0 b0Var) {
        p.e(inputStream, "input");
        p.e(b0Var, "timeout");
        this.a = inputStream;
        this.b = b0Var;
    }

    public void close() {
        this.a.close();
    }

    public long read(d dVar, long j) {
        p.e(dVar, "sink");
        int i = (j > 0 ? 1 : (j == 0 ? 0 : -1));
        if (i == 0) {
            return 0;
        }
        if (i >= 0) {
            try {
                this.b.throwIfReached();
                v M = dVar.M(1);
                int read = this.a.read(M.a, M.c, (int) Math.min(j, (long) (8192 - M.c)));
                if (read != -1) {
                    M.c += read;
                    long j2 = (long) read;
                    dVar.b += j2;
                    return j2;
                } else if (M.b != M.c) {
                    return -1;
                } else {
                    dVar.a = M.a();
                    w.a(M);
                    return -1;
                }
            } catch (AssertionError e2) {
                if (p.b(e2)) {
                    throw new IOException(e2);
                }
                throw e2;
            }
        } else {
            throw new IllegalArgumentException(a.s("byteCount < 0: ", j).toString());
        }
    }

    public b0 timeout() {
        return this.b;
    }

    public String toString() {
        StringBuilder V0 = a.V0("source(");
        V0.append(this.a);
        V0.append(')');
        return V0.toString();
    }
}

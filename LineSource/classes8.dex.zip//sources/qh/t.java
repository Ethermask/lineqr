package qh;

import e.e.b.a.a;
import java.nio.ByteBuffer;
import ka.h.c.p;

public final class t implements f {
    public final d a = new d();
    public boolean b;
    public final y c;

    public t(y yVar) {
        p.e(yVar, "sink");
        this.c = yVar;
    }

    public f B() {
        if (!this.b) {
            long b2 = this.a.b();
            if (b2 > 0) {
                this.c.write(this.a, b2);
            }
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public f C(String str) {
        p.e(str, "string");
        if (!this.b) {
            this.a.l0(str);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public f D(String str, int i, int i2) {
        p.e(str, "string");
        if (!this.b) {
            this.a.n0(str, i, i2);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public long E(a0 a0Var) {
        p.e(a0Var, "source");
        long j = 0;
        while (true) {
            long read = a0Var.read(this.a, (long) 8192);
            if (read == -1) {
                return j;
            }
            j += read;
            B();
        }
    }

    public f L(byte[] bArr) {
        p.e(bArr, "source");
        if (!this.b) {
            this.a.P(bArr);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public f T(long j) {
        if (!this.b) {
            this.a.T(j);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public void close() {
        if (!this.b) {
            Throwable th2 = null;
            try {
                if (this.a.b > 0) {
                    this.c.write(this.a, this.a.b);
                }
            } catch (Throwable th3) {
                th2 = th3;
            }
            try {
                this.c.close();
            } catch (Throwable th4) {
                if (th2 == null) {
                    th2 = th4;
                }
            }
            this.b = true;
            if (th2 != null) {
                throw th2;
            }
        }
    }

    public f e(int i) {
        if (!this.b) {
            this.a.g0(i);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public void flush() {
        if (!this.b) {
            d dVar = this.a;
            long j = dVar.b;
            if (j > 0) {
                this.c.write(dVar, j);
            }
            this.c.flush();
            return;
        }
        throw new IllegalStateException("closed".toString());
    }

    public d getBuffer() {
        return this.a;
    }

    public boolean isOpen() {
        return !this.b;
    }

    public f k0(long j) {
        if (!this.b) {
            this.a.k0(j);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public f m(int i) {
        if (!this.b) {
            this.a.i0(i);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public f n(int i) {
        if (!this.b) {
            this.a.a0(i);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public f p0(h hVar) {
        p.e(hVar, "byteString");
        if (!this.b) {
            this.a.N(hVar);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public b0 timeout() {
        return this.c.timeout();
    }

    public String toString() {
        StringBuilder V0 = a.V0("buffer(");
        V0.append(this.c);
        V0.append(')');
        return V0.toString();
    }

    public int write(ByteBuffer byteBuffer) {
        p.e(byteBuffer, "source");
        if (!this.b) {
            int write = this.a.write(byteBuffer);
            B();
            return write;
        }
        throw new IllegalStateException("closed".toString());
    }

    public f y() {
        if (!this.b) {
            d dVar = this.a;
            long j = dVar.b;
            if (j > 0) {
                this.c.write(dVar, j);
            }
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }

    public void write(d dVar, long j) {
        p.e(dVar, "source");
        if (!this.b) {
            this.a.write(dVar, j);
            B();
            return;
        }
        throw new IllegalStateException("closed".toString());
    }

    public f write(byte[] bArr, int i, int i2) {
        p.e(bArr, "source");
        if (!this.b) {
            this.a.W(bArr, i, i2);
            B();
            return this;
        }
        throw new IllegalStateException("closed".toString());
    }
}

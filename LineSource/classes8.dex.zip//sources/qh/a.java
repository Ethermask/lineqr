package qh;

import ka.h.c.p;

public final class a {
    public static final byte[] a = h.f117e.c("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/").c;

    static {
        h.f117e.c("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0013, code lost:
        r5 = r0 - 1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final byte[] a(java.lang.String r15) {
        /*
            java.lang.String r0 = "$this$decodeBase64ToArray"
            ka.h.c.p.e(r15, r0)
            int r0 = r15.length()
        L_0x0009:
            r1 = 9
            r2 = 32
            r3 = 13
            r4 = 10
            if (r0 <= 0) goto L_0x0028
            int r5 = r0 + -1
            char r6 = r15.charAt(r5)
            r7 = 61
            if (r6 == r7) goto L_0x0026
            if (r6 == r4) goto L_0x0026
            if (r6 == r3) goto L_0x0026
            if (r6 == r2) goto L_0x0026
            if (r6 == r1) goto L_0x0026
            goto L_0x0028
        L_0x0026:
            r0 = r5
            goto L_0x0009
        L_0x0028:
            long r5 = (long) r0
            r7 = 6
            long r5 = r5 * r7
            r7 = 8
            long r5 = r5 / r7
            int r5 = (int) r5
            byte[] r6 = new byte[r5]
            r7 = 0
            r8 = r7
            r9 = r8
            r10 = r9
        L_0x0036:
            r11 = 0
            if (r7 >= r0) goto L_0x00a2
            char r12 = r15.charAt(r7)
            r13 = 90
            r14 = 65
            if (r14 <= r12) goto L_0x0044
            goto L_0x0049
        L_0x0044:
            if (r13 < r12) goto L_0x0049
            int r12 = r12 + -65
            goto L_0x0082
        L_0x0049:
            r13 = 122(0x7a, float:1.71E-43)
            r14 = 97
            if (r14 <= r12) goto L_0x0050
            goto L_0x0055
        L_0x0050:
            if (r13 < r12) goto L_0x0055
            int r12 = r12 + -71
            goto L_0x0082
        L_0x0055:
            r13 = 57
            r14 = 48
            if (r14 <= r12) goto L_0x005c
            goto L_0x0061
        L_0x005c:
            if (r13 < r12) goto L_0x0061
            int r12 = r12 + 4
            goto L_0x0082
        L_0x0061:
            r13 = 43
            if (r12 == r13) goto L_0x0080
            r13 = 45
            if (r12 != r13) goto L_0x006a
            goto L_0x0080
        L_0x006a:
            r13 = 47
            if (r12 == r13) goto L_0x007d
            r13 = 95
            if (r12 != r13) goto L_0x0073
            goto L_0x007d
        L_0x0073:
            if (r12 == r4) goto L_0x009f
            if (r12 == r3) goto L_0x009f
            if (r12 == r2) goto L_0x009f
            if (r12 != r1) goto L_0x007c
            goto L_0x009f
        L_0x007c:
            return r11
        L_0x007d:
            r12 = 63
            goto L_0x0082
        L_0x0080:
            r12 = 62
        L_0x0082:
            int r9 = r9 << 6
            r9 = r9 | r12
            int r8 = r8 + 1
            int r11 = r8 % 4
            if (r11 != 0) goto L_0x009f
            int r11 = r10 + 1
            int r12 = r9 >> 16
            byte r12 = (byte) r12
            r6[r10] = r12
            int r10 = r11 + 1
            int r12 = r9 >> 8
            byte r12 = (byte) r12
            r6[r11] = r12
            int r11 = r10 + 1
            byte r12 = (byte) r9
            r6[r10] = r12
            r10 = r11
        L_0x009f:
            int r7 = r7 + 1
            goto L_0x0036
        L_0x00a2:
            int r8 = r8 % 4
            r15 = 1
            if (r8 == r15) goto L_0x00d6
            r15 = 2
            if (r8 == r15) goto L_0x00bf
            r15 = 3
            if (r8 == r15) goto L_0x00ae
            goto L_0x00c9
        L_0x00ae:
            int r15 = r9 << 6
            int r0 = r10 + 1
            int r1 = r15 >> 16
            byte r1 = (byte) r1
            r6[r10] = r1
            int r10 = r0 + 1
            int r15 = r15 >> 8
            byte r15 = (byte) r15
            r6[r0] = r15
            goto L_0x00c9
        L_0x00bf:
            int r15 = r9 << 12
            int r0 = r10 + 1
            int r15 = r15 >> 16
            byte r15 = (byte) r15
            r6[r10] = r15
            r10 = r0
        L_0x00c9:
            if (r10 != r5) goto L_0x00cc
            return r6
        L_0x00cc:
            byte[] r15 = java.util.Arrays.copyOf(r6, r10)
            java.lang.String r0 = "java.util.Arrays.copyOf(this, newSize)"
            ka.h.c.p.d(r15, r0)
            return r15
        L_0x00d6:
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: qh.a.a(java.lang.String):byte[]");
    }

    public static String b(byte[] bArr, byte[] bArr2, int i) {
        byte[] bArr3 = (i & 1) != 0 ? a : null;
        p.e(bArr, "$this$encodeBase64");
        p.e(bArr3, "map");
        byte[] bArr4 = new byte[(((bArr.length + 2) / 3) * 4)];
        int length = bArr.length - (bArr.length % 3);
        int i2 = 0;
        int i3 = 0;
        while (i2 < length) {
            int i4 = i2 + 1;
            byte b = bArr[i2];
            int i5 = i4 + 1;
            byte b2 = bArr[i4];
            int i6 = i5 + 1;
            byte b3 = bArr[i5];
            int i7 = i3 + 1;
            bArr4[i3] = bArr3[(b & 255) >> 2];
            int i8 = i7 + 1;
            bArr4[i7] = bArr3[((b & 3) << 4) | ((b2 & 255) >> 4)];
            int i9 = i8 + 1;
            bArr4[i8] = bArr3[((b2 & 15) << 2) | ((b3 & 255) >> 6)];
            i3 = i9 + 1;
            bArr4[i9] = bArr3[b3 & 63];
            i2 = i6;
        }
        int length2 = bArr.length - length;
        if (length2 == 1) {
            byte b4 = bArr[i2];
            int i10 = i3 + 1;
            bArr4[i3] = bArr3[(b4 & 255) >> 2];
            int i11 = i10 + 1;
            bArr4[i10] = bArr3[(b4 & 3) << 4];
            byte b5 = (byte) 61;
            bArr4[i11] = b5;
            bArr4[i11 + 1] = b5;
        } else if (length2 == 2) {
            int i12 = i2 + 1;
            byte b6 = bArr[i2];
            byte b7 = bArr[i12];
            int i13 = i3 + 1;
            bArr4[i3] = bArr3[(b6 & 255) >> 2];
            int i14 = i13 + 1;
            bArr4[i13] = bArr3[((b6 & 3) << 4) | ((b7 & 255) >> 4)];
            bArr4[i14] = bArr3[(b7 & 15) << 2];
            bArr4[i14 + 1] = (byte) 61;
        }
        p.e(bArr4, "$this$toUtf8String");
        return new String(bArr4, ka.m.a.a);
    }
}

package qh;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;
import ka.b.q;
import ka.h.c.p;
import kotlin.PublishedApi;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;

public class b extends b0 {
    public static final a Companion = new a((DefaultConstructorMarker) null);
    public static final long IDLE_TIMEOUT_MILLIS = TimeUnit.SECONDS.toMillis(60);
    public static final long IDLE_TIMEOUT_NANOS = TimeUnit.MILLISECONDS.toNanos(IDLE_TIMEOUT_MILLIS);
    public static final int TIMEOUT_WRITE_SIZE = 65536;
    public static b head;
    public boolean inQueue;
    public b next;
    public long timeoutAt;

    public static final class a {
        public a(DefaultConstructorMarker defaultConstructorMarker) {
        }

        public final b a() throws InterruptedException {
            Class<b> cls = b.class;
            b access$getHead$cp = b.head;
            p.c(access$getHead$cp);
            b access$getNext$p = access$getHead$cp.next;
            if (access$getNext$p == null) {
                long nanoTime = System.nanoTime();
                cls.wait(b.IDLE_TIMEOUT_MILLIS);
                b access$getHead$cp2 = b.head;
                p.c(access$getHead$cp2);
                if (access$getHead$cp2.next != null || System.nanoTime() - nanoTime < b.IDLE_TIMEOUT_NANOS) {
                    return null;
                }
                return b.head;
            }
            long access$remainingNanos = access$getNext$p.remainingNanos(System.nanoTime());
            if (access$remainingNanos > 0) {
                long j = access$remainingNanos / 1000000;
                cls.wait(j, (int) (access$remainingNanos - (1000000 * j)));
                return null;
            }
            b access$getHead$cp3 = b.head;
            p.c(access$getHead$cp3);
            access$getHead$cp3.next = access$getNext$p.next;
            access$getNext$p.next = null;
            return access$getNext$p;
        }
    }

    /* renamed from: qh.b$b  reason: collision with other inner class name */
    public static final class C0010b extends Thread {
        public C0010b() {
            super("Okio Watchdog");
            setDaemon(true);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:15:0x0018, code lost:
            if (r1 == null) goto L_0x0000;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x001a, code lost:
            r1.timedOut();
         */
        /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void run() {
            /*
                r3 = this;
            L_0x0000:
                java.lang.Class<qh.b> r0 = qh.b.class
                monitor-enter(r0)     // Catch:{ InterruptedException -> 0x0000 }
                qh.b$a r1 = qh.b.Companion     // Catch:{ all -> 0x001e }
                qh.b r1 = r1.a()     // Catch:{ all -> 0x001e }
                qh.b r2 = qh.b.head     // Catch:{ all -> 0x001e }
                if (r1 != r2) goto L_0x0015
                r1 = 0
                qh.b.head = r1     // Catch:{ all -> 0x001e }
                monitor-exit(r0)     // Catch:{ InterruptedException -> 0x0000 }
                return
            L_0x0015:
                kotlin.Unit r2 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x001e }
                monitor-exit(r0)     // Catch:{ InterruptedException -> 0x0000 }
                if (r1 == 0) goto L_0x0000
                r1.timedOut()     // Catch:{ InterruptedException -> 0x0000 }
                goto L_0x0000
            L_0x001e:
                r1 = move-exception
                monitor-exit(r0)     // Catch:{ InterruptedException -> 0x0000 }
                throw r1     // Catch:{ InterruptedException -> 0x0000 }
            */
            throw new UnsupportedOperationException("Method not decompiled: qh.b.C0010b.run():void");
        }
    }

    public static final class c implements y {
        public final /* synthetic */ b a;
        public final /* synthetic */ y b;

        public c(b bVar, y yVar) {
            this.a = bVar;
            this.b = yVar;
        }

        public void close() {
            b bVar = this.a;
            bVar.enter();
            try {
                this.b.close();
                Unit unit = Unit.INSTANCE;
                if (bVar.exit()) {
                    throw bVar.access$newTimeoutException((IOException) null);
                }
            } catch (IOException e2) {
                e = e2;
                if (bVar.exit()) {
                    e = bVar.access$newTimeoutException(e);
                }
                throw e;
            } finally {
                boolean exit = bVar.exit();
            }
        }

        public void flush() {
            b bVar = this.a;
            bVar.enter();
            try {
                this.b.flush();
                Unit unit = Unit.INSTANCE;
                if (bVar.exit()) {
                    throw bVar.access$newTimeoutException((IOException) null);
                }
            } catch (IOException e2) {
                e = e2;
                if (bVar.exit()) {
                    e = bVar.access$newTimeoutException(e);
                }
                throw e;
            } finally {
                boolean exit = bVar.exit();
            }
        }

        public b0 timeout() {
            return this.a;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("AsyncTimeout.sink(");
            V0.append(this.b);
            V0.append(')');
            return V0.toString();
        }

        public void write(d dVar, long j) {
            p.e(dVar, "source");
            q.Z(dVar.b, 0, j);
            while (true) {
                long j2 = 0;
                if (j > 0) {
                    v vVar = dVar.a;
                    p.c(vVar);
                    while (true) {
                        if (j2 >= ((long) b.TIMEOUT_WRITE_SIZE)) {
                            break;
                        }
                        j2 += (long) (vVar.c - vVar.b);
                        if (j2 >= j) {
                            j2 = j;
                            break;
                        } else {
                            vVar = vVar.f;
                            p.c(vVar);
                        }
                    }
                    b bVar = this.a;
                    bVar.enter();
                    try {
                        this.b.write(dVar, j2);
                        Unit unit = Unit.INSTANCE;
                        if (!bVar.exit()) {
                            j -= j2;
                        } else {
                            throw bVar.access$newTimeoutException((IOException) null);
                        }
                    } catch (IOException e2) {
                        e = e2;
                        if (bVar.exit()) {
                            e = bVar.access$newTimeoutException(e);
                        }
                        throw e;
                    } finally {
                        boolean exit = bVar.exit();
                    }
                } else {
                    return;
                }
            }
        }
    }

    public static final class d implements a0 {
        public final /* synthetic */ b a;
        public final /* synthetic */ a0 b;

        public d(b bVar, a0 a0Var) {
            this.a = bVar;
            this.b = a0Var;
        }

        public void close() {
            b bVar = this.a;
            bVar.enter();
            try {
                this.b.close();
                Unit unit = Unit.INSTANCE;
                if (bVar.exit()) {
                    throw bVar.access$newTimeoutException((IOException) null);
                }
            } catch (IOException e2) {
                e = e2;
                if (bVar.exit()) {
                    e = bVar.access$newTimeoutException(e);
                }
                throw e;
            } finally {
                boolean exit = bVar.exit();
            }
        }

        public long read(d dVar, long j) {
            p.e(dVar, "sink");
            b bVar = this.a;
            bVar.enter();
            try {
                long read = this.b.read(dVar, j);
                if (!bVar.exit()) {
                    return read;
                }
                throw bVar.access$newTimeoutException((IOException) null);
            } catch (IOException e2) {
                e = e2;
                if (bVar.exit()) {
                    e = bVar.access$newTimeoutException(e);
                }
                throw e;
            } finally {
                boolean exit = bVar.exit();
            }
        }

        public b0 timeout() {
            return this.a;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("AsyncTimeout.source(");
            V0.append(this.b);
            V0.append(')');
            return V0.toString();
        }
    }

    /* access modifiers changed from: private */
    public final long remainingNanos(long j) {
        return this.timeoutAt - j;
    }

    @PublishedApi
    public final IOException access$newTimeoutException(IOException iOException) {
        return newTimeoutException(iOException);
    }

    public final void enter() {
        long timeoutNanos = timeoutNanos();
        boolean hasDeadline = hasDeadline();
        int i = (timeoutNanos > 0 ? 1 : (timeoutNanos == 0 ? 0 : -1));
        if (i == 0 && !hasDeadline) {
            return;
        }
        if (Companion != null) {
            Class<b> cls = b.class;
            synchronized (cls) {
                if (!this.inQueue) {
                    this.inQueue = true;
                    if (head == null) {
                        head = new b();
                        new C0010b().start();
                    }
                    long nanoTime = System.nanoTime();
                    if (i != 0 && hasDeadline) {
                        this.timeoutAt = Math.min(timeoutNanos, deadlineNanoTime() - nanoTime) + nanoTime;
                    } else if (i != 0) {
                        this.timeoutAt = timeoutNanos + nanoTime;
                    } else if (hasDeadline) {
                        this.timeoutAt = deadlineNanoTime();
                    } else {
                        throw new AssertionError();
                    }
                    long access$remainingNanos = remainingNanos(nanoTime);
                    b access$getHead$cp = head;
                    p.c(access$getHead$cp);
                    while (true) {
                        if (access$getHead$cp.next == null) {
                            break;
                        }
                        b access$getNext$p = access$getHead$cp.next;
                        p.c(access$getNext$p);
                        if (access$remainingNanos < access$getNext$p.remainingNanos(nanoTime)) {
                            break;
                        }
                        access$getHead$cp = access$getHead$cp.next;
                        p.c(access$getHead$cp);
                    }
                    this.next = access$getHead$cp.next;
                    access$getHead$cp.next = this;
                    if (access$getHead$cp == head) {
                        cls.notify();
                    }
                    Unit unit = Unit.INSTANCE;
                } else {
                    throw new IllegalStateException("Unbalanced enter/exit".toString());
                }
            }
            return;
        }
        throw null;
    }

    public final boolean exit() {
        boolean z;
        if (Companion != null) {
            synchronized (b.class) {
                z = false;
                if (this.inQueue) {
                    this.inQueue = false;
                    b access$getHead$cp = head;
                    while (true) {
                        if (access$getHead$cp == null) {
                            z = true;
                            break;
                        } else if (access$getHead$cp.next == this) {
                            access$getHead$cp.next = this.next;
                            this.next = null;
                            break;
                        } else {
                            access$getHead$cp = access$getHead$cp.next;
                        }
                    }
                }
            }
            return z;
        }
        throw null;
    }

    public IOException newTimeoutException(IOException iOException) {
        InterruptedIOException interruptedIOException = new InterruptedIOException("timeout");
        if (iOException != null) {
            interruptedIOException.initCause(iOException);
        }
        return interruptedIOException;
    }

    public final y sink(y yVar) {
        p.e(yVar, "sink");
        return new c(this, yVar);
    }

    public final a0 source(a0 a0Var) {
        p.e(a0Var, "source");
        return new d(this, a0Var);
    }

    public void timedOut() {
    }

    public final <T> T withTimeout(ka.h.b.a<? extends T> aVar) {
        p.e(aVar, "block");
        enter();
        try {
            T invoke = aVar.invoke();
            if (!exit()) {
                return invoke;
            }
            throw access$newTimeoutException((IOException) null);
        } catch (IOException e2) {
            e = e2;
            if (exit()) {
                e = access$newTimeoutException(e);
            }
            throw e;
        } finally {
            boolean exit = exit();
        }
    }
}

package qh;

import java.io.IOException;
import java.nio.channels.WritableByteChannel;

public interface f extends y, WritableByteChannel {
    f B() throws IOException;

    f C(String str) throws IOException;

    f D(String str, int i, int i2) throws IOException;

    long E(a0 a0Var) throws IOException;

    f L(byte[] bArr) throws IOException;

    f T(long j) throws IOException;

    f e(int i) throws IOException;

    void flush() throws IOException;

    d getBuffer();

    f k0(long j) throws IOException;

    f m(int i) throws IOException;

    f n(int i) throws IOException;

    f p0(h hVar) throws IOException;

    f write(byte[] bArr, int i, int i2) throws IOException;

    f y() throws IOException;
}

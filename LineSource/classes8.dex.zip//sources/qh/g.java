package qh;

import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.Charset;

public interface g extends a0, ReadableByteChannel {
    String G() throws IOException;

    byte[] I(long j) throws IOException;

    void S(long j) throws IOException;

    h U(long j) throws IOException;

    byte[] Y() throws IOException;

    boolean Z() throws IOException;

    long b0() throws IOException;

    boolean f(long j) throws IOException;

    String f0(Charset charset) throws IOException;

    d getBuffer();

    long l(h hVar) throws IOException;

    h m0() throws IOException;

    void o(d dVar, long j) throws IOException;

    long p(h hVar) throws IOException;

    g peek();

    String q(long j) throws IOException;

    long r0(y yVar) throws IOException;

    int read(byte[] bArr, int i, int i2) throws IOException;

    byte readByte() throws IOException;

    void readFully(byte[] bArr) throws IOException;

    int readInt() throws IOException;

    long readLong() throws IOException;

    short readShort() throws IOException;

    long s0() throws IOException;

    void skip(long j) throws IOException;

    InputStream t0();

    boolean u(long j, h hVar) throws IOException;

    int u0(q qVar) throws IOException;
}

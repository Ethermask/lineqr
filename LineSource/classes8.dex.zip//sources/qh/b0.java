package qh;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;
import ka.h.c.p;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;

public class b0 {
    public static final b Companion = new b((DefaultConstructorMarker) null);
    public static final b0 NONE = new a();
    public long deadlineNanoTime;
    public boolean hasDeadline;
    public long timeoutNanos;

    public static final class a extends b0 {
        public b0 deadlineNanoTime(long j) {
            return this;
        }

        public void throwIfReached() {
        }

        public b0 timeout(long j, TimeUnit timeUnit) {
            p.e(timeUnit, "unit");
            return this;
        }
    }

    public static final class b {
        public b(DefaultConstructorMarker defaultConstructorMarker) {
        }

        public final long a(long j, long j2) {
            return (j != 0 && (j2 == 0 || j < j2)) ? j : j2;
        }
    }

    public b0 clearDeadline() {
        this.hasDeadline = false;
        return this;
    }

    public b0 clearTimeout() {
        this.timeoutNanos = 0;
        return this;
    }

    public final b0 deadline(long j, TimeUnit timeUnit) {
        p.e(timeUnit, "unit");
        if (j > 0) {
            return deadlineNanoTime(timeUnit.toNanos(j) + System.nanoTime());
        }
        throw new IllegalArgumentException(e.e.b.a.a.s("duration <= 0: ", j).toString());
    }

    public long deadlineNanoTime() {
        if (this.hasDeadline) {
            return this.deadlineNanoTime;
        }
        throw new IllegalStateException("No deadline".toString());
    }

    public boolean hasDeadline() {
        return this.hasDeadline;
    }

    public final void intersectWith(b0 b0Var, ka.h.b.a<Unit> aVar) {
        p.e(b0Var, "other");
        p.e(aVar, "block");
        long timeoutNanos2 = timeoutNanos();
        timeout(Companion.a(b0Var.timeoutNanos(), timeoutNanos()), TimeUnit.NANOSECONDS);
        if (hasDeadline()) {
            long deadlineNanoTime2 = deadlineNanoTime();
            if (b0Var.hasDeadline()) {
                deadlineNanoTime(Math.min(deadlineNanoTime(), b0Var.deadlineNanoTime()));
            }
            try {
                aVar.invoke();
            } finally {
                timeout(timeoutNanos2, TimeUnit.NANOSECONDS);
                if (b0Var.hasDeadline()) {
                    deadlineNanoTime(deadlineNanoTime2);
                }
            }
        } else {
            if (b0Var.hasDeadline()) {
                deadlineNanoTime(b0Var.deadlineNanoTime());
            }
            try {
                aVar.invoke();
            } finally {
                timeout(timeoutNanos2, TimeUnit.NANOSECONDS);
                if (b0Var.hasDeadline()) {
                    clearDeadline();
                }
            }
        }
    }

    public void throwIfReached() throws IOException {
        Thread currentThread = Thread.currentThread();
        p.d(currentThread, "Thread.currentThread()");
        if (currentThread.isInterrupted()) {
            throw new InterruptedIOException("interrupted");
        } else if (this.hasDeadline && this.deadlineNanoTime - System.nanoTime() <= 0) {
            throw new InterruptedIOException("deadline reached");
        }
    }

    public b0 timeout(long j, TimeUnit timeUnit) {
        p.e(timeUnit, "unit");
        if (j >= 0) {
            this.timeoutNanos = timeUnit.toNanos(j);
            return this;
        }
        throw new IllegalArgumentException(e.e.b.a.a.s("timeout < 0: ", j).toString());
    }

    public long timeoutNanos() {
        return this.timeoutNanos;
    }

    public final void waitUntilNotified(Object obj) throws InterruptedIOException {
        p.e(obj, "monitor");
        try {
            boolean hasDeadline2 = hasDeadline();
            long timeoutNanos2 = timeoutNanos();
            long j = 0;
            if (hasDeadline2 || timeoutNanos2 != 0) {
                long nanoTime = System.nanoTime();
                if (hasDeadline2 && timeoutNanos2 != 0) {
                    timeoutNanos2 = Math.min(timeoutNanos2, deadlineNanoTime() - nanoTime);
                } else if (hasDeadline2) {
                    timeoutNanos2 = deadlineNanoTime() - nanoTime;
                }
                if (timeoutNanos2 > 0) {
                    long j2 = timeoutNanos2 / 1000000;
                    Long.signum(j2);
                    obj.wait(j2, (int) (timeoutNanos2 - (1000000 * j2)));
                    j = System.nanoTime() - nanoTime;
                }
                if (j >= timeoutNanos2) {
                    throw new InterruptedIOException("timeout");
                }
                return;
            }
            obj.wait();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            throw new InterruptedIOException("interrupted");
        }
    }

    public b0 deadlineNanoTime(long j) {
        this.hasDeadline = true;
        this.deadlineNanoTime = j;
        return this;
    }
}

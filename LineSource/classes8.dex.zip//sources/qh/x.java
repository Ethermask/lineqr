package qh;

import java.security.MessageDigest;
import ka.b.k;
import ka.b.q;
import ka.h.c.p;

public final class x extends h {
    public final transient byte[][] f;
    public final transient int[] g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public x(byte[][] bArr, int[] iArr) {
        super(h.d.c);
        p.e(bArr, "segments");
        p.e(iArr, "directory");
        this.f = bArr;
        this.g = iArr;
    }

    private final Object writeReplace() {
        return d0();
    }

    public byte[] H() {
        return c0();
    }

    public byte J(int i) {
        int i2;
        q.Z((long) this.g[this.f.length - 1], (long) i, 1);
        int X2 = q.X2(this, i);
        if (X2 == 0) {
            i2 = 0;
        } else {
            i2 = this.g[X2 - 1];
        }
        int[] iArr = this.g;
        byte[][] bArr = this.f;
        return bArr[X2][(i - i2) + iArr[bArr.length + X2]];
    }

    public boolean K(int i, h hVar, int i2, int i3) {
        int i4;
        p.e(hVar, "other");
        if (i < 0 || i > j() - i3) {
            return false;
        }
        int i5 = i3 + i;
        int X2 = q.X2(this, i);
        while (i < i5) {
            if (X2 == 0) {
                i4 = 0;
            } else {
                i4 = this.g[X2 - 1];
            }
            int[] iArr = this.g;
            int i6 = iArr[this.f.length + X2];
            int min = Math.min(i5, (iArr[X2] - i4) + i4) - i;
            if (!hVar.M(i2, this.f[X2], (i - i4) + i6, min)) {
                return false;
            }
            i2 += min;
            i += min;
            X2++;
        }
        return true;
    }

    public boolean M(int i, byte[] bArr, int i2, int i3) {
        int i4;
        p.e(bArr, "other");
        if (i < 0 || i > j() - i3 || i2 < 0 || i2 > bArr.length - i3) {
            return false;
        }
        int i5 = i3 + i;
        int X2 = q.X2(this, i);
        while (i < i5) {
            if (X2 == 0) {
                i4 = 0;
            } else {
                i4 = this.g[X2 - 1];
            }
            int[] iArr = this.g;
            int i6 = iArr[this.f.length + X2];
            int min = Math.min(i5, (iArr[X2] - i4) + i4) - i;
            if (!q.p(this.f[X2], (i - i4) + i6, bArr, i2, min)) {
                return false;
            }
            i2 += min;
            i += min;
            X2++;
        }
        return true;
    }

    public h P() {
        return d0().P();
    }

    public String a() {
        return d0().a();
    }

    public void a0(d dVar, int i, int i2) {
        int i3;
        p.e(dVar, "buffer");
        int i4 = i + i2;
        int X2 = q.X2(this, i);
        while (i < i4) {
            if (X2 == 0) {
                i3 = 0;
            } else {
                i3 = this.g[X2 - 1];
            }
            int[] iArr = this.g;
            int i5 = iArr[this.f.length + X2];
            int min = Math.min(i4, (iArr[X2] - i3) + i3) - i;
            int i6 = (i - i3) + i5;
            v vVar = new v(this.f[X2], i6, i6 + min, true, false);
            v vVar2 = dVar.a;
            if (vVar2 == null) {
                vVar.g = vVar;
                vVar.f = vVar;
                dVar.a = vVar;
            } else {
                p.c(vVar2);
                v vVar3 = vVar2.g;
                p.c(vVar3);
                vVar3.b(vVar);
            }
            i += min;
            X2++;
        }
        dVar.b += (long) i2;
    }

    public byte[] c0() {
        byte[] bArr = new byte[j()];
        int length = this.f.length;
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (i < length) {
            int[] iArr = this.g;
            int i4 = iArr[length + i];
            int i5 = iArr[i];
            int i6 = i5 - i2;
            k.e(this.f[i], bArr, i3, i4, i4 + i6);
            i3 += i6;
            i++;
            i2 = i5;
        }
        return bArr;
    }

    public final h d0() {
        return new h(c0());
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof h) {
            h hVar = (h) obj;
            if (hVar.j() == j() && K(0, hVar, 0, j())) {
                return true;
            }
        }
        return false;
    }

    public h f(String str) {
        p.e(str, "algorithm");
        MessageDigest instance = MessageDigest.getInstance(str);
        int length = this.f.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            int[] iArr = this.g;
            int i3 = iArr[length + i];
            int i4 = iArr[i];
            instance.update(this.f[i], i3, i4 - i2);
            i++;
            i2 = i4;
        }
        byte[] digest = instance.digest();
        p.d(digest, "digestBytes");
        return new h(digest);
    }

    public int hashCode() {
        int i = this.a;
        if (i != 0) {
            return i;
        }
        int length = this.f.length;
        int i2 = 0;
        int i3 = 1;
        int i4 = 0;
        while (i2 < length) {
            int[] iArr = this.g;
            int i5 = iArr[length + i2];
            int i6 = iArr[i2];
            byte[] bArr = this.f[i2];
            int i7 = (i6 - i4) + i5;
            while (i5 < i7) {
                i3 = (i3 * 31) + bArr[i5];
                i5++;
            }
            i2++;
            i4 = i6;
        }
        this.a = i3;
        return i3;
    }

    public int j() {
        return this.g[this.f.length - 1];
    }

    public String r() {
        return d0().r();
    }

    public String toString() {
        return d0().toString();
    }
}

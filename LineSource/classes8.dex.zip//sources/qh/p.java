package qh;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.logging.Logger;
import ka.m.w;

public final /* synthetic */ class p {
    public static final Logger a = Logger.getLogger("okio.Okio");

    public static final y a(File file) throws FileNotFoundException {
        ka.h.c.p.e(file, "$this$appendingSink");
        return d(new FileOutputStream(file, true));
    }

    public static final boolean b(AssertionError assertionError) {
        ka.h.c.p.e(assertionError, "$this$isAndroidGetsocknameError");
        if (assertionError.getCause() == null) {
            return false;
        }
        String message = assertionError.getMessage();
        return message != null ? w.K(message, "getsockname failed", false, 2) : false;
    }

    public static final y c(File file, boolean z) throws FileNotFoundException {
        ka.h.c.p.e(file, "$this$sink");
        return d(new FileOutputStream(file, z));
    }

    public static final y d(OutputStream outputStream) {
        ka.h.c.p.e(outputStream, "$this$sink");
        return new r(outputStream, new b0());
    }

    public static final y e(Socket socket) throws IOException {
        ka.h.c.p.e(socket, "$this$sink");
        z zVar = new z(socket);
        OutputStream outputStream = socket.getOutputStream();
        ka.h.c.p.d(outputStream, "getOutputStream()");
        return zVar.sink(new r(outputStream, zVar));
    }

    public static final a0 f(File file) throws FileNotFoundException {
        ka.h.c.p.e(file, "$this$source");
        return g(new FileInputStream(file));
    }

    public static final a0 g(InputStream inputStream) {
        ka.h.c.p.e(inputStream, "$this$source");
        return new o(inputStream, new b0());
    }

    public static final a0 h(Socket socket) throws IOException {
        ka.h.c.p.e(socket, "$this$source");
        z zVar = new z(socket);
        InputStream inputStream = socket.getInputStream();
        ka.h.c.p.d(inputStream, "getInputStream()");
        return zVar.source(new o(inputStream, zVar));
    }
}

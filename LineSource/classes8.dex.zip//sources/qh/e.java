package qh;

import java.io.OutputStream;
import ka.h.c.p;

public final class e extends OutputStream {
    public final /* synthetic */ d a;

    public e(d dVar) {
        this.a = dVar;
    }

    public void close() {
    }

    public void flush() {
    }

    public String toString() {
        return this.a + ".outputStream()";
    }

    public void write(int i) {
        this.a.a0(i);
    }

    public void write(byte[] bArr, int i, int i2) {
        p.e(bArr, "data");
        this.a.W(bArr, i, i2);
    }
}

package qh;

import e.e.b.a.a;
import java.io.EOFException;
import java.io.IOException;
import java.util.zip.CRC32;
import java.util.zip.Inflater;
import ka.h.c.p;

public final class m implements a0 {
    public byte a;
    public final u b;
    public final Inflater c;
    public final n d;

    /* renamed from: e  reason: collision with root package name */
    public final CRC32 f118e = new CRC32();

    public m(a0 a0Var) {
        p.e(a0Var, "source");
        this.b = new u(a0Var);
        Inflater inflater = new Inflater(true);
        this.c = inflater;
        this.d = new n((g) this.b, inflater);
    }

    public final void a(String str, int i, int i2) {
        if (i2 != i) {
            throw new IOException(a.O0(new Object[]{str, Integer.valueOf(i2), Integer.valueOf(i)}, 3, "%s: actual 0x%08x != expected 0x%08x", "java.lang.String.format(this, *args)"));
        }
    }

    public final void b(d dVar, long j, long j2) {
        v vVar = dVar.a;
        p.c(vVar);
        while (true) {
            int i = vVar.c;
            int i2 = vVar.b;
            if (j < ((long) (i - i2))) {
                break;
            }
            j -= (long) (i - i2);
            vVar = vVar.f;
            p.c(vVar);
        }
        while (j2 > 0) {
            int i3 = (int) (((long) vVar.b) + j);
            int min = (int) Math.min((long) (vVar.c - i3), j2);
            this.f118e.update(vVar.a, i3, min);
            j2 -= (long) min;
            vVar = vVar.f;
            p.c(vVar);
            j = 0;
        }
    }

    public void close() throws IOException {
        this.d.close();
    }

    public long read(d dVar, long j) throws IOException {
        long j2;
        d dVar2 = dVar;
        long j3 = j;
        p.e(dVar2, "sink");
        int i = (j3 > 0 ? 1 : (j3 == 0 ? 0 : -1));
        boolean z = false;
        if (!(i >= 0)) {
            throw new IllegalArgumentException(a.s("byteCount < 0: ", j3).toString());
        } else if (i == 0) {
            return 0;
        } else {
            if (this.a == 0) {
                this.b.S(10);
                byte d2 = this.b.a.d(3);
                boolean z2 = ((d2 >> 1) & 1) == 1;
                if (z2) {
                    b(this.b.a, 0, 10);
                }
                a("ID1ID2", 8075, this.b.readShort());
                this.b.skip(8);
                if (((d2 >> 2) & 1) == 1) {
                    this.b.S(2);
                    if (z2) {
                        b(this.b.a, 0, 2);
                    }
                    long s = (long) this.b.a.s();
                    this.b.S(s);
                    if (z2) {
                        j2 = s;
                        b(this.b.a, 0, s);
                    } else {
                        j2 = s;
                    }
                    this.b.skip(j2);
                }
                if (((d2 >> 3) & 1) == 1) {
                    long a2 = this.b.a((byte) 0, 0, Long.MAX_VALUE);
                    if (a2 != -1) {
                        if (z2) {
                            b(this.b.a, 0, a2 + 1);
                        }
                        this.b.skip(a2 + 1);
                    } else {
                        throw new EOFException();
                    }
                }
                if (((d2 >> 4) & 1) == 1) {
                    z = true;
                }
                if (z) {
                    long a3 = this.b.a((byte) 0, 0, Long.MAX_VALUE);
                    if (a3 != -1) {
                        if (z2) {
                            b(this.b.a, 0, a3 + 1);
                        }
                        this.b.skip(a3 + 1);
                    } else {
                        throw new EOFException();
                    }
                }
                if (z2) {
                    u uVar = this.b;
                    uVar.S(2);
                    a("FHCRC", uVar.a.s(), (short) ((int) this.f118e.getValue()));
                    this.f118e.reset();
                }
                this.a = 1;
            }
            if (this.a == 1) {
                long j4 = dVar2.b;
                long read = this.d.read(dVar2, j3);
                if (read != -1) {
                    b(dVar, j4, read);
                    return read;
                }
                this.a = 2;
            }
            if (this.a == 2) {
                a("CRC", this.b.b(), (int) this.f118e.getValue());
                a("ISIZE", this.b.b(), (int) this.c.getBytesWritten());
                this.a = 3;
                if (!this.b.Z()) {
                    throw new IOException("gzip finished without exhausting source");
                }
            }
            return -1;
        }
    }

    public b0 timeout() {
        return this.b.timeout();
    }
}

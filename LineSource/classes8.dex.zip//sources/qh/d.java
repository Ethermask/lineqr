package qh;

import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.charset.Charset;
import java.util.Arrays;
import ka.b.k;
import ka.b.q;
import ka.h.c.p;
import okhttp3.internal.http2.Hpack;

public final class d implements g, f, Cloneable, ByteChannel {
    public v a;
    public long b;

    public static final class a implements Closeable {
        public d a;
        public boolean b;
        public v c;
        public long d = -1;

        /* renamed from: e  reason: collision with root package name */
        public byte[] f116e;
        public int f = -1;
        public int g = -1;

        public final long a(long j) {
            d dVar = this.a;
            if (dVar == null) {
                throw new IllegalStateException("not attached to a buffer".toString());
            } else if (this.b) {
                long j2 = dVar.b;
                int i = (j > j2 ? 1 : (j == j2 ? 0 : -1));
                int i2 = 1;
                if (i <= 0) {
                    if (j < 0) {
                        i2 = 0;
                    }
                    if (i2 != 0) {
                        long j3 = j2 - j;
                        while (true) {
                            if (j3 <= 0) {
                                break;
                            }
                            v vVar = dVar.a;
                            p.c(vVar);
                            v vVar2 = vVar.g;
                            p.c(vVar2);
                            int i3 = vVar2.c;
                            long j4 = (long) (i3 - vVar2.b);
                            if (j4 > j3) {
                                vVar2.c = i3 - ((int) j3);
                                break;
                            }
                            dVar.a = vVar2.a();
                            w.a(vVar2);
                            j3 -= j4;
                        }
                        this.c = null;
                        this.d = j;
                        this.f116e = null;
                        this.f = -1;
                        this.g = -1;
                    } else {
                        throw new IllegalArgumentException(e.e.b.a.a.s("newSize < 0: ", j).toString());
                    }
                } else if (i > 0) {
                    long j5 = j - j2;
                    boolean z = true;
                    while (j5 > 0) {
                        v M = dVar.M(i2);
                        int min = (int) Math.min(j5, (long) (8192 - M.c));
                        int i4 = M.c + min;
                        M.c = i4;
                        j5 -= (long) min;
                        if (z) {
                            this.c = M;
                            this.d = j2;
                            this.f116e = M.a;
                            this.f = i4 - min;
                            this.g = i4;
                            z = false;
                        }
                        i2 = 1;
                    }
                }
                dVar.b = j;
                return j2;
            } else {
                throw new IllegalStateException("resizeBuffer() only permitted for read/write buffers".toString());
            }
        }

        public final int b(long j) {
            long j2;
            v vVar;
            long j3 = j;
            d dVar = this.a;
            if (dVar != null) {
                if (j3 >= ((long) -1)) {
                    long j4 = dVar.b;
                    if (j3 <= j4) {
                        if (j3 == -1 || j3 == j4) {
                            this.c = null;
                            this.d = j3;
                            this.f116e = null;
                            this.f = -1;
                            this.g = -1;
                            return -1;
                        }
                        long j5 = 0;
                        v vVar2 = dVar.a;
                        v vVar3 = this.c;
                        if (vVar3 != null) {
                            long j6 = this.d;
                            int i = this.f;
                            p.c(vVar3);
                            j2 = j6 - ((long) (i - vVar3.b));
                            if (j2 > j3) {
                                vVar = this.c;
                            } else {
                                long j7 = j4;
                                vVar = vVar2;
                                vVar2 = this.c;
                                j5 = j2;
                                j2 = j7;
                            }
                        } else {
                            j2 = j4;
                            vVar = vVar2;
                        }
                        if (j2 - j3 > j3 - j5) {
                            while (true) {
                                p.c(vVar2);
                                int i2 = vVar2.c;
                                int i3 = vVar2.b;
                                if (j3 < ((long) (i2 - i3)) + j5) {
                                    break;
                                }
                                j5 += (long) (i2 - i3);
                                vVar2 = vVar2.f;
                            }
                        } else {
                            while (j2 > j3) {
                                p.c(vVar);
                                vVar = vVar.g;
                                p.c(vVar);
                                j2 -= (long) (vVar.c - vVar.b);
                            }
                            vVar2 = vVar;
                            j5 = j2;
                        }
                        if (this.b) {
                            p.c(vVar2);
                            if (vVar2.d) {
                                byte[] bArr = vVar2.a;
                                byte[] copyOf = Arrays.copyOf(bArr, bArr.length);
                                p.d(copyOf, "java.util.Arrays.copyOf(this, size)");
                                v vVar4 = new v(copyOf, vVar2.b, vVar2.c, false, true);
                                if (dVar.a == vVar2) {
                                    dVar.a = vVar4;
                                }
                                vVar2.b(vVar4);
                                v vVar5 = vVar4.g;
                                p.c(vVar5);
                                vVar5.a();
                                vVar2 = vVar4;
                            }
                        }
                        this.c = vVar2;
                        this.d = j3;
                        p.c(vVar2);
                        this.f116e = vVar2.a;
                        int i4 = vVar2.b + ((int) (j3 - j5));
                        this.f = i4;
                        int i5 = vVar2.c;
                        this.g = i5;
                        return i5 - i4;
                    }
                }
                StringBuilder b1 = e.e.b.a.a.b1("offset=", j3, " > size=");
                b1.append(dVar.b);
                throw new ArrayIndexOutOfBoundsException(b1.toString());
            }
            throw new IllegalStateException("not attached to a buffer".toString());
        }

        public void close() {
            if (this.a != null) {
                this.a = null;
                this.c = null;
                this.d = -1;
                this.f116e = null;
                this.f = -1;
                this.g = -1;
                return;
            }
            throw new IllegalStateException("not attached to a buffer".toString());
        }
    }

    public f B() {
        return this;
    }

    public /* bridge */ /* synthetic */ f C(String str) {
        l0(str);
        return this;
    }

    public /* bridge */ /* synthetic */ f D(String str, int i, int i2) {
        n0(str, i, i2);
        return this;
    }

    public long E(a0 a0Var) throws IOException {
        p.e(a0Var, "source");
        long j = 0;
        while (true) {
            long read = a0Var.read(this, (long) 8192);
            if (read == -1) {
                return j;
            }
            j += read;
        }
    }

    public String F(long j) throws EOFException {
        return t(j, ka.m.a.a);
    }

    public String G() throws EOFException {
        return q(Long.MAX_VALUE);
    }

    public byte[] I(long j) throws EOFException {
        if (!(j >= 0 && j <= ((long) Integer.MAX_VALUE))) {
            throw new IllegalArgumentException(e.e.b.a.a.s("byteCount: ", j).toString());
        } else if (this.b >= j) {
            byte[] bArr = new byte[((int) j)];
            readFully(bArr);
            return bArr;
        } else {
            throw new EOFException();
        }
    }

    public int J() throws EOFException {
        byte b2;
        int i;
        byte b3;
        if (this.b != 0) {
            byte d = d(0);
            int i2 = 1;
            if ((d & 128) == 0) {
                b3 = d & Byte.MAX_VALUE;
                b2 = 0;
                i = 1;
            } else if ((d & 224) == 192) {
                b3 = d & 31;
                i = 2;
                b2 = 128;
            } else if ((d & 240) == 224) {
                b3 = d & 15;
                i = 3;
                b2 = 2048;
            } else if ((d & 248) == 240) {
                b3 = d & 7;
                i = 4;
                b2 = 65536;
            } else {
                skip(1);
                return 65533;
            }
            long j = (long) i;
            if (this.b >= j) {
                while (i2 < i) {
                    long j2 = (long) i2;
                    byte d2 = d(j2);
                    if ((d2 & 192) == 128) {
                        b3 = (b3 << 6) | (d2 & 63);
                        i2++;
                    } else {
                        skip(j2);
                        return 65533;
                    }
                }
                skip(j);
                if (b3 > 1114111) {
                    return 65533;
                }
                if ((55296 <= b3 && 57343 >= b3) || b3 < b2) {
                    return 65533;
                }
                return b3;
            }
            StringBuilder Z0 = e.e.b.a.a.Z0("size < ", i, ": ");
            Z0.append(this.b);
            Z0.append(" (to read code point prefixed 0x");
            Z0.append(q.G3(d));
            Z0.append(')');
            throw new EOFException(Z0.toString());
        }
        throw new EOFException();
    }

    public final h K(int i) {
        if (i == 0) {
            return h.d;
        }
        q.Z(this.b, 0, (long) i);
        v vVar = this.a;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (i3 < i) {
            p.c(vVar);
            int i5 = vVar.c;
            int i6 = vVar.b;
            if (i5 != i6) {
                i3 += i5 - i6;
                i4++;
                vVar = vVar.f;
            } else {
                throw new AssertionError("s.limit == s.pos");
            }
        }
        byte[][] bArr = new byte[i4][];
        int[] iArr = new int[(i4 * 2)];
        v vVar2 = this.a;
        int i7 = 0;
        while (i2 < i) {
            p.c(vVar2);
            bArr[i7] = vVar2.a;
            i2 += vVar2.c - vVar2.b;
            iArr[i7] = Math.min(i2, i);
            iArr[i7 + i4] = vVar2.b;
            vVar2.d = true;
            i7++;
            vVar2 = vVar2.f;
        }
        return new x(bArr, iArr);
    }

    public /* bridge */ /* synthetic */ f L(byte[] bArr) {
        P(bArr);
        return this;
    }

    public final v M(int i) {
        boolean z = true;
        if (i < 1 || i > 8192) {
            z = false;
        }
        if (z) {
            v vVar = this.a;
            if (vVar == null) {
                v b2 = w.b();
                this.a = b2;
                b2.g = b2;
                b2.f = b2;
                return b2;
            }
            p.c(vVar);
            v vVar2 = vVar.g;
            p.c(vVar2);
            if (vVar2.c + i <= 8192 && vVar2.f120e) {
                return vVar2;
            }
            v b3 = w.b();
            vVar2.b(b3);
            return b3;
        }
        throw new IllegalArgumentException("unexpected capacity".toString());
    }

    public d N(h hVar) {
        p.e(hVar, "byteString");
        hVar.a0(this, 0, hVar.j());
        return this;
    }

    public d P(byte[] bArr) {
        p.e(bArr, "source");
        W(bArr, 0, bArr.length);
        return this;
    }

    public void S(long j) throws EOFException {
        if (this.b < j) {
            throw new EOFException();
        }
    }

    public h U(long j) throws EOFException {
        if (!(j >= 0 && j <= ((long) Integer.MAX_VALUE))) {
            throw new IllegalArgumentException(e.e.b.a.a.s("byteCount: ", j).toString());
        } else if (this.b < j) {
            throw new EOFException();
        } else if (j < ((long) Hpack.SETTINGS_HEADER_TABLE_SIZE)) {
            return new h(I(j));
        } else {
            h K = K((int) j);
            skip(j);
            return K;
        }
    }

    public d W(byte[] bArr, int i, int i2) {
        p.e(bArr, "source");
        long j = (long) i2;
        q.Z((long) bArr.length, (long) i, j);
        int i3 = i2 + i;
        while (i < i3) {
            v M = M(1);
            int min = Math.min(i3 - i, 8192 - M.c);
            int i4 = i + min;
            k.e(bArr, M.a, M.c, i, i4);
            M.c += min;
            i = i4;
        }
        this.b += j;
        return this;
    }

    public byte[] Y() {
        return I(this.b);
    }

    public boolean Z() {
        return this.b == 0;
    }

    /* renamed from: a */
    public d clone() {
        d dVar = new d();
        if (this.b != 0) {
            v vVar = this.a;
            p.c(vVar);
            v c = vVar.c();
            dVar.a = c;
            c.g = c;
            c.f = c;
            for (v vVar2 = vVar.f; vVar2 != vVar; vVar2 = vVar2.f) {
                v vVar3 = c.g;
                p.c(vVar3);
                p.c(vVar2);
                vVar3.b(vVar2.c());
            }
            dVar.b = this.b;
        }
        return dVar;
    }

    public d a0(int i) {
        v M = M(1);
        byte[] bArr = M.a;
        int i2 = M.c;
        M.c = i2 + 1;
        bArr[i2] = (byte) i;
        this.b++;
        return this;
    }

    public final long b() {
        long j = this.b;
        if (j == 0) {
            return 0;
        }
        v vVar = this.a;
        p.c(vVar);
        v vVar2 = vVar.g;
        p.c(vVar2);
        int i = vVar2.c;
        if (i < 8192 && vVar2.f120e) {
            j -= (long) (i - vVar2.b);
        }
        return j;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:32:0x009d, code lost:
        if (r10 != r11) goto L_0x00a9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x009f, code lost:
        r0.a = r15.a();
        qh.w.a(r15);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x00a9, code lost:
        r15.b = r10;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x00ac, code lost:
        if (r6 != false) goto L_0x00b2;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public long b0() throws java.io.EOFException {
        /*
            r17 = this;
            r0 = r17
            long r1 = r0.b
            r3 = 0
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 == 0) goto L_0x00bd
            r1 = -7
            r5 = 0
            r6 = r5
            r7 = r6
        L_0x000f:
            qh.v r8 = r0.a
            ka.h.c.p.c(r8)
            byte[] r9 = r8.a
            int r10 = r8.b
            int r11 = r8.c
        L_0x001a:
            r12 = 1
            if (r10 >= r11) goto L_0x009c
            byte r13 = r9[r10]
            r14 = 48
            byte r14 = (byte) r14
            if (r13 < r14) goto L_0x006b
            r15 = 57
            byte r15 = (byte) r15
            if (r13 > r15) goto L_0x006b
            int r14 = r14 - r13
            r15 = -922337203685477580(0xf333333333333334, double:-8.390303882365713E246)
            int r12 = (r3 > r15 ? 1 : (r3 == r15 ? 0 : -1))
            if (r12 < 0) goto L_0x0044
            r15 = r8
            r16 = r9
            if (r12 != 0) goto L_0x003e
            long r8 = (long) r14
            int r8 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
            if (r8 >= 0) goto L_0x003e
            goto L_0x0044
        L_0x003e:
            r8 = 10
            long r3 = r3 * r8
            long r8 = (long) r14
            long r3 = r3 + r8
            goto L_0x0079
        L_0x0044:
            qh.d r1 = new qh.d
            r1.<init>()
            r1.T(r3)
            r1.a0(r13)
            if (r7 != 0) goto L_0x0054
            r1.readByte()
        L_0x0054:
            java.lang.NumberFormatException r2 = new java.lang.NumberFormatException
            java.lang.String r3 = "Number too large: "
            java.lang.StringBuilder r3 = e.e.b.a.a.V0(r3)
            java.lang.String r1 = r1.v()
            r3.append(r1)
            java.lang.String r1 = r3.toString()
            r2.<init>(r1)
            throw r2
        L_0x006b:
            r15 = r8
            r16 = r9
            r8 = 45
            byte r8 = (byte) r8
            if (r13 != r8) goto L_0x0081
            if (r5 != 0) goto L_0x0081
            r7 = 1
            long r1 = r1 - r7
            r7 = r12
        L_0x0079:
            int r10 = r10 + 1
            int r5 = r5 + 1
            r8 = r15
            r9 = r16
            goto L_0x001a
        L_0x0081:
            if (r5 == 0) goto L_0x0085
            r6 = r12
            goto L_0x009d
        L_0x0085:
            java.lang.NumberFormatException r1 = new java.lang.NumberFormatException
            java.lang.String r2 = "Expected leading [0-9] or '-' character but was 0x"
            java.lang.StringBuilder r2 = e.e.b.a.a.V0(r2)
            java.lang.String r3 = ka.b.q.G3(r13)
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x009c:
            r15 = r8
        L_0x009d:
            if (r10 != r11) goto L_0x00a9
            qh.v r8 = r15.a()
            r0.a = r8
            qh.w.a(r15)
            goto L_0x00ac
        L_0x00a9:
            r8 = r15
            r8.b = r10
        L_0x00ac:
            if (r6 != 0) goto L_0x00b2
            qh.v r8 = r0.a
            if (r8 != 0) goto L_0x000f
        L_0x00b2:
            long r1 = r0.b
            long r5 = (long) r5
            long r1 = r1 - r5
            r0.b = r1
            if (r7 == 0) goto L_0x00bb
            goto L_0x00bc
        L_0x00bb:
            long r3 = -r3
        L_0x00bc:
            return r3
        L_0x00bd:
            java.io.EOFException r1 = new java.io.EOFException
            r1.<init>()
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: qh.d.b0():long");
    }

    public final d c(d dVar, long j, long j2) {
        p.e(dVar, "out");
        q.Z(this.b, j, j2);
        if (j2 != 0) {
            dVar.b += j2;
            v vVar = this.a;
            while (true) {
                p.c(vVar);
                int i = vVar.c;
                int i2 = vVar.b;
                if (j < ((long) (i - i2))) {
                    break;
                }
                j -= (long) (i - i2);
                vVar = vVar.f;
            }
            while (j2 > 0) {
                p.c(vVar);
                v c = vVar.c();
                int i3 = c.b + ((int) j);
                c.b = i3;
                c.c = Math.min(i3 + ((int) j2), c.c);
                v vVar2 = dVar.a;
                if (vVar2 == null) {
                    c.g = c;
                    c.f = c;
                    dVar.a = c;
                } else {
                    p.c(vVar2);
                    v vVar3 = vVar2.g;
                    p.c(vVar3);
                    vVar3.b(c);
                }
                j2 -= (long) (c.c - c.b);
                vVar = vVar.f;
                j = 0;
            }
        }
        return this;
    }

    /* JADX WARNING: Removed duplicated region for block: B:65:0x00e0  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x00ef A[LOOP:0: B:67:0x00eb->B:69:0x00ef, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x00ff  */
    /* renamed from: c0 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public qh.d T(long r13) {
        /*
            r12 = this;
            r0 = 0
            int r2 = (r13 > r0 ? 1 : (r13 == r0 ? 0 : -1))
            if (r2 != 0) goto L_0x000d
            r13 = 48
            r12.a0(r13)
            goto L_0x0111
        L_0x000d:
            r3 = 0
            r4 = 1
            if (r2 >= 0) goto L_0x001e
            long r13 = -r13
            int r2 = (r13 > r0 ? 1 : (r13 == r0 ? 0 : -1))
            if (r2 >= 0) goto L_0x001d
            java.lang.String r13 = "-9223372036854775808"
            r12.l0(r13)
            goto L_0x0111
        L_0x001d:
            r3 = r4
        L_0x001e:
            r5 = 100000000(0x5f5e100, double:4.94065646E-316)
            int r2 = (r13 > r5 ? 1 : (r13 == r5 ? 0 : -1))
            r5 = 10
            if (r2 >= 0) goto L_0x0066
            r6 = 10000(0x2710, double:4.9407E-320)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x0048
            r6 = 100
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x003e
            r6 = 10
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x003b
            goto L_0x00de
        L_0x003b:
            r4 = 2
            goto L_0x00de
        L_0x003e:
            r6 = 1000(0x3e8, double:4.94E-321)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x0046
            r2 = 3
            goto L_0x0092
        L_0x0046:
            r2 = 4
            goto L_0x0092
        L_0x0048:
            r6 = 1000000(0xf4240, double:4.940656E-318)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x005a
            r6 = 100000(0x186a0, double:4.94066E-319)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x0058
            r2 = 5
            goto L_0x0092
        L_0x0058:
            r2 = 6
            goto L_0x0092
        L_0x005a:
            r6 = 10000000(0x989680, double:4.9406565E-317)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x0063
            r2 = 7
            goto L_0x0092
        L_0x0063:
            r2 = 8
            goto L_0x0092
        L_0x0066:
            r6 = 1000000000000(0xe8d4a51000, double:4.94065645841E-312)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x0094
            r6 = 10000000000(0x2540be400, double:4.9406564584E-314)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x0084
            r6 = 1000000000(0x3b9aca00, double:4.94065646E-315)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x0082
            r4 = 9
            goto L_0x00de
        L_0x0082:
            r4 = r5
            goto L_0x00de
        L_0x0084:
            r6 = 100000000000(0x174876e800, double:4.9406564584E-313)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x0090
            r2 = 11
            goto L_0x0092
        L_0x0090:
            r2 = 12
        L_0x0092:
            r4 = r2
            goto L_0x00de
        L_0x0094:
            r6 = 1000000000000000(0x38d7ea4c68000, double:4.940656458412465E-309)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x00b8
            r6 = 10000000000000(0x9184e72a000, double:4.9406564584125E-311)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x00a9
            r4 = 13
            goto L_0x00de
        L_0x00a9:
            r6 = 100000000000000(0x5af3107a4000, double:4.94065645841247E-310)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x00b5
            r2 = 14
            goto L_0x0092
        L_0x00b5:
            r2 = 15
            goto L_0x0092
        L_0x00b8:
            r6 = 100000000000000000(0x16345785d8a0000, double:5.620395787888205E-302)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x00d0
            r6 = 10000000000000000(0x2386f26fc10000, double:5.431165199810528E-308)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x00cd
            r4 = 16
            goto L_0x00de
        L_0x00cd:
            r4 = 17
            goto L_0x00de
        L_0x00d0:
            r6 = 1000000000000000000(0xde0b6b3a7640000, double:7.832953389245686E-242)
            int r2 = (r13 > r6 ? 1 : (r13 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x00dc
            r4 = 18
            goto L_0x00de
        L_0x00dc:
            r4 = 19
        L_0x00de:
            if (r3 == 0) goto L_0x00e2
            int r4 = r4 + 1
        L_0x00e2:
            qh.v r2 = r12.M(r4)
            byte[] r6 = r2.a
            int r7 = r2.c
            int r7 = r7 + r4
        L_0x00eb:
            int r8 = (r13 > r0 ? 1 : (r13 == r0 ? 0 : -1))
            if (r8 == 0) goto L_0x00fd
            long r8 = (long) r5
            long r10 = r13 % r8
            int r10 = (int) r10
            int r7 = r7 + -1
            byte[] r11 = qh.c0.a.a
            byte r10 = r11[r10]
            r6[r7] = r10
            long r13 = r13 / r8
            goto L_0x00eb
        L_0x00fd:
            if (r3 == 0) goto L_0x0106
            int r7 = r7 + -1
            r13 = 45
            byte r13 = (byte) r13
            r6[r7] = r13
        L_0x0106:
            int r13 = r2.c
            int r13 = r13 + r4
            r2.c = r13
            long r13 = r12.b
            long r0 = (long) r4
            long r13 = r13 + r0
            r12.b = r13
        L_0x0111:
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: qh.d.T(long):qh.d");
    }

    public void close() {
    }

    public final byte d(long j) {
        q.Z(this.b, j, 1);
        v vVar = this.a;
        if (vVar != null) {
            long j2 = this.b;
            if (j2 - j < j) {
                while (j2 > j) {
                    vVar = vVar.g;
                    p.c(vVar);
                    j2 -= (long) (vVar.c - vVar.b);
                }
                p.c(vVar);
                return vVar.a[(int) ((((long) vVar.b) + j) - j2)];
            }
            long j3 = 0;
            while (true) {
                long j4 = ((long) (vVar.c - vVar.b)) + j3;
                if (j4 > j) {
                    p.c(vVar);
                    return vVar.a[(int) ((((long) vVar.b) + j) - j3)];
                }
                vVar = vVar.f;
                p.c(vVar);
                j3 = j4;
            }
        } else {
            p.c((Object) null);
            return null.a[(int) ((((long) null.b) + j) - -1)];
        }
    }

    public /* bridge */ /* synthetic */ f e(int i) {
        g0(i);
        return this;
    }

    /* renamed from: e0 */
    public d k0(long j) {
        if (j == 0) {
            a0(48);
        } else {
            long j2 = (j >>> 1) | j;
            long j3 = j2 | (j2 >>> 2);
            long j4 = j3 | (j3 >>> 4);
            long j5 = j4 | (j4 >>> 8);
            long j6 = j5 | (j5 >>> 16);
            long j7 = j6 | (j6 >>> 32);
            long j8 = j7 - ((j7 >>> 1) & 6148914691236517205L);
            long j9 = ((j8 >>> 2) & 3689348814741910323L) + (j8 & 3689348814741910323L);
            long j10 = ((j9 >>> 4) + j9) & 1085102592571150095L;
            long j11 = j10 + (j10 >>> 8);
            long j12 = j11 + (j11 >>> 16);
            int i = (int) ((((j12 & 63) + ((j12 >>> 32) & 63)) + ((long) 3)) / ((long) 4));
            v M = M(i);
            byte[] bArr = M.a;
            int i2 = M.c;
            for (int i3 = (i2 + i) - 1; i3 >= i2; i3--) {
                bArr[i3] = qh.c0.a.a[(int) (15 & j)];
                j >>>= 4;
            }
            M.c += i;
            this.b += (long) i;
        }
        return this;
    }

    /* JADX WARNING: type inference failed for: r21v0, types: [java.lang.Object] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r21) {
        /*
            r20 = this;
            r0 = r20
            r1 = r21
            r2 = 0
            r3 = 1
            if (r0 != r1) goto L_0x000b
        L_0x0008:
            r2 = r3
            goto L_0x0078
        L_0x000b:
            boolean r4 = r1 instanceof qh.d
            if (r4 != 0) goto L_0x0011
            goto L_0x0078
        L_0x0011:
            long r4 = r0.b
            qh.d r1 = (qh.d) r1
            long r6 = r1.b
            int r6 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r6 == 0) goto L_0x001c
            goto L_0x0078
        L_0x001c:
            r6 = 0
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 != 0) goto L_0x0023
            goto L_0x0008
        L_0x0023:
            qh.v r4 = r0.a
            ka.h.c.p.c(r4)
            qh.v r1 = r1.a
            ka.h.c.p.c(r1)
            int r5 = r4.b
            int r8 = r1.b
            r9 = r6
        L_0x0032:
            long r11 = r0.b
            int r11 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r11 >= 0) goto L_0x0008
            int r11 = r4.c
            int r11 = r11 - r5
            int r12 = r1.c
            int r12 = r12 - r8
            int r11 = java.lang.Math.min(r11, r12)
            long r11 = (long) r11
            r13 = r6
        L_0x0044:
            int r15 = (r13 > r11 ? 1 : (r13 == r11 ? 0 : -1))
            if (r15 >= 0) goto L_0x0060
            byte[] r15 = r4.a
            int r16 = r5 + 1
            byte r5 = r15[r5]
            byte[] r15 = r1.a
            int r17 = r8 + 1
            byte r8 = r15[r8]
            if (r5 == r8) goto L_0x0057
            goto L_0x0078
        L_0x0057:
            r18 = 1
            long r13 = r13 + r18
            r5 = r16
            r8 = r17
            goto L_0x0044
        L_0x0060:
            int r13 = r4.c
            if (r5 != r13) goto L_0x006b
            qh.v r4 = r4.f
            ka.h.c.p.c(r4)
            int r5 = r4.b
        L_0x006b:
            int r13 = r1.c
            if (r8 != r13) goto L_0x0076
            qh.v r1 = r1.f
            ka.h.c.p.c(r1)
            int r8 = r1.b
        L_0x0076:
            long r9 = r9 + r11
            goto L_0x0032
        L_0x0078:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: qh.d.equals(java.lang.Object):boolean");
    }

    public boolean f(long j) {
        return this.b >= j;
    }

    public String f0(Charset charset) {
        p.e(charset, "charset");
        return t(this.b, charset);
    }

    public void flush() {
    }

    public long g(byte b2, long j, long j2) {
        v vVar;
        long j3 = 0;
        if (0 <= j && j2 >= j) {
            long j4 = this.b;
            if (j2 > j4) {
                j2 = j4;
            }
            if (!(j == j2 || (vVar = this.a) == null)) {
                long j5 = this.b;
                if (j5 - j < j) {
                    while (j5 > j) {
                        vVar = vVar.g;
                        p.c(vVar);
                        j5 -= (long) (vVar.c - vVar.b);
                    }
                    while (j5 < j2) {
                        byte[] bArr = vVar.a;
                        int min = (int) Math.min((long) vVar.c, (((long) vVar.b) + j2) - j5);
                        for (int i = (int) ((((long) vVar.b) + j) - j5); i < min; i++) {
                            if (bArr[i] == b2) {
                                return ((long) (i - vVar.b)) + j5;
                            }
                        }
                        j5 += (long) (vVar.c - vVar.b);
                        vVar = vVar.f;
                        p.c(vVar);
                        j = j5;
                    }
                } else {
                    while (true) {
                        long j6 = ((long) (vVar.c - vVar.b)) + j3;
                        if (j6 > j) {
                            break;
                        }
                        vVar = vVar.f;
                        p.c(vVar);
                        j3 = j6;
                    }
                    while (j3 < j2) {
                        byte[] bArr2 = vVar.a;
                        int min2 = (int) Math.min((long) vVar.c, (((long) vVar.b) + j2) - j3);
                        for (int i2 = (int) ((((long) vVar.b) + j) - j3); i2 < min2; i2++) {
                            if (bArr2[i2] == b2) {
                                return ((long) (i2 - vVar.b)) + j3;
                            }
                        }
                        j3 += (long) (vVar.c - vVar.b);
                        vVar = vVar.f;
                        p.c(vVar);
                        j = j3;
                    }
                }
            }
            return -1;
        }
        StringBuilder V0 = e.e.b.a.a.V0("size=");
        V0.append(this.b);
        V0.append(" fromIndex=");
        V0.append(j);
        V0.append(" toIndex=");
        V0.append(j2);
        throw new IllegalArgumentException(V0.toString().toString());
    }

    public d g0(int i) {
        v M = M(4);
        byte[] bArr = M.a;
        int i2 = M.c;
        int i3 = i2 + 1;
        bArr[i2] = (byte) ((i >>> 24) & 255);
        int i4 = i3 + 1;
        bArr[i3] = (byte) ((i >>> 16) & 255);
        int i5 = i4 + 1;
        bArr[i4] = (byte) ((i >>> 8) & 255);
        bArr[i5] = (byte) (i & 255);
        M.c = i5 + 1;
        this.b += 4;
        return this;
    }

    public d getBuffer() {
        return this;
    }

    public long h(h hVar, long j) throws IOException {
        long j2 = j;
        p.e(hVar, "bytes");
        if (hVar.j() > 0) {
            long j3 = 0;
            if (j2 >= 0) {
                v vVar = this.a;
                if (vVar != null) {
                    long j4 = this.b;
                    if (j4 - j2 < j2) {
                        while (j4 > j2) {
                            vVar = vVar.g;
                            p.c(vVar);
                            j4 -= (long) (vVar.c - vVar.b);
                        }
                        byte[] H = hVar.H();
                        byte b2 = H[0];
                        int j5 = hVar.j();
                        long j6 = (this.b - ((long) j5)) + 1;
                        long j7 = j4;
                        while (j7 < j6) {
                            byte[] bArr = vVar.a;
                            long j8 = j6;
                            int min = (int) Math.min((long) vVar.c, (((long) vVar.b) + j6) - j7);
                            for (int i = (int) ((((long) vVar.b) + j2) - j7); i < min; i++) {
                                if (bArr[i] == b2 && qh.c0.a.b(vVar, i + 1, H, 1, j5)) {
                                    return ((long) (i - vVar.b)) + j7;
                                }
                            }
                            j7 += (long) (vVar.c - vVar.b);
                            vVar = vVar.f;
                            p.c(vVar);
                            j2 = j7;
                            j6 = j8;
                        }
                    } else {
                        while (true) {
                            long j9 = ((long) (vVar.c - vVar.b)) + j3;
                            if (j9 > j2) {
                                break;
                            }
                            vVar = vVar.f;
                            p.c(vVar);
                            j3 = j9;
                        }
                        byte[] H2 = hVar.H();
                        byte b3 = H2[0];
                        int j10 = hVar.j();
                        long j11 = (this.b - ((long) j10)) + 1;
                        while (j3 < j11) {
                            byte[] bArr2 = vVar.a;
                            long j12 = j11;
                            int min2 = (int) Math.min((long) vVar.c, (((long) vVar.b) + j11) - j3);
                            for (int i2 = (int) ((((long) vVar.b) + j2) - j3); i2 < min2; i2++) {
                                if (bArr2[i2] == b3 && qh.c0.a.b(vVar, i2 + 1, H2, 1, j10)) {
                                    return ((long) (i2 - vVar.b)) + j3;
                                }
                            }
                            j3 += (long) (vVar.c - vVar.b);
                            vVar = vVar.f;
                            p.c(vVar);
                            j2 = j3;
                            j11 = j12;
                        }
                    }
                }
                return -1;
            }
            throw new IllegalArgumentException(e.e.b.a.a.s("fromIndex < 0: ", j2).toString());
        }
        throw new IllegalArgumentException("bytes is empty".toString());
    }

    public d h0(long j) {
        v M = M(8);
        byte[] bArr = M.a;
        int i = M.c;
        int i2 = i + 1;
        bArr[i] = (byte) ((int) ((j >>> 56) & 255));
        int i3 = i2 + 1;
        bArr[i2] = (byte) ((int) ((j >>> 48) & 255));
        int i4 = i3 + 1;
        bArr[i3] = (byte) ((int) ((j >>> 40) & 255));
        int i5 = i4 + 1;
        bArr[i4] = (byte) ((int) ((j >>> 32) & 255));
        int i6 = i5 + 1;
        bArr[i5] = (byte) ((int) ((j >>> 24) & 255));
        int i7 = i6 + 1;
        bArr[i6] = (byte) ((int) ((j >>> 16) & 255));
        int i8 = i7 + 1;
        bArr[i7] = (byte) ((int) ((j >>> 8) & 255));
        bArr[i8] = (byte) ((int) (j & 255));
        M.c = i8 + 1;
        this.b += 8;
        return this;
    }

    public int hashCode() {
        v vVar = this.a;
        if (vVar == null) {
            return 0;
        }
        int i = 1;
        do {
            int i2 = vVar.c;
            for (int i3 = vVar.b; i3 < i2; i3++) {
                i = (i * 31) + vVar.a[i3];
            }
            vVar = vVar.f;
            p.c(vVar);
        } while (vVar != this.a);
        return i;
    }

    public long i(h hVar, long j) {
        int i;
        int i2;
        int i3;
        int i4;
        p.e(hVar, "targetBytes");
        long j2 = 0;
        if (j >= 0) {
            v vVar = this.a;
            if (vVar == null) {
                return -1;
            }
            long j3 = this.b;
            if (j3 - j < j) {
                while (j3 > j) {
                    vVar = vVar.g;
                    p.c(vVar);
                    j3 -= (long) (vVar.c - vVar.b);
                }
                if (hVar.j() == 2) {
                    byte J = hVar.J(0);
                    byte J2 = hVar.J(1);
                    while (j3 < this.b) {
                        byte[] bArr = vVar.a;
                        i3 = (int) ((((long) vVar.b) + j) - j3);
                        int i5 = vVar.c;
                        while (i3 < i5) {
                            byte b2 = bArr[i3];
                            if (b2 == J || b2 == J2) {
                                i4 = vVar.b;
                            } else {
                                i3++;
                            }
                        }
                        j3 += (long) (vVar.c - vVar.b);
                        vVar = vVar.f;
                        p.c(vVar);
                        j = j3;
                    }
                    return -1;
                }
                byte[] H = hVar.H();
                while (j3 < this.b) {
                    byte[] bArr2 = vVar.a;
                    int i6 = (int) ((((long) vVar.b) + j) - j3);
                    int i7 = vVar.c;
                    while (i3 < i7) {
                        byte b3 = bArr2[i3];
                        int length = H.length;
                        int i8 = 0;
                        while (i8 < length) {
                            if (b3 == H[i8]) {
                                i4 = vVar.b;
                            } else {
                                i8++;
                            }
                        }
                        i6 = i3 + 1;
                    }
                    j3 += (long) (vVar.c - vVar.b);
                    vVar = vVar.f;
                    p.c(vVar);
                    j = j3;
                }
                return -1;
                return ((long) (i3 - i4)) + j3;
            }
            while (true) {
                long j4 = ((long) (vVar.c - vVar.b)) + j2;
                if (j4 > j) {
                    break;
                }
                vVar = vVar.f;
                p.c(vVar);
                j2 = j4;
            }
            if (hVar.j() == 2) {
                byte J3 = hVar.J(0);
                byte J4 = hVar.J(1);
                while (j2 < this.b) {
                    byte[] bArr3 = vVar.a;
                    i = (int) ((((long) vVar.b) + j) - j2);
                    int i9 = vVar.c;
                    while (i < i9) {
                        byte b4 = bArr3[i];
                        if (b4 == J3 || b4 == J4) {
                            i2 = vVar.b;
                        } else {
                            i++;
                        }
                    }
                    j2 += (long) (vVar.c - vVar.b);
                    vVar = vVar.f;
                    p.c(vVar);
                    j = j2;
                }
                return -1;
            }
            byte[] H2 = hVar.H();
            while (j2 < this.b) {
                byte[] bArr4 = vVar.a;
                int i10 = (int) ((((long) vVar.b) + j) - j2);
                int i11 = vVar.c;
                while (i < i11) {
                    byte b5 = bArr4[i];
                    int length2 = H2.length;
                    int i12 = 0;
                    while (i12 < length2) {
                        if (b5 == H2[i12]) {
                            i2 = vVar.b;
                        } else {
                            i12++;
                        }
                    }
                    i10 = i + 1;
                }
                j2 += (long) (vVar.c - vVar.b);
                vVar = vVar.f;
                p.c(vVar);
                j = j2;
            }
            return -1;
            return ((long) (i - i2)) + j2;
        }
        throw new IllegalArgumentException(e.e.b.a.a.s("fromIndex < 0: ", j).toString());
    }

    public d i0(int i) {
        v M = M(2);
        byte[] bArr = M.a;
        int i2 = M.c;
        int i3 = i2 + 1;
        bArr[i2] = (byte) ((i >>> 8) & 255);
        bArr[i3] = (byte) (i & 255);
        M.c = i3 + 1;
        this.b += 2;
        return this;
    }

    public boolean isOpen() {
        return true;
    }

    public final a j(a aVar) {
        p.e(aVar, "unsafeCursor");
        qh.c0.a.a(this, aVar);
        return aVar;
    }

    public d j0(String str, int i, int i2, Charset charset) {
        p.e(str, "string");
        p.e(charset, "charset");
        boolean z = true;
        if (i >= 0) {
            if (i2 >= i) {
                if (i2 > str.length()) {
                    z = false;
                }
                if (!z) {
                    StringBuilder Z0 = e.e.b.a.a.Z0("endIndex > string.length: ", i2, " > ");
                    Z0.append(str.length());
                    throw new IllegalArgumentException(Z0.toString().toString());
                } else if (p.b(charset, ka.m.a.a)) {
                    n0(str, i, i2);
                    return this;
                } else {
                    String substring = str.substring(i, i2);
                    p.d(substring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                    byte[] bytes = substring.getBytes(charset);
                    p.d(bytes, "(this as java.lang.String).getBytes(charset)");
                    W(bytes, 0, bytes.length);
                    return this;
                }
            } else {
                throw new IllegalArgumentException(e.e.b.a.a.q("endIndex < beginIndex: ", i2, " < ", i).toString());
            }
        } else {
            throw new IllegalArgumentException(e.e.b.a.a.m("beginIndex < 0: ", i).toString());
        }
    }

    public long l(h hVar) throws IOException {
        p.e(hVar, "bytes");
        return h(hVar, 0);
    }

    public d l0(String str) {
        p.e(str, "string");
        n0(str, 0, str.length());
        return this;
    }

    public /* bridge */ /* synthetic */ f m(int i) {
        i0(i);
        return this;
    }

    public h m0() {
        return U(this.b);
    }

    public /* bridge */ /* synthetic */ f n(int i) {
        a0(i);
        return this;
    }

    public d n0(String str, int i, int i2) {
        char charAt;
        p.e(str, "string");
        if (i >= 0) {
            if (i2 >= i) {
                if (i2 <= str.length()) {
                    while (i < i2) {
                        char charAt2 = str.charAt(i);
                        if (charAt2 < 128) {
                            v M = M(1);
                            byte[] bArr = M.a;
                            int i3 = M.c - i;
                            int min = Math.min(i2, 8192 - i3);
                            int i4 = i + 1;
                            bArr[i + i3] = (byte) charAt2;
                            while (true) {
                                i = i4;
                                if (i >= min || (charAt = str.charAt(i)) >= 128) {
                                    int i5 = M.c;
                                    int i6 = (i3 + i) - i5;
                                    M.c = i5 + i6;
                                    this.b += (long) i6;
                                } else {
                                    i4 = i + 1;
                                    bArr[i + i3] = (byte) charAt;
                                }
                            }
                            int i52 = M.c;
                            int i62 = (i3 + i) - i52;
                            M.c = i52 + i62;
                            this.b += (long) i62;
                        } else {
                            if (charAt2 < 2048) {
                                v M2 = M(2);
                                byte[] bArr2 = M2.a;
                                int i7 = M2.c;
                                bArr2[i7] = (byte) ((charAt2 >> 6) | 192);
                                bArr2[i7 + 1] = (byte) ((charAt2 & '?') | 128);
                                M2.c = i7 + 2;
                                this.b += 2;
                            } else if (charAt2 < 55296 || charAt2 > 57343) {
                                v M3 = M(3);
                                byte[] bArr3 = M3.a;
                                int i8 = M3.c;
                                bArr3[i8] = (byte) ((charAt2 >> 12) | 224);
                                bArr3[i8 + 1] = (byte) ((63 & (charAt2 >> 6)) | 128);
                                bArr3[i8 + 2] = (byte) ((charAt2 & '?') | 128);
                                M3.c = i8 + 3;
                                this.b += 3;
                            } else {
                                int i9 = i + 1;
                                char charAt3 = i9 < i2 ? str.charAt(i9) : 0;
                                if (charAt2 > 56319 || 56320 > charAt3 || 57343 < charAt3) {
                                    a0(63);
                                    i = i9;
                                } else {
                                    int i10 = (((charAt2 & 1023) << 10) | (charAt3 & 1023)) + b.TIMEOUT_WRITE_SIZE;
                                    v M4 = M(4);
                                    byte[] bArr4 = M4.a;
                                    int i11 = M4.c;
                                    bArr4[i11] = (byte) ((i10 >> 18) | 240);
                                    bArr4[i11 + 1] = (byte) (((i10 >> 12) & 63) | 128);
                                    bArr4[i11 + 2] = (byte) (((i10 >> 6) & 63) | 128);
                                    bArr4[i11 + 3] = (byte) ((i10 & 63) | 128);
                                    M4.c = i11 + 4;
                                    this.b += 4;
                                    i += 2;
                                }
                            }
                            i++;
                        }
                    }
                    return this;
                }
                StringBuilder Z0 = e.e.b.a.a.Z0("endIndex > string.length: ", i2, " > ");
                Z0.append(str.length());
                throw new IllegalArgumentException(Z0.toString().toString());
            }
            throw new IllegalArgumentException(e.e.b.a.a.q("endIndex < beginIndex: ", i2, " < ", i).toString());
        }
        throw new IllegalArgumentException(e.e.b.a.a.m("beginIndex < 0: ", i).toString());
    }

    public void o(d dVar, long j) throws EOFException {
        p.e(dVar, "sink");
        long j2 = this.b;
        if (j2 >= j) {
            dVar.write(this, j);
        } else {
            dVar.write(this, j2);
            throw new EOFException();
        }
    }

    public long p(h hVar) {
        p.e(hVar, "targetBytes");
        return i(hVar, 0);
    }

    public /* bridge */ /* synthetic */ f p0(h hVar) {
        N(hVar);
        return this;
    }

    public g peek() {
        return q.J(new s(this));
    }

    public String q(long j) throws EOFException {
        if (j >= 0) {
            long j2 = Long.MAX_VALUE;
            if (j != Long.MAX_VALUE) {
                j2 = j + 1;
            }
            byte b2 = (byte) 10;
            long g = g(b2, 0, j2);
            if (g != -1) {
                return qh.c0.a.c(this, g);
            }
            if (j2 < this.b && d(j2 - 1) == ((byte) 13) && d(j2) == b2) {
                return qh.c0.a.c(this, j2);
            }
            d dVar = new d();
            c(dVar, 0, Math.min((long) 32, this.b));
            StringBuilder V0 = e.e.b.a.a.V0("\\n not found: limit=");
            V0.append(Math.min(this.b, j));
            V0.append(" content=");
            V0.append(dVar.m0().r());
            V0.append(8230);
            throw new EOFException(V0.toString());
        }
        throw new IllegalArgumentException(e.e.b.a.a.s("limit < 0: ", j).toString());
    }

    public final d r(InputStream inputStream) throws IOException {
        v M;
        p.e(inputStream, "input");
        long j = Long.MAX_VALUE;
        while (true) {
            int i = (j > 0 ? 1 : (j == 0 ? 0 : -1));
            M = M(1);
            int read = inputStream.read(M.a, M.c, (int) Math.min(j, (long) (8192 - M.c)));
            if (read == -1) {
                break;
            }
            M.c += read;
            long j2 = (long) read;
            this.b += j2;
            j -= j2;
        }
        if (M.b == M.c) {
            this.a = M.a();
            w.a(M);
        }
        return this;
    }

    public long r0(y yVar) throws IOException {
        p.e(yVar, "sink");
        long j = this.b;
        if (j > 0) {
            yVar.write(this, j);
        }
        return j;
    }

    public long read(d dVar, long j) {
        p.e(dVar, "sink");
        if (j >= 0) {
            long j2 = this.b;
            if (j2 == 0) {
                return -1;
            }
            if (j > j2) {
                j = j2;
            }
            dVar.write(this, j);
            return j;
        }
        throw new IllegalArgumentException(e.e.b.a.a.s("byteCount < 0: ", j).toString());
    }

    public byte readByte() throws EOFException {
        if (this.b != 0) {
            v vVar = this.a;
            p.c(vVar);
            int i = vVar.b;
            int i2 = vVar.c;
            int i3 = i + 1;
            byte b2 = vVar.a[i];
            this.b--;
            if (i3 == i2) {
                this.a = vVar.a();
                w.a(vVar);
            } else {
                vVar.b = i3;
            }
            return b2;
        }
        throw new EOFException();
    }

    public void readFully(byte[] bArr) throws EOFException {
        p.e(bArr, "sink");
        int i = 0;
        while (i < bArr.length) {
            int read = read(bArr, i, bArr.length - i);
            if (read != -1) {
                i += read;
            } else {
                throw new EOFException();
            }
        }
    }

    public int readInt() throws EOFException {
        if (this.b >= 4) {
            v vVar = this.a;
            p.c(vVar);
            int i = vVar.b;
            int i2 = vVar.c;
            if (((long) (i2 - i)) < 4) {
                return ((readByte() & 255) << 24) | ((readByte() & 255) << 16) | ((readByte() & 255) << 8) | (readByte() & 255);
            }
            byte[] bArr = vVar.a;
            int i3 = i + 1;
            int i4 = i3 + 1;
            byte b2 = ((bArr[i] & 255) << 24) | ((bArr[i3] & 255) << 16);
            int i5 = i4 + 1;
            byte b3 = b2 | ((bArr[i4] & 255) << 8);
            int i6 = i5 + 1;
            byte b4 = b3 | (bArr[i5] & 255);
            this.b -= 4;
            if (i6 == i2) {
                this.a = vVar.a();
                w.a(vVar);
            } else {
                vVar.b = i6;
            }
            return b4;
        }
        throw new EOFException();
    }

    public long readLong() throws EOFException {
        if (this.b >= 8) {
            v vVar = this.a;
            p.c(vVar);
            int i = vVar.b;
            int i2 = vVar.c;
            if (((long) (i2 - i)) < 8) {
                return ((((long) readInt()) & 4294967295L) << 32) | (4294967295L & ((long) readInt()));
            }
            byte[] bArr = vVar.a;
            int i3 = i + 1;
            int i4 = i3 + 1;
            int i5 = i4 + 1;
            int i6 = i5 + 1;
            int i7 = i6 + 1;
            int i8 = i7 + 1;
            long j = ((((long) bArr[i]) & 255) << 56) | ((((long) bArr[i3]) & 255) << 48) | ((((long) bArr[i4]) & 255) << 40) | ((((long) bArr[i5]) & 255) << 32) | ((((long) bArr[i6]) & 255) << 24) | ((((long) bArr[i7]) & 255) << 16);
            int i9 = i8 + 1;
            int i10 = i9 + 1;
            long j2 = j | ((((long) bArr[i8]) & 255) << 8) | (((long) bArr[i9]) & 255);
            this.b -= 8;
            if (i10 == i2) {
                this.a = vVar.a();
                w.a(vVar);
            } else {
                vVar.b = i10;
            }
            return j2;
        }
        throw new EOFException();
    }

    public short readShort() throws EOFException {
        if (this.b >= 2) {
            v vVar = this.a;
            p.c(vVar);
            int i = vVar.b;
            int i2 = vVar.c;
            if (i2 - i < 2) {
                return (short) (((readByte() & 255) << 8) | (readByte() & 255));
            }
            byte[] bArr = vVar.a;
            int i3 = i + 1;
            int i4 = i3 + 1;
            byte b2 = ((bArr[i] & 255) << 8) | (bArr[i3] & 255);
            this.b -= 2;
            if (i4 == i2) {
                this.a = vVar.a();
                w.a(vVar);
            } else {
                vVar.b = i4;
            }
            return (short) b2;
        }
        throw new EOFException();
    }

    public short s() throws EOFException {
        short readShort = readShort() & 65535;
        return (short) (((readShort & 255) << 8) | ((65280 & readShort) >>> 8));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:28:0x008d, code lost:
        if (r8 != r9) goto L_0x0099;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x008f, code lost:
        r14.a = r6.a();
        qh.w.a(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0099, code lost:
        r6.b = r8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x009b, code lost:
        if (r1 != false) goto L_0x00a1;
     */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x0076 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public long s0() throws java.io.EOFException {
        /*
            r14 = this;
            long r0 = r14.b
            r2 = 0
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 == 0) goto L_0x00a8
            r0 = 0
            r1 = r0
            r4 = r2
        L_0x000b:
            qh.v r6 = r14.a
            ka.h.c.p.c(r6)
            byte[] r7 = r6.a
            int r8 = r6.b
            int r9 = r6.c
        L_0x0016:
            if (r8 >= r9) goto L_0x008d
            byte r10 = r7[r8]
            r11 = 48
            byte r11 = (byte) r11
            if (r10 < r11) goto L_0x0027
            r12 = 57
            byte r12 = (byte) r12
            if (r10 > r12) goto L_0x0027
            int r11 = r10 - r11
            goto L_0x0040
        L_0x0027:
            r11 = 97
            byte r11 = (byte) r11
            if (r10 < r11) goto L_0x0032
            r12 = 102(0x66, float:1.43E-43)
            byte r12 = (byte) r12
            if (r10 > r12) goto L_0x0032
            goto L_0x003c
        L_0x0032:
            r11 = 65
            byte r11 = (byte) r11
            if (r10 < r11) goto L_0x0072
            r12 = 70
            byte r12 = (byte) r12
            if (r10 > r12) goto L_0x0072
        L_0x003c:
            int r11 = r10 - r11
            int r11 = r11 + 10
        L_0x0040:
            r12 = -1152921504606846976(0xf000000000000000, double:-3.105036184601418E231)
            long r12 = r12 & r4
            int r12 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r12 != 0) goto L_0x0050
            r10 = 4
            long r4 = r4 << r10
            long r10 = (long) r11
            long r4 = r4 | r10
            int r8 = r8 + 1
            int r0 = r0 + 1
            goto L_0x0016
        L_0x0050:
            qh.d r0 = new qh.d
            r0.<init>()
            r0.k0(r4)
            r0.a0(r10)
            java.lang.NumberFormatException r1 = new java.lang.NumberFormatException
            java.lang.String r2 = "Number too large: "
            java.lang.StringBuilder r2 = e.e.b.a.a.V0(r2)
            java.lang.String r0 = r0.v()
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            r1.<init>(r0)
            throw r1
        L_0x0072:
            if (r0 == 0) goto L_0x0076
            r1 = 1
            goto L_0x008d
        L_0x0076:
            java.lang.NumberFormatException r0 = new java.lang.NumberFormatException
            java.lang.String r1 = "Expected leading [0-9a-fA-F] character but was 0x"
            java.lang.StringBuilder r1 = e.e.b.a.a.V0(r1)
            java.lang.String r2 = ka.b.q.G3(r10)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x008d:
            if (r8 != r9) goto L_0x0099
            qh.v r7 = r6.a()
            r14.a = r7
            qh.w.a(r6)
            goto L_0x009b
        L_0x0099:
            r6.b = r8
        L_0x009b:
            if (r1 != 0) goto L_0x00a1
            qh.v r6 = r14.a
            if (r6 != 0) goto L_0x000b
        L_0x00a1:
            long r1 = r14.b
            long r6 = (long) r0
            long r1 = r1 - r6
            r14.b = r1
            return r4
        L_0x00a8:
            java.io.EOFException r0 = new java.io.EOFException
            r0.<init>()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: qh.d.s0():long");
    }

    public void skip(long j) throws EOFException {
        while (j > 0) {
            v vVar = this.a;
            if (vVar != null) {
                int min = (int) Math.min(j, (long) (vVar.c - vVar.b));
                long j2 = (long) min;
                this.b -= j2;
                j -= j2;
                int i = vVar.b + min;
                vVar.b = i;
                if (i == vVar.c) {
                    this.a = vVar.a();
                    w.a(vVar);
                }
            } else {
                throw new EOFException();
            }
        }
    }

    public String t(long j, Charset charset) throws EOFException {
        p.e(charset, "charset");
        int i = (j > 0 ? 1 : (j == 0 ? 0 : -1));
        if (!(i >= 0 && j <= ((long) Integer.MAX_VALUE))) {
            throw new IllegalArgumentException(e.e.b.a.a.s("byteCount: ", j).toString());
        } else if (this.b < j) {
            throw new EOFException();
        } else if (i == 0) {
            return "";
        } else {
            v vVar = this.a;
            p.c(vVar);
            int i2 = vVar.b;
            if (((long) i2) + j > ((long) vVar.c)) {
                return new String(I(j), charset);
            }
            int i3 = (int) j;
            String str = new String(vVar.a, i2, i3, charset);
            int i4 = vVar.b + i3;
            vVar.b = i4;
            this.b -= j;
            if (i4 == vVar.c) {
                this.a = vVar.a();
                w.a(vVar);
            }
            return str;
        }
    }

    public InputStream t0() {
        return new b(this);
    }

    public b0 timeout() {
        return b0.NONE;
    }

    public String toString() {
        if (this.b <= ((long) Integer.MAX_VALUE)) {
            return K((int) this.b).toString();
        }
        StringBuilder V0 = e.e.b.a.a.V0("size > Int.MAX_VALUE: ");
        V0.append(this.b);
        throw new IllegalStateException(V0.toString().toString());
    }

    public boolean u(long j, h hVar) {
        p.e(hVar, "bytes");
        int j2 = hVar.j();
        p.e(hVar, "bytes");
        if (j < 0 || j2 < 0 || this.b - j < ((long) j2) || hVar.j() - 0 < j2) {
            return false;
        }
        for (int i = 0; i < j2; i++) {
            if (d(((long) i) + j) != hVar.J(0 + i)) {
                return false;
            }
        }
        return true;
    }

    public int u0(q qVar) {
        p.e(qVar, "options");
        int d = qh.c0.a.d(this, qVar, false);
        if (d == -1) {
            return -1;
        }
        skip((long) qVar.a[d].j());
        return d;
    }

    public String v() {
        return t(this.b, ka.m.a.a);
    }

    public d v0(int i) {
        String str;
        if (i < 128) {
            a0(i);
        } else if (i < 2048) {
            v M = M(2);
            byte[] bArr = M.a;
            int i2 = M.c;
            bArr[i2] = (byte) ((i >> 6) | 192);
            bArr[i2 + 1] = (byte) ((i & 63) | 128);
            M.c = i2 + 2;
            this.b += 2;
        } else if (55296 <= i && 57343 >= i) {
            a0(63);
        } else if (i < 65536) {
            v M2 = M(3);
            byte[] bArr2 = M2.a;
            int i3 = M2.c;
            bArr2[i3] = (byte) ((i >> 12) | 224);
            bArr2[i3 + 1] = (byte) (((i >> 6) & 63) | 128);
            bArr2[i3 + 2] = (byte) ((i & 63) | 128);
            M2.c = i3 + 3;
            this.b += 3;
        } else if (i <= 1114111) {
            v M3 = M(4);
            byte[] bArr3 = M3.a;
            int i4 = M3.c;
            bArr3[i4] = (byte) ((i >> 18) | 240);
            bArr3[i4 + 1] = (byte) (((i >> 12) & 63) | 128);
            bArr3[i4 + 2] = (byte) (((i >> 6) & 63) | 128);
            bArr3[i4 + 3] = (byte) ((i & 63) | 128);
            M3.c = i4 + 4;
            this.b += 4;
        } else {
            StringBuilder V0 = e.e.b.a.a.V0("Unexpected code point: 0x");
            if (i != 0) {
                char[] cArr = qh.c0.b.a;
                int i5 = 0;
                char[] cArr2 = {cArr[(i >> 28) & 15], cArr[(i >> 24) & 15], cArr[(i >> 20) & 15], cArr[(i >> 16) & 15], cArr[(i >> 12) & 15], cArr[(i >> 8) & 15], cArr[(i >> 4) & 15], cArr[i & 15]};
                while (i5 < 8 && cArr2[i5] == '0') {
                    i5++;
                }
                str = new String(cArr2, i5, 8 - i5);
            } else {
                str = "0";
            }
            V0.append(str);
            throw new IllegalArgumentException(V0.toString());
        }
        return this;
    }

    public /* bridge */ /* synthetic */ f write(byte[] bArr, int i, int i2) {
        W(bArr, i, i2);
        return this;
    }

    public f y() {
        return this;
    }

    public void write(d dVar, long j) {
        int i;
        v vVar;
        v vVar2;
        p.e(dVar, "source");
        if (dVar != this) {
            q.Z(dVar.b, 0, j);
            while (j > 0) {
                v vVar3 = dVar.a;
                p.c(vVar3);
                int i2 = vVar3.c;
                v vVar4 = dVar.a;
                p.c(vVar4);
                if (j < ((long) (i2 - vVar4.b))) {
                    v vVar5 = this.a;
                    if (vVar5 != null) {
                        p.c(vVar5);
                        vVar = vVar5.g;
                    } else {
                        vVar = null;
                    }
                    if (vVar != null && vVar.f120e) {
                        if ((((long) vVar.c) + j) - ((long) (vVar.d ? 0 : vVar.b)) <= ((long) 8192)) {
                            v vVar6 = dVar.a;
                            p.c(vVar6);
                            vVar6.d(vVar, (int) j);
                            dVar.b -= j;
                            this.b += j;
                            return;
                        }
                    }
                    v vVar7 = dVar.a;
                    p.c(vVar7);
                    int i3 = (int) j;
                    if (i3 > 0 && i3 <= vVar7.c - vVar7.b) {
                        if (i3 >= 1024) {
                            vVar2 = vVar7.c();
                        } else {
                            vVar2 = w.b();
                            byte[] bArr = vVar7.a;
                            byte[] bArr2 = vVar2.a;
                            int i4 = vVar7.b;
                            k.g(bArr, bArr2, 0, i4, i4 + i3, 2);
                        }
                        vVar2.c = vVar2.b + i3;
                        vVar7.b += i3;
                        v vVar8 = vVar7.g;
                        p.c(vVar8);
                        vVar8.b(vVar2);
                        dVar.a = vVar2;
                    } else {
                        throw new IllegalArgumentException("byteCount out of range".toString());
                    }
                }
                v vVar9 = dVar.a;
                p.c(vVar9);
                long j2 = (long) (vVar9.c - vVar9.b);
                dVar.a = vVar9.a();
                v vVar10 = this.a;
                if (vVar10 == null) {
                    this.a = vVar9;
                    vVar9.g = vVar9;
                    vVar9.f = vVar9;
                } else {
                    p.c(vVar10);
                    v vVar11 = vVar10.g;
                    p.c(vVar11);
                    vVar11.b(vVar9);
                    if (vVar9.g != vVar9) {
                        v vVar12 = vVar9.g;
                        p.c(vVar12);
                        if (vVar12.f120e) {
                            int i5 = vVar9.c - vVar9.b;
                            v vVar13 = vVar9.g;
                            p.c(vVar13);
                            int i6 = 8192 - vVar13.c;
                            v vVar14 = vVar9.g;
                            p.c(vVar14);
                            if (vVar14.d) {
                                i = 0;
                            } else {
                                v vVar15 = vVar9.g;
                                p.c(vVar15);
                                i = vVar15.b;
                            }
                            if (i5 <= i6 + i) {
                                v vVar16 = vVar9.g;
                                p.c(vVar16);
                                vVar9.d(vVar16, i5);
                                vVar9.a();
                                w.a(vVar9);
                            }
                        }
                    } else {
                        throw new IllegalStateException("cannot compact".toString());
                    }
                }
                dVar.b -= j2;
                this.b += j2;
                j -= j2;
            }
            return;
        }
        throw new IllegalArgumentException("source == this".toString());
    }

    public static final class b extends InputStream {
        public final /* synthetic */ d a;

        public b(d dVar) {
            this.a = dVar;
        }

        public int available() {
            return (int) Math.min(this.a.b, (long) Integer.MAX_VALUE);
        }

        public void close() {
        }

        public int read() {
            d dVar = this.a;
            if (dVar.b > 0) {
                return dVar.readByte() & 255;
            }
            return -1;
        }

        public String toString() {
            return this.a + ".inputStream()";
        }

        public int read(byte[] bArr, int i, int i2) {
            p.e(bArr, "sink");
            return this.a.read(bArr, i, i2);
        }
    }

    public int read(ByteBuffer byteBuffer) throws IOException {
        p.e(byteBuffer, "sink");
        v vVar = this.a;
        if (vVar == null) {
            return -1;
        }
        int min = Math.min(byteBuffer.remaining(), vVar.c - vVar.b);
        byteBuffer.put(vVar.a, vVar.b, min);
        int i = vVar.b + min;
        vVar.b = i;
        this.b -= (long) min;
        if (i == vVar.c) {
            this.a = vVar.a();
            w.a(vVar);
        }
        return min;
    }

    public int read(byte[] bArr, int i, int i2) {
        p.e(bArr, "sink");
        q.Z((long) bArr.length, (long) i, (long) i2);
        v vVar = this.a;
        if (vVar == null) {
            return -1;
        }
        int min = Math.min(i2, vVar.c - vVar.b);
        byte[] bArr2 = vVar.a;
        int i3 = vVar.b;
        k.e(bArr2, bArr, i, i3, i3 + min);
        int i4 = vVar.b + min;
        vVar.b = i4;
        this.b -= (long) min;
        if (i4 != vVar.c) {
            return min;
        }
        this.a = vVar.a();
        w.a(vVar);
        return min;
    }

    public int write(ByteBuffer byteBuffer) throws IOException {
        p.e(byteBuffer, "source");
        int remaining = byteBuffer.remaining();
        int i = remaining;
        while (i > 0) {
            v M = M(1);
            int min = Math.min(i, 8192 - M.c);
            byteBuffer.get(M.a, M.c, min);
            i -= min;
            M.c += min;
        }
        this.b += (long) remaining;
        return remaining;
    }
}

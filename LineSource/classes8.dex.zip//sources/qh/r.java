package qh;

import e.e.b.a.a;
import java.io.OutputStream;
import ka.b.q;
import ka.h.c.p;

public final class r implements y {
    public final OutputStream a;
    public final b0 b;

    public r(OutputStream outputStream, b0 b0Var) {
        p.e(outputStream, "out");
        p.e(b0Var, "timeout");
        this.a = outputStream;
        this.b = b0Var;
    }

    public void close() {
        this.a.close();
    }

    public void flush() {
        this.a.flush();
    }

    public b0 timeout() {
        return this.b;
    }

    public String toString() {
        StringBuilder V0 = a.V0("sink(");
        V0.append(this.a);
        V0.append(')');
        return V0.toString();
    }

    public void write(d dVar, long j) {
        p.e(dVar, "source");
        q.Z(dVar.b, 0, j);
        while (j > 0) {
            this.b.throwIfReached();
            v vVar = dVar.a;
            p.c(vVar);
            int min = (int) Math.min(j, (long) (vVar.c - vVar.b));
            this.a.write(vVar.a, vVar.b, min);
            int i = vVar.b + min;
            vVar.b = i;
            long j2 = (long) min;
            j -= j2;
            dVar.b -= j2;
            if (i == vVar.c) {
                dVar.a = vVar.a();
                w.a(vVar);
            }
        }
    }
}

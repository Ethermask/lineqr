package qh;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;

public interface y extends Closeable, Flushable {
    void close() throws IOException;

    void flush() throws IOException;

    b0 timeout();

    void write(d dVar, long j) throws IOException;
}

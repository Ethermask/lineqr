package qh;

import java.io.IOException;
import ka.h.c.p;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.ReplaceWith;

public abstract class k implements a0 {
    public final a0 delegate;

    public k(a0 a0Var) {
        p.e(a0Var, "delegate");
        this.delegate = a0Var;
    }

    @Deprecated(level = DeprecationLevel.ERROR, message = "moved to val", replaceWith = @ReplaceWith(expression = "delegate", imports = {}))
    /* renamed from: -deprecated_delegate  reason: not valid java name */
    public final a0 m142deprecated_delegate() {
        return this.delegate;
    }

    public void close() throws IOException {
        this.delegate.close();
    }

    public final a0 delegate() {
        return this.delegate;
    }

    public long read(d dVar, long j) throws IOException {
        p.e(dVar, "sink");
        return this.delegate.read(dVar, j);
    }

    public b0 timeout() {
        return this.delegate.timeout();
    }

    public String toString() {
        return getClass().getSimpleName() + '(' + this.delegate + ')';
    }
}

package qh;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import ka.b.q;
import ka.h.c.p;

public final class u implements g {
    public final d a = new d();
    public boolean b;
    public final a0 c;

    public u(a0 a0Var) {
        p.e(a0Var, "source");
        this.c = a0Var;
    }

    public String G() {
        return q(Long.MAX_VALUE);
    }

    public byte[] I(long j) {
        if (f(j)) {
            return this.a.I(j);
        }
        throw new EOFException();
    }

    public void S(long j) {
        if (!f(j)) {
            throw new EOFException();
        }
    }

    public h U(long j) {
        if (f(j)) {
            return this.a.U(j);
        }
        throw new EOFException();
    }

    public byte[] Y() {
        this.a.E(this.c);
        return this.a.Y();
    }

    public boolean Z() {
        if (!(!this.b)) {
            throw new IllegalStateException("closed".toString());
        } else if (!this.a.Z() || this.c.read(this.a, (long) 8192) != -1) {
            return false;
        } else {
            return true;
        }
    }

    public long a(byte b2, long j, long j2) {
        boolean z = true;
        if (!this.b) {
            if (0 > j || j2 < j) {
                z = false;
            }
            if (z) {
                while (j < j2) {
                    long g = this.a.g(b2, j, j2);
                    if (g != -1) {
                        return g;
                    }
                    d dVar = this.a;
                    long j3 = dVar.b;
                    if (j3 >= j2 || this.c.read(dVar, (long) 8192) == -1) {
                        return -1;
                    }
                    j = Math.max(j, j3);
                }
                return -1;
            }
            StringBuilder b1 = e.e.b.a.a.b1("fromIndex=", j, " toIndex=");
            b1.append(j2);
            throw new IllegalArgumentException(b1.toString().toString());
        }
        throw new IllegalStateException("closed".toString());
    }

    public int b() {
        S(4);
        int readInt = this.a.readInt();
        return ((readInt & 255) << 24) | ((-16777216 & readInt) >>> 24) | ((16711680 & readInt) >>> 8) | ((65280 & readInt) << 8);
    }

    public long b0() {
        int i;
        S(1);
        long j = 0;
        while (true) {
            long j2 = j + 1;
            if (!f(j2)) {
                break;
            }
            byte d = this.a.d(j);
            if ((d >= ((byte) 48) && d <= ((byte) 57)) || (j == 0 && d == ((byte) 45))) {
                j = j2;
            } else if (i == 0) {
                StringBuilder sb = new StringBuilder();
                sb.append("Expected leading [0-9] or '-' character but was 0x");
                q.a0(16);
                q.a0(16);
                String num = Integer.toString(d, 16);
                p.d(num, "java.lang.Integer.toStri…(this, checkRadix(radix))");
                sb.append(num);
                throw new NumberFormatException(sb.toString());
            }
        }
        return this.a.b0();
    }

    public String c() {
        this.a.E(this.c);
        return this.a.v();
    }

    public void close() {
        if (!this.b) {
            this.b = true;
            this.c.close();
            d dVar = this.a;
            dVar.skip(dVar.b);
        }
    }

    public boolean f(long j) {
        d dVar;
        if (!(j >= 0)) {
            throw new IllegalArgumentException(e.e.b.a.a.s("byteCount < 0: ", j).toString());
        } else if (!this.b) {
            do {
                dVar = this.a;
                if (dVar.b >= j) {
                    return true;
                }
            } while (this.c.read(dVar, (long) 8192) != -1);
            return false;
        } else {
            throw new IllegalStateException("closed".toString());
        }
    }

    public String f0(Charset charset) {
        p.e(charset, "charset");
        this.a.E(this.c);
        return this.a.f0(charset);
    }

    public d getBuffer() {
        return this.a;
    }

    public boolean isOpen() {
        return !this.b;
    }

    public long l(h hVar) {
        p.e(hVar, "bytes");
        p.e(hVar, "bytes");
        if (!this.b) {
            long j = 0;
            while (true) {
                long h = this.a.h(hVar, j);
                if (h != -1) {
                    return h;
                }
                d dVar = this.a;
                long j2 = dVar.b;
                if (this.c.read(dVar, (long) 8192) == -1) {
                    return -1;
                }
                j = Math.max(j, (j2 - ((long) hVar.j())) + 1);
            }
        } else {
            throw new IllegalStateException("closed".toString());
        }
    }

    public h m0() {
        this.a.E(this.c);
        return this.a.m0();
    }

    public void o(d dVar, long j) {
        p.e(dVar, "sink");
        try {
            if (f(j)) {
                this.a.o(dVar, j);
                return;
            }
            throw new EOFException();
        } catch (EOFException e2) {
            dVar.E(this.a);
            throw e2;
        }
    }

    public long p(h hVar) {
        p.e(hVar, "targetBytes");
        p.e(hVar, "targetBytes");
        if (!this.b) {
            long j = 0;
            while (true) {
                long i = this.a.i(hVar, j);
                if (i != -1) {
                    return i;
                }
                d dVar = this.a;
                long j2 = dVar.b;
                if (this.c.read(dVar, (long) 8192) == -1) {
                    return -1;
                }
                j = Math.max(j, j2);
            }
        } else {
            throw new IllegalStateException("closed".toString());
        }
    }

    public g peek() {
        return q.J(new s(this));
    }

    public String q(long j) {
        if (j >= 0) {
            long j2 = j == Long.MAX_VALUE ? Long.MAX_VALUE : j + 1;
            byte b2 = (byte) 10;
            long a2 = a(b2, 0, j2);
            if (a2 != -1) {
                return qh.c0.a.c(this.a, a2);
            }
            if (j2 < Long.MAX_VALUE && f(j2) && this.a.d(j2 - 1) == ((byte) 13) && f(1 + j2) && this.a.d(j2) == b2) {
                return qh.c0.a.c(this.a, j2);
            }
            d dVar = new d();
            d dVar2 = this.a;
            dVar2.c(dVar, 0, Math.min((long) 32, dVar2.b));
            StringBuilder V0 = e.e.b.a.a.V0("\\n not found: limit=");
            V0.append(Math.min(this.a.b, j));
            V0.append(" content=");
            V0.append(dVar.m0().r());
            V0.append("…");
            throw new EOFException(V0.toString());
        }
        throw new IllegalArgumentException(e.e.b.a.a.s("limit < 0: ", j).toString());
    }

    public long r0(y yVar) {
        p.e(yVar, "sink");
        long j = 0;
        while (this.c.read(this.a, (long) 8192) != -1) {
            long b2 = this.a.b();
            if (b2 > 0) {
                j += b2;
                yVar.write(this.a, b2);
            }
        }
        d dVar = this.a;
        long j2 = dVar.b;
        if (j2 <= 0) {
            return j;
        }
        long j3 = j + j2;
        yVar.write(dVar, j2);
        return j3;
    }

    public long read(d dVar, long j) {
        p.e(dVar, "sink");
        if (!(j >= 0)) {
            throw new IllegalArgumentException(e.e.b.a.a.s("byteCount < 0: ", j).toString());
        } else if (!this.b) {
            d dVar2 = this.a;
            if (dVar2.b == 0 && this.c.read(dVar2, (long) 8192) == -1) {
                return -1;
            }
            return this.a.read(dVar, Math.min(j, this.a.b));
        } else {
            throw new IllegalStateException("closed".toString());
        }
    }

    public byte readByte() {
        S(1);
        return this.a.readByte();
    }

    public void readFully(byte[] bArr) {
        p.e(bArr, "sink");
        try {
            S((long) bArr.length);
            this.a.readFully(bArr);
        } catch (EOFException e2) {
            int i = 0;
            while (true) {
                d dVar = this.a;
                long j = dVar.b;
                if (j > 0) {
                    int read = dVar.read(bArr, i, (int) j);
                    if (read != -1) {
                        i += read;
                    } else {
                        throw new AssertionError();
                    }
                } else {
                    throw e2;
                }
            }
        }
    }

    public int readInt() {
        S(4);
        return this.a.readInt();
    }

    public long readLong() {
        S(8);
        return this.a.readLong();
    }

    public short readShort() {
        S(2);
        return this.a.readShort();
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x003a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public long s0() {
        /*
            r5 = this;
            r0 = 1
            r5.S(r0)
            r0 = 0
        L_0x0006:
            int r1 = r0 + 1
            long r2 = (long) r1
            boolean r2 = r5.f(r2)
            if (r2 == 0) goto L_0x0062
            qh.d r2 = r5.a
            long r3 = (long) r0
            byte r2 = r2.d(r3)
            r3 = 48
            byte r3 = (byte) r3
            if (r2 < r3) goto L_0x0020
            r3 = 57
            byte r3 = (byte) r3
            if (r2 <= r3) goto L_0x0035
        L_0x0020:
            r3 = 97
            byte r3 = (byte) r3
            if (r2 < r3) goto L_0x002a
            r3 = 102(0x66, float:1.43E-43)
            byte r3 = (byte) r3
            if (r2 <= r3) goto L_0x0035
        L_0x002a:
            r3 = 65
            byte r3 = (byte) r3
            if (r2 < r3) goto L_0x0037
            r3 = 70
            byte r3 = (byte) r3
            if (r2 <= r3) goto L_0x0035
            goto L_0x0037
        L_0x0035:
            r0 = r1
            goto L_0x0006
        L_0x0037:
            if (r0 == 0) goto L_0x003a
            goto L_0x0062
        L_0x003a:
            java.lang.NumberFormatException r0 = new java.lang.NumberFormatException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = "Expected leading [0-9a-fA-F] character but was 0x"
            r1.append(r3)
            r3 = 16
            ka.b.q.a0(r3)
            ka.b.q.a0(r3)
            java.lang.String r2 = java.lang.Integer.toString(r2, r3)
            java.lang.String r3 = "java.lang.Integer.toStri…(this, checkRadix(radix))"
            ka.h.c.p.d(r2, r3)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0062:
            qh.d r0 = r5.a
            long r0 = r0.s0()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: qh.u.s0():long");
    }

    public void skip(long j) {
        if (!this.b) {
            while (j > 0) {
                d dVar = this.a;
                if (dVar.b == 0 && this.c.read(dVar, (long) 8192) == -1) {
                    throw new EOFException();
                }
                long min = Math.min(j, this.a.b);
                this.a.skip(min);
                j -= min;
            }
            return;
        }
        throw new IllegalStateException("closed".toString());
    }

    public InputStream t0() {
        return new a(this);
    }

    public b0 timeout() {
        return this.c.timeout();
    }

    public String toString() {
        StringBuilder V0 = e.e.b.a.a.V0("buffer(");
        V0.append(this.c);
        V0.append(')');
        return V0.toString();
    }

    public boolean u(long j, h hVar) {
        p.e(hVar, "bytes");
        int j2 = hVar.j();
        p.e(hVar, "bytes");
        if (!this.b) {
            if (j >= 0 && j2 >= 0 && hVar.j() - 0 >= j2) {
                int i = 0;
                while (i < j2) {
                    long j3 = ((long) i) + j;
                    if (f(1 + j3) && this.a.d(j3) == hVar.J(0 + i)) {
                        i++;
                    }
                }
                return true;
            }
            return false;
        }
        throw new IllegalStateException("closed".toString());
    }

    public int u0(q qVar) {
        p.e(qVar, "options");
        if (!this.b) {
            while (true) {
                int d = qh.c0.a.d(this.a, qVar, true);
                if (d == -2) {
                    if (this.c.read(this.a, (long) 8192) == -1) {
                        break;
                    }
                } else if (d != -1) {
                    this.a.skip((long) qVar.a[d].j());
                    return d;
                }
            }
            return -1;
        }
        throw new IllegalStateException("closed".toString());
    }

    public static final class a extends InputStream {
        public final /* synthetic */ u a;

        public a(u uVar) {
            this.a = uVar;
        }

        public int available() {
            u uVar = this.a;
            if (!uVar.b) {
                return (int) Math.min(uVar.a.b, (long) Integer.MAX_VALUE);
            }
            throw new IOException("closed");
        }

        public void close() {
            this.a.close();
        }

        public int read() {
            u uVar = this.a;
            if (!uVar.b) {
                d dVar = uVar.a;
                if (dVar.b == 0 && uVar.c.read(dVar, (long) 8192) == -1) {
                    return -1;
                }
                return this.a.a.readByte() & 255;
            }
            throw new IOException("closed");
        }

        public String toString() {
            return this.a + ".inputStream()";
        }

        public int read(byte[] bArr, int i, int i2) {
            p.e(bArr, "data");
            if (!this.a.b) {
                q.Z((long) bArr.length, (long) i, (long) i2);
                u uVar = this.a;
                d dVar = uVar.a;
                if (dVar.b == 0 && uVar.c.read(dVar, (long) 8192) == -1) {
                    return -1;
                }
                return this.a.a.read(bArr, i, i2);
            }
            throw new IOException("closed");
        }
    }

    public int read(byte[] bArr, int i, int i2) {
        p.e(bArr, "sink");
        long j = (long) i2;
        q.Z((long) bArr.length, (long) i, j);
        d dVar = this.a;
        if (dVar.b == 0 && this.c.read(dVar, (long) 8192) == -1) {
            return -1;
        }
        return this.a.read(bArr, i, (int) Math.min(j, this.a.b));
    }

    public int read(ByteBuffer byteBuffer) {
        p.e(byteBuffer, "sink");
        d dVar = this.a;
        if (dVar.b == 0 && this.c.read(dVar, (long) 8192) == -1) {
            return -1;
        }
        return this.a.read(byteBuffer);
    }
}

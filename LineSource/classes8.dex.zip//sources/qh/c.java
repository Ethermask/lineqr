package qh;

import ka.h.c.p;

public final class c implements y {
    public void close() {
    }

    public void flush() {
    }

    public b0 timeout() {
        return b0.NONE;
    }

    public void write(d dVar, long j) {
        p.e(dVar, "source");
        dVar.skip(j);
    }
}

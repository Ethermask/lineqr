package qh.c0;

import ka.h.c.p;
import qh.d;
import qh.q;
import qh.v;

public final class a {
    public static final byte[] a;

    static {
        p.e("0123456789abcdef", "$this$asUtf8ToByteArray");
        byte[] bytes = "0123456789abcdef".getBytes(ka.m.a.a);
        p.d(bytes, "(this as java.lang.String).getBytes(charset)");
        a = bytes;
    }

    public static final d.a a(d dVar, d.a aVar) {
        p.e(dVar, "$this$commonReadAndWriteUnsafe");
        p.e(aVar, "unsafeCursor");
        if (aVar.a == null) {
            aVar.a = dVar;
            aVar.b = true;
            return aVar;
        }
        throw new IllegalStateException("already attached to a buffer".toString());
    }

    public static final boolean b(v vVar, int i, byte[] bArr, int i2, int i3) {
        p.e(vVar, "segment");
        p.e(bArr, "bytes");
        int i4 = vVar.c;
        byte[] bArr2 = vVar.a;
        while (i2 < i3) {
            if (i == i4) {
                vVar = vVar.f;
                p.c(vVar);
                byte[] bArr3 = vVar.a;
                int i5 = vVar.b;
                bArr2 = bArr3;
                i = i5;
                i4 = vVar.c;
            }
            if (bArr2[i] != bArr[i2]) {
                return false;
            }
            i++;
            i2++;
        }
        return true;
    }

    public static final String c(d dVar, long j) {
        p.e(dVar, "$this$readUtf8Line");
        if (j > 0) {
            long j2 = j - 1;
            if (dVar.d(j2) == ((byte) 13)) {
                String F = dVar.F(j2);
                dVar.skip(2);
                return F;
            }
        }
        String F2 = dVar.F(j);
        dVar.skip(1);
        return F2;
    }

    public static final int d(d dVar, q qVar, boolean z) {
        int i;
        int i2;
        int i3;
        v vVar;
        int i4;
        d dVar2 = dVar;
        q qVar2 = qVar;
        p.e(dVar2, "$this$selectPrefix");
        p.e(qVar2, "options");
        v vVar2 = dVar2.a;
        if (vVar2 != null) {
            byte[] bArr = vVar2.a;
            int i5 = vVar2.b;
            int i6 = vVar2.c;
            int[] iArr = qVar2.b;
            v vVar3 = vVar2;
            int i7 = -1;
            int i8 = 0;
            loop0:
            while (true) {
                int i9 = i8 + 1;
                int i10 = iArr[i8];
                int i11 = i9 + 1;
                int i12 = iArr[i9];
                if (i12 != -1) {
                    i7 = i12;
                }
                if (vVar3 == null) {
                    break;
                }
                if (i10 < 0) {
                    int i13 = (i10 * -1) + i11;
                    while (true) {
                        int i14 = i5 + 1;
                        int i15 = i11 + 1;
                        if ((bArr[i5] & 255) != iArr[i11]) {
                            return i7;
                        }
                        boolean z2 = i15 == i13;
                        if (i14 == i6) {
                            p.c(vVar3);
                            v vVar4 = vVar3.f;
                            p.c(vVar4);
                            i4 = vVar4.b;
                            byte[] bArr2 = vVar4.a;
                            i3 = vVar4.c;
                            if (vVar4 != vVar2) {
                                byte[] bArr3 = bArr2;
                                vVar = vVar4;
                                bArr = bArr3;
                            } else if (!z2) {
                                break loop0;
                            } else {
                                bArr = bArr2;
                                vVar = null;
                            }
                        } else {
                            v vVar5 = vVar3;
                            i3 = i6;
                            i4 = i14;
                            vVar = vVar5;
                        }
                        if (z2) {
                            i2 = iArr[i15];
                            i = i4;
                            i6 = i3;
                            vVar3 = vVar;
                            break;
                        }
                        i5 = i4;
                        i6 = i3;
                        i11 = i15;
                        vVar3 = vVar;
                    }
                } else {
                    i = i5 + 1;
                    byte b = bArr[i5] & 255;
                    int i16 = i11 + i10;
                    while (i11 != i16) {
                        if (b == iArr[i11]) {
                            i2 = iArr[i11 + i10];
                            if (i == i6) {
                                vVar3 = vVar3.f;
                                p.c(vVar3);
                                i = vVar3.b;
                                bArr = vVar3.a;
                                i6 = vVar3.c;
                                if (vVar3 == vVar2) {
                                    vVar3 = null;
                                }
                            }
                        } else {
                            i11++;
                        }
                    }
                    return i7;
                }
                if (i2 >= 0) {
                    return i2;
                }
                i8 = -i2;
                i5 = i;
            }
            if (z) {
                return -2;
            }
            return i7;
        } else if (z) {
            return -2;
        } else {
            return -1;
        }
    }
}

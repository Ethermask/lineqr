package qh;

import e.e.b.a.a;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import ka.h.c.p;

public final class z extends b {
    public final Socket a;

    public z(Socket socket) {
        p.e(socket, "socket");
        this.a = socket;
    }

    public IOException newTimeoutException(IOException iOException) {
        SocketTimeoutException socketTimeoutException = new SocketTimeoutException("timeout");
        if (iOException != null) {
            socketTimeoutException.initCause(iOException);
        }
        return socketTimeoutException;
    }

    public void timedOut() {
        try {
            this.a.close();
        } catch (Exception e2) {
            Logger logger = p.a;
            Level level = Level.WARNING;
            StringBuilder V0 = a.V0("Failed to close timed out socket ");
            V0.append(this.a);
            logger.log(level, V0.toString(), e2);
        } catch (AssertionError e3) {
            if (p.b(e3)) {
                Logger logger2 = p.a;
                Level level2 = Level.WARNING;
                StringBuilder V02 = a.V0("Failed to close timed out socket ");
                V02.append(this.a);
                logger2.log(level2, V02.toString(), e3);
                return;
            }
            throw e3;
        }
    }
}

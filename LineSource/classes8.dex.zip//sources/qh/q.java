package qh;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.RandomAccess;
import ka.b.c;
import ka.h.c.p;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class q extends c<h> implements RandomAccess {
    public static final a c = new a((DefaultConstructorMarker) null);
    public final h[] a;
    public final int[] b;

    public static final class a {
        public a(DefaultConstructorMarker defaultConstructorMarker) {
        }

        public final void a(long j, d dVar, int i, List<? extends h> list, int i2, int i3, List<Integer> list2) {
            int i4;
            int i5;
            int i6;
            int i7;
            d dVar2;
            d dVar3 = dVar;
            int i8 = i;
            List<? extends h> list3 = list;
            int i9 = i2;
            int i10 = i3;
            List<Integer> list4 = list2;
            if (i9 < i10) {
                int i11 = i9;
                while (i11 < i10) {
                    if (((h) list3.get(i11)).j() >= i8) {
                        i11++;
                    } else {
                        throw new IllegalArgumentException("Failed requirement.".toString());
                    }
                }
                h hVar = (h) list.get(i2);
                h hVar2 = (h) list3.get(i10 - 1);
                int i12 = -1;
                if (i8 == hVar.j()) {
                    int intValue = list4.get(i9).intValue();
                    int i13 = i9 + 1;
                    i4 = i13;
                    i5 = intValue;
                    hVar = (h) list3.get(i13);
                } else {
                    i4 = i9;
                    i5 = -1;
                }
                if (hVar.J(i8) != hVar2.J(i8)) {
                    int i14 = 1;
                    for (int i15 = i4 + 1; i15 < i10; i15++) {
                        if (((h) list3.get(i15 - 1)).J(i8) != ((h) list3.get(i15)).J(i8)) {
                            i14++;
                        }
                    }
                    long b = b(dVar3) + j + ((long) 2) + ((long) (i14 * 2));
                    dVar3.g0(i14);
                    dVar3.g0(i5);
                    for (int i16 = i4; i16 < i10; i16++) {
                        byte J = ((h) list3.get(i16)).J(i8);
                        if (i16 == i4 || J != ((h) list3.get(i16 - 1)).J(i8)) {
                            dVar3.g0(J & 255);
                        }
                    }
                    d dVar4 = new d();
                    while (i4 < i10) {
                        byte J2 = ((h) list3.get(i4)).J(i8);
                        int i17 = i4 + 1;
                        int i18 = i17;
                        while (true) {
                            if (i18 >= i10) {
                                i6 = i10;
                                break;
                            } else if (J2 != ((h) list3.get(i18)).J(i8)) {
                                i6 = i18;
                                break;
                            } else {
                                i18++;
                            }
                        }
                        if (i17 == i6 && i8 + 1 == ((h) list3.get(i4)).j()) {
                            dVar3.g0(list4.get(i4).intValue());
                            i7 = i6;
                            dVar2 = dVar4;
                        } else {
                            dVar3.g0(((int) (b(dVar4) + b)) * i12);
                            i7 = i6;
                            dVar2 = dVar4;
                            a(b, dVar4, i8 + 1, list, i4, i6, list2);
                        }
                        dVar4 = dVar2;
                        i4 = i7;
                        i12 = -1;
                    }
                    dVar3.E(dVar4);
                    return;
                }
                int min = Math.min(hVar.j(), hVar2.j());
                int i19 = i8;
                int i20 = 0;
                while (i19 < min && hVar.J(i19) == hVar2.J(i19)) {
                    i20++;
                    i19++;
                }
                long b2 = b(dVar3) + j + ((long) 2) + ((long) i20) + 1;
                dVar3.g0(-i20);
                dVar3.g0(i5);
                int i21 = i8 + i20;
                while (i8 < i21) {
                    dVar3.g0(hVar.J(i8) & 255);
                    i8++;
                }
                if (i4 + 1 == i10) {
                    if (i21 == ((h) list3.get(i4)).j()) {
                        dVar3.g0(list4.get(i4).intValue());
                        return;
                    }
                    throw new IllegalStateException("Check failed.".toString());
                }
                d dVar5 = new d();
                dVar3.g0(((int) (b(dVar5) + b2)) * -1);
                a(b2, dVar5, i21, list, i4, i3, list2);
                dVar3.E(dVar5);
                return;
            }
            throw new IllegalArgumentException("Failed requirement.".toString());
        }

        public final long b(d dVar) {
            return dVar.b / ((long) 4);
        }

        public final q c(h... hVarArr) {
            int i;
            h[] hVarArr2 = hVarArr;
            p.e(hVarArr2, "byteStrings");
            int i2 = 1;
            int i3 = 0;
            if (hVarArr2.length == 0) {
                return new q(new h[0], new int[]{0, -1}, (DefaultConstructorMarker) null);
            }
            List v3 = i0.a.a.a.u1.c.v3(hVarArr);
            ka.b.q.k3(v3);
            ArrayList arrayList = new ArrayList(hVarArr2.length);
            for (h hVar : hVarArr2) {
                arrayList.add(-1);
            }
            Object[] array = arrayList.toArray(new Integer[0]);
            if (array != null) {
                Integer[] numArr = (Integer[]) array;
                List o2 = ka.b.q.o2((Integer[]) Arrays.copyOf(numArr, numArr.length));
                int length = hVarArr2.length;
                int i4 = 0;
                int i5 = 0;
                while (i4 < length) {
                    h hVar2 = hVarArr2[i4];
                    int i6 = i5 + 1;
                    ArrayList arrayList2 = (ArrayList) v3;
                    int size = arrayList2.size();
                    p.e(v3, "$this$binarySearch");
                    ka.b.q.G2(arrayList2.size(), 0, size);
                    int i7 = size - 1;
                    int i8 = 0;
                    while (true) {
                        if (i8 > i7) {
                            i = -(i8 + 1);
                            break;
                        }
                        i = (i8 + i7) >>> i2;
                        int k0 = ka.b.q.k0((Comparable) arrayList2.get(i), hVar2);
                        if (k0 >= 0) {
                            if (k0 <= 0) {
                                break;
                            }
                            i7 = i - 1;
                        } else {
                            i8 = i + 1;
                        }
                        i2 = 1;
                    }
                    o2.set(i, Integer.valueOf(i5));
                    i4++;
                    i5 = i6;
                    i2 = 1;
                }
                ArrayList arrayList3 = (ArrayList) v3;
                if (((h) arrayList3.get(0)).j() > 0) {
                    int i9 = 0;
                    while (i9 < arrayList3.size()) {
                        h hVar3 = (h) arrayList3.get(i9);
                        int i10 = i9 + 1;
                        int i11 = i10;
                        while (i11 < arrayList3.size()) {
                            h hVar4 = (h) arrayList3.get(i11);
                            if (hVar4 != null) {
                                p.e(hVar3, "prefix");
                                if (!hVar4.K(0, hVar3, 0, hVar3.j())) {
                                    continue;
                                    break;
                                }
                                if (!(hVar4.j() != hVar3.j())) {
                                    throw new IllegalArgumentException(("duplicate option: " + hVar4).toString());
                                } else if (((Number) o2.get(i11)).intValue() > ((Number) o2.get(i9)).intValue()) {
                                    arrayList3.remove(i11);
                                    o2.remove(i11);
                                } else {
                                    i11++;
                                }
                            } else {
                                throw null;
                            }
                        }
                        i9 = i10;
                    }
                    d dVar = new d();
                    a(0, dVar, 0, v3, 0, arrayList3.size(), o2);
                    int[] iArr = new int[((int) b(dVar))];
                    while (!dVar.Z()) {
                        iArr[i3] = dVar.readInt();
                        i3++;
                    }
                    Object[] copyOf = Arrays.copyOf(hVarArr2, hVarArr2.length);
                    p.d(copyOf, "java.util.Arrays.copyOf(this, size)");
                    return new q((h[]) copyOf, iArr, (DefaultConstructorMarker) null);
                }
                throw new IllegalArgumentException("the empty byte string is not a supported option".toString());
            }
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
        }
    }

    public q(h[] hVarArr, int[] iArr, DefaultConstructorMarker defaultConstructorMarker) {
        this.a = hVarArr;
        this.b = iArr;
    }

    public int c() {
        return this.a.length;
    }

    public final /* bridge */ boolean contains(Object obj) {
        if (obj instanceof h) {
            return q.super.contains((h) obj);
        }
        return false;
    }

    public Object get(int i) {
        return this.a[i];
    }

    public final /* bridge */ int indexOf(Object obj) {
        if (obj instanceof h) {
            return q.super.indexOf((h) obj);
        }
        return -1;
    }

    public final /* bridge */ int lastIndexOf(Object obj) {
        if (obj instanceof h) {
            return q.super.lastIndexOf((h) obj);
        }
        return -1;
    }
}

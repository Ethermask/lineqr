package qh;

import e.e.b.a.a;
import java.io.IOException;
import java.util.zip.Deflater;
import ka.b.q;
import ka.h.c.p;

public final class i implements y {
    public boolean a;
    public final f b;
    public final Deflater c;

    public i(y yVar, Deflater deflater) {
        p.e(yVar, "sink");
        p.e(deflater, "deflater");
        f I = q.I(yVar);
        p.e(I, "sink");
        p.e(deflater, "deflater");
        this.b = I;
        this.c = deflater;
    }

    public final void a(boolean z) {
        v M;
        int i;
        d buffer = this.b.getBuffer();
        while (true) {
            M = buffer.M(1);
            if (z) {
                Deflater deflater = this.c;
                byte[] bArr = M.a;
                int i2 = M.c;
                i = deflater.deflate(bArr, i2, 8192 - i2, 2);
            } else {
                Deflater deflater2 = this.c;
                byte[] bArr2 = M.a;
                int i3 = M.c;
                i = deflater2.deflate(bArr2, i3, 8192 - i3);
            }
            if (i > 0) {
                M.c += i;
                buffer.b += (long) i;
                this.b.B();
            } else if (this.c.needsInput()) {
                break;
            }
        }
        if (M.b == M.c) {
            buffer.a = M.a();
            w.a(M);
        }
    }

    public void close() throws IOException {
        if (!this.a) {
            Throwable th2 = null;
            try {
                this.c.finish();
                a(false);
            } catch (Throwable th3) {
                th2 = th3;
            }
            try {
                this.c.end();
            } catch (Throwable th4) {
                if (th2 == null) {
                    th2 = th4;
                }
            }
            try {
                this.b.close();
            } catch (Throwable th5) {
                if (th2 == null) {
                    th2 = th5;
                }
            }
            this.a = true;
            if (th2 != null) {
                throw th2;
            }
        }
    }

    public void flush() throws IOException {
        a(true);
        this.b.flush();
    }

    public b0 timeout() {
        return this.b.timeout();
    }

    public String toString() {
        StringBuilder V0 = a.V0("DeflaterSink(");
        V0.append(this.b);
        V0.append(')');
        return V0.toString();
    }

    public void write(d dVar, long j) throws IOException {
        p.e(dVar, "source");
        q.Z(dVar.b, 0, j);
        while (j > 0) {
            v vVar = dVar.a;
            p.c(vVar);
            int min = (int) Math.min(j, (long) (vVar.c - vVar.b));
            this.c.setInput(vVar.a, vVar.b, min);
            a(false);
            long j2 = (long) min;
            dVar.b -= j2;
            int i = vVar.b + min;
            vVar.b = i;
            if (i == vVar.c) {
                dVar.a = vVar.a();
                w.a(vVar);
            }
            j -= j2;
        }
    }
}

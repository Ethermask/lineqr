package qh;

import ka.h.c.p;

public final class s implements a0 {
    public final d a;
    public v b;
    public int c;
    public boolean d;

    /* renamed from: e  reason: collision with root package name */
    public long f119e;
    public final g f;

    public s(g gVar) {
        p.e(gVar, "upstream");
        this.f = gVar;
        d buffer = gVar.getBuffer();
        this.a = buffer;
        v vVar = buffer.a;
        this.b = vVar;
        this.c = vVar != null ? vVar.b : -1;
    }

    public void close() {
        this.d = true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0028, code lost:
        if (r5 == r6.b) goto L_0x002a;
     */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x002d  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x006d  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public long read(qh.d r9, long r10) {
        /*
            r8 = this;
            java.lang.String r0 = "sink"
            ka.h.c.p.e(r9, r0)
            r0 = 0
            int r2 = (r10 > r0 ? 1 : (r10 == r0 ? 0 : -1))
            r3 = 0
            r4 = 1
            if (r2 < 0) goto L_0x000f
            r5 = r4
            goto L_0x0010
        L_0x000f:
            r5 = r3
        L_0x0010:
            if (r5 == 0) goto L_0x0085
            boolean r5 = r8.d
            r5 = r5 ^ r4
            if (r5 == 0) goto L_0x0079
            qh.v r5 = r8.b
            if (r5 == 0) goto L_0x002a
            qh.d r6 = r8.a
            qh.v r6 = r6.a
            if (r5 != r6) goto L_0x002b
            int r5 = r8.c
            ka.h.c.p.c(r6)
            int r6 = r6.b
            if (r5 != r6) goto L_0x002b
        L_0x002a:
            r3 = r4
        L_0x002b:
            if (r3 == 0) goto L_0x006d
            if (r2 != 0) goto L_0x0030
            return r0
        L_0x0030:
            qh.g r0 = r8.f
            long r1 = r8.f119e
            r3 = 1
            long r1 = r1 + r3
            boolean r0 = r0.f(r1)
            if (r0 != 0) goto L_0x0040
            r9 = -1
            return r9
        L_0x0040:
            qh.v r0 = r8.b
            if (r0 != 0) goto L_0x0053
            qh.d r0 = r8.a
            qh.v r0 = r0.a
            if (r0 == 0) goto L_0x0053
            r8.b = r0
            ka.h.c.p.c(r0)
            int r0 = r0.b
            r8.c = r0
        L_0x0053:
            qh.d r0 = r8.a
            long r0 = r0.b
            long r2 = r8.f119e
            long r0 = r0 - r2
            long r10 = java.lang.Math.min(r10, r0)
            qh.d r2 = r8.a
            long r4 = r8.f119e
            r3 = r9
            r6 = r10
            r2.c(r3, r4, r6)
            long r0 = r8.f119e
            long r0 = r0 + r10
            r8.f119e = r0
            return r10
        L_0x006d:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "Peek source is invalid because upstream source was used"
            java.lang.String r10 = r10.toString()
            r9.<init>(r10)
            throw r9
        L_0x0079:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "closed"
            java.lang.String r10 = r10.toString()
            r9.<init>(r10)
            throw r9
        L_0x0085:
            java.lang.String r9 = "byteCount < 0: "
            java.lang.String r9 = e.e.b.a.a.s(r9, r10)
            java.lang.IllegalArgumentException r10 = new java.lang.IllegalArgumentException
            java.lang.String r9 = r9.toString()
            r10.<init>(r9)
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: qh.s.read(qh.d, long):long");
    }

    public b0 timeout() {
        return this.f.timeout();
    }
}

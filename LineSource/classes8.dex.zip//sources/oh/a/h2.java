package oh.a;

import ka.e.f;

public interface h2<S> extends f.a {
    void F(f fVar, S s);

    S a0(f fVar);
}

package oh.a;

import kotlin.Unit;
import oh.a.t2.l;

public abstract class a0 extends l implements ka.h.b.l<Throwable, Unit> {
    public abstract void w(Throwable th2);
}

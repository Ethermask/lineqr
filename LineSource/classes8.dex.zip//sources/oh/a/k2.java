package oh.a;

import e.e.b.a.a;
import ka.e.d;
import oh.a.t2.s;

public final class k2<U, T extends U> extends s<T> implements Runnable {

    /* renamed from: e  reason: collision with root package name */
    public final long f61e;

    public k2(long j, d<? super U> dVar) {
        super(dVar.getContext(), dVar);
        this.f61e = j;
    }

    public String f0() {
        return super.f0() + "(timeMillis=" + this.f61e + ')';
    }

    public void run() {
        E(new j2(a.t("Timed out waiting for ", this.f61e, " ms"), this));
    }
}

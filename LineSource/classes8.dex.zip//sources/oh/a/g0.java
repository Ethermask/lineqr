package oh.a;

import ka.e.f;
import ka.h.c.p;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class g0 extends ka.e.a {
    public static final a b = new a((DefaultConstructorMarker) null);
    public final String a;

    public static final class a implements f.b<g0> {
        public a(DefaultConstructorMarker defaultConstructorMarker) {
        }
    }

    public g0(String str) {
        super(b);
        this.a = str;
    }

    public boolean equals(Object obj) {
        if (this != obj) {
            return (obj instanceof g0) && p.b(this.a, ((g0) obj).a);
        }
        return true;
    }

    public int hashCode() {
        String str = this.a;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return e.e.b.a.a.o0(e.e.b.a.a.V0("CoroutineName("), this.a, ')');
    }
}

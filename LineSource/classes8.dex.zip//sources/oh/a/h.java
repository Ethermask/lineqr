package oh.a;

import e.e.b.a.a;
import java.util.concurrent.Future;
import kotlin.Unit;

public final class h extends i {
    public final Future<?> a;

    public h(Future<?> future) {
        this.a = future;
    }

    public void a(Throwable th2) {
        this.a.cancel(false);
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        this.a.cancel(false);
        return Unit.INSTANCE;
    }

    public String toString() {
        StringBuilder V0 = a.V0("CancelFutureOnCancel[");
        V0.append(this.a);
        V0.append(']');
        return V0.toString();
    }
}

package oh.a;

import ka.e.f;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class p2 extends ka.e.a {
    public static final a b = new a((DefaultConstructorMarker) null);
    public boolean a;

    public static final class a implements f.b<p2> {
        public a(DefaultConstructorMarker defaultConstructorMarker) {
        }
    }

    public p2() {
        super(b);
    }
}

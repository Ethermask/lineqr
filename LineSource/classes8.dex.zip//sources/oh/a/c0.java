package oh.a;

import ka.e.d;
import ka.e.e;
import ka.e.f;

public final class c0 {
    public static final boolean a;

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0028, code lost:
        if (r0.equals("on") != false) goto L_0x0033;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0031, code lost:
        if (r0.equals("") != false) goto L_0x0033;
     */
    static {
        /*
            java.lang.String r0 = "kotlinx.coroutines.scheduler"
            java.lang.String r0 = oh.a.t2.w.a(r0)
            if (r0 != 0) goto L_0x0009
            goto L_0x0033
        L_0x0009:
            int r1 = r0.hashCode()
            if (r1 == 0) goto L_0x002b
            r2 = 3551(0xddf, float:4.976E-42)
            if (r1 == r2) goto L_0x0022
            r2 = 109935(0x1ad6f, float:1.54052E-40)
            if (r1 != r2) goto L_0x0037
            java.lang.String r1 = "off"
            boolean r1 = r0.equals(r1)
            if (r1 == 0) goto L_0x0037
            r0 = 0
            goto L_0x0034
        L_0x0022:
            java.lang.String r1 = "on"
            boolean r1 = r0.equals(r1)
            if (r1 == 0) goto L_0x0037
            goto L_0x0033
        L_0x002b:
            java.lang.String r1 = ""
            boolean r1 = r0.equals(r1)
            if (r1 == 0) goto L_0x0037
        L_0x0033:
            r0 = 1
        L_0x0034:
            a = r0
            return
        L_0x0037:
            java.lang.String r1 = "System property 'kotlinx.coroutines.scheduler' has unrecognized value '"
            r2 = 39
            java.lang.String r0 = e.e.b.a.a.D(r1, r0, r2)
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.c0.<clinit>():void");
    }

    public static final String a(f fVar) {
        return null;
    }

    public static final f b(h0 h0Var, f fVar) {
        e0 plus = h0Var.getCoroutineContext().plus(fVar);
        return (plus == s0.a || plus.get(e.X) != null) ? plus : plus.plus(s0.a);
    }

    public static final n2<?> c(d<?> dVar, f fVar, Object obj) {
        n2<?> n2Var = null;
        if (!(dVar instanceof ka.e.k.a.d)) {
            return null;
        }
        if (!(fVar.get(o2.a) != null)) {
            return null;
        }
        ka.e.k.a.d dVar2 = (ka.e.k.a.d) dVar;
        while (true) {
            if (!(dVar2 instanceof p0) && (dVar2 = dVar2.getCallerFrame()) != null) {
                if (dVar2 instanceof n2) {
                    n2Var = (n2) dVar2;
                    break;
                }
            } else {
                break;
            }
        }
        if (n2Var != null) {
            n2Var.f66e = fVar;
            n2Var.f = obj;
        }
        return n2Var;
    }
}

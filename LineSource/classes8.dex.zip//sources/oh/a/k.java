package oh.a;

import ka.e.d;
import ka.h.b.l;
import kotlin.Unit;

public interface k<T> extends d<T> {
    Object d(T t, Object obj);

    boolean isActive();

    void l(l<? super Throwable, Unit> lVar);

    Object m(Throwable th2);

    void n(T t, l<? super Throwable, Unit> lVar);

    boolean o(Throwable th2);

    Object q(T t, Object obj, l<? super Throwable, Unit> lVar);

    void u(e0 e0Var, T t);

    void z(Object obj);
}

package oh.a;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;

@Deprecated(level = DeprecationLevel.ERROR, message = "This is internal API and may be removed in the future releases")
public interface r extends n1 {
    void t(a2 a2Var);
}

package oh.a;

import ka.e.d;

public interface m0<T> extends n1 {
    T g();

    Object r(d<? super T> dVar);
}

package oh.a;

import java.util.concurrent.CancellationException;
import ka.h.c.p;

public final class o1 extends CancellationException {
    public final n1 a;

    public o1(String str, Throwable th2, n1 n1Var) {
        super(str);
        this.a = n1Var;
        if (th2 != null) {
            initCause(th2);
        }
    }

    public boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof o1) {
                o1 o1Var = (o1) obj;
                if (!p.b(o1Var.getMessage(), getMessage()) || !p.b(o1Var.a, this.a) || !p.b(o1Var.getCause(), getCause())) {
                    return false;
                }
            }
            return false;
        }
        return true;
    }

    public Throwable fillInStackTrace() {
        setStackTrace(new StackTraceElement[0]);
        return this;
    }

    public int hashCode() {
        String message = getMessage();
        p.c(message);
        int hashCode = (this.a.hashCode() + (message.hashCode() * 31)) * 31;
        Throwable cause = getCause();
        return hashCode + (cause != null ? cause.hashCode() : 0);
    }

    public String toString() {
        return super.toString() + "; job=" + this.a;
    }
}

package oh.a;

import e.e.b.a.a;
import ka.h.b.l;
import ka.h.c.p;
import kotlin.Unit;

public final class x {
    public final Object a;
    public final i b;
    public final l<Throwable, Unit> c;
    public final Object d;

    /* renamed from: e  reason: collision with root package name */
    public final Throwable f97e;

    public x(Object obj, i iVar, l<? super Throwable, Unit> lVar, Object obj2, Throwable th2) {
        this.a = obj;
        this.b = iVar;
        this.c = lVar;
        this.d = obj2;
        this.f97e = th2;
    }

    public static x a(x xVar, Object obj, i iVar, l lVar, Object obj2, Throwable th2, int i) {
        Object obj3 = (i & 1) != 0 ? xVar.a : null;
        if ((i & 2) != 0) {
            iVar = xVar.b;
        }
        i iVar2 = iVar;
        l<Throwable, Unit> lVar2 = (i & 4) != 0 ? xVar.c : null;
        Object obj4 = (i & 8) != 0 ? xVar.d : null;
        if ((i & 16) != 0) {
            th2 = xVar.f97e;
        }
        Throwable th3 = th2;
        if (xVar != null) {
            return new x(obj3, iVar2, lVar2, obj4, th3);
        }
        throw null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof x)) {
            return false;
        }
        x xVar = (x) obj;
        return p.b(this.a, xVar.a) && p.b(this.b, xVar.b) && p.b(this.c, xVar.c) && p.b(this.d, xVar.d) && p.b(this.f97e, xVar.f97e);
    }

    public int hashCode() {
        Object obj = this.a;
        int i = 0;
        int hashCode = (obj != null ? obj.hashCode() : 0) * 31;
        i iVar = this.b;
        int hashCode2 = (hashCode + (iVar != null ? iVar.hashCode() : 0)) * 31;
        l<Throwable, Unit> lVar = this.c;
        int hashCode3 = (hashCode2 + (lVar != null ? lVar.hashCode() : 0)) * 31;
        Object obj2 = this.d;
        int hashCode4 = (hashCode3 + (obj2 != null ? obj2.hashCode() : 0)) * 31;
        Throwable th2 = this.f97e;
        if (th2 != null) {
            i = th2.hashCode();
        }
        return hashCode4 + i;
    }

    public String toString() {
        StringBuilder V0 = a.V0("CompletedContinuation(result=");
        V0.append(this.a);
        V0.append(", cancelHandler=");
        V0.append(this.b);
        V0.append(", onCancellation=");
        V0.append(this.c);
        V0.append(", idempotentResume=");
        V0.append(this.d);
        V0.append(", cancelCause=");
        return a.x0(V0, this.f97e, ")");
    }

    public x(Object obj, i iVar, l<Throwable, Unit> lVar, Object obj2, Throwable th2, int i) {
        iVar = (i & 2) != 0 ? null : iVar;
        lVar = (i & 4) != 0 ? null : lVar;
        obj2 = (i & 8) != 0 ? null : obj2;
        th2 = (i & 16) != 0 ? null : th2;
        this.a = obj;
        this.b = iVar;
        this.c = lVar;
        this.d = obj2;
        this.f97e = th2;
    }
}

package oh.a;

public enum i0 {
    DEFAULT,
    LAZY,
    ATOMIC,
    UNDISPATCHED
}

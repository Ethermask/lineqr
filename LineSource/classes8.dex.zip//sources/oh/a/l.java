package oh.a;

import e.e.b.a.a;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.b.q;
import ka.e.f;
import ka.e.k.a.d;
import kotlin.PublishedApi;
import kotlin.Result;
import kotlin.Unit;
import oh.a.t2.h;
import oh.a.t2.i;
import oh.a.t2.v;

@PublishedApi
public class l<T> extends q0<T> implements k<T>, d {
    public static final /* synthetic */ AtomicIntegerFieldUpdater f = AtomicIntegerFieldUpdater.newUpdater(l.class, "_decision");
    public static final /* synthetic */ AtomicReferenceFieldUpdater g = AtomicReferenceFieldUpdater.newUpdater(l.class, Object.class, "_state");
    public volatile /* synthetic */ int _decision = 0;
    public volatile /* synthetic */ Object _parentHandle = null;
    public volatile /* synthetic */ Object _state = b.a;
    public final f d;

    /* renamed from: e  reason: collision with root package name */
    public final ka.e.d<T> f62e;

    public l(ka.e.d<? super T> dVar, int i) {
        super(i);
        this.f62e = dVar;
        this.d = dVar.getContext();
    }

    public String A() {
        return "CancellableContinuation";
    }

    public final void B(Object obj, int i, ka.h.b.l<? super Throwable, Unit> lVar) {
        Object obj2;
        do {
            obj2 = this._state;
            if (obj2 instanceof z1) {
            } else {
                if (obj2 instanceof n) {
                    n nVar = (n) obj2;
                    if (nVar == null) {
                        throw null;
                    } else if (n.c.compareAndSet(nVar, 0, 1)) {
                        if (lVar != null) {
                            j(lVar, nVar.a);
                            return;
                        }
                        return;
                    }
                }
                throw new IllegalStateException(a.B("Already resumed, but proposed with update ", obj).toString());
            }
        } while (!g.compareAndSet(this, obj2, C((z1) obj2, obj, i, lVar, (Object) null)));
        p();
        r(i);
    }

    public final Object C(z1 z1Var, Object obj, int i, ka.h.b.l<? super Throwable, Unit> lVar, Object obj2) {
        if (obj instanceof y) {
            return obj;
        }
        if (!q.Q1(i) && obj2 == null) {
            return obj;
        }
        if (lVar == null && ((!(z1Var instanceof i) || (z1Var instanceof e)) && obj2 == null)) {
            return obj;
        }
        if (!(z1Var instanceof i)) {
            z1Var = null;
        }
        return new x(obj, (i) z1Var, lVar, obj2, (Throwable) null, 16);
    }

    public final void D() {
        n1 n1Var;
        boolean w = w();
        if (this.c == 2) {
            ka.e.d<T> dVar = this.f62e;
            Throwable th2 = null;
            if (!(dVar instanceof h)) {
                dVar = null;
            }
            h hVar = (h) dVar;
            if (hVar != null) {
                while (true) {
                    Object obj = hVar._reusableCancellableContinuation;
                    Object obj2 = i.b;
                    if (obj == obj2) {
                        if (h.h.compareAndSet(hVar, obj2, this)) {
                            break;
                        }
                    } else if (obj != null) {
                        if (!(obj instanceof Throwable)) {
                            throw new IllegalStateException(a.B("Inconsistent state ", obj).toString());
                        } else if (h.h.compareAndSet(hVar, obj, (Object) null)) {
                            th2 = (Throwable) obj;
                        } else {
                            throw new IllegalArgumentException("Failed requirement.".toString());
                        }
                    }
                }
                if (th2 != null) {
                    if (!w) {
                        o(th2);
                    }
                    w = true;
                }
            }
        }
        if (!w && ((u0) this._parentHandle) == null && (n1Var = this.f62e.getContext().get(n1.Z)) != null) {
            u0 N1 = q.N1(n1Var, true, false, new o(this), 2, (Object) null);
            this._parentHandle = N1;
            if (w() && !x()) {
                N1.dispose();
                this._parentHandle = y1.a;
            }
        }
    }

    public final v E(Object obj, Object obj2, ka.h.b.l<? super Throwable, Unit> lVar) {
        Object obj3;
        do {
            obj3 = this._state;
            if (obj3 instanceof z1) {
            } else if (!(obj3 instanceof x) || obj2 == null || ((x) obj3).d != obj2) {
                return null;
            } else {
                return m.a;
            }
        } while (!g.compareAndSet(this, obj3, C((z1) obj3, obj, this.c, lVar, obj2)));
        p();
        return m.a;
    }

    public void a(Object obj, Throwable th2) {
        while (true) {
            Object obj2 = this._state;
            if (obj2 instanceof z1) {
                throw new IllegalStateException("Not completed".toString());
            } else if (!(obj2 instanceof y)) {
                if (obj2 instanceof x) {
                    x xVar = (x) obj2;
                    if (!(xVar.f97e != null)) {
                        if (g.compareAndSet(this, obj2, x.a(xVar, (Object) null, (i) null, (ka.h.b.l) null, (Object) null, th2, 15))) {
                            i iVar = xVar.b;
                            if (iVar != null) {
                                i(iVar, th2);
                            }
                            ka.h.b.l<Throwable, Unit> lVar = xVar.c;
                            if (lVar != null) {
                                j(lVar, th2);
                                return;
                            }
                            return;
                        }
                    } else {
                        throw new IllegalStateException("Must be called at most once".toString());
                    }
                } else if (g.compareAndSet(this, obj2, new x(obj2, (i) null, (ka.h.b.l) null, (Object) null, th2, 14))) {
                    return;
                }
            } else {
                return;
            }
        }
    }

    public final ka.e.d<T> b() {
        return this.f62e;
    }

    public Throwable c(Object obj) {
        Throwable c = super.c(obj);
        if (c != null) {
            return c;
        }
        return null;
    }

    public Object d(T t, Object obj) {
        return E(t, obj, (ka.h.b.l<? super Throwable, Unit>) null);
    }

    public <T> T e(Object obj) {
        return obj instanceof x ? ((x) obj).a : obj;
    }

    public Object g() {
        return this._state;
    }

    public d getCallerFrame() {
        ka.e.d<T> dVar = this.f62e;
        if (!(dVar instanceof d)) {
            dVar = null;
        }
        return (d) dVar;
    }

    public f getContext() {
        return this.d;
    }

    public final void h(ka.h.b.l<? super Throwable, Unit> lVar, Throwable th2) {
        try {
            lVar.invoke(th2);
        } catch (Throwable th3) {
            f fVar = this.d;
            q.I1(fVar, new b0("Exception in invokeOnCancellation handler for " + this, th3));
        }
    }

    public final void i(i iVar, Throwable th2) {
        try {
            iVar.a(th2);
        } catch (Throwable th3) {
            f fVar = this.d;
            q.I1(fVar, new b0("Exception in invokeOnCancellation handler for " + this, th3));
        }
    }

    public boolean isActive() {
        return this._state instanceof z1;
    }

    public final void j(ka.h.b.l<? super Throwable, Unit> lVar, Throwable th2) {
        try {
            lVar.invoke(th2);
        } catch (Throwable th3) {
            f fVar = this.d;
            q.I1(fVar, new b0("Exception in resume onCancellation handler for " + this, th3));
        }
    }

    public final void k() {
        u0 u0Var = (u0) this._parentHandle;
        if (u0Var != null) {
            u0Var.dispose();
        }
        this._parentHandle = y1.a;
    }

    public void l(ka.h.b.l<? super Throwable, Unit> lVar) {
        i k1Var = lVar instanceof i ? (i) lVar : new k1(lVar);
        while (true) {
            Object obj = this._state;
            if (!(obj instanceof b)) {
                Throwable th2 = null;
                if (!(obj instanceof i)) {
                    boolean z = obj instanceof y;
                    boolean z2 = true;
                    if (z) {
                        y yVar = (y) obj;
                        if (yVar == null) {
                            throw null;
                        } else if (!y.b.compareAndSet(yVar, 0, 1)) {
                            y(lVar, obj);
                            throw null;
                        } else if (obj instanceof n) {
                            if (!z) {
                                obj = null;
                            }
                            y yVar2 = (y) obj;
                            if (yVar2 != null) {
                                th2 = yVar2.a;
                            }
                            h(lVar, th2);
                            return;
                        } else {
                            return;
                        }
                    } else if (obj instanceof x) {
                        x xVar = (x) obj;
                        if (xVar.b != null) {
                            y(lVar, obj);
                            throw null;
                        } else if (!(k1Var instanceof e)) {
                            if (xVar.f97e == null) {
                                z2 = false;
                            }
                            if (z2) {
                                h(lVar, xVar.f97e);
                                return;
                            } else {
                                if (g.compareAndSet(this, obj, x.a(xVar, (Object) null, k1Var, (ka.h.b.l) null, (Object) null, (Throwable) null, 29))) {
                                    return;
                                }
                            }
                        } else {
                            return;
                        }
                    } else if (!(k1Var instanceof e)) {
                        if (g.compareAndSet(this, obj, new x(obj, k1Var, (ka.h.b.l) null, (Object) null, (Throwable) null, 28))) {
                            return;
                        }
                    } else {
                        return;
                    }
                } else {
                    y(lVar, obj);
                    throw null;
                }
            } else if (g.compareAndSet(this, obj, k1Var)) {
                return;
            }
        }
    }

    public Object m(Throwable th2) {
        return E(new y(th2, false, 2), (Object) null, (ka.h.b.l<? super Throwable, Unit>) null);
    }

    public void n(T t, ka.h.b.l<? super Throwable, Unit> lVar) {
        B(t, this.c, lVar);
    }

    public boolean o(Throwable th2) {
        Object obj;
        boolean z;
        do {
            obj = this._state;
            if (!(obj instanceof z1)) {
                return false;
            }
            z = obj instanceof i;
        } while (!g.compareAndSet(this, obj, new n(this, th2, z)));
        if (!z) {
            obj = null;
        }
        i iVar = (i) obj;
        if (iVar != null) {
            i(iVar, th2);
        }
        p();
        r(this.c);
        return true;
    }

    public final void p() {
        if (!x()) {
            k();
        }
    }

    public Object q(T t, Object obj, ka.h.b.l<? super Throwable, Unit> lVar) {
        return E(t, (Object) null, lVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:0:0x0000 A[LOOP_START, MTH_ENTER_BLOCK] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void r(int r5) {
        /*
            r4 = this;
        L_0x0000:
            int r0 = r4._decision
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L_0x0016
            if (r0 != r1) goto L_0x000a
            r0 = r2
            goto L_0x0020
        L_0x000a:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "Already resumed"
            java.lang.String r0 = r0.toString()
            r5.<init>(r0)
            throw r5
        L_0x0016:
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r0 = f
            r3 = 2
            boolean r0 = r0.compareAndSet(r4, r2, r3)
            if (r0 == 0) goto L_0x0000
            r0 = r1
        L_0x0020:
            if (r0 == 0) goto L_0x0023
            return
        L_0x0023:
            ka.e.d r0 = r4.b()
            r3 = 4
            if (r5 != r3) goto L_0x002b
            r2 = r1
        L_0x002b:
            if (r2 != 0) goto L_0x007f
            boolean r3 = r0 instanceof oh.a.t2.h
            if (r3 == 0) goto L_0x007f
            boolean r5 = ka.b.q.Q1(r5)
            int r3 = r4.c
            boolean r3 = ka.b.q.Q1(r3)
            if (r5 != r3) goto L_0x007f
            r5 = r0
            oh.a.t2.h r5 = (oh.a.t2.h) r5
            oh.a.e0 r5 = r5.f
            ka.e.f r0 = r0.getContext()
            boolean r2 = r5.g0(r0)
            if (r2 == 0) goto L_0x0050
            r5.d0(r0, r4)
            goto L_0x0082
        L_0x0050:
            oh.a.i2 r5 = oh.a.i2.b
            oh.a.y0 r5 = oh.a.i2.a()
            boolean r0 = r5.v0()
            if (r0 == 0) goto L_0x0060
            r5.l0(r4)
            goto L_0x0082
        L_0x0060:
            r5.n0(r1)
            ka.e.d r0 = r4.b()     // Catch:{ all -> 0x0071 }
            ka.b.q.P2(r4, r0, r1)     // Catch:{ all -> 0x0071 }
        L_0x006a:
            boolean r0 = r5.x0()     // Catch:{ all -> 0x0071 }
            if (r0 != 0) goto L_0x006a
            goto L_0x0076
        L_0x0071:
            r0 = move-exception
            r2 = 0
            r4.f(r0, r2)     // Catch:{ all -> 0x007a }
        L_0x0076:
            r5.h0(r1)
            goto L_0x0082
        L_0x007a:
            r0 = move-exception
            r5.h0(r1)
            throw r0
        L_0x007f:
            ka.b.q.P2(r4, r0, r2)
        L_0x0082:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.l.r(int):void");
    }

    public void resumeWith(Object obj) {
        Throwable r0 = Result.exceptionOrNull-impl(obj);
        if (r0 != null) {
            obj = new y(r0, false, 2);
        }
        B(obj, this.c, (ka.h.b.l<? super Throwable, Unit>) null);
    }

    public Throwable s(n1 n1Var) {
        return n1Var.k();
    }

    @PublishedApi
    public final Object t() {
        boolean z;
        n1 n1Var;
        D();
        while (true) {
            int i = this._decision;
            z = false;
            if (i == 0) {
                if (f.compareAndSet(this, 0, 1)) {
                    z = true;
                    break;
                }
            } else if (i != 2) {
                throw new IllegalStateException("Already suspended".toString());
            }
        }
        if (z) {
            return ka.e.j.a.COROUTINE_SUSPENDED;
        }
        Object obj = this._state;
        if (obj instanceof y) {
            throw ((y) obj).a;
        } else if (!q.Q1(this.c) || (n1Var = this.d.get(n1.Z)) == null || n1Var.isActive()) {
            return e(obj);
        } else {
            CancellationException k = n1Var.k();
            a(obj, k);
            throw k;
        }
    }

    public String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append(A());
        sb.append('(');
        sb.append(q.E3(this.f62e));
        sb.append("){");
        Object obj = this._state;
        if (obj instanceof z1) {
            str = "Active";
        } else {
            str = obj instanceof n ? "Cancelled" : "Completed";
        }
        sb.append(str);
        sb.append("}@");
        sb.append(q.q1(this));
        return sb.toString();
    }

    public void u(e0 e0Var, T t) {
        ka.e.d<T> dVar = this.f62e;
        if (!(dVar instanceof h)) {
            dVar = null;
        }
        h hVar = (h) dVar;
        B(t, (hVar != null ? hVar.f : null) == e0Var ? 4 : this.c, (ka.h.b.l<? super Throwable, Unit>) null);
    }

    public void v() {
        D();
    }

    public boolean w() {
        return !(this._state instanceof z1);
    }

    public final boolean x() {
        h hVar = this.f62e;
        if (hVar instanceof h) {
            Object obj = hVar._reusableCancellableContinuation;
            if (obj != null && (!(obj instanceof l) || obj == this)) {
                return true;
            }
        }
        return false;
    }

    public final void y(ka.h.b.l<? super Throwable, Unit> lVar, Object obj) {
        throw new IllegalStateException(("It's prohibited to register multiple handlers, tried to register " + lVar + ", already has " + obj).toString());
    }

    public void z(Object obj) {
        r(this.c);
    }
}

package oh.a.w2;

import java.util.NoSuchElementException;
import ka.h.b.l;
import ka.h.c.p;
import ka.h.c.r;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import mh.c.r0.b.s;
import mh.c.r0.b.t;
import mh.c.r0.c.c;
import oh.a.k;

public final class d implements t<T> {
    public c a;
    public T b;
    public boolean c;
    public final /* synthetic */ k d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ a f96e;
    public final /* synthetic */ Object f;

    public static final class a extends r implements l<Throwable, Unit> {
        public final /* synthetic */ c a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(c cVar) {
            super(1);
            this.a = cVar;
        }

        public Object invoke(Object obj) {
            Throwable th2 = (Throwable) obj;
            this.a.dispose();
            return Unit.INSTANCE;
        }
    }

    public d(k kVar, s sVar, a aVar, Object obj) {
        this.d = kVar;
        this.f96e = aVar;
        this.f = obj;
    }

    public void a(c cVar) {
        this.a = cVar;
        this.d.l(new a(cVar));
    }

    public void onComplete() {
        if (this.c) {
            if (this.d.isActive()) {
                k kVar = this.d;
                T t = this.b;
                Result.Companion companion = Result.Companion;
                kVar.resumeWith(Result.constructor-impl(t));
            }
        } else if (this.f96e == a.FIRST_OR_DEFAULT) {
            k kVar2 = this.d;
            Object obj = this.f;
            Result.Companion companion2 = Result.Companion;
            kVar2.resumeWith(Result.constructor-impl(obj));
        } else if (this.d.isActive()) {
            k kVar3 = this.d;
            StringBuilder V0 = e.e.b.a.a.V0("No value received via onNext for ");
            V0.append(this.f96e);
            NoSuchElementException noSuchElementException = new NoSuchElementException(V0.toString());
            Result.Companion companion3 = Result.Companion;
            kVar3.resumeWith(Result.constructor-impl(ResultKt.createFailure(noSuchElementException)));
        }
    }

    public void onError(Throwable th2) {
        k kVar = this.d;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(th2)));
    }

    public void onNext(T t) {
        int ordinal = this.f96e.ordinal();
        if (ordinal == 0 || ordinal == 1) {
            if (!this.c) {
                this.c = true;
                k kVar = this.d;
                Result.Companion companion = Result.Companion;
                kVar.resumeWith(Result.constructor-impl(t));
                c cVar = this.a;
                if (cVar != null) {
                    cVar.dispose();
                } else {
                    p.l("subscription");
                    throw null;
                }
            }
        } else if (ordinal != 2 && ordinal != 3) {
        } else {
            if (this.f96e != a.SINGLE || !this.c) {
                this.b = t;
                this.c = true;
                return;
            }
            if (this.d.isActive()) {
                k kVar2 = this.d;
                StringBuilder V0 = e.e.b.a.a.V0("More than one onNext value for ");
                V0.append(this.f96e);
                IllegalArgumentException illegalArgumentException = new IllegalArgumentException(V0.toString());
                Result.Companion companion2 = Result.Companion;
                kVar2.resumeWith(Result.constructor-impl(ResultKt.createFailure(illegalArgumentException)));
            }
            c cVar2 = this.a;
            if (cVar2 != null) {
                cVar2.dispose();
            } else {
                p.l("subscription");
                throw null;
            }
        }
    }
}

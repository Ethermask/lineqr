package oh.a.w2;

import ka.e.f;
import ka.h.b.p;
import mh.c.r0.b.c;
import mh.c.r0.b.e;
import mh.c.r0.f.a.a;
import mh.c.r0.f.a.b;
import mh.c.r0.f.e.a.b;
import oh.a.c0;
import oh.a.h0;
import oh.a.i0;

public final class h implements e {
    public final /* synthetic */ h0 a;
    public final /* synthetic */ f b;
    public final /* synthetic */ p c;

    public h(h0 h0Var, f fVar, p pVar) {
        this.a = h0Var;
        this.b = fVar;
        this.c = pVar;
    }

    public final void a(c cVar) {
        g gVar = new g(c0.b(this.a, this.b), cVar);
        b.i((b.a) cVar, new a(new f(gVar)));
        gVar.x0(i0.DEFAULT, gVar, this.c);
    }
}

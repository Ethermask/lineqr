package oh.a.w2;

import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import mh.c.r0.b.d;
import mh.c.r0.c.c;
import oh.a.k;

public final class b implements d {
    public final /* synthetic */ k a;

    public b(k kVar) {
        this.a = kVar;
    }

    public void a(c cVar) {
        this.a.l(new e(cVar));
    }

    public void onComplete() {
        k kVar = this.a;
        Unit unit = Unit.INSTANCE;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(unit));
    }

    public void onError(Throwable th2) {
        k kVar = this.a;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(th2)));
    }
}

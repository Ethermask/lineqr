package oh.a.w2;

public enum a {
    FIRST("awaitFirst"),
    FIRST_OR_DEFAULT("awaitFirstOrDefault"),
    LAST("awaitLast"),
    SINGLE("awaitSingle");
    
    public final String s;

    /* access modifiers changed from: public */
    a(String str) {
        this.s = str;
    }

    public String toString() {
        return this.s;
    }
}

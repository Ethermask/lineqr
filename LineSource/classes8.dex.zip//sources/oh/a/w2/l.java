package oh.a.w2;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import mh.c.r0.b.m;
import mh.c.r0.b.t;
import mh.c.r0.c.c;
import oh.a.r2.n;

public final class l<T> extends n<T> implements t<T>, m<T> {
    public static final /* synthetic */ AtomicReferenceFieldUpdater d = AtomicReferenceFieldUpdater.newUpdater(l.class, Object.class, "_subscription");
    public volatile /* synthetic */ Object _subscription = null;

    public l() {
        super((ka.h.b.l) null);
    }

    public void a(c cVar) {
        this._subscription = cVar;
    }

    public void o(oh.a.t2.l lVar) {
        c cVar = (c) d.getAndSet(this, (Object) null);
        if (cVar != null) {
            cVar.dispose();
        }
    }

    public void onComplete() {
        w((Throwable) null);
    }

    public void onError(Throwable th2) {
        w(th2);
    }

    public void onNext(T t) {
        offer(t);
    }

    public void onSuccess(T t) {
        offer(t);
    }
}

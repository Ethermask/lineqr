package oh.a.w2;

import java.util.concurrent.CancellationException;
import ka.e.d;
import ka.e.f;
import ka.h.b.p;
import kotlin.ResultKt;
import kotlin.Unit;
import mh.c.r0.b.q;
import mh.c.r0.b.r;
import mh.c.r0.f.a.b;
import mh.c.r0.f.e.e.d;
import oh.a.g1;
import oh.a.h0;
import oh.a.i0;
import oh.a.s0;
import oh.a.s2.e;

public final class i<T> implements r<T> {
    public final /* synthetic */ e a;
    public final /* synthetic */ f b;

    @ka.e.k.a.e(c = "kotlinx.coroutines.rx3.RxConvertKt$asObservable$1$job$1", f = "RxConvert.kt", l = {157}, m = "invokeSuspend")
    public static final class a extends ka.e.k.a.i implements p<h0, d<? super Unit>, Object> {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ i c;
        public final /* synthetic */ q d;

        /* renamed from: oh.a.w2.i$a$a  reason: collision with other inner class name */
        public static final class C0007a implements oh.a.s2.f<T> {
            public final /* synthetic */ a a;

            public C0007a(a aVar) {
                this.a = aVar;
            }

            public Object a(Object obj, d dVar) {
                this.a.d.onNext(obj);
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(i iVar, q qVar, d dVar) {
            super(2, dVar);
            this.c = iVar;
            this.d = qVar;
        }

        public final d<Unit> create(Object obj, d<?> dVar) {
            a aVar = new a(this.c, this.d, dVar);
            aVar.a = obj;
            return aVar;
        }

        public final Object invoke(Object obj, Object obj2) {
            a aVar = new a(this.c, this.d, (d) obj2);
            aVar.a = obj;
            return aVar.invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            Throwable th2;
            h0 h0Var;
            ka.e.j.a aVar = ka.e.j.a.COROUTINE_SUSPENDED;
            int i = this.b;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                h0 h0Var2 = (h0) this.a;
                try {
                    e eVar = this.c.a;
                    C0007a aVar2 = new C0007a(this);
                    this.a = h0Var2;
                    this.b = 1;
                    if (eVar.c(aVar2, this) == aVar) {
                        return aVar;
                    }
                    h0Var = h0Var2;
                } catch (Throwable th3) {
                    Throwable th4 = th3;
                    h0Var = h0Var2;
                    th2 = th4;
                    if (th2 instanceof CancellationException) {
                        this.d.onComplete();
                    } else if (!this.d.a(th2)) {
                        ka.b.q.K1(th2, h0Var.getCoroutineContext());
                    }
                    return Unit.INSTANCE;
                }
            } else if (i == 1) {
                h0Var = (h0) this.a;
                try {
                    ResultKt.throwOnFailure(obj);
                } catch (Throwable th5) {
                    th2 = th5;
                }
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            this.d.onComplete();
            return Unit.INSTANCE;
        }
    }

    public i(e eVar, f fVar) {
        this.a = eVar;
        this.b = fVar;
    }

    public final void a(q<T> qVar) {
        b.i((d.a) qVar, new mh.c.r0.f.a.a(new f(ka.b.q.W1(g1.a, s0.b.plus(this.b), i0.ATOMIC, new a(this, qVar, (ka.e.d) null)))));
    }
}

package oh.a.w2;

import ka.b.q;
import ka.e.f;
import kotlin.Unit;
import mh.c.r0.b.c;
import oh.a.a;

public final class g extends a<Unit> {
    public final c d;

    public g(f fVar, c cVar) {
        super(fVar, true);
        this.d = cVar;
    }

    public void u0(Throwable th2, boolean z) {
        try {
            if (!this.d.b(th2)) {
                q.K1(th2, this.b);
            }
        } catch (Throwable th3) {
            q.K1(th3, this.b);
        }
    }

    public void v0(Object obj) {
        Unit unit = (Unit) obj;
        try {
            this.d.a();
        } catch (Throwable th2) {
            q.K1(th2, this.b);
        }
    }
}

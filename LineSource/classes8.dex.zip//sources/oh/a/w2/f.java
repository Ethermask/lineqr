package oh.a.w2;

import java.util.concurrent.CancellationException;
import ka.b.q;
import mh.c.r0.e.d;
import oh.a.n1;

public final class f implements d {
    public final n1 a;

    public f(n1 n1Var) {
        this.a = n1Var;
    }

    public void cancel() {
        q.R(this.a, (CancellationException) null, 1, (Object) null);
    }
}

package oh.a.w2;

import ka.h.b.l;
import ka.h.c.r;
import kotlin.Unit;
import mh.c.r0.c.c;

public final class e extends r implements l<Throwable, Unit> {
    public final /* synthetic */ c a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public e(c cVar) {
        super(1);
        this.a = cVar;
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        this.a.dispose();
        return Unit.INSTANCE;
    }
}

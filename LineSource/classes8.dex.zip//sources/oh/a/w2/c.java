package oh.a.w2;

import kotlin.Result;
import kotlin.ResultKt;
import mh.c.r0.b.x;
import oh.a.k;

public final class c implements x<T> {
    public final /* synthetic */ k a;

    public c(k kVar) {
        this.a = kVar;
    }

    public void a(mh.c.r0.c.c cVar) {
        this.a.l(new e(cVar));
    }

    public void onError(Throwable th2) {
        k kVar = this.a;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(th2)));
    }

    public void onSuccess(T t) {
        k kVar = this.a;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(t));
    }
}

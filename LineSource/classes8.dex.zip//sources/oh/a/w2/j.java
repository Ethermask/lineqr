package oh.a.w2;

import ka.b.q;
import ka.e.f;
import mh.c.r0.b.w;
import oh.a.a;

public final class j<T> extends a<T> {
    public final w<T> d;

    public j(f fVar, w<T> wVar) {
        super(fVar, true);
        this.d = wVar;
    }

    public void u0(Throwable th2, boolean z) {
        try {
            if (!this.d.a(th2)) {
                q.K1(th2, this.b);
            }
        } catch (Throwable th3) {
            q.K1(th3, this.b);
        }
    }

    public void v0(T t) {
        try {
            this.d.onSuccess(t);
        } catch (Throwable th2) {
            q.K1(th2, this.b);
        }
    }
}

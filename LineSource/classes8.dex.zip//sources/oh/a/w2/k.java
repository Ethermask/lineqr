package oh.a.w2;

import ka.e.f;
import ka.h.b.p;
import mh.c.r0.b.w;
import mh.c.r0.b.y;
import oh.a.c0;
import oh.a.h0;
import oh.a.i0;

public final class k<T> implements y<T> {
    public final /* synthetic */ h0 a;
    public final /* synthetic */ f b;
    public final /* synthetic */ p c;

    public k(h0 h0Var, f fVar, p pVar) {
        this.a = h0Var;
        this.b = fVar;
        this.c = pVar;
    }

    public final void a(w<T> wVar) {
        j jVar = new j(c0.b(this.a, this.b), wVar);
        wVar.b(new f(jVar));
        jVar.x0(i0.DEFAULT, jVar, this.c);
    }
}

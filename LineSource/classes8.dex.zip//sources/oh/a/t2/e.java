package oh.a.t2;

public final class e {
    public static final v a = new v("CLOSED");
}

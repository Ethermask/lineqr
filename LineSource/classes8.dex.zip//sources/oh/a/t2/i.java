package oh.a.t2;

import ka.e.d;
import ka.h.b.l;
import kotlin.Unit;

public final class i {
    public static final v a = new v("UNDEFINED");
    public static final v b = new v("REUSABLE_CLAIMED");

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0097, code lost:
        if (r8.y0() != false) goto L_0x0099;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final <T> void a(ka.e.d<? super T> r6, java.lang.Object r7, ka.h.b.l<? super java.lang.Throwable, kotlin.Unit> r8) {
        /*
            boolean r0 = r6 instanceof oh.a.t2.h
            if (r0 == 0) goto L_0x00be
            oh.a.t2.h r6 = (oh.a.t2.h) r6
            java.lang.Object r8 = ka.b.q.U3(r7, r8)
            oh.a.e0 r0 = r6.f
            ka.e.f r1 = r6.getContext()
            boolean r0 = r0.g0(r1)
            r1 = 1
            if (r0 == 0) goto L_0x0026
            r6.d = r8
            r6.c = r1
            oh.a.e0 r7 = r6.f
            ka.e.f r8 = r6.getContext()
            r7.d0(r8, r6)
            goto L_0x00c1
        L_0x0026:
            oh.a.i2 r0 = oh.a.i2.b
            oh.a.y0 r0 = oh.a.i2.a()
            boolean r2 = r0.v0()
            if (r2 == 0) goto L_0x003b
            r6.d = r8
            r6.c = r1
            r0.l0(r6)
            goto L_0x00c1
        L_0x003b:
            r0.n0(r1)
            r2 = 0
            ka.e.f r3 = r6.getContext()     // Catch:{ all -> 0x00b1 }
            oh.a.n1$a r4 = oh.a.n1.Z     // Catch:{ all -> 0x00b1 }
            ka.e.f$a r3 = r3.get(r4)     // Catch:{ all -> 0x00b1 }
            oh.a.n1 r3 = (oh.a.n1) r3     // Catch:{ all -> 0x00b1 }
            if (r3 == 0) goto L_0x0071
            boolean r4 = r3.isActive()     // Catch:{ all -> 0x00b1 }
            if (r4 != 0) goto L_0x0071
            java.util.concurrent.CancellationException r3 = r3.k()     // Catch:{ all -> 0x00b1 }
            boolean r4 = r8 instanceof oh.a.z     // Catch:{ all -> 0x00b1 }
            if (r4 == 0) goto L_0x0062
            oh.a.z r8 = (oh.a.z) r8     // Catch:{ all -> 0x00b1 }
            ka.h.b.l<java.lang.Throwable, kotlin.Unit> r8 = r8.b     // Catch:{ all -> 0x00b1 }
            r8.invoke(r3)     // Catch:{ all -> 0x00b1 }
        L_0x0062:
            kotlin.Result$Companion r8 = kotlin.Result.Companion     // Catch:{ all -> 0x00b1 }
            java.lang.Object r8 = kotlin.ResultKt.createFailure(r3)     // Catch:{ all -> 0x00b1 }
            java.lang.Object r8 = kotlin.Result.constructor-impl(r8)     // Catch:{ all -> 0x00b1 }
            r6.resumeWith(r8)     // Catch:{ all -> 0x00b1 }
            r8 = r1
            goto L_0x0072
        L_0x0071:
            r8 = 0
        L_0x0072:
            if (r8 != 0) goto L_0x00aa
            ka.e.d<T> r8 = r6.g     // Catch:{ all -> 0x00b1 }
            java.lang.Object r3 = r6.f90e     // Catch:{ all -> 0x00b1 }
            ka.e.f r4 = r8.getContext()     // Catch:{ all -> 0x00b1 }
            java.lang.Object r3 = oh.a.t2.x.c(r4, r3)     // Catch:{ all -> 0x00b1 }
            oh.a.t2.v r5 = oh.a.t2.x.a     // Catch:{ all -> 0x00b1 }
            if (r3 == r5) goto L_0x0089
            oh.a.n2 r8 = oh.a.c0.c(r8, r4, r3)     // Catch:{ all -> 0x00b1 }
            goto L_0x008a
        L_0x0089:
            r8 = r2
        L_0x008a:
            ka.e.d<T> r5 = r6.g     // Catch:{ all -> 0x009d }
            r5.resumeWith(r7)     // Catch:{ all -> 0x009d }
            kotlin.Unit r7 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x009d }
            if (r8 == 0) goto L_0x0099
            boolean r7 = r8.y0()     // Catch:{ all -> 0x00b1 }
            if (r7 == 0) goto L_0x00aa
        L_0x0099:
            oh.a.t2.x.a(r4, r3)     // Catch:{ all -> 0x00b1 }
            goto L_0x00aa
        L_0x009d:
            r7 = move-exception
            if (r8 == 0) goto L_0x00a6
            boolean r8 = r8.y0()     // Catch:{ all -> 0x00b1 }
            if (r8 == 0) goto L_0x00a9
        L_0x00a6:
            oh.a.t2.x.a(r4, r3)     // Catch:{ all -> 0x00b1 }
        L_0x00a9:
            throw r7     // Catch:{ all -> 0x00b1 }
        L_0x00aa:
            boolean r7 = r0.x0()     // Catch:{ all -> 0x00b1 }
            if (r7 != 0) goto L_0x00aa
            goto L_0x00b5
        L_0x00b1:
            r7 = move-exception
            r6.f(r7, r2)     // Catch:{ all -> 0x00b9 }
        L_0x00b5:
            r0.h0(r1)
            goto L_0x00c1
        L_0x00b9:
            r6 = move-exception
            r0.h0(r1)
            throw r6
        L_0x00be:
            r6.resumeWith(r7)
        L_0x00c1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.t2.i.a(ka.e.d, java.lang.Object, ka.h.b.l):void");
    }

    public static /* synthetic */ void b(d dVar, Object obj, l lVar, int i) {
        int i2 = i & 2;
        a(dVar, obj, (l<? super Throwable, Unit>) null);
    }
}

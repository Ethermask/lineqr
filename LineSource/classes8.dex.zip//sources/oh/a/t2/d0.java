package oh.a.t2;

public final class d0 extends RuntimeException {
    public d0(String str, Throwable th2) {
        super(str, th2);
    }
}

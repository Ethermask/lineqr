package oh.a.t2;

import ka.e.f;
import oh.a.h2;

public final class c0 {
    public final Object[] a;
    public final h2<Object>[] b;
    public int c;
    public final f d;

    public c0(f fVar, int i) {
        this.d = fVar;
        this.a = new Object[i];
        this.b = new h2[i];
    }
}

package oh.a.t2;

import e.e.b.a.a;

public final class r {
    public final l a;

    public r(l lVar) {
        this.a = lVar;
    }

    public String toString() {
        StringBuilder V0 = a.V0("Removed[");
        V0.append(this.a);
        V0.append(']');
        return V0.toString();
    }
}

package oh.a.t2;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public abstract class c<T> extends q {
    public static final /* synthetic */ AtomicReferenceFieldUpdater a = AtomicReferenceFieldUpdater.newUpdater(c.class, Object.class, "_consensus");
    public volatile /* synthetic */ Object _consensus = b.a;

    public final Object a(Object obj) {
        Object obj2 = this._consensus;
        if (obj2 == b.a) {
            obj2 = c(obj);
            Object obj3 = this._consensus;
            Object obj4 = b.a;
            if (obj3 != obj4) {
                obj2 = obj3;
            } else if (!a.compareAndSet(this, obj4, obj2)) {
                obj2 = this._consensus;
            }
        }
        b(obj, obj2);
        return obj2;
    }

    public abstract void b(T t, Object obj);

    public abstract Object c(T t);
}

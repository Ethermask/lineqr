package oh.a.t2;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class m<E> {
    public static final /* synthetic */ AtomicReferenceFieldUpdater a = AtomicReferenceFieldUpdater.newUpdater(m.class, Object.class, "_cur");
    public volatile /* synthetic */ Object _cur;

    public m(boolean z) {
        this._cur = new n(8, z);
    }

    public final boolean a(E e2) {
        while (true) {
            n nVar = (n) this._cur;
            int a2 = nVar.a(e2);
            if (a2 == 0) {
                return true;
            }
            if (a2 == 1) {
                a.compareAndSet(this, nVar, nVar.d());
            } else if (a2 == 2) {
                return false;
            }
        }
    }

    public final void b() {
        while (true) {
            n nVar = (n) this._cur;
            if (!nVar.b()) {
                a.compareAndSet(this, nVar, nVar.d());
            } else {
                return;
            }
        }
    }

    public final int c() {
        long j = ((n) this._cur)._state;
        return (((int) ((j & 1152921503533105152L) >> 30)) - ((int) ((1073741823 & j) >> 0))) & 1073741823;
    }

    public final E d() {
        while (true) {
            n nVar = (n) this._cur;
            E e2 = nVar.e();
            if (e2 != n.g) {
                return e2;
            }
            a.compareAndSet(this, nVar, nVar.d());
        }
    }
}

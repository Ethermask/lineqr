package oh.a.t2;

import e.e.b.a.a;
import ka.e.f;
import ka.e.h;
import ka.h.b.p;
import oh.a.h2;

public final class y<T> implements h2<T> {
    public final f.b<?> a;
    public final T b;
    public final ThreadLocal<T> c;

    public y(T t, ThreadLocal<T> threadLocal) {
        this.b = t;
        this.c = threadLocal;
        this.a = new z(threadLocal);
    }

    public void F(f fVar, T t) {
        this.c.set(t);
    }

    public T a0(f fVar) {
        T t = this.c.get();
        this.c.set(this.b);
        return t;
    }

    public <R> R fold(R r, p<? super R, ? super f.a, ? extends R> pVar) {
        return f.a.a.a(this, r, pVar);
    }

    public <E extends f.a> E get(f.b<E> bVar) {
        if (ka.h.c.p.b(this.a, bVar)) {
            return this;
        }
        return null;
    }

    public f.b<?> getKey() {
        return this.a;
    }

    public f minusKey(f.b<?> bVar) {
        return ka.h.c.p.b(this.a, bVar) ? h.a : this;
    }

    public f plus(f fVar) {
        return f.a.a.d(this, fVar);
    }

    public String toString() {
        StringBuilder V0 = a.V0("ThreadLocal(value=");
        V0.append(this.b);
        V0.append(", threadLocal = ");
        V0.append(this.c);
        V0.append(')');
        return V0.toString();
    }
}

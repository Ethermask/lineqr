package oh.a.t2;

import ka.b.q;
import ka.e.f;
import ka.e.k.a.d;
import ka.h.b.l;
import oh.a.a;

public class s<T> extends a<T> implements d {
    public final ka.e.d<T> d;

    public s(f fVar, ka.e.d<? super T> dVar) {
        super(fVar, true);
        this.d = dVar;
    }

    public void C(Object obj) {
        i.b(q.M1(this.d), q.J2(obj, this.d), (l) null, 2);
    }

    public final boolean b0() {
        return true;
    }

    public final d getCallerFrame() {
        ka.e.d<T> dVar = this.d;
        if (!(dVar instanceof d)) {
            dVar = null;
        }
        return (d) dVar;
    }

    public void s0(Object obj) {
        ka.e.d<T> dVar = this.d;
        dVar.resumeWith(q.J2(obj, dVar));
    }
}

package oh.a.t2;

import kotlin.Result;
import kotlin.ResultKt;

public final class u {
    public static final String a;
    public static final String b;

    static {
        Object obj;
        Object obj2;
        try {
            Result.Companion companion = Result.Companion;
            obj = Result.constructor-impl(Class.forName("ka.e.k.a.a").getCanonicalName());
        } catch (Throwable th2) {
            Result.Companion companion2 = Result.Companion;
            obj = Result.constructor-impl(ResultKt.createFailure(th2));
        }
        if (Result.exceptionOrNull-impl(obj) != null) {
            obj = "kotlin.coroutines.jvm.internal.BaseContinuationImpl";
        }
        a = (String) obj;
        try {
            Result.Companion companion3 = Result.Companion;
            obj2 = Result.constructor-impl(Class.forName("oh.a.t2.u").getCanonicalName());
        } catch (Throwable th3) {
            Result.Companion companion4 = Result.Companion;
            obj2 = Result.constructor-impl(ResultKt.createFailure(th3));
        }
        if (Result.exceptionOrNull-impl(obj2) != null) {
            obj2 = "kotlinx.coroutines.internal.StackTraceRecoveryKt";
        }
        b = (String) obj2;
    }

    public static final <E extends Throwable> E a(E e2) {
        return e2;
    }
}

package oh.a.t2;

public final class k {
    public static final Object a = new v("CONDITION_FALSE");
}

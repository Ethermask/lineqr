package oh.a.t2;

import ka.b.q;
import ka.e.f;
import ka.h.b.l;
import ka.h.c.r;
import kotlin.Unit;

public final class p extends r implements l<Throwable, Unit> {
    public final /* synthetic */ l a;
    public final /* synthetic */ Object b;
    public final /* synthetic */ f c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public p(l lVar, Object obj, f fVar) {
        super(1);
        this.a = lVar;
        this.b = obj;
        this.c = fVar;
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        l lVar = this.a;
        Object obj2 = this.b;
        f fVar = this.c;
        d0 L = q.L(lVar, obj2, (d0) null);
        if (L != null) {
            q.I1(fVar, L);
        }
        return Unit.INSTANCE;
    }
}

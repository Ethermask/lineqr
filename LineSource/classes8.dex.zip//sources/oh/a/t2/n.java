package oh.a.t2;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class n<E> {

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f91e;
    public static final /* synthetic */ AtomicLongFieldUpdater f;
    public static final v g = new v("REMOVE_FROZEN");
    public static final a h = new a((DefaultConstructorMarker) null);
    public volatile /* synthetic */ Object _next = null;
    public volatile /* synthetic */ long _state = 0;
    public final int a;
    public /* synthetic */ AtomicReferenceArray b = new AtomicReferenceArray(this.c);
    public final int c;
    public final boolean d;

    public static final class a {
        public a(DefaultConstructorMarker defaultConstructorMarker) {
        }
    }

    public static final class b {
        public final int a;

        public b(int i) {
            this.a = i;
        }
    }

    static {
        Class<n> cls = n.class;
        f91e = AtomicReferenceFieldUpdater.newUpdater(cls, Object.class, "_next");
        f = AtomicLongFieldUpdater.newUpdater(cls, "_state");
    }

    public n(int i, boolean z) {
        this.c = i;
        this.d = z;
        boolean z2 = true;
        this.a = i - 1;
        if (this.a <= 1073741823) {
            if (!((this.c & this.a) != 0 ? false : z2)) {
                throw new IllegalStateException("Check failed.".toString());
            }
            return;
        }
        throw new IllegalStateException("Check failed.".toString());
    }

    public final int a(E e2) {
        while (true) {
            long j = this._state;
            if ((3458764513820540928L & j) != 0) {
                return (j & 2305843009213693952L) != 0 ? 2 : 1;
            }
            int i = (int) ((1073741823 & j) >> 0);
            int i2 = (int) ((1152921503533105152L & j) >> 30);
            int i3 = this.a;
            if (((i2 + 2) & i3) == (i & i3)) {
                return 1;
            }
            if (this.d || this.b.get(i2 & i3) == null) {
                if (f.compareAndSet(this, j, (-1152921503533105153L & j) | (((long) ((i2 + 1) & 1073741823)) << 30))) {
                    this.b.set(i2 & i3, e2);
                    n nVar = this;
                    while ((nVar._state & 1152921504606846976L) != 0) {
                        nVar = nVar.d();
                        Object obj = nVar.b.get(nVar.a & i2);
                        if (!(obj instanceof b) || ((b) obj).a != i2) {
                            nVar = null;
                            continue;
                        } else {
                            nVar.b.set(nVar.a & i2, e2);
                            continue;
                        }
                        if (nVar == null) {
                            break;
                        }
                    }
                    return 0;
                }
            } else {
                int i4 = this.c;
                if (i4 < 1024 || ((i2 - i) & 1073741823) > (i4 >> 1)) {
                    return 1;
                }
            }
        }
        return 1;
    }

    public final boolean b() {
        long j;
        do {
            j = this._state;
            if ((j & 2305843009213693952L) != 0) {
                return true;
            }
            if ((1152921504606846976L & j) != 0) {
                return false;
            }
        } while (!f.compareAndSet(this, j, j | 2305843009213693952L));
        return true;
    }

    public final boolean c() {
        long j = this._state;
        return ((int) ((1073741823 & j) >> 0)) == ((int) ((j & 1152921503533105152L) >> 30));
    }

    /* JADX WARNING: Removed duplicated region for block: B:0:0x0000 A[LOOP_START, MTH_ENTER_BLOCK] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final oh.a.t2.n<E> d() {
        /*
            r10 = this;
        L_0x0000:
            long r2 = r10._state
            r0 = 1152921504606846976(0x1000000000000000, double:1.2882297539194267E-231)
            long r4 = r2 & r0
            r6 = 0
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 == 0) goto L_0x000d
            goto L_0x001a
        L_0x000d:
            long r6 = r2 | r0
            java.util.concurrent.atomic.AtomicLongFieldUpdater r0 = f
            r1 = r10
            r4 = r6
            boolean r0 = r0.compareAndSet(r1, r2, r4)
            if (r0 == 0) goto L_0x0000
            r2 = r6
        L_0x001a:
            java.lang.Object r0 = r10._next
            oh.a.t2.n r0 = (oh.a.t2.n) r0
            if (r0 == 0) goto L_0x0021
            return r0
        L_0x0021:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = f91e
            r1 = 0
            oh.a.t2.n r4 = new oh.a.t2.n
            int r5 = r10.c
            int r5 = r5 * 2
            boolean r6 = r10.d
            r4.<init>(r5, r6)
            r5 = 1073741823(0x3fffffff, double:5.304989472E-315)
            long r5 = r5 & r2
            r7 = 0
            long r5 = r5 >> r7
            int r5 = (int) r5
            r6 = 1152921503533105152(0xfffffffc0000000, double:1.2882296003504729E-231)
            long r6 = r6 & r2
            r8 = 30
            long r6 = r6 >> r8
            int r6 = (int) r6
        L_0x0040:
            int r7 = r10.a
            r8 = r5 & r7
            r7 = r7 & r6
            if (r8 == r7) goto L_0x0060
            java.util.concurrent.atomic.AtomicReferenceArray r7 = r10.b
            java.lang.Object r7 = r7.get(r8)
            if (r7 == 0) goto L_0x0050
            goto L_0x0055
        L_0x0050:
            oh.a.t2.n$b r7 = new oh.a.t2.n$b
            r7.<init>(r5)
        L_0x0055:
            java.util.concurrent.atomic.AtomicReferenceArray r8 = r4.b
            int r9 = r4.a
            r9 = r9 & r5
            r8.set(r9, r7)
            int r5 = r5 + 1
            goto L_0x0040
        L_0x0060:
            r5 = -1152921504606846977(0xefffffffffffffff, double:-3.1050361846014175E231)
            long r5 = r5 & r2
            r4._state = r5
            r0.compareAndSet(r10, r1, r4)
            goto L_0x001a
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.t2.n.d():oh.a.t2.n");
    }

    public final Object e() {
        while (true) {
            long j = this._state;
            if ((j & 1152921504606846976L) != 0) {
                return g;
            }
            int i = (int) ((j & 1073741823) >> 0);
            int i2 = this.a;
            int i3 = ((int) ((1152921503533105152L & j) >> 30)) & i2;
            int i4 = i2 & i;
            if (i3 == i4) {
                return null;
            }
            Object obj = this.b.get(i4);
            if (obj == null) {
                if (this.d) {
                    return null;
                }
            } else if (obj instanceof b) {
                return null;
            } else {
                long j2 = ((long) ((i + 1) & 1073741823)) << 0;
                Object obj2 = obj;
                if (f.compareAndSet(this, j, (j & -1073741824) | j2)) {
                    this.b.set(this.a & i, (Object) null);
                    return obj2;
                } else if (this.d) {
                    n nVar = this;
                    while (true) {
                        long j3 = nVar._state;
                        int i5 = (int) ((j3 & 1073741823) >> 0);
                        if ((j3 & 1152921504606846976L) != 0) {
                            nVar = nVar.d();
                        } else {
                            if (f.compareAndSet(nVar, j3, (j3 & -1073741824) | j2)) {
                                nVar.b.set(nVar.a & i5, (Object) null);
                                nVar = null;
                            } else {
                                continue;
                            }
                        }
                        if (nVar == null) {
                            return obj2;
                        }
                    }
                }
            }
        }
    }
}

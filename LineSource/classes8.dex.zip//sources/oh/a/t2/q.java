package oh.a.t2;

public abstract class q {
    public abstract Object a(Object obj);

    public String toString() {
        return getClass().getSimpleName() + '@' + ka.b.q.q1(this);
    }
}

package oh.a.t2;

import ka.e.f;
import ka.h.b.p;
import ka.h.c.r;
import oh.a.h2;

public final class x {
    public static final v a = new v("NO_THREAD_ELEMENTS");
    public static final p<Object, f.a, Object> b = a.a;
    public static final p<h2<?>, f.a, h2<?>> c = b.a;
    public static final p<c0, f.a, c0> d = c.a;

    public static final class a extends r implements p<Object, f.a, Object> {
        public static final a a = new a();

        public a() {
            super(2);
        }

        public Object invoke(Object obj, Object obj2) {
            f.a aVar = (f.a) obj2;
            if (!(aVar instanceof h2)) {
                return obj;
            }
            if (!(obj instanceof Integer)) {
                obj = null;
            }
            Integer num = (Integer) obj;
            int intValue = num != null ? num.intValue() : 1;
            if (intValue == 0) {
                return aVar;
            }
            return Integer.valueOf(intValue + 1);
        }
    }

    public static final class b extends r implements p<h2<?>, f.a, h2<?>> {
        public static final b a = new b();

        public b() {
            super(2);
        }

        public Object invoke(Object obj, Object obj2) {
            h2 h2Var = (h2) obj;
            h2 h2Var2 = (f.a) obj2;
            if (h2Var != null) {
                return h2Var;
            }
            if (!(h2Var2 instanceof h2)) {
                h2Var2 = null;
            }
            return h2Var2;
        }
    }

    public static final class c extends r implements p<c0, f.a, c0> {
        public static final c a = new c();

        public c() {
            super(2);
        }

        public Object invoke(Object obj, Object obj2) {
            c0 c0Var = (c0) obj;
            h2<Object> h2Var = (f.a) obj2;
            if (h2Var instanceof h2) {
                h2<Object> h2Var2 = h2Var;
                Object a0 = h2Var2.a0(c0Var.d);
                Object[] objArr = c0Var.a;
                int i = c0Var.c;
                objArr[i] = a0;
                h2<Object>[] h2VarArr = c0Var.b;
                c0Var.c = i + 1;
                h2VarArr[i] = h2Var2;
            }
            return c0Var;
        }
    }

    public static final void a(f fVar, Object obj) {
        if (obj != a) {
            if (obj instanceof c0) {
                c0 c0Var = (c0) obj;
                int length = c0Var.b.length;
                while (true) {
                    length--;
                    if (length >= 0) {
                        h2<Object> h2Var = c0Var.b[length];
                        ka.h.c.p.c(h2Var);
                        h2Var.F(fVar, c0Var.a[length]);
                    } else {
                        return;
                    }
                }
            } else {
                Object fold = fVar.fold((Object) null, c);
                if (fold != null) {
                    ((h2) fold).F(fVar, obj);
                    return;
                }
                throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.ThreadContextElement<kotlin.Any?>");
            }
        }
    }

    public static final Object b(f fVar) {
        Object fold = fVar.fold(0, b);
        ka.h.c.p.c(fold);
        return fold;
    }

    public static final Object c(f fVar, Object obj) {
        if (obj == null) {
            obj = b(fVar);
        }
        if (obj == 0) {
            return a;
        }
        if (obj instanceof Integer) {
            return fVar.fold(new c0(fVar, ((Number) obj).intValue()), d);
        }
        return ((h2) obj).a0(fVar);
    }
}

package oh.a.t2;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import oh.a.t2.t;
import oh.a.y2.k;
import qh.b;

public abstract class t<S extends t<S>> extends f<S> {
    public static final /* synthetic */ AtomicIntegerFieldUpdater d = AtomicIntegerFieldUpdater.newUpdater(t.class, "cleanedAndPointers");
    public final long c;
    public volatile /* synthetic */ int cleanedAndPointers;

    public t(long j, S s, int i) {
        super(s);
        this.c = j;
        this.cleanedAndPointers = i << 16;
    }

    public boolean b() {
        return this.cleanedAndPointers == k.f && !c();
    }

    public final boolean e() {
        return d.addAndGet(this, -65536) == k.f && !c();
    }

    public final boolean f() {
        int i;
        do {
            i = this.cleanedAndPointers;
            if (!(i != k.f || c())) {
                return false;
            }
        } while (!d.compareAndSet(this, i, b.TIMEOUT_WRITE_SIZE + i));
        return true;
    }
}

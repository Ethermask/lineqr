package oh.a.t2;

import e.e.b.a.a;
import ka.e.f;
import oh.a.h0;

public final class g implements h0 {
    public final f a;

    public g(f fVar) {
        this.a = fVar;
    }

    public f getCoroutineContext() {
        return this.a;
    }

    public String toString() {
        StringBuilder V0 = a.V0("CoroutineScope(coroutineContext=");
        V0.append(this.a);
        V0.append(')');
        return V0.toString();
    }
}

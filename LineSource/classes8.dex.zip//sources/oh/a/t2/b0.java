package oh.a.t2;

public interface b0 {
    void K(int i);

    void a(a0<?> a0Var);

    a0<?> f();

    int getIndex();
}

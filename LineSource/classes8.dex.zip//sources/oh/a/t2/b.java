package oh.a.t2;

public final class b {
    public static final Object a = new v("NO_DECISION");
}

package oh.a.t2;

public class a<T> {
    public Object[] a = new Object[16];
    public int b;
    public int c;
}

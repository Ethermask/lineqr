package oh.a.t2;

import e.e.b.a.a;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.b.q;
import ka.e.f;
import ka.e.k.a.d;
import ka.h.b.l;
import kotlin.Unit;
import oh.a.e0;
import oh.a.i2;
import oh.a.q0;
import oh.a.y0;
import oh.a.z;

public final class h<T> extends q0<T> implements d, ka.e.d<T> {
    public static final /* synthetic */ AtomicReferenceFieldUpdater h = AtomicReferenceFieldUpdater.newUpdater(h.class, Object.class, "_reusableCancellableContinuation");
    public volatile /* synthetic */ Object _reusableCancellableContinuation = null;
    public Object d = i.a;

    /* renamed from: e  reason: collision with root package name */
    public final Object f90e = x.b(getContext());
    public final e0 f;
    public final ka.e.d<T> g;

    public h(e0 e0Var, ka.e.d<? super T> dVar) {
        super(-1);
        this.f = e0Var;
        this.g = dVar;
    }

    public void a(Object obj, Throwable th2) {
        if (obj instanceof z) {
            ((z) obj).b.invoke(th2);
        }
    }

    public ka.e.d<T> b() {
        return this;
    }

    public Object g() {
        Object obj = this.d;
        this.d = i.a;
        return obj;
    }

    public d getCallerFrame() {
        ka.e.d<T> dVar = this.g;
        if (!(dVar instanceof d)) {
            dVar = null;
        }
        return (d) dVar;
    }

    public f getContext() {
        return this.g.getContext();
    }

    public void resumeWith(Object obj) {
        f context;
        Object c;
        f context2 = this.g.getContext();
        Object U3 = q.U3(obj, (l) null);
        if (this.f.g0(context2)) {
            this.d = U3;
            this.c = 0;
            this.f.d0(context2, this);
            return;
        }
        i2 i2Var = i2.b;
        y0 a = i2.a();
        if (a.v0()) {
            this.d = U3;
            this.c = 0;
            a.l0(this);
            return;
        }
        a.n0(true);
        try {
            context = getContext();
            c = x.c(context, this.f90e);
            this.g.resumeWith(obj);
            Unit unit = Unit.INSTANCE;
            x.a(context, c);
            do {
            } while (a.x0());
        } catch (Throwable th2) {
            try {
                f(th2, (Throwable) null);
            } catch (Throwable th3) {
                a.h0(true);
                throw th3;
            }
        }
        a.h0(true);
    }

    public String toString() {
        StringBuilder V0 = a.V0("DispatchedContinuation[");
        V0.append(this.f);
        V0.append(", ");
        V0.append(q.E3(this.g));
        V0.append(']');
        return V0.toString();
    }
}

package oh.a.t2;

import e.e.b.a.a;

public final class v {
    public final String a;

    public v(String str) {
        this.a = str;
    }

    public String toString() {
        return a.o0(a.R0('<'), this.a, '>');
    }
}

package oh.a.t2;

public class j extends l {
    public boolean s() {
        return false;
    }

    public final boolean t() {
        throw new IllegalStateException("head cannot be removed".toString());
    }
}

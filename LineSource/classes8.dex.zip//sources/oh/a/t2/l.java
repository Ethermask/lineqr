package oh.a.t2;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.h.c.p;
import kotlin.PublishedApi;

public class l {
    public static final /* synthetic */ AtomicReferenceFieldUpdater a;
    public static final /* synthetic */ AtomicReferenceFieldUpdater b;
    public static final /* synthetic */ AtomicReferenceFieldUpdater c;
    public volatile /* synthetic */ Object _next = this;
    public volatile /* synthetic */ Object _prev = this;
    public volatile /* synthetic */ Object _removedRef = null;

    @PublishedApi
    public static abstract class a extends c<l> {
        public l b;
        public final l c;

        public a(l lVar) {
            this.c = lVar;
        }

        public void b(Object obj, Object obj2) {
            l lVar = (l) obj;
            boolean z = obj2 == null;
            l lVar2 = z ? this.c : this.b;
            if (lVar2 != null && l.a.compareAndSet(lVar, this, lVar2) && z) {
                l lVar3 = this.c;
                l lVar4 = this.b;
                p.c(lVar4);
                lVar3.m(lVar4);
            }
        }
    }

    public static final class b extends q {
    }

    static {
        Class<Object> cls = Object.class;
        Class<l> cls2 = l.class;
        a = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_next");
        b = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_prev");
        c = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_removedRef");
    }

    @PublishedApi
    public final boolean i(l lVar, l lVar2) {
        b.lazySet(lVar, this);
        a.lazySet(lVar, lVar2);
        if (!a.compareAndSet(this, lVar2, lVar)) {
            return false;
        }
        lVar.m(lVar2);
        return true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x003c, code lost:
        if (a.compareAndSet(r2, r1, ((oh.a.t2.r) r3).a) != false) goto L_0x003f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final oh.a.t2.l l(oh.a.t2.q r7) {
        /*
            r6 = this;
        L_0x0000:
            java.lang.Object r7 = r6._prev
            oh.a.t2.l r7 = (oh.a.t2.l) r7
            r0 = 0
            r1 = r7
        L_0x0006:
            r2 = r0
        L_0x0007:
            java.lang.Object r3 = r1._next
            if (r3 != r6) goto L_0x0018
            if (r7 != r1) goto L_0x000e
            return r1
        L_0x000e:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = b
            boolean r7 = r0.compareAndSet(r6, r7, r1)
            if (r7 != 0) goto L_0x0017
            goto L_0x0000
        L_0x0017:
            return r1
        L_0x0018:
            boolean r4 = r6.s()
            if (r4 == 0) goto L_0x001f
            return r0
        L_0x001f:
            if (r3 != 0) goto L_0x0022
            return r1
        L_0x0022:
            boolean r4 = r3 instanceof oh.a.t2.q
            if (r4 == 0) goto L_0x002c
            oh.a.t2.q r3 = (oh.a.t2.q) r3
            r3.a(r1)
            goto L_0x0000
        L_0x002c:
            boolean r4 = r3 instanceof oh.a.t2.r
            if (r4 == 0) goto L_0x0046
            if (r2 == 0) goto L_0x0041
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = a
            oh.a.t2.r r3 = (oh.a.t2.r) r3
            oh.a.t2.l r3 = r3.a
            boolean r1 = r4.compareAndSet(r2, r1, r3)
            if (r1 != 0) goto L_0x003f
            goto L_0x0000
        L_0x003f:
            r1 = r2
            goto L_0x0006
        L_0x0041:
            java.lang.Object r1 = r1._prev
            oh.a.t2.l r1 = (oh.a.t2.l) r1
            goto L_0x0007
        L_0x0046:
            if (r3 == 0) goto L_0x004f
            r2 = r3
            oh.a.t2.l r2 = (oh.a.t2.l) r2
            r5 = r2
            r2 = r1
            r1 = r5
            goto L_0x0007
        L_0x004f:
            java.lang.NullPointerException r7 = new java.lang.NullPointerException
            java.lang.String r0 = "null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */"
            r7.<init>(r0)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.t2.l.l(oh.a.t2.q):oh.a.t2.l");
    }

    public final void m(l lVar) {
        l lVar2;
        do {
            lVar2 = (l) lVar._prev;
            if (n() != lVar) {
                return;
            }
        } while (!b.compareAndSet(lVar, lVar2, this));
        if (s()) {
            lVar.l((q) null);
        }
    }

    public final Object n() {
        while (true) {
            Object obj = this._next;
            if (!(obj instanceof q)) {
                return obj;
            }
            ((q) obj).a(this);
        }
    }

    public final l o() {
        l lVar;
        Object n = n();
        r rVar = (r) (!(n instanceof r) ? null : n);
        if (rVar != null && (lVar = rVar.a) != null) {
            return lVar;
        }
        if (n != null) {
            return (l) n;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */");
    }

    public final l p() {
        l l = l((q) null);
        if (l == null) {
            Object obj = this._prev;
            while (true) {
                l = (l) obj;
                if (!l.s()) {
                    break;
                }
                obj = l._prev;
            }
        }
        return l;
    }

    public final void q() {
        Object n = n();
        if (n != null) {
            ((r) n).a.l((q) null);
            return;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.Removed");
    }

    @PublishedApi
    public final void r() {
        l lVar = this;
        while (true) {
            Object n = lVar.n();
            if (!(n instanceof r)) {
                lVar.l((q) null);
                return;
            }
            lVar = ((r) n).a;
        }
    }

    public boolean s() {
        return n() instanceof r;
    }

    public boolean t() {
        return u() == null;
    }

    public String toString() {
        return getClass().getSimpleName() + '@' + Integer.toHexString(System.identityHashCode(this));
    }

    @PublishedApi
    public final l u() {
        Object n;
        l lVar;
        r rVar;
        do {
            n = n();
            if (n instanceof r) {
                return ((r) n).a;
            }
            if (n == this) {
                return (l) n;
            }
            if (n != null) {
                lVar = (l) n;
                rVar = (r) lVar._removedRef;
                if (rVar == null) {
                    rVar = new r(lVar);
                    c.lazySet(lVar, rVar);
                }
            } else {
                throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */");
            }
        } while (!a.compareAndSet(this, n, rVar));
        lVar.l((q) null);
        return null;
    }

    @PublishedApi
    public final int v(l lVar, l lVar2, a aVar) {
        b.lazySet(lVar, this);
        a.lazySet(lVar, lVar2);
        aVar.b = lVar2;
        if (!a.compareAndSet(this, lVar2, aVar)) {
            return 0;
        }
        return aVar.a(this) == null ? 1 : 2;
    }
}

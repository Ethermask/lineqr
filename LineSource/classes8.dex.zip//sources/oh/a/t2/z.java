package oh.a.t2;

import e.e.b.a.a;
import ka.e.f;
import ka.h.c.p;
import kotlin.PublishedApi;

@PublishedApi
public final class z implements f.b<y<?>> {
    public final ThreadLocal<?> a;

    public z(ThreadLocal<?> threadLocal) {
        this.a = threadLocal;
    }

    public boolean equals(Object obj) {
        if (this != obj) {
            return (obj instanceof z) && p.b(this.a, ((z) obj).a);
        }
        return true;
    }

    public int hashCode() {
        ThreadLocal<?> threadLocal = this.a;
        if (threadLocal != null) {
            return threadLocal.hashCode();
        }
        return 0;
    }

    public String toString() {
        StringBuilder V0 = a.V0("ThreadLocalKey(threadLocal=");
        V0.append(this.a);
        V0.append(")");
        return V0.toString();
    }
}

package oh.a.t2;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.h.c.p;
import oh.a.t2.f;

public abstract class f<N extends f<N>> {
    public static final /* synthetic */ AtomicReferenceFieldUpdater a;
    public static final /* synthetic */ AtomicReferenceFieldUpdater b;
    public volatile /* synthetic */ Object _next = null;
    public volatile /* synthetic */ Object _prev;

    static {
        Class<Object> cls = Object.class;
        Class<f> cls2 = f.class;
        a = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_next");
        b = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_prev");
    }

    public f(N n) {
        this._prev = n;
    }

    public final N a() {
        N n = this._next;
        if (n == e.a) {
            return null;
        }
        return (f) n;
    }

    public abstract boolean b();

    public final boolean c() {
        return a() == null;
    }

    public final void d() {
        while (true) {
            f fVar = (f) this._prev;
            while (fVar != null && fVar.b()) {
                fVar = (f) fVar._prev;
            }
            f a2 = a();
            p.c(a2);
            while (a2.b()) {
                a2 = a2.a();
                p.c(a2);
            }
            a2._prev = fVar;
            if (fVar != null) {
                fVar._next = a2;
            }
            if (!a2.b() && (fVar == null || !fVar.b())) {
                return;
            }
        }
    }
}

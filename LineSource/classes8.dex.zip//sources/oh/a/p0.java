package oh.a;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import ka.e.d;
import ka.e.f;
import oh.a.t2.s;

public final class p0<T> extends s<T> {

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f68e = AtomicIntegerFieldUpdater.newUpdater(p0.class, "_decision");
    public volatile /* synthetic */ int _decision = 0;

    public p0(f fVar, d<? super T> dVar) {
        super(fVar, dVar);
    }

    public void C(Object obj) {
        s0(obj);
    }

    /* JADX WARNING: Removed duplicated region for block: B:0:0x0000 A[LOOP_START, MTH_ENTER_BLOCK] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void s0(java.lang.Object r5) {
        /*
            r4 = this;
        L_0x0000:
            int r0 = r4._decision
            r1 = 0
            r2 = 1
            r3 = 2
            if (r0 == 0) goto L_0x0016
            if (r0 != r2) goto L_0x000a
            goto L_0x001f
        L_0x000a:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "Already resumed"
            java.lang.String r0 = r0.toString()
            r5.<init>(r0)
            throw r5
        L_0x0016:
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r0 = f68e
            boolean r0 = r0.compareAndSet(r4, r1, r3)
            if (r0 == 0) goto L_0x0000
            r1 = r2
        L_0x001f:
            if (r1 == 0) goto L_0x0022
            return
        L_0x0022:
            ka.e.d<T> r0 = r4.d
            ka.e.d r0 = ka.b.q.M1(r0)
            ka.e.d<T> r1 = r4.d
            java.lang.Object r5 = ka.b.q.J2(r5, r1)
            r1 = 0
            oh.a.t2.i.b(r0, r5, r1, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.p0.s0(java.lang.Object):void");
    }
}

package oh.a;

public final class g2 extends q1 {
    public g2(n1 n1Var) {
        super(n1Var);
    }

    public boolean M(Throwable th2) {
        return false;
    }
}

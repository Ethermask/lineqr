package oh.a;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public class y {
    public static final /* synthetic */ AtomicIntegerFieldUpdater b = AtomicIntegerFieldUpdater.newUpdater(y.class, "_handled");
    public volatile /* synthetic */ int _handled;
    public final Throwable a;

    public y(Throwable th2, boolean z) {
        this.a = th2;
        this._handled = z ? 1 : 0;
    }

    public String toString() {
        return getClass().getSimpleName() + '[' + this.a + ']';
    }

    public y(Throwable th2, boolean z, int i) {
        z = (i & 2) != 0 ? false : z;
        this.a = th2;
        this._handled = z ? 1 : 0;
    }
}

package oh.a.r2;

import java.util.concurrent.CancellationException;
import ka.e.d;
import ka.e.f;
import ka.h.b.l;
import kotlin.Unit;
import oh.a.a;
import oh.a.o1;
import oh.a.s1;

public class g<E> extends a<Unit> implements f<E> {
    public final f<E> d;

    public g(f fVar, f<E> fVar2, boolean z) {
        super(fVar, z);
        this.d = fVar2;
    }

    public void G(Throwable th2) {
        CancellationException p0 = s1.p0(this, th2, (String) null, 1, (Object) null);
        this.d.c(p0);
        E(p0);
    }

    public final void c(CancellationException cancellationException) {
        if (!isCancelled()) {
            if (cancellationException == null) {
                cancellationException = new o1(L(), (Throwable) null, this);
            }
            CancellationException p0 = s1.p0(this, cancellationException, (String) null, 1, (Object) null);
            this.d.c(p0);
            E(p0);
        }
    }

    public Object e(d<? super a0<? extends E>> dVar) {
        return this.d.e(dVar);
    }

    public h<E> iterator() {
        return this.d.iterator();
    }

    public boolean offer(E e2) {
        return this.d.offer(e2);
    }

    public void p(l<? super Throwable, Unit> lVar) {
        this.d.p(lVar);
    }

    public boolean w(Throwable th2) {
        return this.d.w(th2);
    }

    public Object x(E e2, d<? super Unit> dVar) {
        return this.d.x(e2, dVar);
    }

    public boolean y() {
        return this.d.y();
    }
}

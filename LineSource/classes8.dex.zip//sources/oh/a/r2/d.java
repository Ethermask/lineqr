package oh.a.r2;

import e.e.b.a.a;
import java.util.concurrent.locks.ReentrantLock;
import ka.b.k;
import ka.b.q;
import ka.h.b.l;
import ka.h.c.p;
import kotlin.Unit;
import oh.a.t2.d0;
import oh.a.t2.l;

public class d<E> extends a<E> {
    public final ReentrantLock d;

    /* renamed from: e  reason: collision with root package name */
    public Object[] f74e;
    public int f;
    public final int g;
    public final e h;
    public volatile /* synthetic */ int size;

    public d(int i, e eVar, l<? super E, Unit> lVar) {
        super(lVar);
        this.g = i;
        this.h = eVar;
        if (i < 1 ? false : true) {
            this.d = new ReentrantLock();
            Object[] objArr = new Object[Math.min(this.g, 8)];
            k.p(objArr, b.a, 0, 0, 6);
            Unit unit = Unit.INSTANCE;
            this.f74e = objArr;
            this.size = 0;
            return;
        }
        throw new IllegalArgumentException(a.a0(a.V0("ArrayChannel capacity must be at least 1, but "), this.g, " was specified").toString());
    }

    /* JADX INFO: finally extract failed */
    public void A(boolean z) {
        l<E, Unit> lVar = this.b;
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            int i = this.size;
            d0 d0Var = null;
            for (int i2 = 0; i2 < i; i2++) {
                Object obj = this.f74e[this.f];
                if (!(lVar == null || obj == b.a)) {
                    d0Var = q.L(lVar, obj, d0Var);
                }
                this.f74e[this.f] = b.a;
                this.f = (this.f + 1) % this.f74e.length;
            }
            this.size = 0;
            Unit unit = Unit.INSTANCE;
            reentrantLock.unlock();
            super.A(z);
            if (d0Var != null) {
                throw d0Var;
            }
        } catch (Throwable th2) {
            reentrantLock.unlock();
            throw th2;
        }
    }

    public Object E() {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            int i = this.size;
            if (i == 0) {
                Object i2 = i();
                if (i2 == null) {
                    i2 = b.d;
                }
                return i2;
            }
            Object obj = this.f74e[this.f];
            w wVar = null;
            this.f74e[this.f] = null;
            this.size = i - 1;
            Object obj2 = b.d;
            boolean z = false;
            if (i == this.g) {
                w wVar2 = null;
                while (true) {
                    w r = r();
                    if (r == null) {
                        wVar = wVar2;
                        break;
                    }
                    p.c(r);
                    if (r.z((l.b) null) != null) {
                        p.c(r);
                        obj2 = r.x();
                        z = true;
                        wVar = r;
                        break;
                    }
                    p.c(r);
                    r.A();
                    wVar2 = r;
                }
            }
            if (obj2 != b.d && !(obj2 instanceof j)) {
                this.size = i;
                this.f74e[(this.f + i) % this.f74e.length] = obj2;
            }
            this.f = (this.f + 1) % this.f74e.length;
            Unit unit = Unit.INSTANCE;
            reentrantLock.unlock();
            if (z) {
                p.c(wVar);
                wVar.w();
            }
            return obj;
        } finally {
            reentrantLock.unlock();
        }
    }

    public final void F(int i, E e2) {
        int i2 = this.g;
        if (i < i2) {
            Object[] objArr = this.f74e;
            if (i >= objArr.length) {
                int min = Math.min(objArr.length * 2, i2);
                Object[] objArr2 = new Object[min];
                for (int i3 = 0; i3 < i; i3++) {
                    Object[] objArr3 = this.f74e;
                    objArr2[i3] = objArr3[(this.f + i3) % objArr3.length];
                }
                k.o(objArr2, b.a, i, min);
                this.f74e = objArr2;
                this.f = 0;
            }
            Object[] objArr4 = this.f74e;
            objArr4[(this.f + i) % objArr4.length] = e2;
            return;
        }
        Object[] objArr5 = this.f74e;
        int i4 = this.f;
        objArr5[i4 % objArr5.length] = null;
        objArr5[(i + i4) % objArr5.length] = e2;
        this.f = (i4 + 1) % objArr5.length;
    }

    public Object g(w wVar) {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            return super.g(wVar);
        } finally {
            reentrantLock.unlock();
        }
    }

    public String h() {
        StringBuilder V0 = a.V0("(buffer:capacity=");
        V0.append(this.g);
        V0.append(",size=");
        return a.Y(V0, this.size, ')');
    }

    public final boolean l() {
        return false;
    }

    public final boolean m() {
        return this.size == this.g && this.h == e.SUSPEND;
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0038  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x003c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object n(E r6) {
        /*
            r5 = this;
            java.util.concurrent.locks.ReentrantLock r0 = r5.d
            r0.lock()
            int r1 = r5.size     // Catch:{ all -> 0x0078 }
            oh.a.r2.j r2 = r5.i()     // Catch:{ all -> 0x0078 }
            if (r2 == 0) goto L_0x0011
            r0.unlock()
            return r2
        L_0x0011:
            int r2 = r5.g     // Catch:{ all -> 0x0078 }
            r3 = 1
            r4 = 0
            if (r1 >= r2) goto L_0x001c
            int r2 = r1 + 1
            r5.size = r2     // Catch:{ all -> 0x0078 }
            goto L_0x0032
        L_0x001c:
            oh.a.r2.e r2 = r5.h     // Catch:{ all -> 0x0078 }
            int r2 = r2.ordinal()     // Catch:{ all -> 0x0078 }
            if (r2 == 0) goto L_0x0034
            if (r2 == r3) goto L_0x0032
            r3 = 2
            if (r2 != r3) goto L_0x002c
            oh.a.t2.v r2 = oh.a.r2.b.b     // Catch:{ all -> 0x0078 }
            goto L_0x0036
        L_0x002c:
            kotlin.NoWhenBranchMatchedException r6 = new kotlin.NoWhenBranchMatchedException     // Catch:{ all -> 0x0078 }
            r6.<init>()     // Catch:{ all -> 0x0078 }
            throw r6     // Catch:{ all -> 0x0078 }
        L_0x0032:
            r2 = r4
            goto L_0x0036
        L_0x0034:
            oh.a.t2.v r2 = oh.a.r2.b.c     // Catch:{ all -> 0x0078 }
        L_0x0036:
            if (r2 == 0) goto L_0x003c
            r0.unlock()
            return r2
        L_0x003c:
            if (r1 != 0) goto L_0x006f
        L_0x003e:
            oh.a.r2.u r2 = r5.q()     // Catch:{ all -> 0x0078 }
            if (r2 == 0) goto L_0x006f
            boolean r3 = r2 instanceof oh.a.r2.j     // Catch:{ all -> 0x0078 }
            if (r3 == 0) goto L_0x0051
            r5.size = r1     // Catch:{ all -> 0x0078 }
            ka.h.c.p.c(r2)     // Catch:{ all -> 0x0078 }
            r0.unlock()
            return r2
        L_0x0051:
            ka.h.c.p.c(r2)     // Catch:{ all -> 0x0078 }
            oh.a.t2.v r3 = r2.h(r6, r4)     // Catch:{ all -> 0x0078 }
            if (r3 == 0) goto L_0x003e
            r5.size = r1     // Catch:{ all -> 0x0078 }
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x0078 }
            r0.unlock()
            ka.h.c.p.c(r2)
            r2.d(r6)
            ka.h.c.p.c(r2)
            java.lang.Object r6 = r2.a()
            return r6
        L_0x006f:
            r5.F(r1, r6)     // Catch:{ all -> 0x0078 }
            oh.a.t2.v r6 = oh.a.r2.b.b     // Catch:{ all -> 0x0078 }
            r0.unlock()
            return r6
        L_0x0078:
            r6 = move-exception
            r0.unlock()
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.r2.d.n(java.lang.Object):java.lang.Object");
    }

    public boolean t(s<? super E> sVar) {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            return super.t(sVar);
        } finally {
            reentrantLock.unlock();
        }
    }

    public final boolean u() {
        return false;
    }

    public final boolean v() {
        return this.size == 0;
    }

    public boolean z() {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            return super.z();
        } finally {
            reentrantLock.unlock();
        }
    }
}

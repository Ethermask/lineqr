package oh.a.r2;

import java.util.concurrent.CancellationException;
import ka.e.d;

public interface t<E> {
    void c(CancellationException cancellationException);

    Object e(d<? super a0<? extends E>> dVar);

    h<E> iterator();
}

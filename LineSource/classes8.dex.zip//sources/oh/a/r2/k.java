package oh.a.r2;

import java.util.NoSuchElementException;

public final class k extends NoSuchElementException {
    public k(String str) {
        super(str);
    }
}

package oh.a.r2;

import ka.b.q;
import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;
import ka.h.b.a;

@e(c = "kotlinx.coroutines.channels.ProduceKt", f = "Produce.kt", l = {157}, m = "awaitClose")
public final class o extends c {
    public /* synthetic */ Object a;
    public int b;
    public Object c;
    public Object d;

    public o(d dVar) {
        super(dVar);
    }

    public final Object invokeSuspend(Object obj) {
        this.a = obj;
        this.b |= Integer.MIN_VALUE;
        return q.A((r) null, (a) null, this);
    }
}

package oh.a.r2;

import ka.e.d;
import ka.h.b.l;
import kotlin.Unit;

public interface x<E> {
    boolean offer(E e2);

    void p(l<? super Throwable, Unit> lVar);

    boolean w(Throwable th2);

    Object x(E e2, d<? super Unit> dVar);

    boolean y();
}

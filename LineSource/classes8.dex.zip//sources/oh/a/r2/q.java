package oh.a.r2;

import ka.e.f;
import kotlin.Unit;

public class q<E> extends g<E> implements r<E> {
    public q(f fVar, f<E> fVar2) {
        super(fVar, fVar2, true);
    }

    public boolean isActive() {
        return super.isActive();
    }

    public x s() {
        return this;
    }

    public void u0(Throwable th2, boolean z) {
        if (!this.d.w(th2) && !z) {
            ka.b.q.I1(this.b, th2);
        }
    }

    public /* bridge */ /* synthetic */ void v0(Object obj) {
        Unit unit = (Unit) obj;
        y0();
    }

    public void y0() {
        ka.b.q.f0(this.d, (Throwable) null, 1, (Object) null);
    }
}

package oh.a.r2;

import e.e.b.a.a;
import ka.b.q;
import oh.a.m;
import oh.a.t2.l;
import oh.a.t2.v;

public final class j<E> extends w implements u<E> {
    public final Throwable d;

    public j(Throwable th2) {
        this.d = th2;
    }

    public final Throwable B() {
        Throwable th2 = this.d;
        return th2 != null ? th2 : new k("Channel was closed");
    }

    public final Throwable C() {
        Throwable th2 = this.d;
        return th2 != null ? th2 : new l("Channel was closed");
    }

    public Object a() {
        return this;
    }

    public void d(E e2) {
    }

    public v h(E e2, l.b bVar) {
        return m.a;
    }

    public String toString() {
        StringBuilder V0 = a.V0("Closed@");
        V0.append(q.q1(this));
        V0.append('[');
        V0.append(this.d);
        V0.append(']');
        return V0.toString();
    }

    public void w() {
    }

    public Object x() {
        return this;
    }

    public void y(j<?> jVar) {
    }

    public v z(l.b bVar) {
        return m.a;
    }
}

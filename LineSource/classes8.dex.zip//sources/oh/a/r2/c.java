package oh.a.r2;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.b.q;
import ka.e.d;
import ka.h.b.l;
import ka.h.c.n0;
import ka.h.c.p;
import kotlin.ExceptionsKt__ExceptionsKt;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.b2;
import oh.a.m;
import oh.a.t2.d0;
import oh.a.t2.j;
import oh.a.t2.k;
import oh.a.t2.l;
import oh.a.t2.u;
import oh.a.t2.v;

public abstract class c<E> implements x<E> {
    public static final /* synthetic */ AtomicReferenceFieldUpdater c = AtomicReferenceFieldUpdater.newUpdater(c.class, Object.class, "onCloseHandler");
    public final j a = new j();
    public final l<E, Unit> b;
    public volatile /* synthetic */ Object onCloseHandler = null;

    public static final class a<E> extends w {
        public final E d;

        public a(E e2) {
            this.d = e2;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("SendBuffered@");
            V0.append(q.q1(this));
            V0.append('(');
            return e.e.b.a.a.l0(V0, this.d, ')');
        }

        public void w() {
        }

        public Object x() {
            return this.d;
        }

        public void y(j<?> jVar) {
        }

        public v z(l.b bVar) {
            return m.a;
        }
    }

    public static final class b extends l.a {
        public final /* synthetic */ c d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(oh.a.t2.l lVar, oh.a.t2.l lVar2, c cVar) {
            super(lVar2);
            this.d = cVar;
        }

        public Object c(Object obj) {
            oh.a.t2.l lVar = (oh.a.t2.l) obj;
            if (this.d.m()) {
                return null;
            }
            return k.a;
        }
    }

    public c(ka.h.b.l<? super E, Unit> lVar) {
        this.b = lVar;
    }

    public static final void f(c cVar, d dVar, Object obj, j jVar) {
        d0 M;
        cVar.j(jVar);
        Throwable C = jVar.C();
        ka.h.b.l<E, Unit> lVar = cVar.b;
        if (lVar == null || (M = q.M(lVar, obj, (d0) null, 2)) == null) {
            Result.Companion companion = Result.Companion;
            dVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(C)));
            return;
        }
        ExceptionsKt__ExceptionsKt.addSuppressed(M, C);
        Result.Companion companion2 = Result.Companion;
        dVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(M)));
    }

    public Object g(w wVar) {
        boolean z;
        oh.a.t2.l p;
        if (l()) {
            j jVar = this.a;
            do {
                p = jVar.p();
                if (p instanceof u) {
                    return p;
                }
            } while (!p.i(wVar, jVar));
            return null;
        }
        j jVar2 = this.a;
        b bVar = new b(wVar, wVar, this);
        while (true) {
            oh.a.t2.l p2 = jVar2.p();
            if (!(p2 instanceof u)) {
                int v = p2.v(wVar, jVar2, bVar);
                z = true;
                if (v != 1) {
                    if (v == 2) {
                        z = false;
                        break;
                    }
                } else {
                    break;
                }
            } else {
                return p2;
            }
        }
        if (!z) {
            return b.f73e;
        }
        return null;
    }

    public String h() {
        return "";
    }

    public final j<?> i() {
        oh.a.t2.l p = this.a.p();
        if (!(p instanceof j)) {
            p = null;
        }
        j<?> jVar = (j) p;
        if (jVar == null) {
            return null;
        }
        j(jVar);
        return jVar;
    }

    public final void j(j<?> jVar) {
        Object obj = null;
        while (true) {
            oh.a.t2.l p = jVar.p();
            if (!(p instanceof s)) {
                p = null;
            }
            s sVar = (s) p;
            if (sVar == null) {
                break;
            } else if (!sVar.t()) {
                sVar.q();
            } else {
                obj = q.C2(obj, sVar);
            }
        }
        if (obj != null) {
            if (obj instanceof ArrayList) {
                ArrayList arrayList = (ArrayList) obj;
                int size = arrayList.size();
                while (true) {
                    size--;
                    if (size < 0) {
                        break;
                    }
                    ((s) arrayList.get(size)).x(jVar);
                }
            } else {
                ((s) obj).x(jVar);
            }
        }
        o(jVar);
    }

    public final Throwable k(E e2, j<?> jVar) {
        d0 M;
        j(jVar);
        ka.h.b.l<E, Unit> lVar = this.b;
        if (lVar == null || (M = q.M(lVar, e2, (d0) null, 2)) == null) {
            return jVar.C();
        }
        ExceptionsKt__ExceptionsKt.addSuppressed(M, jVar.C());
        throw M;
    }

    public abstract boolean l();

    public abstract boolean m();

    public Object n(E e2) {
        u q;
        do {
            q = q();
            if (q == null) {
                return b.c;
            }
        } while (q.h(e2, (l.b) null) == null);
        q.d(e2);
        return q.a();
    }

    public void o(oh.a.t2.l lVar) {
    }

    public final boolean offer(E e2) {
        Object n = n(e2);
        if (n == b.b) {
            return true;
        }
        if (n == b.c) {
            j<?> i = i();
            if (i == null) {
                return false;
            }
            Throwable k = k(e2, i);
            u.a(k);
            throw k;
        } else if (n instanceof j) {
            Throwable k2 = k(e2, (j) n);
            u.a(k2);
            throw k2;
        } else {
            throw new IllegalStateException(e.e.b.a.a.B("offerInternal returned ", n).toString());
        }
    }

    public void p(ka.h.b.l<? super Throwable, Unit> lVar) {
        if (!c.compareAndSet(this, (Object) null, lVar)) {
            Object obj = this.onCloseHandler;
            if (obj == b.f) {
                throw new IllegalStateException("Another handler was already registered and successfully invoked");
            }
            throw new IllegalStateException(e.e.b.a.a.B("Another handler was already registered: ", obj));
        }
        j<?> i = i();
        if (i != null && c.compareAndSet(this, lVar, b.f)) {
            lVar.invoke(i.d);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0012, code lost:
        r1 = null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public oh.a.r2.u<E> q() {
        /*
            r4 = this;
            oh.a.t2.j r0 = r4.a
        L_0x0002:
            java.lang.Object r1 = r0.n()
            if (r1 == 0) goto L_0x002f
            oh.a.t2.l r1 = (oh.a.t2.l) r1
            r2 = 0
            if (r1 != r0) goto L_0x000e
            goto L_0x0012
        L_0x000e:
            boolean r3 = r1 instanceof oh.a.r2.u
            if (r3 != 0) goto L_0x0014
        L_0x0012:
            r1 = r2
            goto L_0x0028
        L_0x0014:
            r2 = r1
            oh.a.r2.u r2 = (oh.a.r2.u) r2
            boolean r2 = r2 instanceof oh.a.r2.j
            if (r2 == 0) goto L_0x0022
            boolean r2 = r1.s()
            if (r2 != 0) goto L_0x0022
            goto L_0x0028
        L_0x0022:
            oh.a.t2.l r2 = r1.u()
            if (r2 != 0) goto L_0x002b
        L_0x0028:
            oh.a.r2.u r1 = (oh.a.r2.u) r1
            return r1
        L_0x002b:
            r2.r()
            goto L_0x0002
        L_0x002f:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */"
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.r2.c.q():oh.a.r2.u");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0012, code lost:
        r1 = null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final oh.a.r2.w r() {
        /*
            r4 = this;
            oh.a.t2.j r0 = r4.a
        L_0x0002:
            java.lang.Object r1 = r0.n()
            if (r1 == 0) goto L_0x002f
            oh.a.t2.l r1 = (oh.a.t2.l) r1
            r2 = 0
            if (r1 != r0) goto L_0x000e
            goto L_0x0012
        L_0x000e:
            boolean r3 = r1 instanceof oh.a.r2.w
            if (r3 != 0) goto L_0x0014
        L_0x0012:
            r1 = r2
            goto L_0x0028
        L_0x0014:
            r2 = r1
            oh.a.r2.w r2 = (oh.a.r2.w) r2
            boolean r2 = r2 instanceof oh.a.r2.j
            if (r2 == 0) goto L_0x0022
            boolean r2 = r1.s()
            if (r2 != 0) goto L_0x0022
            goto L_0x0028
        L_0x0022:
            oh.a.t2.l r2 = r1.u()
            if (r2 != 0) goto L_0x002b
        L_0x0028:
            oh.a.r2.w r1 = (oh.a.r2.w) r1
            return r1
        L_0x002b:
            r2.r()
            goto L_0x0002
        L_0x002f:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */"
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.r2.c.r():oh.a.r2.w");
    }

    public String toString() {
        String str;
        String str2;
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append('@');
        sb.append(q.q1(this));
        sb.append('{');
        oh.a.t2.l o = this.a.o();
        if (o == this.a) {
            str = "EmptyQueue";
        } else {
            if (o instanceof j) {
                str2 = o.toString();
            } else if (o instanceof s) {
                str2 = "ReceiveQueued";
            } else if (o instanceof w) {
                str2 = "SendQueued";
            } else {
                str2 = "UNEXPECTED:" + o;
            }
            oh.a.t2.l p = this.a.p();
            if (p != o) {
                StringBuilder g1 = e.e.b.a.a.g1(str2, ",queueSize=");
                j jVar = this.a;
                Object n = jVar.n();
                if (n != null) {
                    int i = 0;
                    for (oh.a.t2.l lVar = (oh.a.t2.l) n; !p.b(lVar, jVar); lVar = lVar.o()) {
                        i++;
                    }
                    g1.append(i);
                    str = g1.toString();
                    if (p instanceof j) {
                        str = str + ",closedForSend=" + p;
                    }
                } else {
                    throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */");
                }
            } else {
                str = str2;
            }
        }
        sb.append(str);
        sb.append('}');
        sb.append(h());
        return sb.toString();
    }

    public boolean w(Throwable th2) {
        boolean z;
        Object obj;
        v vVar;
        j jVar = new j(th2);
        j jVar2 = this.a;
        while (true) {
            oh.a.t2.l p = jVar2.p();
            if (!(p instanceof j)) {
                if (p.i(jVar, jVar2)) {
                    z = true;
                    break;
                }
            } else {
                z = false;
                break;
            }
        }
        if (!z) {
            jVar = (j) this.a.p();
        }
        j(jVar);
        if (z && (obj = this.onCloseHandler) != null && obj != (vVar = b.f) && c.compareAndSet(this, obj, vVar)) {
            n0.e(obj, 1);
            ((ka.h.b.l) obj).invoke(th2);
        }
        return z;
    }

    public final Object x(E e2, d<? super Unit> dVar) {
        w wVar;
        if (n(e2) == b.b) {
            return Unit.INSTANCE;
        }
        oh.a.l C1 = q.C1(q.M1(dVar));
        while (true) {
            if (!(this.a.o() instanceof u) && m()) {
                if (this.b == null) {
                    wVar = new y(e2, C1);
                } else {
                    wVar = new z(e2, C1, this.b);
                }
                Object g = g(wVar);
                if (g == null) {
                    C1.l(new b2(wVar));
                    break;
                } else if (g instanceof j) {
                    f(this, C1, e2, (j) g);
                    break;
                } else if (g != b.f73e && !(g instanceof s)) {
                    throw new IllegalStateException(e.e.b.a.a.B("enqueueSend returned ", g).toString());
                }
            }
            Object n = n(e2);
            if (n == b.b) {
                Unit unit = Unit.INSTANCE;
                Result.Companion companion = Result.Companion;
                C1.resumeWith(Result.constructor-impl(unit));
                break;
            } else if (n != b.c) {
                if (n instanceof j) {
                    f(this, C1, e2, (j) n);
                } else {
                    throw new IllegalStateException(e.e.b.a.a.B("offerInternal returned ", n).toString());
                }
            }
        }
        Object t = C1.t();
        if (t == ka.e.j.a.COROUTINE_SUSPENDED) {
            p.e(dVar, "frame");
        }
        if (t == ka.e.j.a.COROUTINE_SUSPENDED) {
            return t;
        }
        return Unit.INSTANCE;
    }

    public final boolean y() {
        return i() != null;
    }
}

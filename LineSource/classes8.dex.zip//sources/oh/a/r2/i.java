package oh.a.r2;

import ka.e.d;
import ka.e.j.a;
import ka.e.k.a.e;
import ka.h.b.p;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.h0;

@e(c = "kotlinx.coroutines.channels.ChannelsKt__ChannelsKt$sendBlocking$1", f = "Channels.kt", l = {25}, m = "invokeSuspend")
public final class i extends ka.e.k.a.i implements p<h0, d<? super Unit>, Object> {
    public int a;
    public final /* synthetic */ x b;
    public final /* synthetic */ Object c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public i(x xVar, Object obj, d dVar) {
        super(2, dVar);
        this.b = xVar;
        this.c = obj;
    }

    public final d<Unit> create(Object obj, d<?> dVar) {
        return new i(this.b, this.c, dVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return new i(this.b, this.c, (d) obj2).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.COROUTINE_SUSPENDED;
        int i = this.a;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            x xVar = this.b;
            Object obj2 = this.c;
            this.a = 1;
            if (xVar.x(obj2, this) == aVar) {
                return aVar;
            }
        } else if (i == 1) {
            ResultKt.throwOnFailure(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }
}

package oh.a.r2;

public final class l extends IllegalStateException {
    public l(String str) {
        super(str);
    }
}

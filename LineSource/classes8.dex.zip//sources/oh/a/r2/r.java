package oh.a.r2;

import oh.a.h0;

public interface r<E> extends h0, x<E> {
    x<E> s();
}

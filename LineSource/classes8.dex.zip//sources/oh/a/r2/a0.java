package oh.a.r2;

import ka.h.c.p;

public final class a0<T> {
    public final Object a;

    public static final class a {
        public final Throwable a;

        public a(Throwable th2) {
            this.a = th2;
        }

        public boolean equals(Object obj) {
            return (obj instanceof a) && p.b(this.a, ((a) obj).a);
        }

        public int hashCode() {
            Throwable th2 = this.a;
            if (th2 != null) {
                return th2.hashCode();
            }
            return 0;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("Closed(");
            V0.append(this.a);
            V0.append(')');
            return V0.toString();
        }
    }

    public /* synthetic */ a0(Object obj) {
        this.a = obj;
    }

    public boolean equals(Object obj) {
        return (obj instanceof a0) && p.b(this.a, ((a0) obj).a);
    }

    public int hashCode() {
        Object obj = this.a;
        if (obj != null) {
            return obj.hashCode();
        }
        return 0;
    }

    public String toString() {
        Object obj = this.a;
        if (obj instanceof a) {
            return obj.toString();
        }
        return "Value(" + obj + ')';
    }
}

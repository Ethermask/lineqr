package oh.a.r2;

import e.e.b.a.a;
import java.util.ArrayList;
import ka.b.q;
import ka.h.b.l;
import kotlin.Unit;
import oh.a.r2.c;
import oh.a.t2.d0;
import oh.a.t2.j;
import oh.a.t2.v;

public class n<E> extends a<E> {
    public n(l<? super E, Unit> lVar) {
        super(lVar);
    }

    public void B(Object obj, j<?> jVar) {
        d0 d0Var = null;
        if (obj != null) {
            if (!(obj instanceof ArrayList)) {
                w wVar = (w) obj;
                if (wVar instanceof c.a) {
                    l<E, Unit> lVar = this.b;
                    if (lVar != null) {
                        d0Var = q.L(lVar, ((c.a) wVar).d, (d0) null);
                    }
                } else {
                    wVar.y(jVar);
                }
            } else {
                ArrayList arrayList = (ArrayList) obj;
                d0 d0Var2 = null;
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    w wVar2 = (w) arrayList.get(size);
                    if (wVar2 instanceof c.a) {
                        l<E, Unit> lVar2 = this.b;
                        d0Var2 = lVar2 != null ? q.L(lVar2, ((c.a) wVar2).d, d0Var2) : null;
                    } else {
                        wVar2.y(jVar);
                    }
                }
                d0Var = d0Var2;
            }
        }
        if (d0Var != null) {
            throw d0Var;
        }
    }

    public final boolean l() {
        return false;
    }

    public final boolean m() {
        return false;
    }

    public Object n(E e2) {
        u uVar;
        do {
            Object n = super.n(e2);
            v vVar = b.b;
            if (n == vVar) {
                return vVar;
            }
            if (n == b.c) {
                j jVar = this.a;
                c.a aVar = new c.a(e2);
                while (true) {
                    oh.a.t2.l p = jVar.p();
                    if (!(p instanceof u)) {
                        if (p.i(aVar, jVar)) {
                            uVar = null;
                            break;
                        }
                    } else {
                        uVar = (u) p;
                        break;
                    }
                }
                if (uVar == null) {
                    return b.b;
                }
            } else if (n instanceof j) {
                return n;
            } else {
                throw new IllegalStateException(a.B("Invalid offerInternal result ", n).toString());
            }
        } while (!(uVar instanceof j));
        return uVar;
    }

    public final boolean u() {
        return true;
    }

    public final boolean v() {
        return true;
    }
}

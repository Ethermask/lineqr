package oh.a.r2;

import ka.h.b.l;
import ka.h.c.r;
import kotlin.Result;
import kotlin.Unit;
import oh.a.k;

public final class p extends r implements l<Throwable, Unit> {
    public final /* synthetic */ k a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public p(k kVar) {
        super(1);
        this.a = kVar;
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        k kVar = this.a;
        Unit unit = Unit.INSTANCE;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(unit));
        return Unit.INSTANCE;
    }
}

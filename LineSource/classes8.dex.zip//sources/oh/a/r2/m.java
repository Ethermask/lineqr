package oh.a.r2;

import e.e.b.a.a;
import java.util.concurrent.locks.ReentrantLock;
import ka.b.q;
import ka.h.b.l;
import ka.h.c.p;
import kotlin.Unit;
import oh.a.t2.d0;
import oh.a.t2.l;
import oh.a.t2.v;

public class m<E> extends a<E> {
    public final ReentrantLock d = new ReentrantLock();

    /* renamed from: e  reason: collision with root package name */
    public Object f75e = b.a;

    public m(l<? super E, Unit> lVar) {
        super(lVar);
    }

    /* JADX INFO: finally extract failed */
    public void A(boolean z) {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            d0 F = F(b.a);
            Unit unit = Unit.INSTANCE;
            reentrantLock.unlock();
            super.A(z);
            if (F != null) {
                throw F;
            }
        } catch (Throwable th2) {
            reentrantLock.unlock();
            throw th2;
        }
    }

    public Object E() {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            if (this.f75e == b.a) {
                Object i = i();
                if (i == null) {
                    i = b.d;
                }
                return i;
            }
            Object obj = this.f75e;
            this.f75e = b.a;
            Unit unit = Unit.INSTANCE;
            reentrantLock.unlock();
            return obj;
        } finally {
            reentrantLock.unlock();
        }
    }

    public final d0 F(Object obj) {
        l<E, Unit> lVar;
        Object obj2 = this.f75e;
        d0 d0Var = null;
        if (!(obj2 == b.a || (lVar = this.b) == null)) {
            d0Var = q.M(lVar, obj2, (d0) null, 2);
        }
        this.f75e = obj;
        return d0Var;
    }

    public String h() {
        return a.l0(a.V0("(value="), this.f75e, ')');
    }

    public final boolean l() {
        return false;
    }

    public final boolean m() {
        return false;
    }

    public Object n(E e2) {
        u q;
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            j<?> i = i();
            if (i != null) {
                return i;
            }
            if (this.f75e == b.a) {
                do {
                    q = q();
                    if (q != null) {
                        if (q instanceof j) {
                            p.c(q);
                            reentrantLock.unlock();
                            return q;
                        }
                        p.c(q);
                    }
                } while (q.h(e2, (l.b) null) == null);
                Unit unit = Unit.INSTANCE;
                reentrantLock.unlock();
                p.c(q);
                q.d(e2);
                p.c(q);
                return q.a();
            }
            d0 F = F(e2);
            if (F == null) {
                v vVar = b.b;
                reentrantLock.unlock();
                return vVar;
            }
            throw F;
        } finally {
            reentrantLock.unlock();
        }
    }

    public boolean t(s<? super E> sVar) {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            return super.t(sVar);
        } finally {
            reentrantLock.unlock();
        }
    }

    public final boolean u() {
        return false;
    }

    public final boolean v() {
        return this.f75e == b.a;
    }
}

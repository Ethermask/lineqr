package oh.a.r2;

import ka.b.q;
import ka.e.f;
import ka.h.b.l;
import kotlin.Unit;
import oh.a.k;
import oh.a.t2.d0;

public final class z<E> extends y<E> {
    public final l<E, Unit> f;

    public z(E e2, k<? super Unit> kVar, l<? super E, Unit> lVar) {
        super(e2, kVar);
        this.f = lVar;
    }

    public void A() {
        l<E, Unit> lVar = this.f;
        E e2 = this.d;
        f context = this.f76e.getContext();
        d0 L = q.L(lVar, e2, (d0) null);
        if (L != null) {
            q.I1(context, L);
        }
    }

    public boolean t() {
        if (!super.t()) {
            return false;
        }
        A();
        return true;
    }
}

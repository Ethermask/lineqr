package oh.a.r2;

import oh.a.t2.v;

public final class b {
    public static final v a = new v("EMPTY");
    public static final v b = new v("OFFER_SUCCESS");
    public static final v c = new v("OFFER_FAILED");
    public static final v d = new v("POLL_FAILED");

    /* renamed from: e  reason: collision with root package name */
    public static final v f73e = new v("ENQUEUE_FAILED");
    public static final v f = new v("ON_CLOSE_HANDLER_INVOKED");
}

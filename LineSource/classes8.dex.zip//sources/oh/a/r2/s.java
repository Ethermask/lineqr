package oh.a.r2;

import kotlin.Unit;
import oh.a.t2.l;

public abstract class s<E> extends l implements u<E> {
    public Object a() {
        return b.b;
    }

    public ka.h.b.l<Throwable, Unit> w(E e2) {
        return null;
    }

    public abstract void x(j<?> jVar);
}

package oh.a.r2;

import e.e.b.a.a;
import ka.b.q;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.k;
import oh.a.m;
import oh.a.t2.l;
import oh.a.t2.v;

public class y<E> extends w {
    public final E d;

    /* renamed from: e  reason: collision with root package name */
    public final k<Unit> f76e;

    public y(E e2, k<? super Unit> kVar) {
        this.d = e2;
        this.f76e = kVar;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append('@');
        sb.append(q.q1(this));
        sb.append('(');
        return a.l0(sb, this.d, ')');
    }

    public void w() {
        this.f76e.z(m.a);
    }

    public E x() {
        return this.d;
    }

    public void y(j<?> jVar) {
        k<Unit> kVar = this.f76e;
        Throwable C = jVar.C();
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(C)));
    }

    public v z(l.b bVar) {
        if (this.f76e.d(Unit.INSTANCE, (Object) null) != null) {
            return m.a;
        }
        return null;
    }
}

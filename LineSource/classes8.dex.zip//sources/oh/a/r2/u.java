package oh.a.r2;

import oh.a.t2.l;
import oh.a.t2.v;

public interface u<E> {
    Object a();

    void d(E e2);

    v h(E e2, l.b bVar);
}

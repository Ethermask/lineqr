package oh.a.r2;

import ka.h.b.l;
import kotlin.Unit;

public class v<E> extends a<E> {
    public v(l<? super E, Unit> lVar) {
        super(lVar);
    }

    public final boolean l() {
        return true;
    }

    public final boolean m() {
        return true;
    }

    public final boolean u() {
        return true;
    }

    public final boolean v() {
        return true;
    }
}

package oh.a.r2;

import ka.b.q;

public interface f<E> extends x<E>, t<E> {
    public static final a a0 = a.b;

    public static final class a {
        public static final int a = q.t3("kotlinx.coroutines.channels.defaultBuffer", 64, 1, 2147483646);
        public static final /* synthetic */ a b = new a();
    }
}

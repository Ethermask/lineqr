package oh.a.r2;

public enum e {
    SUSPEND,
    DROP_OLDEST,
    DROP_LATEST
}

package oh.a.r2;

import java.util.ArrayList;
import java.util.concurrent.CancellationException;
import ka.b.q;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.k;
import oh.a.l;
import oh.a.m;
import oh.a.r2.a0;
import oh.a.t2.j;
import oh.a.t2.l;
import oh.a.t2.p;
import oh.a.t2.u;
import oh.a.t2.v;

public abstract class a<E> extends c<E> implements f<E> {

    /* renamed from: oh.a.r2.a$a  reason: collision with other inner class name */
    public static final class C0002a<E> implements h<E> {
        public Object a = b.d;
        public final a<E> b;

        public C0002a(a<E> aVar) {
            this.b = aVar;
        }

        public Object a(ka.e.d<? super Boolean> dVar) {
            Object obj = this.a;
            if (obj != b.d) {
                return Boolean.valueOf(b(obj));
            }
            Object E = this.b.E();
            this.a = E;
            if (E != b.d) {
                return Boolean.valueOf(b(E));
            }
            l C1 = q.C1(q.M1(dVar));
            d dVar2 = new d(this, C1);
            while (true) {
                a<E> aVar = this.b;
                boolean t = aVar.t(dVar2);
                if (t) {
                    aVar.D();
                }
                ka.h.b.l lVar = null;
                if (t) {
                    a<E> aVar2 = this.b;
                    if (aVar2 != null) {
                        C1.l(new e(dVar2));
                    } else {
                        throw null;
                    }
                } else {
                    Object E2 = this.b.E();
                    this.a = E2;
                    if (E2 instanceof j) {
                        j jVar = (j) E2;
                        if (jVar.d == null) {
                            Boolean bool = Boolean.FALSE;
                            Result.Companion companion = Result.Companion;
                            C1.resumeWith(Result.constructor-impl(bool));
                        } else {
                            Throwable B = jVar.B();
                            Result.Companion companion2 = Result.Companion;
                            C1.resumeWith(Result.constructor-impl(ResultKt.createFailure(B)));
                        }
                    } else if (E2 != b.d) {
                        Boolean bool2 = Boolean.TRUE;
                        ka.h.b.l<E, Unit> lVar2 = this.b.b;
                        if (lVar2 != null) {
                            lVar = new p(lVar2, E2, C1.getContext());
                        }
                        C1.n(bool2, lVar);
                    }
                }
            }
            Object t2 = C1.t();
            if (t2 == ka.e.j.a.COROUTINE_SUSPENDED) {
                ka.h.c.p.e(dVar, "frame");
            }
            return t2;
        }

        public final boolean b(Object obj) {
            if (!(obj instanceof j)) {
                return true;
            }
            j jVar = (j) obj;
            if (jVar.d == null) {
                return false;
            }
            Throwable B = jVar.B();
            u.a(B);
            throw B;
        }

        public E next() {
            E e2 = this.a;
            if (!(e2 instanceof j)) {
                E e3 = b.d;
                if (e2 != e3) {
                    this.a = e3;
                    return e2;
                }
                throw new IllegalStateException("'hasNext' should be called prior to 'next' invocation");
            }
            Throwable B = ((j) e2).B();
            u.a(B);
            throw B;
        }
    }

    public static class b<E> extends s<E> {
        public final k<Object> d;

        /* renamed from: e  reason: collision with root package name */
        public final int f71e;

        public b(k<Object> kVar, int i) {
            this.d = kVar;
            this.f71e = i;
        }

        public void d(E e2) {
            this.d.z(m.a);
        }

        public v h(E e2, l.b bVar) {
            E e3;
            k<Object> kVar = this.d;
            if (this.f71e != 2) {
                e3 = e2;
            } else {
                e3 = new a0(e2);
            }
            if (kVar.q(e3, (Object) null, w(e2)) != null) {
                return m.a;
            }
            return null;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("ReceiveElement@");
            V0.append(q.q1(this));
            V0.append("[receiveMode=");
            return e.e.b.a.a.Y(V0, this.f71e, ']');
        }

        public void x(j<?> jVar) {
            if (this.f71e == 1 && jVar.d == null) {
                k<Object> kVar = this.d;
                Result.Companion companion = Result.Companion;
                kVar.resumeWith(Result.constructor-impl((Object) null));
            } else if (this.f71e == 2) {
                k<Object> kVar2 = this.d;
                a0 a0Var = new a0(new a0.a(jVar.d));
                Result.Companion companion2 = Result.Companion;
                kVar2.resumeWith(Result.constructor-impl(a0Var));
            } else {
                k<Object> kVar3 = this.d;
                Throwable B = jVar.B();
                Result.Companion companion3 = Result.Companion;
                kVar3.resumeWith(Result.constructor-impl(ResultKt.createFailure(B)));
            }
        }
    }

    public static final class c<E> extends b<E> {
        public final ka.h.b.l<E, Unit> f;

        public c(k<Object> kVar, int i, ka.h.b.l<? super E, Unit> lVar) {
            super(kVar, i);
            this.f = lVar;
        }

        public ka.h.b.l<Throwable, Unit> w(E e2) {
            return new p(this.f, e2, this.d.getContext());
        }
    }

    public static class d<E> extends s<E> {
        public final C0002a<E> d;

        /* renamed from: e  reason: collision with root package name */
        public final k<Boolean> f72e;

        public d(C0002a<E> aVar, k<? super Boolean> kVar) {
            this.d = aVar;
            this.f72e = kVar;
        }

        public void d(E e2) {
            this.d.a = e2;
            this.f72e.z(m.a);
        }

        public v h(E e2, l.b bVar) {
            if (this.f72e.q(Boolean.TRUE, (Object) null, w(e2)) != null) {
                return m.a;
            }
            return null;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("ReceiveHasNext@");
            V0.append(q.q1(this));
            return V0.toString();
        }

        public ka.h.b.l<Throwable, Unit> w(E e2) {
            ka.h.b.l<E, Unit> lVar = this.d.b.b;
            if (lVar != null) {
                return new p(lVar, e2, this.f72e.getContext());
            }
            return null;
        }

        public void x(j<?> jVar) {
            Object obj;
            if (jVar.d == null) {
                obj = this.f72e.d(Boolean.FALSE, (Object) null);
            } else {
                obj = this.f72e.m(jVar.B());
            }
            if (obj != null) {
                this.d.a = jVar;
                this.f72e.z(obj);
            }
        }
    }

    public final class e extends oh.a.e {
        public final s<?> a;

        public e(s<?> sVar) {
            this.a = sVar;
        }

        public void a(Throwable th2) {
            if (this.a.t()) {
                a.this.C();
            }
        }

        public Object invoke(Object obj) {
            Throwable th2 = (Throwable) obj;
            if (this.a.t()) {
                a.this.C();
            }
            return Unit.INSTANCE;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("RemoveReceiveOnCancel[");
            V0.append(this.a);
            V0.append(']');
            return V0.toString();
        }
    }

    public static final class f extends l.a {
        public final /* synthetic */ a d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public f(oh.a.t2.l lVar, oh.a.t2.l lVar2, a aVar) {
            super(lVar2);
            this.d = aVar;
        }

        public Object c(Object obj) {
            oh.a.t2.l lVar = (oh.a.t2.l) obj;
            if (this.d.v()) {
                return null;
            }
            return oh.a.t2.k.a;
        }
    }

    @ka.e.k.a.e(c = "kotlinx.coroutines.channels.AbstractChannel", f = "AbstractChannel.kt", l = {631}, m = "receiveOrClosed-WVj179g")
    public static final class g extends ka.e.k.a.c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ a c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public g(a aVar, ka.e.d dVar) {
            super(dVar);
            this.c = aVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            Object e2 = this.c.e(this);
            if (e2 == ka.e.j.a.COROUTINE_SUSPENDED) {
                return e2;
            }
            return new a0(e2);
        }
    }

    public a(ka.h.b.l<? super E, Unit> lVar) {
        super(lVar);
    }

    public void A(boolean z) {
        j<?> i = i();
        if (i != null) {
            Object obj = null;
            while (true) {
                oh.a.t2.l p = i.p();
                if (p instanceof j) {
                    B(obj, i);
                    return;
                } else if (!p.t()) {
                    p.q();
                } else {
                    obj = q.C2(obj, (w) p);
                }
            }
        } else {
            throw new IllegalStateException("Cannot happen".toString());
        }
    }

    public void B(Object obj, j<?> jVar) {
        if (obj != null) {
            if (!(obj instanceof ArrayList)) {
                ((w) obj).y(jVar);
                return;
            }
            ArrayList arrayList = (ArrayList) obj;
            int size = arrayList.size();
            while (true) {
                size--;
                if (size >= 0) {
                    ((w) arrayList.get(size)).y(jVar);
                } else {
                    return;
                }
            }
        }
    }

    public void C() {
    }

    public void D() {
    }

    public Object E() {
        while (true) {
            w r = r();
            if (r == null) {
                return b.d;
            }
            if (r.z((l.b) null) != null) {
                r.w();
                return r.x();
            }
            r.A();
        }
    }

    public final void c(CancellationException cancellationException) {
        if (!z()) {
            if (cancellationException == null) {
                cancellationException = new CancellationException(getClass().getSimpleName() + " was cancelled");
            }
            A(w(cancellationException));
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0030  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object e(ka.e.d<? super oh.a.r2.a0<? extends E>> r7) {
        /*
            r6 = this;
            boolean r0 = r7 instanceof oh.a.r2.a.g
            if (r0 == 0) goto L_0x0013
            r0 = r7
            oh.a.r2.a$g r0 = (oh.a.r2.a.g) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.r2.a$g r0 = new oh.a.r2.a$g
            r0.<init>(r6, r7)
        L_0x0018:
            java.lang.Object r7 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 1
            if (r2 == 0) goto L_0x0030
            if (r2 != r3) goto L_0x0028
            kotlin.ResultKt.throwOnFailure(r7)
            goto L_0x00ae
        L_0x0028:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r0)
            throw r7
        L_0x0030:
            kotlin.ResultKt.throwOnFailure(r7)
            java.lang.Object r7 = r6.E()
            oh.a.t2.v r2 = oh.a.r2.b.d
            if (r7 == r2) goto L_0x004a
            boolean r0 = r7 instanceof oh.a.r2.j
            if (r0 == 0) goto L_0x0049
            oh.a.r2.j r7 = (oh.a.r2.j) r7
            java.lang.Throwable r7 = r7.d
            oh.a.r2.a0$a r0 = new oh.a.r2.a0$a
            r0.<init>(r7)
            r7 = r0
        L_0x0049:
            return r7
        L_0x004a:
            r0.b = r3
            ka.e.d r7 = ka.b.q.M1(r0)
            oh.a.l r7 = ka.b.q.C1(r7)
            ka.h.b.l<E, kotlin.Unit> r2 = r6.b
            r3 = 2
            if (r2 != 0) goto L_0x005f
            oh.a.r2.a$b r2 = new oh.a.r2.a$b
            r2.<init>(r7, r3)
            goto L_0x0066
        L_0x005f:
            oh.a.r2.a$c r2 = new oh.a.r2.a$c
            ka.h.b.l<E, kotlin.Unit> r4 = r6.b
            r2.<init>(r7, r3, r4)
        L_0x0066:
            boolean r4 = r6.t(r2)
            if (r4 == 0) goto L_0x006f
            r6.D()
        L_0x006f:
            if (r4 == 0) goto L_0x007a
            oh.a.r2.a$e r3 = new oh.a.r2.a$e
            r3.<init>(r2)
            r7.l(r3)
            goto L_0x009e
        L_0x007a:
            java.lang.Object r4 = r6.E()
            boolean r5 = r4 instanceof oh.a.r2.j
            if (r5 == 0) goto L_0x0088
            oh.a.r2.j r4 = (oh.a.r2.j) r4
            r2.x(r4)
            goto L_0x009e
        L_0x0088:
            oh.a.t2.v r5 = oh.a.r2.b.d
            if (r4 == r5) goto L_0x0066
            int r5 = r2.f71e
            if (r5 == r3) goto L_0x0092
            r3 = r4
            goto L_0x0097
        L_0x0092:
            oh.a.r2.a0 r3 = new oh.a.r2.a0
            r3.<init>(r4)
        L_0x0097:
            ka.h.b.l r2 = r2.w(r4)
            r7.n(r3, r2)
        L_0x009e:
            java.lang.Object r7 = r7.t()
            ka.e.j.a r2 = ka.e.j.a.COROUTINE_SUSPENDED
            if (r7 != r2) goto L_0x00ab
            java.lang.String r2 = "frame"
            ka.h.c.p.e(r0, r2)
        L_0x00ab:
            if (r7 != r1) goto L_0x00ae
            return r1
        L_0x00ae:
            oh.a.r2.a0 r7 = (oh.a.r2.a0) r7
            java.lang.Object r7 = r7.a
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.r2.a.e(ka.e.d):java.lang.Object");
    }

    public final h<E> iterator() {
        return new C0002a(this);
    }

    public u<E> q() {
        u<E> q = super.q();
        if (q != null && !(q instanceof j)) {
            C();
        }
        return q;
    }

    public boolean t(s<? super E> sVar) {
        int v;
        oh.a.t2.l p;
        if (!u()) {
            j jVar = this.a;
            f fVar = new f(sVar, sVar, this);
            do {
                oh.a.t2.l p2 = jVar.p();
                if (!(!(p2 instanceof w))) {
                    break;
                }
                v = p2.v(sVar, jVar, fVar);
                if (v == 1) {
                    return true;
                }
            } while (v != 2);
        } else {
            j jVar2 = this.a;
            do {
                p = jVar2.p();
                if (!(!(p instanceof w))) {
                }
            } while (!p.i(sVar, jVar2));
            return true;
        }
        return false;
    }

    public abstract boolean u();

    public abstract boolean v();

    public boolean z() {
        oh.a.t2.l o = this.a.o();
        j jVar = null;
        if (!(o instanceof j)) {
            o = null;
        }
        j jVar2 = (j) o;
        if (jVar2 != null) {
            j(jVar2);
            jVar = jVar2;
        }
        return jVar != null && v();
    }
}

package oh.a.r2;

import ka.e.d;

public interface h<E> {
    Object a(d<? super Boolean> dVar);

    E next();
}

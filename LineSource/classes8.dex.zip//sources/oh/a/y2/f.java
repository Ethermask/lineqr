package oh.a.y2;

import ka.h.b.l;
import ka.h.c.r;
import kotlin.Unit;
import oh.a.k;
import oh.a.y2.e;

public final class f extends r implements l<Throwable, Unit> {
    public final /* synthetic */ e a;
    public final /* synthetic */ Object b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public f(k kVar, e.a aVar, e eVar, Object obj) {
        super(1);
        this.a = eVar;
        this.b = obj;
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        this.a.b(this.b);
        return Unit.INSTANCE;
    }
}

package oh.a.y2;

import ka.e.d;
import kotlin.Unit;

public interface i {
    Object a(d<? super Unit> dVar);

    void release();
}

package oh.a.y2;

import kotlin.Unit;
import oh.a.i;
import oh.a.t2.t;

public final class a extends i {
    public final l a;
    public final int b;

    public a(l lVar, int i) {
        this.a = lVar;
        this.b = i;
    }

    public void a(Throwable th2) {
        l lVar = this.a;
        int i = this.b;
        if (lVar != null) {
            lVar.f109e.set(i, k.f108e);
            if (t.d.incrementAndGet(lVar) == k.f && !lVar.c()) {
                lVar.d();
                return;
            }
            return;
        }
        throw null;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        a((Throwable) obj);
        return Unit.INSTANCE;
    }

    public String toString() {
        StringBuilder V0 = e.e.b.a.a.V0("CancelSemaphoreAcquisitionHandler[");
        V0.append(this.a);
        V0.append(", ");
        return e.e.b.a.a.Y(V0, this.b, ']');
    }
}

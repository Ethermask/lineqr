package oh.a.y2;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.h.b.l;
import ka.h.c.r;
import kotlin.Unit;

public final class j implements i {
    public static final /* synthetic */ AtomicReferenceFieldUpdater c;
    public static final /* synthetic */ AtomicLongFieldUpdater d;

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f107e;
    public static final /* synthetic */ AtomicLongFieldUpdater f;
    public static final /* synthetic */ AtomicIntegerFieldUpdater g;
    public volatile /* synthetic */ int _availablePermits;
    public final l<Throwable, Unit> a;
    public final int b;
    public volatile /* synthetic */ long deqIdx = 0;
    public volatile /* synthetic */ long enqIdx = 0;
    public volatile /* synthetic */ Object head;
    public volatile /* synthetic */ Object tail;

    public static final class a extends r implements l<Throwable, Unit> {
        public final /* synthetic */ j a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(j jVar) {
            super(1);
            this.a = jVar;
        }

        public Object invoke(Object obj) {
            Throwable th2 = (Throwable) obj;
            this.a.release();
            return Unit.INSTANCE;
        }
    }

    static {
        Class<Object> cls = Object.class;
        Class<j> cls2 = j.class;
        c = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "head");
        d = AtomicLongFieldUpdater.newUpdater(cls2, "deqIdx");
        f107e = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "tail");
        f = AtomicLongFieldUpdater.newUpdater(cls2, "enqIdx");
        g = AtomicIntegerFieldUpdater.newUpdater(cls2, "_availablePermits");
    }

    public j(int i, int i2) {
        this.b = i;
        boolean z = true;
        if (this.b > 0) {
            if ((i2 < 0 || this.b < i2) ? false : z) {
                l lVar = new l(0, (l) null, 2);
                this.head = lVar;
                this.tail = lVar;
                this._availablePermits = this.b - i2;
                this.a = new a(this);
                return;
            }
            StringBuilder V0 = e.e.b.a.a.V0("The number of acquired permits should be in 0..");
            V0.append(this.b);
            throw new IllegalArgumentException(V0.toString().toString());
        }
        StringBuilder V02 = e.e.b.a.a.V0("Semaphore should have at least 1 permit, but had ");
        V02.append(this.b);
        throw new IllegalArgumentException(V02.toString().toString());
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v0, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v1, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v2, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v0, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v4, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v5, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v6, resolved type: oh.a.y2.l} */
    /* JADX WARNING: type inference failed for: r8v13, types: [oh.a.t2.t] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00ae  */
    /* JADX WARNING: Removed duplicated region for block: B:65:0x00bd A[EDGE_INSN: B:65:0x00bd->B:47:0x00bd ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object a(ka.e.d<? super kotlin.Unit> r16) {
        /*
            r15 = this;
            r0 = r15
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r1 = g
            int r1 = r1.getAndDecrement(r15)
            if (r1 <= 0) goto L_0x000c
            kotlin.Unit r1 = kotlin.Unit.INSTANCE
            return r1
        L_0x000c:
            ka.e.d r1 = ka.b.q.M1(r16)
            oh.a.l r1 = ka.b.q.C1(r1)
        L_0x0014:
            java.lang.Object r2 = r0.tail
            oh.a.y2.l r2 = (oh.a.y2.l) r2
            java.util.concurrent.atomic.AtomicLongFieldUpdater r3 = f
            long r3 = r3.getAndIncrement(r15)
            int r5 = oh.a.y2.k.f
            long r5 = (long) r5
            long r5 = r3 / r5
        L_0x0023:
            r7 = r2
        L_0x0024:
            long r8 = r7.c
            int r8 = (r8 > r5 ? 1 : (r8 == r5 ? 0 : -1))
            r9 = 0
            if (r8 < 0) goto L_0x0031
            boolean r8 = r7.b()
            if (r8 == 0) goto L_0x0038
        L_0x0031:
            java.lang.Object r8 = r7._next
            oh.a.t2.v r11 = oh.a.t2.e.a
            if (r8 != r11) goto L_0x00d8
            r7 = r11
        L_0x0038:
            oh.a.t2.v r8 = oh.a.t2.e.a
            if (r7 != r8) goto L_0x003e
            r8 = 1
            goto L_0x003f
        L_0x003e:
            r8 = 0
        L_0x003f:
            if (r8 != 0) goto L_0x0079
            oh.a.t2.t r8 = ka.b.q.F1(r7)
        L_0x0045:
            java.lang.Object r12 = r0.tail
            oh.a.t2.t r12 = (oh.a.t2.t) r12
            long r13 = r12.c
            long r10 = r8.c
            int r10 = (r13 > r10 ? 1 : (r13 == r10 ? 0 : -1))
            if (r10 < 0) goto L_0x0052
            goto L_0x006b
        L_0x0052:
            boolean r10 = r8.f()
            if (r10 != 0) goto L_0x005a
            r8 = 0
            goto L_0x006c
        L_0x005a:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r10 = f107e
            boolean r10 = r10.compareAndSet(r15, r12, r8)
            if (r10 == 0) goto L_0x006f
            boolean r8 = r12.e()
            if (r8 == 0) goto L_0x006b
            r12.d()
        L_0x006b:
            r8 = 1
        L_0x006c:
            if (r8 == 0) goto L_0x0023
            goto L_0x0079
        L_0x006f:
            boolean r10 = r8.e()
            if (r10 == 0) goto L_0x0045
            r8.d()
            goto L_0x0045
        L_0x0079:
            oh.a.t2.t r2 = ka.b.q.F1(r7)
            oh.a.y2.l r2 = (oh.a.y2.l) r2
            int r5 = oh.a.y2.k.f
            long r5 = (long) r5
            long r3 = r3 % r5
            int r3 = (int) r3
            java.util.concurrent.atomic.AtomicReferenceArray r4 = r2.f109e
            boolean r4 = r4.compareAndSet(r3, r9, r1)
            if (r4 == 0) goto L_0x0095
            oh.a.y2.a r4 = new oh.a.y2.a
            r4.<init>(r2, r3)
            r1.l(r4)
            goto L_0x00a8
        L_0x0095:
            oh.a.t2.v r4 = oh.a.y2.k.b
            oh.a.t2.v r5 = oh.a.y2.k.c
            java.util.concurrent.atomic.AtomicReferenceArray r2 = r2.f109e
            boolean r2 = r2.compareAndSet(r3, r4, r5)
            if (r2 == 0) goto L_0x00aa
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            ka.h.b.l<java.lang.Throwable, kotlin.Unit> r3 = r0.a
            r1.n(r2, r3)
        L_0x00a8:
            r10 = 1
            goto L_0x00ab
        L_0x00aa:
            r10 = 0
        L_0x00ab:
            if (r10 == 0) goto L_0x00ae
            goto L_0x00bd
        L_0x00ae:
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r2 = g
            int r2 = r2.getAndDecrement(r15)
            if (r2 <= 0) goto L_0x00d4
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            ka.h.b.l<java.lang.Throwable, kotlin.Unit> r3 = r0.a
            r1.n(r2, r3)
        L_0x00bd:
            java.lang.Object r1 = r1.t()
            ka.e.j.a r2 = ka.e.j.a.COROUTINE_SUSPENDED
            if (r1 != r2) goto L_0x00cc
            java.lang.String r2 = "frame"
            r10 = r16
            ka.h.c.p.e(r10, r2)
        L_0x00cc:
            ka.e.j.a r2 = ka.e.j.a.COROUTINE_SUSPENDED
            if (r1 != r2) goto L_0x00d1
            return r1
        L_0x00d1:
            kotlin.Unit r1 = kotlin.Unit.INSTANCE
            return r1
        L_0x00d4:
            r10 = r16
            goto L_0x0014
        L_0x00d8:
            r10 = r16
            oh.a.t2.f r8 = (oh.a.t2.f) r8
            oh.a.t2.t r8 = (oh.a.t2.t) r8
            if (r8 == 0) goto L_0x00e3
            r7 = r8
            goto L_0x0024
        L_0x00e3:
            long r11 = r7.c
            r13 = 1
            long r11 = r11 + r13
            r8 = r7
            oh.a.y2.l r8 = (oh.a.y2.l) r8
            oh.a.y2.l r13 = new oh.a.y2.l
            r14 = 0
            r13.<init>(r11, r8, r14)
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r8 = oh.a.t2.f.a
            boolean r8 = r8.compareAndSet(r7, r9, r13)
            if (r8 == 0) goto L_0x0024
            boolean r8 = r7.b()
            if (r8 == 0) goto L_0x0102
            r7.d()
        L_0x0102:
            r7 = r13
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.y2.j.a(ka.e.d):java.lang.Object");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v8, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v9, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v10, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v4, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v16, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v17, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v18, resolved type: oh.a.y2.l} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v19, resolved type: oh.a.y2.l} */
    /* JADX WARNING: type inference failed for: r8v13, types: [oh.a.t2.t] */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0071, code lost:
        r8 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:76:0x0072, code lost:
        continue;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void release() {
        /*
            r15 = this;
        L_0x0000:
            int r0 = r15._availablePermits
            int r1 = r15.b
            r2 = 0
            r3 = 1
            if (r0 >= r1) goto L_0x000a
            r1 = r3
            goto L_0x000b
        L_0x000a:
            r1 = r2
        L_0x000b:
            if (r1 == 0) goto L_0x0101
            int r1 = r0 + 1
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r4 = g
            boolean r1 = r4.compareAndSet(r15, r0, r1)
            if (r1 == 0) goto L_0x0000
            if (r0 < 0) goto L_0x001a
            return
        L_0x001a:
            java.lang.Object r0 = r15.head
            oh.a.y2.l r0 = (oh.a.y2.l) r0
            java.util.concurrent.atomic.AtomicLongFieldUpdater r1 = d
            long r4 = r1.getAndIncrement(r15)
            int r1 = oh.a.y2.k.f
            long r6 = (long) r1
            long r6 = r4 / r6
        L_0x0029:
            r1 = r0
        L_0x002a:
            long r8 = r1.c
            int r8 = (r8 > r6 ? 1 : (r8 == r6 ? 0 : -1))
            r9 = 0
            if (r8 < 0) goto L_0x0037
            boolean r8 = r1.b()
            if (r8 == 0) goto L_0x003e
        L_0x0037:
            java.lang.Object r8 = r1._next
            oh.a.t2.v r10 = oh.a.t2.e.a
            if (r8 != r10) goto L_0x00d7
            r1 = r10
        L_0x003e:
            oh.a.t2.v r8 = oh.a.t2.e.a
            if (r1 != r8) goto L_0x0044
            r8 = r3
            goto L_0x0045
        L_0x0044:
            r8 = r2
        L_0x0045:
            if (r8 != 0) goto L_0x007f
            oh.a.t2.t r8 = ka.b.q.F1(r1)
        L_0x004b:
            java.lang.Object r10 = r15.head
            oh.a.t2.t r10 = (oh.a.t2.t) r10
            long r11 = r10.c
            long r13 = r8.c
            int r11 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r11 < 0) goto L_0x0058
            goto L_0x0071
        L_0x0058:
            boolean r11 = r8.f()
            if (r11 != 0) goto L_0x0060
            r8 = r2
            goto L_0x0072
        L_0x0060:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r11 = c
            boolean r11 = r11.compareAndSet(r15, r10, r8)
            if (r11 == 0) goto L_0x0075
            boolean r8 = r10.e()
            if (r8 == 0) goto L_0x0071
            r10.d()
        L_0x0071:
            r8 = r3
        L_0x0072:
            if (r8 == 0) goto L_0x0029
            goto L_0x007f
        L_0x0075:
            boolean r10 = r8.e()
            if (r10 == 0) goto L_0x004b
            r8.d()
            goto L_0x004b
        L_0x007f:
            oh.a.t2.t r0 = ka.b.q.F1(r1)
            oh.a.y2.l r0 = (oh.a.y2.l) r0
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = oh.a.t2.f.b
            r1.lazySet(r0, r9)
            long r10 = r0.c
            int r1 = (r10 > r6 ? 1 : (r10 == r6 ? 0 : -1))
            if (r1 <= 0) goto L_0x0091
            goto L_0x00d4
        L_0x0091:
            int r1 = oh.a.y2.k.f
            long r6 = (long) r1
            long r4 = r4 % r6
            int r1 = (int) r4
            oh.a.t2.v r4 = oh.a.y2.k.b
            java.util.concurrent.atomic.AtomicReferenceArray r5 = r0.f109e
            java.lang.Object r4 = r5.getAndSet(r1, r4)
            if (r4 != 0) goto L_0x00bf
            int r4 = oh.a.y2.k.a
        L_0x00a2:
            if (r2 >= r4) goto L_0x00b2
            java.util.concurrent.atomic.AtomicReferenceArray r5 = r0.f109e
            java.lang.Object r5 = r5.get(r1)
            oh.a.t2.v r6 = oh.a.y2.k.c
            if (r5 != r6) goto L_0x00af
            goto L_0x00d3
        L_0x00af:
            int r2 = r2 + 1
            goto L_0x00a2
        L_0x00b2:
            oh.a.t2.v r2 = oh.a.y2.k.b
            oh.a.t2.v r3 = oh.a.y2.k.d
            java.util.concurrent.atomic.AtomicReferenceArray r0 = r0.f109e
            boolean r0 = r0.compareAndSet(r1, r2, r3)
            r2 = r0 ^ 1
            goto L_0x00d4
        L_0x00bf:
            oh.a.t2.v r0 = oh.a.y2.k.f108e
            if (r4 != r0) goto L_0x00c4
            goto L_0x00d4
        L_0x00c4:
            oh.a.k r4 = (oh.a.k) r4
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            ka.h.b.l<java.lang.Throwable, kotlin.Unit> r1 = r15.a
            java.lang.Object r0 = r4.q(r0, r9, r1)
            if (r0 == 0) goto L_0x00d4
            r4.z(r0)
        L_0x00d3:
            r2 = r3
        L_0x00d4:
            if (r2 == 0) goto L_0x0000
            return
        L_0x00d7:
            oh.a.t2.f r8 = (oh.a.t2.f) r8
            oh.a.t2.t r8 = (oh.a.t2.t) r8
            if (r8 == 0) goto L_0x00e0
            r1 = r8
            goto L_0x002a
        L_0x00e0:
            long r10 = r1.c
            r12 = 1
            long r10 = r10 + r12
            r8 = r1
            oh.a.y2.l r8 = (oh.a.y2.l) r8
            oh.a.y2.l r12 = new oh.a.y2.l
            r12.<init>(r10, r8, r2)
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r8 = oh.a.t2.f.a
            boolean r8 = r8.compareAndSet(r1, r9, r12)
            if (r8 == 0) goto L_0x002a
            boolean r8 = r1.b()
            if (r8 == 0) goto L_0x00fe
            r1.d()
        L_0x00fe:
            r1 = r12
            goto L_0x002a
        L_0x0101:
            java.lang.String r0 = "The number of released permits cannot be greater than "
            java.lang.StringBuilder r0 = e.e.b.a.a.V0(r0)
            int r1 = r15.b
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.y2.j.release():void");
    }
}

package oh.a.y2;

import e.e.b.a.a;
import java.util.concurrent.atomic.AtomicReferenceArray;
import oh.a.t2.t;

public final class l extends t<l> {

    /* renamed from: e  reason: collision with root package name */
    public /* synthetic */ AtomicReferenceArray f109e = new AtomicReferenceArray(k.f);

    public l(long j, l lVar, int i) {
        super(j, lVar, i);
    }

    public String toString() {
        StringBuilder V0 = a.V0("SemaphoreSegment[id=");
        V0.append(this.c);
        V0.append(", hashCode=");
        V0.append(hashCode());
        V0.append(']');
        return V0.toString();
    }
}

package oh.a.y2;

import oh.a.t2.v;

public final class h {
    public static final v a = new v("UNLOCK_FAIL");
    public static final v b = new v("LOCKED");
    public static final v c = new v("UNLOCKED");
    public static final b d = new b(b);

    /* renamed from: e  reason: collision with root package name */
    public static final b f106e = new b(c);

    public static c a(boolean z, int i) {
        if ((i & 1) != 0) {
            z = false;
        }
        return new e(z);
    }
}

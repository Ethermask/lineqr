package oh.a.y2;

import oh.a.k;
import oh.a.t2.l;
import oh.a.y2.e;

public final class g extends l.a {
    public final /* synthetic */ Object d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ e f105e;
    public final /* synthetic */ Object f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public g(l lVar, l lVar2, Object obj, k kVar, e.a aVar, e eVar, Object obj2) {
        super(lVar2);
        this.d = obj;
        this.f105e = eVar;
        this.f = obj2;
    }

    public Object c(Object obj) {
        l lVar = (l) obj;
        if (this.f105e._state == this.d) {
            return null;
        }
        return oh.a.t2.k.a;
    }
}

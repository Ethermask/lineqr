package oh.a.y2;

import e.e.b.a.a;

public final class b {
    public final Object a;

    public b(Object obj) {
        this.a = obj;
    }

    public String toString() {
        return a.l0(a.V0("Empty["), this.a, ']');
    }
}

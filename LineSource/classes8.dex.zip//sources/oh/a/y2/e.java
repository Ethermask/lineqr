package oh.a.y2;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Unit;
import oh.a.k;
import oh.a.t2.j;
import oh.a.t2.l;
import oh.a.t2.q;
import oh.a.u0;

public final class e implements c {
    public static final /* synthetic */ AtomicReferenceFieldUpdater a = AtomicReferenceFieldUpdater.newUpdater(e.class, Object.class, "_state");
    public volatile /* synthetic */ Object _state;

    public final class a extends b {

        /* renamed from: e  reason: collision with root package name */
        public final k<Unit> f104e;

        public a(Object obj, k<? super Unit> kVar) {
            super(e.this, obj);
            this.f104e = kVar;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("LockCont[");
            V0.append(this.d);
            V0.append(", ");
            V0.append(this.f104e);
            V0.append("] for ");
            V0.append(e.this);
            return V0.toString();
        }
    }

    public abstract class b extends l implements u0 {
        public final Object d;

        public b(e eVar, Object obj) {
            this.d = obj;
        }

        public final void dispose() {
            t();
        }
    }

    public static final class c extends j {
        public Object d;

        public c(Object obj) {
            this.d = obj;
        }

        public String toString() {
            return e.e.b.a.a.l0(e.e.b.a.a.V0("LockedQueue["), this.d, ']');
        }
    }

    public static final class d extends oh.a.t2.c<e> {
        public final c b;

        public d(c cVar) {
            this.b = cVar;
        }

        public void b(Object obj, Object obj2) {
            Object obj3;
            e eVar = (e) obj;
            if (obj2 == null) {
                obj3 = h.f106e;
            } else {
                obj3 = this.b;
            }
            e.a.compareAndSet(eVar, this, obj3);
        }

        public Object c(Object obj) {
            e eVar = (e) obj;
            c cVar = this.b;
            if (cVar.n() == cVar) {
                return null;
            }
            return h.a;
        }
    }

    public e(boolean z) {
        b bVar;
        if (z) {
            bVar = h.d;
        } else {
            bVar = h.f106e;
        }
        this._state = bVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0032, code lost:
        r0 = false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object a(java.lang.Object r18, ka.e.d<? super kotlin.Unit> r19) {
        /*
            r17 = this;
            r8 = r17
        L_0x0002:
            java.lang.Object r0 = r8._state
            boolean r1 = r0 instanceof oh.a.y2.b
            java.lang.String r9 = "Illegal state "
            r10 = 1
            java.lang.String r11 = "Already locked by null"
            if (r1 == 0) goto L_0x0023
            r1 = r0
            oh.a.y2.b r1 = (oh.a.y2.b) r1
            java.lang.Object r1 = r1.a
            oh.a.t2.v r2 = oh.a.y2.h.c
            if (r1 == r2) goto L_0x0017
            goto L_0x0032
        L_0x0017:
            oh.a.y2.b r1 = oh.a.y2.h.d
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r2 = a
            boolean r0 = r2.compareAndSet(r8, r0, r1)
            if (r0 == 0) goto L_0x0002
            r0 = r10
            goto L_0x0033
        L_0x0023:
            boolean r1 = r0 instanceof oh.a.y2.e.c
            if (r1 == 0) goto L_0x00fe
            oh.a.y2.e$c r0 = (oh.a.y2.e.c) r0
            java.lang.Object r0 = r0.d
            if (r0 == 0) goto L_0x002f
            r0 = r10
            goto L_0x0030
        L_0x002f:
            r0 = 0
        L_0x0030:
            if (r0 == 0) goto L_0x00f4
        L_0x0032:
            r0 = 0
        L_0x0033:
            if (r0 == 0) goto L_0x0038
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            return r0
        L_0x0038:
            ka.e.d r0 = ka.b.q.M1(r19)
            oh.a.l r12 = ka.b.q.C1(r0)
            oh.a.y2.e$a r13 = new oh.a.y2.e$a
            r14 = 0
            r13.<init>(r14, r12)
        L_0x0046:
            java.lang.Object r3 = r8._state
            boolean r0 = r3 instanceof oh.a.y2.b
            if (r0 == 0) goto L_0x007b
            r0 = r3
            oh.a.y2.b r0 = (oh.a.y2.b) r0
            java.lang.Object r1 = r0.a
            oh.a.t2.v r2 = oh.a.y2.h.c
            if (r1 == r2) goto L_0x0062
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = a
            oh.a.y2.e$c r2 = new oh.a.y2.e$c
            java.lang.Object r0 = r0.a
            r2.<init>(r0)
            r1.compareAndSet(r8, r3, r2)
            goto L_0x0077
        L_0x0062:
            oh.a.y2.b r0 = oh.a.y2.h.d
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = a
            boolean r0 = r1.compareAndSet(r8, r3, r0)
            if (r0 == 0) goto L_0x0077
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            oh.a.y2.f r1 = new oh.a.y2.f
            r1.<init>(r12, r13, r8, r14)
            r12.n(r0, r1)
            goto L_0x00b7
        L_0x0077:
            r2 = r19
            goto L_0x00e3
        L_0x007b:
            boolean r0 = r3 instanceof oh.a.y2.e.c
            if (r0 == 0) goto L_0x00d8
            r15 = r3
            oh.a.y2.e$c r15 = (oh.a.y2.e.c) r15
            java.lang.Object r0 = r15.d
            if (r0 == 0) goto L_0x0088
            r0 = r10
            goto L_0x0089
        L_0x0088:
            r0 = 0
        L_0x0089:
            if (r0 == 0) goto L_0x00ce
            oh.a.y2.g r7 = new oh.a.y2.g
            r16 = 0
            r0 = r7
            r1 = r13
            r2 = r13
            r4 = r12
            r5 = r13
            r6 = r17
            r14 = r7
            r7 = r16
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
        L_0x009c:
            oh.a.t2.l r0 = r15.p()
            int r0 = r0.v(r13, r15, r14)
            if (r0 == r10) goto L_0x00ac
            r1 = 2
            if (r0 == r1) goto L_0x00aa
            goto L_0x009c
        L_0x00aa:
            r0 = 0
            goto L_0x00ad
        L_0x00ac:
            r0 = r10
        L_0x00ad:
            if (r0 == 0) goto L_0x0077
            oh.a.b2 r0 = new oh.a.b2
            r0.<init>(r13)
            r12.l(r0)
        L_0x00b7:
            java.lang.Object r0 = r12.t()
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            if (r0 != r1) goto L_0x00c6
            java.lang.String r1 = "frame"
            r2 = r19
            ka.h.c.p.e(r2, r1)
        L_0x00c6:
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            if (r0 != r1) goto L_0x00cb
            return r0
        L_0x00cb:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            return r0
        L_0x00ce:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = r11.toString()
            r0.<init>(r1)
            throw r0
        L_0x00d8:
            r2 = r19
            boolean r0 = r3 instanceof oh.a.t2.q
            if (r0 == 0) goto L_0x00e6
            oh.a.t2.q r3 = (oh.a.t2.q) r3
            r3.a(r8)
        L_0x00e3:
            r14 = 0
            goto L_0x0046
        L_0x00e6:
            java.lang.String r0 = e.e.b.a.a.B(r9, r3)
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        L_0x00f4:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = r11.toString()
            r0.<init>(r1)
            throw r0
        L_0x00fe:
            r2 = r19
            boolean r1 = r0 instanceof oh.a.t2.q
            if (r1 == 0) goto L_0x010b
            oh.a.t2.q r0 = (oh.a.t2.q) r0
            r0.a(r8)
            goto L_0x0002
        L_0x010b:
            java.lang.String r0 = e.e.b.a.a.B(r9, r0)
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.y2.e.a(java.lang.Object, ka.e.d):java.lang.Object");
    }

    public void b(Object obj) {
        l lVar;
        while (true) {
            Object obj2 = this._state;
            boolean z = true;
            if (obj2 instanceof b) {
                if (obj == null) {
                    if (((b) obj2).a == h.c) {
                        z = false;
                    }
                    if (!z) {
                        throw new IllegalStateException("Mutex is not locked".toString());
                    }
                } else {
                    b bVar = (b) obj2;
                    if (bVar.a != obj) {
                        z = false;
                    }
                    if (!z) {
                        StringBuilder V0 = e.e.b.a.a.V0("Mutex is locked by ");
                        V0.append(bVar.a);
                        V0.append(" but expected ");
                        V0.append(obj);
                        throw new IllegalStateException(V0.toString().toString());
                    }
                }
                if (a.compareAndSet(this, obj2, h.f106e)) {
                    return;
                }
            } else if (obj2 instanceof q) {
                ((q) obj2).a(this);
            } else if (obj2 instanceof c) {
                if (obj != null) {
                    c cVar = (c) obj2;
                    if (cVar.d != obj) {
                        z = false;
                    }
                    if (!z) {
                        StringBuilder V02 = e.e.b.a.a.V0("Mutex is locked by ");
                        V02.append(cVar.d);
                        V02.append(" but expected ");
                        V02.append(obj);
                        throw new IllegalStateException(V02.toString().toString());
                    }
                }
                c cVar2 = (c) obj2;
                while (true) {
                    Object n = cVar2.n();
                    if (n != null) {
                        lVar = (l) n;
                        if (lVar == cVar2) {
                            lVar = null;
                            break;
                        } else if (lVar.t()) {
                            break;
                        } else {
                            lVar.q();
                        }
                    } else {
                        throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */");
                    }
                }
                if (lVar == null) {
                    d dVar = new d(cVar2);
                    if (a.compareAndSet(this, obj2, dVar) && dVar.a(this) == null) {
                        return;
                    }
                } else {
                    b bVar2 = (b) lVar;
                    a aVar = (a) bVar2;
                    Object q = aVar.f104e.q(Unit.INSTANCE, (Object) null, new d(aVar));
                    if (q != null) {
                        Object obj3 = bVar2.d;
                        if (obj3 == null) {
                            obj3 = h.b;
                        }
                        cVar2.d = obj3;
                        aVar.f104e.z(q);
                        return;
                    }
                }
            } else {
                throw new IllegalStateException(e.e.b.a.a.B("Illegal state ", obj2).toString());
            }
        }
    }

    public String toString() {
        while (true) {
            Object obj = this._state;
            if (obj instanceof b) {
                return e.e.b.a.a.l0(e.e.b.a.a.V0("Mutex["), ((b) obj).a, ']');
            }
            if (obj instanceof q) {
                ((q) obj).a(this);
            } else if (obj instanceof c) {
                return e.e.b.a.a.l0(e.e.b.a.a.V0("Mutex["), ((c) obj).d, ']');
            } else {
                throw new IllegalStateException(e.e.b.a.a.B("Illegal state ", obj).toString());
            }
        }
    }
}

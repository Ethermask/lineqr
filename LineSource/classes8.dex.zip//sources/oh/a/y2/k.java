package oh.a.y2;

import ka.b.q;
import oh.a.t2.v;

public final class k {
    public static final int a = q.v3("kotlinx.coroutines.semaphore.maxSpinCycles", 100, 0, 0, 12, (Object) null);
    public static final v b = new v("PERMIT");
    public static final v c = new v("TAKEN");
    public static final v d = new v("BROKEN");

    /* renamed from: e  reason: collision with root package name */
    public static final v f108e = new v("CANCELLED");
    public static final int f = q.v3("kotlinx.coroutines.semaphore.segmentSize", 16, 0, 0, 12, (Object) null);

    public static i a(int i, int i2, int i3) {
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        return new j(i, i2);
    }
}

package oh.a.y2;

import ka.e.d;
import kotlin.Unit;

public interface c {
    Object a(Object obj, d<? super Unit> dVar);

    void b(Object obj);
}

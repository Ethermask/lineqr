package oh.a.y2;

import ka.h.b.l;
import ka.h.c.r;
import kotlin.Unit;
import oh.a.y2.e;

public final class d extends r implements l<Throwable, Unit> {
    public final /* synthetic */ e.a a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public d(e.a aVar) {
        super(1);
        this.a = aVar;
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        e.a aVar = this.a;
        e.this.b(aVar.d);
        return Unit.INSTANCE;
    }
}

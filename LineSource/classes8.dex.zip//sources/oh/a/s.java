package oh.a;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import ka.e.f;
import ka.m.q;

public final class s extends d1 {
    public static final int b;
    public static final s c = new s();
    public static volatile Executor pool;

    public static final class a implements ThreadFactory {
        public final /* synthetic */ AtomicInteger a;

        public a(AtomicInteger atomicInteger) {
            this.a = atomicInteger;
        }

        public final Thread newThread(Runnable runnable) {
            StringBuilder V0 = e.e.b.a.a.V0("CommonPool-worker-");
            V0.append(this.a.incrementAndGet());
            Thread thread = new Thread(runnable, V0.toString());
            thread.setDaemon(true);
            return thread;
        }
    }

    static {
        String str;
        int i;
        try {
            str = System.getProperty("kotlinx.coroutines.default.parallelism");
        } catch (Throwable unused) {
            str = null;
        }
        if (str != null) {
            Integer j = q.j(str);
            if (j == null || j.intValue() < 1) {
                throw new IllegalStateException(e.e.b.a.a.C("Expected positive number in kotlinx.coroutines.default.parallelism, but has ", str).toString());
            }
            i = j.intValue();
        } else {
            i = -1;
        }
        b = i;
    }

    public void close() {
        throw new IllegalStateException("Close cannot be invoked on CommonPool".toString());
    }

    public void d0(f fVar, Runnable runnable) {
        try {
            Executor executor = pool;
            if (executor == null) {
                executor = l0();
            }
            executor.execute(runnable);
        } catch (RejectedExecutionException unused) {
            k0.h.z0(runnable);
        }
    }

    public Executor h0() {
        Executor executor = pool;
        return executor != null ? executor : l0();
    }

    public final ExecutorService i0() {
        return Executors.newFixedThreadPool(n0(), new a(new AtomicInteger()));
    }

    public final ExecutorService j0() {
        Class<?> cls;
        ExecutorService executorService;
        Integer num;
        if (System.getSecurityManager() != null) {
            return i0();
        }
        ExecutorService executorService2 = null;
        try {
            cls = Class.forName("java.util.concurrent.ForkJoinPool");
        } catch (Throwable unused) {
            cls = null;
        }
        if (cls == null) {
            return i0();
        }
        if (b < 0) {
            try {
                Object invoke = cls.getMethod("commonPool", new Class[0]).invoke((Object) null, new Object[0]);
                if (!(invoke instanceof ExecutorService)) {
                    invoke = null;
                }
                executorService = (ExecutorService) invoke;
            } catch (Throwable unused2) {
                executorService = null;
            }
            if (executorService != null) {
                if (c != null) {
                    executorService.submit(t.a);
                    try {
                        Object invoke2 = cls.getMethod("getPoolSize", new Class[0]).invoke(executorService, new Object[0]);
                        if (!(invoke2 instanceof Integer)) {
                            invoke2 = null;
                        }
                        num = (Integer) invoke2;
                    } catch (Throwable unused3) {
                        num = null;
                    }
                    if (!(num != null && num.intValue() >= 1)) {
                        executorService = null;
                    }
                    if (executorService != null) {
                        return executorService;
                    }
                } else {
                    throw null;
                }
            }
        }
        try {
            Object newInstance = cls.getConstructor(new Class[]{Integer.TYPE}).newInstance(new Object[]{Integer.valueOf(c.n0())});
            if (!(newInstance instanceof ExecutorService)) {
                newInstance = null;
            }
            executorService2 = (ExecutorService) newInstance;
        } catch (Throwable unused4) {
        }
        if (executorService2 != null) {
            return executorService2;
        }
        return i0();
    }

    public final synchronized Executor l0() {
        Executor executor;
        executor = pool;
        if (executor == null) {
            executor = j0();
            pool = executor;
        }
        return executor;
    }

    public final int n0() {
        Integer valueOf = Integer.valueOf(b);
        int i = 1;
        if (!(valueOf.intValue() > 0)) {
            valueOf = null;
        }
        if (valueOf != null) {
            return valueOf.intValue();
        }
        int availableProcessors = Runtime.getRuntime().availableProcessors() - 1;
        if (availableProcessors >= 1) {
            i = availableProcessors;
        }
        return i;
    }

    public String toString() {
        return "CommonPool";
    }
}

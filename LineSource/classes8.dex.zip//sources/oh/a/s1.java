package oh.a;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.b.q;
import ka.e.f;
import ka.e.k.a.h;
import ka.h.c.p;
import ka.l.m;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.ExceptionsKt__ExceptionsKt;
import kotlin.Unit;
import oh.a.t2.k;
import oh.a.t2.l;

@Deprecated(level = DeprecationLevel.ERROR, message = "This is internal API and may be removed in the future releases")
public class s1 implements n1, r, a2 {
    public static final /* synthetic */ AtomicReferenceFieldUpdater a = AtomicReferenceFieldUpdater.newUpdater(s1.class, Object.class, "_state");
    public volatile /* synthetic */ Object _parentHandle;
    public volatile /* synthetic */ Object _state;

    public static final class a<T> extends l<T> {
        public final s1 h;

        public a(ka.e.d<? super T> dVar, s1 s1Var) {
            super(dVar, 1);
            this.h = s1Var;
        }

        public String A() {
            return "AwaitContinuation";
        }

        public Throwable s(n1 n1Var) {
            Throwable th2;
            Object W = this.h.W();
            if ((W instanceof c) && (th2 = (Throwable) ((c) W)._rootCause) != null) {
                return th2;
            }
            if (W instanceof y) {
                return ((y) W).a;
            }
            return n1Var.k();
        }
    }

    public static final class b extends r1 {

        /* renamed from: e  reason: collision with root package name */
        public final s1 f77e;
        public final c f;
        public final q g;
        public final Object h;

        public b(s1 s1Var, c cVar, q qVar, Object obj) {
            this.f77e = s1Var;
            this.f = cVar;
            this.g = qVar;
            this.h = obj;
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            w((Throwable) obj);
            return Unit.INSTANCE;
        }

        public void w(Throwable th2) {
            s1.A(this.f77e, this.f, this.g, this.h);
        }
    }

    public static final class c implements i1 {
        public volatile /* synthetic */ Object _exceptionsHolder = null;
        public volatile /* synthetic */ int _isCompleting;
        public volatile /* synthetic */ Object _rootCause;
        public final x1 a;

        public c(x1 x1Var, boolean z, Throwable th2) {
            this.a = x1Var;
            this._isCompleting = z ? 1 : 0;
            this._rootCause = th2;
        }

        public final void a(Throwable th2) {
            Throwable th3 = (Throwable) this._rootCause;
            if (th3 == null) {
                this._rootCause = th2;
            } else if (th2 != th3) {
                Object obj = this._exceptionsHolder;
                if (obj == null) {
                    this._exceptionsHolder = th2;
                } else if (obj instanceof Throwable) {
                    if (th2 != obj) {
                        ArrayList<Throwable> b = b();
                        b.add(obj);
                        b.add(th2);
                        Unit unit = Unit.INSTANCE;
                        this._exceptionsHolder = b;
                    }
                } else if (obj instanceof ArrayList) {
                    ((ArrayList) obj).add(th2);
                } else {
                    throw new IllegalStateException(e.e.b.a.a.B("State is ", obj).toString());
                }
            }
        }

        public final ArrayList<Throwable> b() {
            return new ArrayList<>(4);
        }

        public x1 c() {
            return this.a;
        }

        public final boolean d() {
            return ((Throwable) this._rootCause) != null;
        }

        public final boolean e() {
            return this._exceptionsHolder == t1.f89e;
        }

        public final List<Throwable> f(Throwable th2) {
            ArrayList<Throwable> arrayList;
            Object obj = this._exceptionsHolder;
            if (obj == null) {
                arrayList = b();
            } else if (obj instanceof Throwable) {
                ArrayList<Throwable> b = b();
                b.add(obj);
                arrayList = b;
            } else if (obj instanceof ArrayList) {
                arrayList = (ArrayList) obj;
            } else {
                throw new IllegalStateException(e.e.b.a.a.B("State is ", obj).toString());
            }
            Throwable th3 = (Throwable) this._rootCause;
            if (th3 != null) {
                arrayList.add(0, th3);
            }
            if (th2 != null && (!p.b(th2, th3))) {
                arrayList.add(th2);
            }
            this._exceptionsHolder = t1.f89e;
            return arrayList;
        }

        public boolean isActive() {
            return ((Throwable) this._rootCause) == null;
        }

        /* JADX WARNING: type inference failed for: r1v2, types: [boolean, int] */
        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("Finishing[cancelling=");
            V0.append(d());
            V0.append(", completing=");
            V0.append(this._isCompleting);
            V0.append(", rootCause=");
            V0.append((Throwable) this._rootCause);
            V0.append(", exceptions=");
            V0.append(this._exceptionsHolder);
            V0.append(", list=");
            V0.append(this.a);
            V0.append(']');
            return V0.toString();
        }
    }

    public static final class d extends l.a {
        public final /* synthetic */ s1 d;

        /* renamed from: e  reason: collision with root package name */
        public final /* synthetic */ Object f78e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public d(l lVar, l lVar2, s1 s1Var, Object obj) {
            super(lVar2);
            this.d = s1Var;
            this.f78e = obj;
        }

        public Object c(Object obj) {
            l lVar = (l) obj;
            if (this.d.W() == this.f78e) {
                return null;
            }
            return k.a;
        }
    }

    @ka.e.k.a.e(c = "kotlinx.coroutines.JobSupport$children$1", f = "JobSupport.kt", l = {952, 954}, m = "invokeSuspend")
    public static final class e extends h implements ka.h.b.p<m<? super r>, ka.e.d<? super Unit>, Object> {
        public /* synthetic */ Object b;
        public Object c;
        public Object d;

        /* renamed from: e  reason: collision with root package name */
        public int f79e;
        public final /* synthetic */ s1 f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public e(s1 s1Var, ka.e.d dVar) {
            super(2, dVar);
            this.f = s1Var;
        }

        public final ka.e.d<Unit> create(Object obj, ka.e.d<?> dVar) {
            e eVar = new e(this.f, dVar);
            eVar.b = obj;
            return eVar;
        }

        public final Object invoke(Object obj, Object obj2) {
            e eVar = new e(this.f, (ka.e.d) obj2);
            eVar.b = obj;
            return eVar.invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARNING: Removed duplicated region for block: B:22:0x0067  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final java.lang.Object invokeSuspend(java.lang.Object r9) {
            /*
                r8 = this;
                ka.e.j.a r0 = ka.e.j.a.COROUTINE_SUSPENDED
                int r1 = r8.f79e
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L_0x0029
                if (r1 == r3) goto L_0x0025
                if (r1 != r2) goto L_0x001d
                java.lang.Object r1 = r8.d
                oh.a.t2.l r1 = (oh.a.t2.l) r1
                java.lang.Object r4 = r8.c
                oh.a.t2.j r4 = (oh.a.t2.j) r4
                java.lang.Object r5 = r8.b
                ka.l.m r5 = (ka.l.m) r5
                kotlin.ResultKt.throwOnFailure(r9)
                r9 = r8
                goto L_0x007f
            L_0x001d:
                java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r9.<init>(r0)
                throw r9
            L_0x0025:
                kotlin.ResultKt.throwOnFailure(r9)
                goto L_0x008c
            L_0x0029:
                kotlin.ResultKt.throwOnFailure(r9)
                java.lang.Object r9 = r8.b
                ka.l.m r9 = (ka.l.m) r9
                oh.a.s1 r1 = r8.f
                java.lang.Object r1 = r1.W()
                boolean r4 = r1 instanceof oh.a.q
                if (r4 == 0) goto L_0x0047
                oh.a.q r1 = (oh.a.q) r1
                oh.a.r r1 = r1.f69e
                r8.f79e = r3
                java.lang.Object r9 = r9.a(r1, r8)
                if (r9 != r0) goto L_0x008c
                return r0
            L_0x0047:
                boolean r4 = r1 instanceof oh.a.i1
                if (r4 == 0) goto L_0x008c
                oh.a.i1 r1 = (oh.a.i1) r1
                oh.a.x1 r1 = r1.c()
                if (r1 == 0) goto L_0x008c
                java.lang.Object r4 = r1.n()
                if (r4 == 0) goto L_0x0084
                oh.a.t2.l r4 = (oh.a.t2.l) r4
                r5 = r9
                r9 = r8
                r7 = r4
                r4 = r1
                r1 = r7
            L_0x0060:
                boolean r6 = ka.h.c.p.b(r1, r4)
                r6 = r6 ^ r3
                if (r6 == 0) goto L_0x008c
                boolean r6 = r1 instanceof oh.a.q
                if (r6 == 0) goto L_0x007f
                r6 = r1
                oh.a.q r6 = (oh.a.q) r6
                oh.a.r r6 = r6.f69e
                r9.b = r5
                r9.c = r4
                r9.d = r1
                r9.f79e = r2
                java.lang.Object r6 = r5.a(r6, r9)
                if (r6 != r0) goto L_0x007f
                return r0
            L_0x007f:
                oh.a.t2.l r1 = r1.o()
                goto L_0x0060
            L_0x0084:
                java.lang.NullPointerException r9 = new java.lang.NullPointerException
                java.lang.String r0 = "null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */"
                r9.<init>(r0)
                throw r9
            L_0x008c:
                kotlin.Unit r9 = kotlin.Unit.INSTANCE
                return r9
            */
            throw new UnsupportedOperationException("Method not decompiled: oh.a.s1.e.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    public s1(boolean z) {
        x0 x0Var;
        if (z) {
            x0Var = t1.g;
        } else {
            x0Var = t1.f;
        }
        this._state = x0Var;
        this._parentHandle = null;
    }

    public static final void A(s1 s1Var, c cVar, q qVar, Object obj) {
        q g0 = s1Var.g0(qVar);
        if (g0 == null || !s1Var.r0(cVar, g0, obj)) {
            s1Var.C(s1Var.Q(cVar, obj));
        }
    }

    public static /* synthetic */ CancellationException p0(s1 s1Var, Throwable th2, String str, int i, Object obj) {
        int i2 = i & 1;
        return s1Var.o0(th2, (String) null);
    }

    public final boolean B(Object obj, x1 x1Var, r1 r1Var) {
        int v;
        d dVar = new d(r1Var, r1Var, this, obj);
        do {
            v = x1Var.p().v(r1Var, x1Var, dVar);
            if (v == 1) {
                return true;
            }
        } while (v != 2);
        return false;
    }

    public void C(Object obj) {
    }

    public final Object D(ka.e.d<Object> dVar) {
        Object W;
        do {
            W = W();
            if (!(W instanceof i1)) {
                if (!(W instanceof y)) {
                    return t1.a(W);
                }
                throw ((y) W).a;
            }
        } while (m0(W) < 0);
        a aVar = new a(q.M1(dVar), this);
        aVar.l(new v0(j(false, true, new c2(aVar))));
        Object t = aVar.t();
        if (t == ka.e.j.a.COROUTINE_SUSPENDED) {
            p.e(dVar, "frame");
        }
        return t;
    }

    /* JADX WARNING: Removed duplicated region for block: B:85:0x00b9 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x003e A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean E(java.lang.Object r10) {
        /*
            r9 = this;
            oh.a.t2.v r0 = oh.a.t1.a
            boolean r1 = r9.U()
            r2 = 2
            r3 = 0
            r4 = 1
            if (r1 == 0) goto L_0x0038
        L_0x000b:
            java.lang.Object r0 = r9.W()
            boolean r1 = r0 instanceof oh.a.i1
            if (r1 == 0) goto L_0x0031
            boolean r1 = r0 instanceof oh.a.s1.c
            if (r1 == 0) goto L_0x001f
            r1 = r0
            oh.a.s1$c r1 = (oh.a.s1.c) r1
            int r1 = r1._isCompleting
            if (r1 == 0) goto L_0x001f
            goto L_0x0031
        L_0x001f:
            oh.a.y r1 = new oh.a.y
            java.lang.Throwable r5 = r9.O(r10)
            r1.<init>(r5, r3, r2)
            java.lang.Object r0 = r9.q0(r0, r1)
            oh.a.t2.v r1 = oh.a.t1.c
            if (r0 == r1) goto L_0x000b
            goto L_0x0033
        L_0x0031:
            oh.a.t2.v r0 = oh.a.t1.a
        L_0x0033:
            oh.a.t2.v r1 = oh.a.t1.b
            if (r0 != r1) goto L_0x0038
            return r4
        L_0x0038:
            oh.a.t2.v r1 = oh.a.t1.a
            if (r0 != r1) goto L_0x00e4
            r0 = 0
            r1 = r0
        L_0x003e:
            java.lang.Object r5 = r9.W()
            boolean r6 = r5 instanceof oh.a.s1.c
            if (r6 == 0) goto L_0x0089
            monitor-enter(r5)
            r2 = r5
            oh.a.s1$c r2 = (oh.a.s1.c) r2     // Catch:{ all -> 0x0086 }
            boolean r2 = r2.e()     // Catch:{ all -> 0x0086 }
            if (r2 == 0) goto L_0x0055
            oh.a.t2.v r10 = oh.a.t1.d     // Catch:{ all -> 0x0086 }
            monitor-exit(r5)
            goto L_0x00e3
        L_0x0055:
            r2 = r5
            oh.a.s1$c r2 = (oh.a.s1.c) r2     // Catch:{ all -> 0x0086 }
            boolean r2 = r2.d()     // Catch:{ all -> 0x0086 }
            if (r10 != 0) goto L_0x0060
            if (r2 != 0) goto L_0x006d
        L_0x0060:
            if (r1 == 0) goto L_0x0063
            goto L_0x0067
        L_0x0063:
            java.lang.Throwable r1 = r9.O(r10)     // Catch:{ all -> 0x0086 }
        L_0x0067:
            r10 = r5
            oh.a.s1$c r10 = (oh.a.s1.c) r10     // Catch:{ all -> 0x0086 }
            r10.a(r1)     // Catch:{ all -> 0x0086 }
        L_0x006d:
            r10 = r5
            oh.a.s1$c r10 = (oh.a.s1.c) r10     // Catch:{ all -> 0x0086 }
            java.lang.Object r10 = r10._rootCause     // Catch:{ all -> 0x0086 }
            java.lang.Throwable r10 = (java.lang.Throwable) r10     // Catch:{ all -> 0x0086 }
            r1 = r2 ^ 1
            if (r1 == 0) goto L_0x0079
            r0 = r10
        L_0x0079:
            monitor-exit(r5)
            if (r0 == 0) goto L_0x0083
            oh.a.s1$c r5 = (oh.a.s1.c) r5
            oh.a.x1 r10 = r5.a
            r9.h0(r10, r0)
        L_0x0083:
            oh.a.t2.v r10 = oh.a.t1.a
            goto L_0x00e3
        L_0x0086:
            r10 = move-exception
            monitor-exit(r5)
            throw r10
        L_0x0089:
            boolean r6 = r5 instanceof oh.a.i1
            if (r6 == 0) goto L_0x00e1
            if (r1 == 0) goto L_0x0090
            goto L_0x0094
        L_0x0090:
            java.lang.Throwable r1 = r9.O(r10)
        L_0x0094:
            r6 = r5
            oh.a.i1 r6 = (oh.a.i1) r6
            boolean r7 = r6.isActive()
            if (r7 == 0) goto L_0x00bc
            oh.a.x1 r5 = r9.V(r6)
            if (r5 == 0) goto L_0x00b6
            oh.a.s1$c r7 = new oh.a.s1$c
            r7.<init>(r5, r3, r1)
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r8 = a
            boolean r6 = r8.compareAndSet(r9, r6, r7)
            if (r6 != 0) goto L_0x00b1
            goto L_0x00b6
        L_0x00b1:
            r9.h0(r5, r1)
            r5 = r4
            goto L_0x00b7
        L_0x00b6:
            r5 = r3
        L_0x00b7:
            if (r5 == 0) goto L_0x003e
            oh.a.t2.v r10 = oh.a.t1.a
            goto L_0x00e3
        L_0x00bc:
            oh.a.y r6 = new oh.a.y
            r6.<init>(r1, r3, r2)
            java.lang.Object r6 = r9.q0(r5, r6)
            oh.a.t2.v r7 = oh.a.t1.a
            if (r6 == r7) goto L_0x00d1
            oh.a.t2.v r5 = oh.a.t1.c
            if (r6 != r5) goto L_0x00cf
            goto L_0x003e
        L_0x00cf:
            r0 = r6
            goto L_0x00e4
        L_0x00d1:
            java.lang.String r10 = "Cannot happen in "
            java.lang.String r10 = e.e.b.a.a.B(r10, r5)
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r10 = r10.toString()
            r0.<init>(r10)
            throw r0
        L_0x00e1:
            oh.a.t2.v r10 = oh.a.t1.d
        L_0x00e3:
            r0 = r10
        L_0x00e4:
            oh.a.t2.v r10 = oh.a.t1.a
            if (r0 != r10) goto L_0x00e9
            goto L_0x00f6
        L_0x00e9:
            oh.a.t2.v r10 = oh.a.t1.b
            if (r0 != r10) goto L_0x00ee
            goto L_0x00f6
        L_0x00ee:
            oh.a.t2.v r10 = oh.a.t1.d
            if (r0 != r10) goto L_0x00f3
            goto L_0x00f7
        L_0x00f3:
            r9.C(r0)
        L_0x00f6:
            r3 = r4
        L_0x00f7:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s1.E(java.lang.Object):boolean");
    }

    public void G(Throwable th2) {
        E(th2);
    }

    public final boolean I(Throwable th2) {
        if (b0()) {
            return true;
        }
        boolean z = th2 instanceof CancellationException;
        p pVar = (p) this._parentHandle;
        if (pVar == null || pVar == y1.a) {
            return z;
        }
        if (pVar.b(th2) || z) {
            return true;
        }
        return false;
    }

    public CancellationException J() {
        Throwable th2;
        Object W = W();
        CancellationException cancellationException = null;
        if (W instanceof c) {
            th2 = (Throwable) ((c) W)._rootCause;
        } else if (W instanceof y) {
            th2 = ((y) W).a;
        } else if (!(W instanceof i1)) {
            th2 = null;
        } else {
            throw new IllegalStateException(e.e.b.a.a.B("Cannot be cancelling child in this state: ", W).toString());
        }
        if (th2 instanceof CancellationException) {
            cancellationException = th2;
        }
        CancellationException cancellationException2 = cancellationException;
        if (cancellationException2 != null) {
            return cancellationException2;
        }
        StringBuilder V0 = e.e.b.a.a.V0("Parent job is ");
        V0.append(n0(W));
        return new o1(V0.toString(), th2, this);
    }

    public final boolean K() {
        return !(W() instanceof i1);
    }

    public String L() {
        return "Job was cancelled";
    }

    public boolean M(Throwable th2) {
        if (th2 instanceof CancellationException) {
            return true;
        }
        if (!E(th2) || !T()) {
            return false;
        }
        return true;
    }

    public final void N(i1 i1Var, Object obj) {
        p pVar = (p) this._parentHandle;
        if (pVar != null) {
            pVar.dispose();
            this._parentHandle = y1.a;
        }
        b0 b0Var = null;
        if (!(obj instanceof y)) {
            obj = null;
        }
        y yVar = (y) obj;
        Throwable th2 = yVar != null ? yVar.a : null;
        if (i1Var instanceof r1) {
            try {
                ((r1) i1Var).w(th2);
            } catch (Throwable th3) {
                Y(new b0("Exception in completion handler " + i1Var + " for " + this, th3));
            }
        } else {
            x1 c2 = i1Var.c();
            if (c2 != null) {
                Object n = c2.n();
                if (n != null) {
                    for (l lVar = (l) n; !p.b(lVar, c2); lVar = lVar.o()) {
                        if (lVar instanceof r1) {
                            r1 r1Var = (r1) lVar;
                            try {
                                r1Var.w(th2);
                            } catch (Throwable th4) {
                                if (b0Var != null) {
                                    ExceptionsKt__ExceptionsKt.addSuppressed(b0Var, th4);
                                } else {
                                    b0Var = new b0("Exception in completion handler " + r1Var + " for " + this, th4);
                                    Unit unit = Unit.INSTANCE;
                                }
                            }
                        }
                    }
                    if (b0Var != null) {
                        Y(b0Var);
                        return;
                    }
                    return;
                }
                throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */");
            }
        }
    }

    public final Throwable O(Object obj) {
        if (obj != null ? obj instanceof Throwable : true) {
            if (obj != null) {
                return (Throwable) obj;
            }
            return new o1(L(), (Throwable) null, this);
        } else if (obj != null) {
            return ((a2) obj).J();
        } else {
            throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.ParentJob");
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:0:0x0000 A[LOOP_START, MTH_ENTER_BLOCK] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object P(ka.e.d<? super kotlin.Unit> r5) {
        /*
            r4 = this;
        L_0x0000:
            java.lang.Object r0 = r4.W()
            boolean r1 = r0 instanceof oh.a.i1
            r2 = 1
            r3 = 0
            if (r1 != 0) goto L_0x000c
            r0 = r3
            goto L_0x0013
        L_0x000c:
            int r0 = r4.m0(r0)
            if (r0 < 0) goto L_0x0000
            r0 = r2
        L_0x0013:
            if (r0 != 0) goto L_0x001f
            ka.e.f r5 = r5.getContext()
            ka.b.q.Y(r5)
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
            return r5
        L_0x001f:
            oh.a.l r0 = new oh.a.l
            ka.e.d r1 = ka.b.q.M1(r5)
            r0.<init>(r1, r2)
            r0.D()
            oh.a.d2 r1 = new oh.a.d2
            r1.<init>(r0)
            oh.a.u0 r1 = r4.j(r3, r2, r1)
            oh.a.v0 r2 = new oh.a.v0
            r2.<init>(r1)
            r0.l(r2)
            java.lang.Object r0 = r0.t()
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            if (r0 != r1) goto L_0x0049
            java.lang.String r1 = "frame"
            ka.h.c.p.e(r5, r1)
        L_0x0049:
            ka.e.j.a r5 = ka.e.j.a.COROUTINE_SUSPENDED
            if (r0 != r5) goto L_0x004e
            return r0
        L_0x004e:
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s1.P(ka.e.d):java.lang.Object");
    }

    public final Object Q(c cVar, Object obj) {
        boolean d2;
        Throwable S;
        Throwable th2 = null;
        y yVar = (y) (!(obj instanceof y) ? null : obj);
        if (yVar != null) {
            th2 = yVar.a;
        }
        synchronized (cVar) {
            d2 = cVar.d();
            List<Throwable> f = cVar.f(th2);
            S = S(cVar, f);
            if (S != null) {
                if (f.size() > 1) {
                    Set newSetFromMap = Collections.newSetFromMap(new IdentityHashMap(f.size()));
                    for (Throwable next : f) {
                        if (next != S && next != S && !(next instanceof CancellationException) && newSetFromMap.add(next)) {
                            ExceptionsKt__ExceptionsKt.addSuppressed(S, next);
                        }
                    }
                }
            }
        }
        if (!(S == null || S == th2)) {
            obj = new y(S, false, 2);
        }
        if (S != null) {
            if (I(S) || X(S)) {
                if (obj != null) {
                    y.b.compareAndSet((y) obj, 0, 1);
                } else {
                    throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.CompletedExceptionally");
                }
            }
        }
        if (!d2) {
            i0();
        }
        j0(obj);
        a.compareAndSet(this, cVar, obj instanceof i1 ? new j1((i1) obj) : obj);
        N(cVar, obj);
        return obj;
    }

    public final Object R() {
        Object W = W();
        if (!(!(W instanceof i1))) {
            throw new IllegalStateException("This job has not completed yet".toString());
        } else if (!(W instanceof y)) {
            return t1.a(W);
        } else {
            throw ((y) W).a;
        }
    }

    public final Throwable S(c cVar, List<? extends Throwable> list) {
        T t;
        boolean z;
        T t2 = null;
        if (!list.isEmpty()) {
            Iterator<T> it = list.iterator();
            while (true) {
                if (!it.hasNext()) {
                    t = null;
                    break;
                }
                t = it.next();
                if (!(((Throwable) t) instanceof CancellationException)) {
                    break;
                }
            }
            Throwable th2 = (Throwable) t;
            if (th2 != null) {
                return th2;
            }
            Throwable th3 = (Throwable) list.get(0);
            if (th3 instanceof j2) {
                Iterator<T> it2 = list.iterator();
                while (true) {
                    if (!it2.hasNext()) {
                        break;
                    }
                    T next = it2.next();
                    Throwable th4 = (Throwable) next;
                    if (th4 == th3 || !(th4 instanceof j2)) {
                        z = false;
                        continue;
                    } else {
                        z = true;
                        continue;
                    }
                    if (z) {
                        t2 = next;
                        break;
                    }
                }
                Throwable th5 = (Throwable) t2;
                if (th5 != null) {
                    return th5;
                }
            }
            return th3;
        } else if (cVar.d()) {
            return new o1(L(), (Throwable) null, this);
        } else {
            return null;
        }
    }

    public boolean T() {
        return true;
    }

    public boolean U() {
        return false;
    }

    public final x1 V(i1 i1Var) {
        x1 c2 = i1Var.c();
        if (c2 != null) {
            return c2;
        }
        if (i1Var instanceof x0) {
            return new x1();
        }
        if (i1Var instanceof r1) {
            l0((r1) i1Var);
            return null;
        }
        throw new IllegalStateException(("State should have list: " + i1Var).toString());
    }

    public final Object W() {
        while (true) {
            Object obj = this._state;
            if (!(obj instanceof oh.a.t2.q)) {
                return obj;
            }
            ((oh.a.t2.q) obj).a(this);
        }
    }

    public boolean X(Throwable th2) {
        return false;
    }

    public void Y(Throwable th2) {
        throw th2;
    }

    public final void Z(n1 n1Var) {
        if (n1Var == null) {
            this._parentHandle = y1.a;
            return;
        }
        n1Var.start();
        p c0 = n1Var.c0(this);
        this._parentHandle = c0;
        if (K()) {
            c0.dispose();
            this._parentHandle = y1.a;
        }
    }

    public boolean b0() {
        return false;
    }

    public void c(CancellationException cancellationException) {
        if (cancellationException == null) {
            cancellationException = new o1(L(), (Throwable) null, this);
        }
        G(cancellationException);
    }

    public final p c0(r rVar) {
        u0 N1 = q.N1(this, true, false, new q(rVar), 2, (Object) null);
        if (N1 != null) {
            return (p) N1;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.ChildHandle");
    }

    public final boolean d0(Object obj) {
        Object q0;
        do {
            q0 = q0(W(), obj);
            if (q0 == t1.a) {
                return false;
            }
            if (q0 == t1.b) {
                return true;
            }
        } while (q0 == t1.c);
        C(q0);
        return true;
    }

    public final Object e0(Object obj) {
        Object q0;
        do {
            q0 = q0(W(), obj);
            if (q0 == t1.a) {
                String str = "Job " + this + " is already complete or completing, " + "but is being completed with " + obj;
                Throwable th2 = null;
                if (!(obj instanceof y)) {
                    obj = null;
                }
                y yVar = (y) obj;
                if (yVar != null) {
                    th2 = yVar.a;
                }
                throw new IllegalStateException(str, th2);
            }
        } while (q0 == t1.c);
        return q0;
    }

    public String f0() {
        return getClass().getSimpleName();
    }

    public <R> R fold(R r, ka.h.b.p<? super R, ? super f.a, ? extends R> pVar) {
        return f.a.a.a(this, r, pVar);
    }

    public final q g0(l lVar) {
        while (lVar.s()) {
            lVar = lVar.p();
        }
        while (true) {
            lVar = lVar.o();
            if (!lVar.s()) {
                if (lVar instanceof q) {
                    return (q) lVar;
                }
                if (lVar instanceof x1) {
                    return null;
                }
            }
        }
    }

    public <E extends f.a> E get(f.b<E> bVar) {
        return f.a.a.b(this, bVar);
    }

    public final f.b<?> getKey() {
        return n1.Z;
    }

    public final void h0(x1 x1Var, Throwable th2) {
        i0();
        Object n = x1Var.n();
        if (n != null) {
            b0 b0Var = null;
            for (l lVar = (l) n; !p.b(lVar, x1Var); lVar = lVar.o()) {
                if (lVar instanceof p1) {
                    r1 r1Var = (r1) lVar;
                    try {
                        r1Var.w(th2);
                    } catch (Throwable th3) {
                        if (b0Var != null) {
                            ExceptionsKt__ExceptionsKt.addSuppressed(b0Var, th3);
                        } else {
                            b0Var = new b0("Exception in completion handler " + r1Var + " for " + this, th3);
                            Unit unit = Unit.INSTANCE;
                        }
                    }
                }
            }
            if (b0Var != null) {
                Y(b0Var);
            }
            I(th2);
            return;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.internal.Node /* = kotlinx.coroutines.internal.LockFreeLinkedListNode */");
    }

    public final ka.l.k<n1> i() {
        return q.Z2(new e(this, (ka.e.d) null));
    }

    public void i0() {
    }

    public boolean isActive() {
        Object W = W();
        return (W instanceof i1) && ((i1) W).isActive();
    }

    public final boolean isCancelled() {
        Object W = W();
        return (W instanceof y) || ((W instanceof c) && ((c) W).d());
    }

    /* JADX WARNING: type inference failed for: r4v8, types: [oh.a.h1] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final oh.a.u0 j(boolean r8, boolean r9, ka.h.b.l<? super java.lang.Throwable, kotlin.Unit> r10) {
        /*
            r7 = this;
            r0 = 0
            if (r8 == 0) goto L_0x0015
            boolean r1 = r10 instanceof oh.a.p1
            if (r1 != 0) goto L_0x0009
            r1 = r0
            goto L_0x000a
        L_0x0009:
            r1 = r10
        L_0x000a:
            oh.a.p1 r1 = (oh.a.p1) r1
            if (r1 == 0) goto L_0x000f
            goto L_0x0026
        L_0x000f:
            oh.a.l1 r1 = new oh.a.l1
            r1.<init>(r10)
            goto L_0x0026
        L_0x0015:
            boolean r1 = r10 instanceof oh.a.r1
            if (r1 != 0) goto L_0x001b
            r1 = r0
            goto L_0x001c
        L_0x001b:
            r1 = r10
        L_0x001c:
            oh.a.r1 r1 = (oh.a.r1) r1
            if (r1 == 0) goto L_0x0021
            goto L_0x0026
        L_0x0021:
            oh.a.m1 r1 = new oh.a.m1
            r1.<init>(r10)
        L_0x0026:
            r1.d = r7
        L_0x0028:
            java.lang.Object r2 = r7.W()
            boolean r3 = r2 instanceof oh.a.x0
            if (r3 == 0) goto L_0x0056
            r3 = r2
            oh.a.x0 r3 = (oh.a.x0) r3
            boolean r4 = r3.a
            if (r4 == 0) goto L_0x0040
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r3 = a
            boolean r2 = r3.compareAndSet(r7, r2, r1)
            if (r2 == 0) goto L_0x0028
            return r1
        L_0x0040:
            oh.a.x1 r2 = new oh.a.x1
            r2.<init>()
            boolean r4 = r3.a
            if (r4 == 0) goto L_0x004a
            goto L_0x0050
        L_0x004a:
            oh.a.h1 r4 = new oh.a.h1
            r4.<init>(r2)
            r2 = r4
        L_0x0050:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = a
            r4.compareAndSet(r7, r3, r2)
            goto L_0x0028
        L_0x0056:
            boolean r3 = r2 instanceof oh.a.i1
            if (r3 == 0) goto L_0x00b4
            r3 = r2
            oh.a.i1 r3 = (oh.a.i1) r3
            oh.a.x1 r3 = r3.c()
            if (r3 != 0) goto L_0x0073
            if (r2 == 0) goto L_0x006b
            oh.a.r1 r2 = (oh.a.r1) r2
            r7.l0(r2)
            goto L_0x0028
        L_0x006b:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            java.lang.String r9 = "null cannot be cast to non-null type kotlinx.coroutines.JobNode"
            r8.<init>(r9)
            throw r8
        L_0x0073:
            oh.a.y1 r4 = oh.a.y1.a
            if (r8 == 0) goto L_0x00a4
            boolean r5 = r2 instanceof oh.a.s1.c
            if (r5 == 0) goto L_0x00a4
            monitor-enter(r2)
            r5 = r2
            oh.a.s1$c r5 = (oh.a.s1.c) r5     // Catch:{ all -> 0x00a1 }
            java.lang.Object r5 = r5._rootCause     // Catch:{ all -> 0x00a1 }
            java.lang.Throwable r5 = (java.lang.Throwable) r5     // Catch:{ all -> 0x00a1 }
            if (r5 == 0) goto L_0x0090
            boolean r6 = r10 instanceof oh.a.q     // Catch:{ all -> 0x00a1 }
            if (r6 == 0) goto L_0x009d
            r6 = r2
            oh.a.s1$c r6 = (oh.a.s1.c) r6     // Catch:{ all -> 0x00a1 }
            int r6 = r6._isCompleting     // Catch:{ all -> 0x00a1 }
            if (r6 != 0) goto L_0x009d
        L_0x0090:
            boolean r4 = r7.B(r2, r3, r1)     // Catch:{ all -> 0x00a1 }
            if (r4 != 0) goto L_0x0098
            monitor-exit(r2)
            goto L_0x0028
        L_0x0098:
            if (r5 != 0) goto L_0x009c
            monitor-exit(r2)
            return r1
        L_0x009c:
            r4 = r1
        L_0x009d:
            kotlin.Unit r6 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x00a1 }
            monitor-exit(r2)
            goto L_0x00a5
        L_0x00a1:
            r8 = move-exception
            monitor-exit(r2)
            throw r8
        L_0x00a4:
            r5 = r0
        L_0x00a5:
            if (r5 == 0) goto L_0x00ad
            if (r9 == 0) goto L_0x00ac
            r10.invoke(r5)
        L_0x00ac:
            return r4
        L_0x00ad:
            boolean r2 = r7.B(r2, r3, r1)
            if (r2 == 0) goto L_0x0028
            return r1
        L_0x00b4:
            if (r9 == 0) goto L_0x00c4
            boolean r8 = r2 instanceof oh.a.y
            if (r8 != 0) goto L_0x00bb
            r2 = r0
        L_0x00bb:
            oh.a.y r2 = (oh.a.y) r2
            if (r2 == 0) goto L_0x00c1
            java.lang.Throwable r0 = r2.a
        L_0x00c1:
            r10.invoke(r0)
        L_0x00c4:
            oh.a.y1 r8 = oh.a.y1.a
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s1.j(boolean, boolean, ka.h.b.l):oh.a.u0");
    }

    public void j0(Object obj) {
    }

    public final CancellationException k() {
        Object W = W();
        if (W instanceof c) {
            Throwable th2 = (Throwable) ((c) W)._rootCause;
            if (th2 != null) {
                return o0(th2, getClass().getSimpleName() + " is cancelling");
            }
            throw new IllegalStateException(("Job is still new or active: " + this).toString());
        } else if (W instanceof i1) {
            throw new IllegalStateException(("Job is still new or active: " + this).toString());
        } else if (W instanceof y) {
            return p0(this, ((y) W).a, (String) null, 1, (Object) null);
        } else {
            return new o1(getClass().getSimpleName() + " has completed normally", (Throwable) null, this);
        }
    }

    public void k0() {
    }

    public final void l0(r1 r1Var) {
        x1 x1Var = new x1();
        l.b.lazySet(x1Var, r1Var);
        l.a.lazySet(x1Var, r1Var);
        while (true) {
            if (r1Var.n() == r1Var) {
                if (l.a.compareAndSet(r1Var, r1Var, x1Var)) {
                    x1Var.m(r1Var);
                    break;
                }
            } else {
                break;
            }
        }
        a.compareAndSet(this, r1Var, r1Var.o());
    }

    public final int m0(Object obj) {
        if (obj instanceof x0) {
            if (((x0) obj).a) {
                return 0;
            }
            if (!a.compareAndSet(this, obj, t1.g)) {
                return -1;
            }
            k0();
            return 1;
        } else if (!(obj instanceof h1)) {
            return 0;
        } else {
            if (!a.compareAndSet(this, obj, ((h1) obj).a)) {
                return -1;
            }
            k0();
            return 1;
        }
    }

    public f minusKey(f.b<?> bVar) {
        return f.a.a.c(this, bVar);
    }

    public final String n0(Object obj) {
        if (obj instanceof c) {
            c cVar = (c) obj;
            if (cVar.d()) {
                return "Cancelling";
            }
            if (cVar._isCompleting != 0) {
                return "Completing";
            }
            return "Active";
        } else if (!(obj instanceof i1)) {
            return obj instanceof y ? "Cancelled" : "Completed";
        } else {
            if (((i1) obj).isActive()) {
                return "Active";
            }
            return "New";
        }
    }

    public final CancellationException o0(Throwable th2, String str) {
        CancellationException cancellationException = (CancellationException) (!(th2 instanceof CancellationException) ? null : th2);
        if (cancellationException == null) {
            if (str == null) {
                str = L();
            }
            cancellationException = new o1(str, th2, this);
        }
        return cancellationException;
    }

    public f plus(f fVar) {
        return f.a.a.d(this, fVar);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:60:0x0096, code lost:
        if (r5 == null) goto L_0x009b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x0098, code lost:
        h0(r0, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x009d, code lost:
        if ((r7 instanceof oh.a.q) != false) goto L_0x00a1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x009f, code lost:
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x00a1, code lost:
        r0 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x00a2, code lost:
        r0 = (oh.a.q) r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x00a4, code lost:
        if (r0 == null) goto L_0x00a8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x00a6, code lost:
        r4 = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x00a8, code lost:
        r7 = r7.c();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x00ac, code lost:
        if (r7 == null) goto L_0x00b2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x00ae, code lost:
        r4 = g0(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x00b2, code lost:
        if (r4 == null) goto L_0x00bd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x00b8, code lost:
        if (r0(r3, r4, r8) == false) goto L_0x00bd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:?, code lost:
        return oh.a.t1.b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:?, code lost:
        return Q(r3, r8);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object q0(java.lang.Object r7, java.lang.Object r8) {
        /*
            r6 = this;
            boolean r0 = r7 instanceof oh.a.i1
            if (r0 != 0) goto L_0x0007
            oh.a.t2.v r7 = oh.a.t1.a
            return r7
        L_0x0007:
            boolean r0 = r7 instanceof oh.a.x0
            r1 = 1
            r2 = 0
            if (r0 != 0) goto L_0x0011
            boolean r0 = r7 instanceof oh.a.r1
            if (r0 == 0) goto L_0x0042
        L_0x0011:
            boolean r0 = r7 instanceof oh.a.q
            if (r0 != 0) goto L_0x0042
            boolean r0 = r8 instanceof oh.a.y
            if (r0 != 0) goto L_0x0042
            oh.a.i1 r7 = (oh.a.i1) r7
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = a
            boolean r3 = r8 instanceof oh.a.i1
            if (r3 == 0) goto L_0x002a
            oh.a.j1 r3 = new oh.a.j1
            r4 = r8
            oh.a.i1 r4 = (oh.a.i1) r4
            r3.<init>(r4)
            goto L_0x002b
        L_0x002a:
            r3 = r8
        L_0x002b:
            boolean r0 = r0.compareAndSet(r6, r7, r3)
            if (r0 != 0) goto L_0x0033
            r1 = r2
            goto L_0x003c
        L_0x0033:
            r6.i0()
            r6.j0(r8)
            r6.N(r7, r8)
        L_0x003c:
            if (r1 == 0) goto L_0x003f
            return r8
        L_0x003f:
            oh.a.t2.v r7 = oh.a.t1.c
            return r7
        L_0x0042:
            oh.a.i1 r7 = (oh.a.i1) r7
            oh.a.x1 r0 = r6.V(r7)
            if (r0 == 0) goto L_0x00c5
            boolean r3 = r7 instanceof oh.a.s1.c
            r4 = 0
            if (r3 != 0) goto L_0x0051
            r3 = r4
            goto L_0x0052
        L_0x0051:
            r3 = r7
        L_0x0052:
            oh.a.s1$c r3 = (oh.a.s1.c) r3
            if (r3 == 0) goto L_0x0057
            goto L_0x005c
        L_0x0057:
            oh.a.s1$c r3 = new oh.a.s1$c
            r3.<init>(r0, r2, r4)
        L_0x005c:
            monitor-enter(r3)
            int r2 = r3._isCompleting     // Catch:{ all -> 0x00c2 }
            if (r2 == 0) goto L_0x0066
            oh.a.t2.v r7 = oh.a.t1.a     // Catch:{ all -> 0x00c2 }
            monitor-exit(r3)
            goto L_0x00c7
        L_0x0066:
            r3._isCompleting = r1     // Catch:{ all -> 0x00c2 }
            if (r3 == r7) goto L_0x0076
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r2 = a     // Catch:{ all -> 0x00c2 }
            boolean r2 = r2.compareAndSet(r6, r7, r3)     // Catch:{ all -> 0x00c2 }
            if (r2 != 0) goto L_0x0076
            oh.a.t2.v r7 = oh.a.t1.c     // Catch:{ all -> 0x00c2 }
            monitor-exit(r3)
            goto L_0x00c7
        L_0x0076:
            boolean r2 = r3.d()     // Catch:{ all -> 0x00c2 }
            boolean r5 = r8 instanceof oh.a.y     // Catch:{ all -> 0x00c2 }
            if (r5 != 0) goto L_0x0080
            r5 = r4
            goto L_0x0081
        L_0x0080:
            r5 = r8
        L_0x0081:
            oh.a.y r5 = (oh.a.y) r5     // Catch:{ all -> 0x00c2 }
            if (r5 == 0) goto L_0x008a
            java.lang.Throwable r5 = r5.a     // Catch:{ all -> 0x00c2 }
            r3.a(r5)     // Catch:{ all -> 0x00c2 }
        L_0x008a:
            java.lang.Object r5 = r3._rootCause     // Catch:{ all -> 0x00c2 }
            java.lang.Throwable r5 = (java.lang.Throwable) r5     // Catch:{ all -> 0x00c2 }
            r1 = r1 ^ r2
            if (r1 == 0) goto L_0x0092
            goto L_0x0093
        L_0x0092:
            r5 = r4
        L_0x0093:
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x00c2 }
            monitor-exit(r3)
            if (r5 == 0) goto L_0x009b
            r6.h0(r0, r5)
        L_0x009b:
            boolean r0 = r7 instanceof oh.a.q
            if (r0 != 0) goto L_0x00a1
            r0 = r4
            goto L_0x00a2
        L_0x00a1:
            r0 = r7
        L_0x00a2:
            oh.a.q r0 = (oh.a.q) r0
            if (r0 == 0) goto L_0x00a8
            r4 = r0
            goto L_0x00b2
        L_0x00a8:
            oh.a.x1 r7 = r7.c()
            if (r7 == 0) goto L_0x00b2
            oh.a.q r4 = r6.g0(r7)
        L_0x00b2:
            if (r4 == 0) goto L_0x00bd
            boolean r7 = r6.r0(r3, r4, r8)
            if (r7 == 0) goto L_0x00bd
            oh.a.t2.v r7 = oh.a.t1.b
            goto L_0x00c7
        L_0x00bd:
            java.lang.Object r7 = r6.Q(r3, r8)
            goto L_0x00c7
        L_0x00c2:
            r7 = move-exception
            monitor-exit(r3)
            throw r7
        L_0x00c5:
            oh.a.t2.v r7 = oh.a.t1.c
        L_0x00c7:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s1.q0(java.lang.Object, java.lang.Object):java.lang.Object");
    }

    public final boolean r0(c cVar, q qVar, Object obj) {
        while (q.N1(qVar.f69e, false, false, new b(this, cVar, qVar, obj), 1, (Object) null) == y1.a) {
            qVar = g0(qVar);
            if (qVar == null) {
                return false;
            }
        }
        return true;
    }

    public final boolean start() {
        int m0;
        do {
            m0 = m0(W());
            if (m0 == 0) {
                return false;
            }
        } while (m0 != 1);
        return true;
    }

    public final void t(a2 a2Var) {
        E(a2Var);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(f0() + '{' + n0(W()) + '}');
        sb.append('@');
        sb.append(q.q1(this));
        return sb.toString();
    }

    public final u0 v(ka.h.b.l<? super Throwable, Unit> lVar) {
        return j(false, true, lVar);
    }
}

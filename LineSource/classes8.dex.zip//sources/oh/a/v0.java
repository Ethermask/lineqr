package oh.a;

import e.e.b.a.a;
import kotlin.Unit;

public final class v0 extends i {
    public final u0 a;

    public v0(u0 u0Var) {
        this.a = u0Var;
    }

    public void a(Throwable th2) {
        this.a.dispose();
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        this.a.dispose();
        return Unit.INSTANCE;
    }

    public String toString() {
        StringBuilder V0 = a.V0("DisposeOnCancel[");
        V0.append(this.a);
        V0.append(']');
        return V0.toString();
    }
}

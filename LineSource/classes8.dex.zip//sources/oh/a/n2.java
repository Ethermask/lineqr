package oh.a;

import ka.b.q;
import ka.e.d;
import ka.e.f;
import kotlin.Unit;
import oh.a.t2.s;
import oh.a.t2.x;

public final class n2<T> extends s<T> {

    /* renamed from: e  reason: collision with root package name */
    public f f66e;
    public Object f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public n2(f fVar, d<? super T> dVar) {
        super(fVar.get(o2.a) == null ? fVar.plus(o2.a) : fVar, dVar);
    }

    public void s0(Object obj) {
        f fVar = this.f66e;
        n2<?> n2Var = null;
        if (fVar != null) {
            x.a(fVar, this.f);
            this.f66e = n2Var;
            this.f = n2Var;
        }
        Object J2 = q.J2(obj, this.d);
        d<T> dVar = this.d;
        f context = dVar.getContext();
        Object c = x.c(context, n2Var);
        if (c != x.a) {
            n2Var = c0.c(dVar, context, c);
        }
        try {
            this.d.resumeWith(J2);
            Unit unit = Unit.INSTANCE;
        } finally {
            if (n2Var == null || n2Var.y0()) {
                x.a(context, c);
            }
        }
    }

    public final boolean y0() {
        if (this.f66e == null) {
            return false;
        }
        this.f66e = null;
        this.f = null;
        return true;
    }
}

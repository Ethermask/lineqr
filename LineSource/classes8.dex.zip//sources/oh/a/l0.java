package oh.a;

public final class l0 {
    public static final o0 a = k0.h;
}

package oh.a;

public interface u<T> extends m0<T> {
    boolean H(T t);
}

package oh.a;

import java.util.concurrent.locks.LockSupport;
import ka.h.c.p;

public final class f<T> extends a<T> {
    public final Thread d;

    /* renamed from: e  reason: collision with root package name */
    public final y0 f60e;

    public f(ka.e.f fVar, Thread thread, y0 y0Var) {
        super(fVar, true);
        this.d = thread;
        this.f60e = y0Var;
    }

    public void C(Object obj) {
        if (!p.b(Thread.currentThread(), this.d)) {
            LockSupport.unpark(this.d);
        }
    }

    public boolean b0() {
        return true;
    }
}

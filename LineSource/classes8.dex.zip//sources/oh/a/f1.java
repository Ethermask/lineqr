package oh.a;

import java.util.concurrent.Executor;
import oh.a.t2.d;

public final class f1 extends e1 {
    public final Executor c;

    public f1(Executor executor) {
        this.c = executor;
        this.b = d.a(executor);
    }

    public Executor h0() {
        return this.c;
    }
}

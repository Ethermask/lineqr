package oh.a;

import ka.e.f;
import kotlin.Unit;

public interface o0 {
    void d(long j, k<? super Unit> kVar);

    u0 s(long j, Runnable runnable, f fVar);
}

package oh.a;

import oh.a.t2.v;

public final class t1 {
    public static final v a = new v("COMPLETING_ALREADY");
    public static final v b = new v("COMPLETING_WAITING_CHILDREN");
    public static final v c = new v("COMPLETING_RETRY");
    public static final v d = new v("TOO_LATE_TO_CANCEL");

    /* renamed from: e  reason: collision with root package name */
    public static final v f89e = new v("SEALED");
    public static final x0 f = new x0(false);
    public static final x0 g = new x0(true);

    public static final Object a(Object obj) {
        i1 i1Var;
        j1 j1Var = (j1) (!(obj instanceof j1) ? null : obj);
        return (j1Var == null || (i1Var = j1Var.a) == null) ? obj : i1Var;
    }
}

package oh.a;

import oh.a.t2.j;

public final class x1 extends j implements i1 {
    public x1 c() {
        return this;
    }

    public boolean isActive() {
        return true;
    }

    public String toString() {
        return super.toString();
    }
}

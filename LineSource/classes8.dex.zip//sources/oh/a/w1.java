package oh.a;

import ka.b.q;

public abstract class w1 extends e0 {
    public abstract w1 h0();

    public final String i0() {
        w1 w1Var;
        w1 c = s0.c();
        if (this == c) {
            return "Dispatchers.Main";
        }
        try {
            w1Var = c.h0();
        } catch (UnsupportedOperationException unused) {
            w1Var = null;
        }
        if (this == w1Var) {
            return "Dispatchers.Main.immediate";
        }
        return null;
    }

    public String toString() {
        String i02 = i0();
        if (i02 != null) {
            return i02;
        }
        return getClass().getSimpleName() + '@' + q.q1(this);
    }
}

package oh.a;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import ka.e.f;
import kotlin.Unit;
import oh.a.t2.a0;
import oh.a.t2.b0;
import oh.a.t2.n;

public abstract class z0 extends a1 implements o0 {

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f110e;
    public static final /* synthetic */ AtomicReferenceFieldUpdater f;
    public volatile /* synthetic */ Object _delayed = null;
    public volatile /* synthetic */ int _isCompleted = 0;
    public volatile /* synthetic */ Object _queue = null;

    public final class a extends c {
        public final k<Unit> d;

        public a(long j, k<? super Unit> kVar) {
            super(j);
            this.d = kVar;
        }

        public void run() {
            this.d.u(z0.this, Unit.INSTANCE);
        }

        public String toString() {
            return super.toString() + this.d.toString();
        }
    }

    public static final class b extends c {
        public final Runnable d;

        public b(long j, Runnable runnable) {
            super(j);
            this.d = runnable;
        }

        public void run() {
            this.d.run();
        }

        public String toString() {
            return super.toString() + this.d.toString();
        }
    }

    public static abstract class c implements Runnable, Comparable<c>, u0, b0 {
        public Object a;
        public int b = -1;
        public long c;

        public c(long j) {
            this.c = j;
        }

        public void K(int i) {
            this.b = i;
        }

        public void a(a0<?> a0Var) {
            if (this.a != b1.a) {
                this.a = a0Var;
                return;
            }
            throw new IllegalArgumentException("Failed requirement.".toString());
        }

        public int compareTo(Object obj) {
            int i = ((this.c - ((c) obj).c) > 0 ? 1 : ((this.c - ((c) obj).c) == 0 ? 0 : -1));
            if (i > 0) {
                return 1;
            }
            return i < 0 ? -1 : 0;
        }

        public final synchronized void dispose() {
            Object obj = this.a;
            if (obj != b1.a) {
                if (!(obj instanceof d)) {
                    obj = null;
                }
                d dVar = (d) obj;
                if (dVar != null) {
                    synchronized (dVar) {
                        if (f() != null) {
                            dVar.c(getIndex());
                        }
                    }
                }
                this.a = b1.a;
            }
        }

        public a0<?> f() {
            Object obj = this.a;
            if (!(obj instanceof a0)) {
                obj = null;
            }
            return (a0) obj;
        }

        public int getIndex() {
            return this.b;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("Delayed[nanos=");
            V0.append(this.c);
            V0.append(']');
            return V0.toString();
        }
    }

    public static final class d extends a0<c> {
        public long b;

        public d(long j) {
            this.b = j;
        }
    }

    static {
        Class<Object> cls = Object.class;
        Class<z0> cls2 = z0.class;
        f110e = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_queue");
        f = AtomicReferenceFieldUpdater.newUpdater(cls2, cls, "_delayed");
    }

    public final boolean A0(Runnable runnable) {
        while (true) {
            Object obj = this._queue;
            if (this._isCompleted != 0) {
                return false;
            }
            if (obj == null) {
                if (f110e.compareAndSet(this, (Object) null, runnable)) {
                    return true;
                }
            } else if (obj instanceof n) {
                n nVar = (n) obj;
                int a2 = nVar.a(runnable);
                if (a2 == 0) {
                    return true;
                }
                if (a2 == 1) {
                    f110e.compareAndSet(this, obj, nVar.d());
                } else if (a2 == 2) {
                    return false;
                }
            } else if (obj == b1.b) {
                return false;
            } else {
                n nVar2 = new n(8, true);
                nVar2.a((Runnable) obj);
                nVar2.a(runnable);
                if (f110e.compareAndSet(this, obj, nVar2)) {
                    return true;
                }
            }
        }
    }

    public boolean B0() {
        oh.a.t2.a<q0<?>> aVar = this.d;
        if (!(aVar == null || aVar.b == aVar.c)) {
            return false;
        }
        d dVar = (d) this._delayed;
        if (dVar != null) {
            if (!(dVar._size == 0)) {
                return false;
            }
        }
        Object obj = this._queue;
        if (obj == null) {
            return true;
        }
        if (obj instanceof n) {
            return ((n) obj).c();
        }
        if (obj == b1.b) {
            return true;
        }
        return false;
    }

    /* JADX WARNING: type inference failed for: r14v2, types: [oh.a.t2.b0] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0069  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0080  */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void C0(long r13, oh.a.z0.c r15) {
        /*
            r12 = this;
            int r0 = r12._isCompleted
            r1 = 0
            r2 = 2
            r3 = 0
            r4 = 1
            if (r0 == 0) goto L_0x0009
            goto L_0x0038
        L_0x0009:
            java.lang.Object r0 = r12._delayed
            oh.a.z0$d r0 = (oh.a.z0.d) r0
            if (r0 == 0) goto L_0x0010
            goto L_0x0021
        L_0x0010:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = f
            oh.a.z0$d r5 = new oh.a.z0$d
            r5.<init>(r13)
            r0.compareAndSet(r12, r3, r5)
            java.lang.Object r0 = r12._delayed
            ka.h.c.p.c(r0)
            oh.a.z0$d r0 = (oh.a.z0.d) r0
        L_0x0021:
            monitor-enter(r15)
            java.lang.Object r5 = r15.a     // Catch:{ all -> 0x00a9 }
            oh.a.t2.v r6 = oh.a.b1.a     // Catch:{ all -> 0x00a9 }
            if (r5 != r6) goto L_0x002b
            monitor-exit(r15)
            r0 = r2
            goto L_0x0067
        L_0x002b:
            monitor-enter(r0)     // Catch:{ all -> 0x00a9 }
            oh.a.t2.b0 r5 = r0.b()     // Catch:{ all -> 0x00a6 }
            oh.a.z0$c r5 = (oh.a.z0.c) r5     // Catch:{ all -> 0x00a6 }
            int r6 = r12._isCompleted     // Catch:{ all -> 0x00a6 }
            if (r6 == 0) goto L_0x003a
            monitor-exit(r0)     // Catch:{ all -> 0x00a9 }
            monitor-exit(r15)
        L_0x0038:
            r0 = r4
            goto L_0x0067
        L_0x003a:
            r6 = 0
            if (r5 != 0) goto L_0x0041
            r0.b = r13     // Catch:{ all -> 0x00a6 }
            goto L_0x0054
        L_0x0041:
            long r8 = r5.c     // Catch:{ all -> 0x00a6 }
            long r10 = r8 - r13
            int r5 = (r10 > r6 ? 1 : (r10 == r6 ? 0 : -1))
            if (r5 < 0) goto L_0x004a
            r8 = r13
        L_0x004a:
            long r10 = r0.b     // Catch:{ all -> 0x00a6 }
            long r10 = r8 - r10
            int r5 = (r10 > r6 ? 1 : (r10 == r6 ? 0 : -1))
            if (r5 <= 0) goto L_0x0054
            r0.b = r8     // Catch:{ all -> 0x00a6 }
        L_0x0054:
            long r8 = r15.c     // Catch:{ all -> 0x00a6 }
            long r10 = r0.b     // Catch:{ all -> 0x00a6 }
            long r8 = r8 - r10
            int r5 = (r8 > r6 ? 1 : (r8 == r6 ? 0 : -1))
            if (r5 >= 0) goto L_0x0061
            long r5 = r0.b     // Catch:{ all -> 0x00a6 }
            r15.c = r5     // Catch:{ all -> 0x00a6 }
        L_0x0061:
            r0.a(r15)     // Catch:{ all -> 0x00a6 }
            monitor-exit(r0)     // Catch:{ all -> 0x00a9 }
            monitor-exit(r15)
            r0 = r1
        L_0x0067:
            if (r0 == 0) goto L_0x0080
            if (r0 == r4) goto L_0x007a
            if (r0 != r2) goto L_0x006e
            goto L_0x00a5
        L_0x006e:
            java.lang.String r13 = "unexpected result"
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r13 = r13.toString()
            r14.<init>(r13)
            throw r14
        L_0x007a:
            oh.a.k0 r0 = oh.a.k0.h
            r0.C0(r13, r15)
            goto L_0x00a5
        L_0x0080:
            java.lang.Object r13 = r12._delayed
            oh.a.z0$d r13 = (oh.a.z0.d) r13
            if (r13 == 0) goto L_0x0093
            monitor-enter(r13)
            oh.a.t2.b0 r14 = r13.b()     // Catch:{ all -> 0x0090 }
            monitor-exit(r13)
            r3 = r14
            oh.a.z0$c r3 = (oh.a.z0.c) r3
            goto L_0x0093
        L_0x0090:
            r14 = move-exception
            monitor-exit(r13)
            throw r14
        L_0x0093:
            if (r3 != r15) goto L_0x0096
            r1 = r4
        L_0x0096:
            if (r1 == 0) goto L_0x00a5
            java.lang.Thread r13 = r12.y0()
            java.lang.Thread r14 = java.lang.Thread.currentThread()
            if (r14 == r13) goto L_0x00a5
            java.util.concurrent.locks.LockSupport.unpark(r13)
        L_0x00a5:
            return
        L_0x00a6:
            r13 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00a9 }
            throw r13     // Catch:{ all -> 0x00a9 }
        L_0x00a9:
            r13 = move-exception
            monitor-exit(r15)
            throw r13
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.z0.C0(long, oh.a.z0$c):void");
    }

    public void d(long j, k<? super Unit> kVar) {
        long a2 = b1.a(j);
        if (a2 < 4611686018427387903L) {
            long nanoTime = System.nanoTime();
            a aVar = new a(a2 + nanoTime, kVar);
            kVar.l(new v0(aVar));
            C0(nanoTime, aVar);
        }
    }

    public final void d0(f fVar, Runnable runnable) {
        z0(runnable);
    }

    public u0 s(long j, Runnable runnable, f fVar) {
        return l0.a.s(j, runnable, fVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:59:0x00a3  */
    /* JADX WARNING: Removed duplicated region for block: B:92:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public long w0() {
        /*
            r11 = this;
            boolean r0 = r11.x0()
            r1 = 0
            if (r0 == 0) goto L_0x0009
            return r1
        L_0x0009:
            java.lang.Object r0 = r11._delayed
            oh.a.z0$d r0 = (oh.a.z0.d) r0
            r3 = 1
            r4 = 0
            r5 = 0
            if (r0 == 0) goto L_0x004f
            int r6 = r0._size
            if (r6 != 0) goto L_0x0018
            r6 = r3
            goto L_0x0019
        L_0x0018:
            r6 = r5
        L_0x0019:
            if (r6 != 0) goto L_0x004f
            long r6 = java.lang.System.nanoTime()
        L_0x001f:
            monitor-enter(r0)
            oh.a.t2.b0 r8 = r0.b()     // Catch:{ all -> 0x004c }
            if (r8 == 0) goto L_0x0045
            oh.a.z0$c r8 = (oh.a.z0.c) r8     // Catch:{ all -> 0x004c }
            long r9 = r8.c     // Catch:{ all -> 0x004c }
            long r9 = r6 - r9
            int r9 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1))
            if (r9 < 0) goto L_0x0032
            r9 = r3
            goto L_0x0033
        L_0x0032:
            r9 = r5
        L_0x0033:
            if (r9 == 0) goto L_0x003a
            boolean r8 = r11.A0(r8)     // Catch:{ all -> 0x004c }
            goto L_0x003b
        L_0x003a:
            r8 = r5
        L_0x003b:
            if (r8 == 0) goto L_0x0042
            oh.a.t2.b0 r8 = r0.c(r5)     // Catch:{ all -> 0x004c }
            goto L_0x0043
        L_0x0042:
            r8 = r4
        L_0x0043:
            monitor-exit(r0)
            goto L_0x0047
        L_0x0045:
            monitor-exit(r0)
            r8 = r4
        L_0x0047:
            oh.a.z0$c r8 = (oh.a.z0.c) r8
            if (r8 == 0) goto L_0x004f
            goto L_0x001f
        L_0x004c:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
        L_0x004f:
            java.lang.Object r0 = r11._queue
            if (r0 != 0) goto L_0x0054
            goto L_0x0081
        L_0x0054:
            boolean r6 = r0 instanceof oh.a.t2.n
            if (r6 == 0) goto L_0x0071
            r6 = r0
            oh.a.t2.n r6 = (oh.a.t2.n) r6
            java.lang.Object r7 = r6.e()
            oh.a.t2.v r8 = oh.a.t2.n.g
            if (r7 == r8) goto L_0x0067
            r4 = r7
            java.lang.Runnable r4 = (java.lang.Runnable) r4
            goto L_0x0081
        L_0x0067:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r7 = f110e
            oh.a.t2.n r6 = r6.d()
            r7.compareAndSet(r11, r0, r6)
            goto L_0x004f
        L_0x0071:
            oh.a.t2.v r6 = oh.a.b1.b
            if (r0 != r6) goto L_0x0076
            goto L_0x0081
        L_0x0076:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r6 = f110e
            boolean r6 = r6.compareAndSet(r11, r0, r4)
            if (r6 == 0) goto L_0x004f
            r4 = r0
            java.lang.Runnable r4 = (java.lang.Runnable) r4
        L_0x0081:
            if (r4 == 0) goto L_0x0087
            r4.run()
            return r1
        L_0x0087:
            oh.a.t2.a<oh.a.q0<?>> r0 = r11.d
            r6 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
            if (r0 == 0) goto L_0x009d
            int r4 = r0.b
            int r0 = r0.c
            if (r4 != r0) goto L_0x0097
            goto L_0x0098
        L_0x0097:
            r3 = r5
        L_0x0098:
            if (r3 == 0) goto L_0x009b
            goto L_0x009d
        L_0x009b:
            r3 = r1
            goto L_0x009e
        L_0x009d:
            r3 = r6
        L_0x009e:
            int r0 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r0 != 0) goto L_0x00a3
            goto L_0x00d9
        L_0x00a3:
            java.lang.Object r0 = r11._queue
            if (r0 != 0) goto L_0x00a8
            goto L_0x00b5
        L_0x00a8:
            boolean r3 = r0 instanceof oh.a.t2.n
            if (r3 == 0) goto L_0x00d4
            oh.a.t2.n r0 = (oh.a.t2.n) r0
            boolean r0 = r0.c()
            if (r0 != 0) goto L_0x00b5
            goto L_0x00d9
        L_0x00b5:
            java.lang.Object r0 = r11._delayed
            oh.a.z0$d r0 = (oh.a.z0.d) r0
            if (r0 == 0) goto L_0x00d8
            monitor-enter(r0)
            oh.a.t2.b0 r3 = r0.b()     // Catch:{ all -> 0x00d1 }
            monitor-exit(r0)
            oh.a.z0$c r3 = (oh.a.z0.c) r3
            if (r3 == 0) goto L_0x00d8
            long r3 = r3.c
            long r5 = java.lang.System.nanoTime()
            long r3 = r3 - r5
            long r1 = ka.k.i.c(r3, r1)
            goto L_0x00d9
        L_0x00d1:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
        L_0x00d4:
            oh.a.t2.v r3 = oh.a.b1.b
            if (r0 != r3) goto L_0x00d9
        L_0x00d8:
            r1 = r6
        L_0x00d9:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.z0.w0():long");
    }

    public final void z0(Runnable runnable) {
        if (A0(runnable)) {
            Thread y0 = y0();
            if (Thread.currentThread() != y0) {
                LockSupport.unpark(y0);
                return;
            }
            return;
        }
        k0.h.z0(runnable);
    }
}

package oh.a;

import ka.e.f;
import ka.h.b.l;
import ka.h.c.r;

public final class c1 extends r implements l<f.a, d1> {
    public static final c1 a = new c1();

    public c1() {
        super(1);
    }

    public Object invoke(Object obj) {
        f.a aVar = (f.a) obj;
        if (!(aVar instanceof d1)) {
            aVar = null;
        }
        return (d1) aVar;
    }
}

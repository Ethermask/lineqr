package oh.a;

public final class y1 implements u0, p {
    public static final y1 a = new y1();

    public boolean b(Throwable th2) {
        return false;
    }

    public void dispose() {
    }

    public String toString() {
        return "NonDisposableHandle";
    }
}

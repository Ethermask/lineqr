package oh.a;

public final class b0 extends RuntimeException {
    public b0(String str, Throwable th2) {
        super(str, th2);
    }
}

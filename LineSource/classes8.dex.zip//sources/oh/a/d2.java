package oh.a;

import ka.e.d;
import kotlin.Result;
import kotlin.Unit;

public final class d2 extends r1 {

    /* renamed from: e  reason: collision with root package name */
    public final d<Unit> f59e;

    public d2(d<? super Unit> dVar) {
        this.f59e = dVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        w((Throwable) obj);
        return Unit.INSTANCE;
    }

    public void w(Throwable th2) {
        d<Unit> dVar = this.f59e;
        Unit unit = Unit.INSTANCE;
        Result.Companion companion = Result.Companion;
        dVar.resumeWith(Result.constructor-impl(unit));
    }
}

package oh.a;

public final class t implements Runnable {
    public static final t a = new t();

    public final void run() {
    }
}

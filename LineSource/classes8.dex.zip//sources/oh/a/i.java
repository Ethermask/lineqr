package oh.a;

public abstract class i extends j implements z1 {
}

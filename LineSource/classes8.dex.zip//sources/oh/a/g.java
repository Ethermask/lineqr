package oh.a;

public final class g extends z0 {
    public final Thread g;

    public g(Thread thread) {
        this.g = thread;
    }

    public Thread y0() {
        return this.g;
    }
}

package oh.a;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import ka.b.q;
import ka.e.f;
import kotlin.Unit;

public abstract class e1 extends d1 implements o0 {
    public boolean b;

    public void close() {
        Executor executor = ((f1) this).c;
        if (!(executor instanceof ExecutorService)) {
            executor = null;
        }
        ExecutorService executorService = (ExecutorService) executor;
        if (executorService != null) {
            executorService.shutdown();
        }
    }

    public void d(long j, k<? super Unit> kVar) {
        ScheduledFuture<?> i02 = this.b ? i0(new e2(this, kVar), kVar.getContext(), j) : null;
        if (i02 != null) {
            kVar.l(new h(i02));
        } else {
            k0.h.d(j, kVar);
        }
    }

    public void d0(f fVar, Runnable runnable) {
        try {
            ((f1) this).c.execute(runnable);
        } catch (RejectedExecutionException e2) {
            CancellationException cancellationException = new CancellationException("The task was rejected");
            cancellationException.initCause(e2);
            q.O(fVar, cancellationException);
            s0.c.d0(fVar, runnable);
        }
    }

    public boolean equals(Object obj) {
        return (obj instanceof e1) && ((f1) ((e1) obj)).c == ((f1) this).c;
    }

    public int hashCode() {
        return System.identityHashCode(((f1) this).c);
    }

    public final ScheduledFuture<?> i0(Runnable runnable, f fVar, long j) {
        try {
            Executor executor = ((f1) this).c;
            if (!(executor instanceof ScheduledExecutorService)) {
                executor = null;
            }
            ScheduledExecutorService scheduledExecutorService = (ScheduledExecutorService) executor;
            if (scheduledExecutorService != null) {
                return scheduledExecutorService.schedule(runnable, j, TimeUnit.MILLISECONDS);
            }
            return null;
        } catch (RejectedExecutionException e2) {
            CancellationException cancellationException = new CancellationException("The task was rejected");
            cancellationException.initCause(e2);
            q.O(fVar, cancellationException);
            return null;
        }
    }

    public u0 s(long j, Runnable runnable, f fVar) {
        ScheduledFuture<?> i02 = this.b ? i0(runnable, fVar, j) : null;
        if (i02 != null) {
            return new t0(i02);
        }
        return k0.h.s(j, runnable, fVar);
    }

    public String toString() {
        return ((f1) this).c.toString();
    }
}

package oh.a;

public interface i1 {
    x1 c();

    boolean isActive();
}

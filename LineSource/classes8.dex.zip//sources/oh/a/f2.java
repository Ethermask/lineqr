package oh.a;

import ka.b.q;
import ka.e.f;
import kotlin.Unit;

public class f2 extends a<Unit> {
    public f2(f fVar, boolean z) {
        super(fVar, z);
    }

    public boolean X(Throwable th2) {
        q.I1(this.b, th2);
        return true;
    }
}

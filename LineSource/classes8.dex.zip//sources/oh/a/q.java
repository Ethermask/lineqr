package oh.a;

import kotlin.Unit;

public final class q extends p1 implements p {

    /* renamed from: e  reason: collision with root package name */
    public final r f69e;

    public q(r rVar) {
        this.f69e = rVar;
    }

    public boolean b(Throwable th2) {
        return x().M(th2);
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        w((Throwable) obj);
        return Unit.INSTANCE;
    }

    public void w(Throwable th2) {
        this.f69e.t(x());
    }
}

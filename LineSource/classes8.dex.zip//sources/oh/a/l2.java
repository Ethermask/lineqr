package oh.a;

import ka.b.q;
import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;
import ka.h.b.p;

@e(c = "kotlinx.coroutines.TimeoutKt", f = "Timeout.kt", l = {101}, m = "withTimeoutOrNull")
public final class l2 extends c {
    public /* synthetic */ Object a;
    public int b;
    public long c;
    public Object d;

    /* renamed from: e  reason: collision with root package name */
    public Object f64e;

    public l2(d dVar) {
        super(dVar);
    }

    public final Object invokeSuspend(Object obj) {
        this.a = obj;
        this.b |= Integer.MIN_VALUE;
        return q.c4(0, (p) null, this);
    }
}

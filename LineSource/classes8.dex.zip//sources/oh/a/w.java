package oh.a;

public interface w extends n1 {
    boolean a();
}

package oh.a;

import ka.b.q;
import ka.e.d;
import ka.e.f;
import ka.h.b.p;
import kotlin.Unit;

public final class u1<T> extends n0<T> {
    public final d<Unit> d;

    public u1(f fVar, p<? super h0, ? super d<? super T>, ? extends Object> pVar) {
        super(fVar, false);
        this.d = q.t0(pVar, this, this);
    }

    public void w0() {
        q.n3(this.d, this);
    }
}

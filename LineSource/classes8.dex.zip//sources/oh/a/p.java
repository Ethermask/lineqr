package oh.a;

import kotlin.Deprecated;
import kotlin.DeprecationLevel;

@Deprecated(level = DeprecationLevel.ERROR, message = "This is internal API and may be removed in the future releases")
public interface p extends u0 {
    boolean b(Throwable th2);
}

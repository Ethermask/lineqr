package oh.a;

public abstract class p1 extends r1 {
}

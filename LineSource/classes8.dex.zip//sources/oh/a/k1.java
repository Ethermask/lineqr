package oh.a;

import e.e.b.a.a;
import ka.b.q;
import ka.h.b.l;
import kotlin.Unit;

public final class k1 extends i {
    public final l<Throwable, Unit> a;

    public k1(l<? super Throwable, Unit> lVar) {
        this.a = lVar;
    }

    public void a(Throwable th2) {
        this.a.invoke(th2);
    }

    public Object invoke(Object obj) {
        this.a.invoke((Throwable) obj);
        return Unit.INSTANCE;
    }

    public String toString() {
        StringBuilder V0 = a.V0("InvokeOnCancel[");
        V0.append(q.n1(this.a));
        V0.append('@');
        V0.append(q.q1(this));
        V0.append(']');
        return V0.toString();
    }
}

package oh.a;

import e.e.b.a.a;
import java.util.concurrent.Future;

public final class t0 implements u0 {
    public final Future<?> a;

    public t0(Future<?> future) {
        this.a = future;
    }

    public void dispose() {
        this.a.cancel(false);
    }

    public String toString() {
        StringBuilder V0 = a.V0("DisposableFutureHandle[");
        V0.append(this.a);
        V0.append(']');
        return V0.toString();
    }
}

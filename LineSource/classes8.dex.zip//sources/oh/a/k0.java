package oh.a;

import java.util.concurrent.TimeUnit;
import ka.e.f;
import oh.a.z0;

public final class k0 extends z0 implements Runnable {
    public static volatile Thread _thread;
    public static volatile int debugStatus;
    public static final long g;
    public static final k0 h;

    static {
        Long l;
        k0 k0Var = new k0();
        h = k0Var;
        k0Var.n0(false);
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        try {
            l = Long.getLong("kotlinx.coroutines.DefaultExecutor.keepAlive", 1000);
        } catch (SecurityException unused) {
            l = 1000L;
        }
        g = timeUnit.toNanos(l.longValue());
    }

    public final synchronized void D0() {
        if (E0()) {
            debugStatus = 3;
            this._queue = null;
            this._delayed = null;
            notifyAll();
        }
    }

    public final boolean E0() {
        int i = debugStatus;
        return i == 2 || i == 3;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:46:0x0083, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x0084, code lost:
        _thread = null;
        D0();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x008d, code lost:
        if (B0() == false) goto L_0x008f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x008f, code lost:
        y0();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x0092, code lost:
        throw r1;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
            r12 = this;
            oh.a.i2 r0 = oh.a.i2.b
            java.lang.ThreadLocal<oh.a.y0> r0 = oh.a.i2.a
            r0.set(r12)
            r0 = 0
            monitor-enter(r12)     // Catch:{ all -> 0x0083 }
            boolean r1 = r12.E0()     // Catch:{ all -> 0x0080 }
            if (r1 == 0) goto L_0x0012
            r1 = 0
            monitor-exit(r12)     // Catch:{ all -> 0x0083 }
            goto L_0x0019
        L_0x0012:
            r1 = 1
            debugStatus = r1     // Catch:{ all -> 0x0080 }
            r12.notifyAll()     // Catch:{ all -> 0x0080 }
            monitor-exit(r12)     // Catch:{ all -> 0x0083 }
        L_0x0019:
            if (r1 != 0) goto L_0x002a
            _thread = r0
            r12.D0()
            boolean r0 = r12.B0()
            if (r0 != 0) goto L_0x0029
            r12.y0()
        L_0x0029:
            return
        L_0x002a:
            r1 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
            r3 = r1
        L_0x0030:
            java.lang.Thread.interrupted()     // Catch:{ all -> 0x0083 }
            long r5 = r12.w0()     // Catch:{ all -> 0x0083 }
            int r7 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
            r8 = 0
            if (r7 != 0) goto L_0x0062
            long r10 = java.lang.System.nanoTime()     // Catch:{ all -> 0x0083 }
            int r7 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r7 != 0) goto L_0x0048
            long r3 = g     // Catch:{ all -> 0x0083 }
            long r3 = r3 + r10
        L_0x0048:
            long r10 = r3 - r10
            int r7 = (r10 > r8 ? 1 : (r10 == r8 ? 0 : -1))
            if (r7 > 0) goto L_0x005d
            _thread = r0
            r12.D0()
            boolean r0 = r12.B0()
            if (r0 != 0) goto L_0x005c
            r12.y0()
        L_0x005c:
            return
        L_0x005d:
            long r5 = ka.k.i.f(r5, r10)     // Catch:{ all -> 0x0083 }
            goto L_0x0063
        L_0x0062:
            r3 = r1
        L_0x0063:
            int r7 = (r5 > r8 ? 1 : (r5 == r8 ? 0 : -1))
            if (r7 <= 0) goto L_0x0030
            boolean r7 = r12.E0()     // Catch:{ all -> 0x0083 }
            if (r7 == 0) goto L_0x007c
            _thread = r0
            r12.D0()
            boolean r0 = r12.B0()
            if (r0 != 0) goto L_0x007b
            r12.y0()
        L_0x007b:
            return
        L_0x007c:
            java.util.concurrent.locks.LockSupport.parkNanos(r12, r5)     // Catch:{ all -> 0x0083 }
            goto L_0x0030
        L_0x0080:
            r1 = move-exception
            monitor-exit(r12)     // Catch:{ all -> 0x0083 }
            throw r1     // Catch:{ all -> 0x0083 }
        L_0x0083:
            r1 = move-exception
            _thread = r0
            r12.D0()
            boolean r0 = r12.B0()
            if (r0 != 0) goto L_0x0092
            r12.y0()
        L_0x0092:
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.k0.run():void");
    }

    public u0 s(long j, Runnable runnable, f fVar) {
        long a = b1.a(j);
        if (a >= 4611686018427387903L) {
            return y1.a;
        }
        long nanoTime = System.nanoTime();
        z0.b bVar = new z0.b(a + nanoTime, runnable);
        C0(nanoTime, bVar);
        return bVar;
    }

    public Thread y0() {
        Thread thread = _thread;
        if (thread == null) {
            synchronized (this) {
                thread = _thread;
                if (thread == null) {
                    thread = new Thread(this, "kotlinx.coroutines.DefaultExecutor");
                    _thread = thread;
                    thread.setDaemon(true);
                    thread.start();
                }
            }
        }
        return thread;
    }
}

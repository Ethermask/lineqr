package oh.a;

import java.lang.Thread;
import java.util.List;
import ka.b.q;
import ka.e.f;
import ka.l.y;
import kotlin.ExceptionsKt__ExceptionsKt;
import kotlinx.coroutines.CoroutineExceptionHandler;

public final class f0 {
    public static final List<CoroutineExceptionHandler> a = y.r(q.r(a.d0()));

    public static final void a(f fVar, Throwable th2) {
        Throwable th3;
        for (CoroutineExceptionHandler handleException : a) {
            try {
                handleException.handleException(fVar, th2);
            } catch (Throwable th4) {
                Thread currentThread = Thread.currentThread();
                Thread.UncaughtExceptionHandler uncaughtExceptionHandler = currentThread.getUncaughtExceptionHandler();
                if (th2 == th4) {
                    th3 = th2;
                } else {
                    th3 = new RuntimeException("Exception while trying to handle coroutine exception", th4);
                    ExceptionsKt__ExceptionsKt.addSuppressed(th3, th2);
                }
                uncaughtExceptionHandler.uncaughtException(currentThread, th3);
            }
        }
        Thread currentThread2 = Thread.currentThread();
        currentThread2.getUncaughtExceptionHandler().uncaughtException(currentThread2, th2);
    }
}

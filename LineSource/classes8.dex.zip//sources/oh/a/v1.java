package oh.a;

import ka.b.q;
import ka.e.d;
import ka.e.f;
import ka.h.b.p;
import kotlin.Unit;

public final class v1 extends f2 {
    public final d<Unit> d;

    public v1(f fVar, p<? super h0, ? super d<? super Unit>, ? extends Object> pVar) {
        super(fVar, false);
        this.d = q.t0(pVar, this, this);
    }

    public void w0() {
        q.n3(this.d, this);
    }
}

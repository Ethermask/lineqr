package oh.a;

import java.util.concurrent.Executor;
import ka.e.h;

public final class r0 implements Executor {
    public final e0 a;

    public r0(e0 e0Var) {
        this.a = e0Var;
    }

    public void execute(Runnable runnable) {
        this.a.d0(h.a, runnable);
    }

    public String toString() {
        return this.a.toString();
    }
}

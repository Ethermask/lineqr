package oh.a;

public final class b implements z1 {
    public static final b a = new b();

    public String toString() {
        return "Active";
    }
}

package oh.a;

public interface u0 {
    void dispose();
}

package oh.a;

import java.util.concurrent.CancellationException;
import ka.e.d;
import ka.e.f;
import ka.h.b.l;
import ka.l.k;
import kotlin.Unit;
import kotlinx.coroutines.CoroutineExceptionHandler;

public interface n1 extends f.a {
    public static final a Z = a.a;

    public static final class a implements f.b<n1> {
        public static final /* synthetic */ a a = new a();

        static {
            CoroutineExceptionHandler.a aVar = CoroutineExceptionHandler.Y;
        }
    }

    boolean K();

    Object P(d<? super Unit> dVar);

    void c(CancellationException cancellationException);

    p c0(r rVar);

    k<n1> i();

    boolean isActive();

    boolean isCancelled();

    u0 j(boolean z, boolean z2, l<? super Throwable, Unit> lVar);

    CancellationException k();

    boolean start();

    u0 v(l<? super Throwable, Unit> lVar);
}

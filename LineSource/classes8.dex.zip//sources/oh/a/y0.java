package oh.a;

import ka.b.k;
import oh.a.t2.a;
import oh.a.t2.b0;
import oh.a.t2.n;
import oh.a.z0;

public abstract class y0 extends e0 {
    public long b;
    public boolean c;
    public a<q0<?>> d;

    public static /* synthetic */ void i0(y0 y0Var, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = false;
        }
        y0Var.h0(z);
    }

    public static /* synthetic */ void q0(y0 y0Var, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = false;
        }
        y0Var.n0(z);
    }

    public final void h0(boolean z) {
        b0 c2;
        long j0 = this.b - j0(z);
        this.b = j0;
        if (j0 <= 0 && this.c) {
            z0 z0Var = (z0) this;
            i2 i2Var = i2.b;
            i2.a.set((Object) null);
            z0Var._isCompleted = 1;
            while (true) {
                Object obj = z0Var._queue;
                if (obj == null) {
                    if (z0.f110e.compareAndSet(z0Var, (Object) null, b1.b)) {
                        break;
                    }
                } else if (obj instanceof n) {
                    ((n) obj).b();
                    break;
                } else if (obj == b1.b) {
                    break;
                } else {
                    n nVar = new n(8, true);
                    nVar.a((Runnable) obj);
                    if (z0.f110e.compareAndSet(z0Var, obj, nVar)) {
                        break;
                    }
                }
            }
            do {
            } while (z0Var.w0() <= 0);
            long nanoTime = System.nanoTime();
            while (true) {
                z0.d dVar = (z0.d) z0Var._delayed;
                if (dVar != null) {
                    synchronized (dVar) {
                        c2 = dVar._size > 0 ? dVar.c(0) : null;
                    }
                    z0.c cVar = (z0.c) c2;
                    if (cVar != null) {
                        k0.h.C0(nanoTime, cVar);
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
        }
    }

    public final long j0(boolean z) {
        return z ? 4294967296L : 1;
    }

    public final void l0(q0<?> q0Var) {
        a<q0<?>> aVar = this.d;
        if (aVar == null) {
            aVar = new a<>();
            this.d = aVar;
        }
        Object[] objArr = aVar.a;
        int i = aVar.c;
        objArr[i] = q0Var;
        int length = (objArr.length - 1) & (i + 1);
        aVar.c = length;
        int i2 = aVar.b;
        if (length == i2) {
            int length2 = objArr.length;
            Object[] objArr2 = new Object[(length2 << 1)];
            k.h(objArr, objArr2, 0, i2, 0, 10);
            Object[] objArr3 = aVar.a;
            int length3 = objArr3.length;
            int i3 = aVar.b;
            k.h(objArr3, objArr2, length3 - i3, 0, i3, 4);
            aVar.a = objArr2;
            aVar.b = 0;
            aVar.c = length2;
        }
    }

    public final void n0(boolean z) {
        this.b = j0(z) + this.b;
        if (!z) {
            this.c = true;
        }
    }

    public final boolean v0() {
        return this.b >= j0(true);
    }

    public long w0() {
        return !x0() ? Long.MAX_VALUE : 0;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v3, resolved type: oh.a.q0} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean x0() {
        /*
            r7 = this;
            oh.a.t2.a<oh.a.q0<?>> r0 = r7.d
            r1 = 0
            if (r0 == 0) goto L_0x002f
            int r2 = r0.b
            int r3 = r0.c
            r4 = 0
            r5 = 1
            if (r2 != r3) goto L_0x000e
            goto L_0x001e
        L_0x000e:
            java.lang.Object[] r3 = r0.a
            r6 = r3[r2]
            r3[r2] = r4
            int r2 = r2 + r5
            int r3 = r3.length
            int r3 = r3 + -1
            r2 = r2 & r3
            r0.b = r2
            if (r6 == 0) goto L_0x0027
            r4 = r6
        L_0x001e:
            oh.a.q0 r4 = (oh.a.q0) r4
            if (r4 == 0) goto L_0x0026
            r4.run()
            return r5
        L_0x0026:
            return r1
        L_0x0027:
            java.lang.NullPointerException r0 = new java.lang.NullPointerException
            java.lang.String r1 = "null cannot be cast to non-null type T"
            r0.<init>(r1)
            throw r0
        L_0x002f:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.y0.x0():boolean");
    }
}

package oh.a;

import ka.e.d;
import ka.h.c.p;
import kotlin.Unit;
import oh.a.t2.h;
import oh.a.t2.i;

public final class o extends p1 {

    /* renamed from: e  reason: collision with root package name */
    public final l<?> f67e;

    public o(l<?> lVar) {
        this.f67e = lVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        w((Throwable) obj);
        return Unit.INSTANCE;
    }

    public void w(Throwable th2) {
        l<?> lVar = this.f67e;
        Throwable s = lVar.s(x());
        boolean z = true;
        boolean z2 = false;
        if (lVar.c == 2) {
            d<T> dVar = lVar.f62e;
            if (!(dVar instanceof h)) {
                dVar = null;
            }
            h hVar = (h) dVar;
            if (hVar != null) {
                while (true) {
                    Object obj = hVar._reusableCancellableContinuation;
                    if (!p.b(obj, i.b)) {
                        if (obj instanceof Throwable) {
                            break;
                        } else if (h.h.compareAndSet(hVar, obj, (Object) null)) {
                            z = false;
                            break;
                        }
                    } else if (h.h.compareAndSet(hVar, i.b, s)) {
                        break;
                    }
                }
                z2 = z;
            }
        }
        if (!z2) {
            lVar.o(s);
            lVar.p();
        }
    }
}

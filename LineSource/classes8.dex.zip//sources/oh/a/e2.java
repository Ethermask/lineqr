package oh.a;

import kotlin.Unit;

public final class e2 implements Runnable {
    public final e0 a;
    public final k<Unit> b;

    public e2(e0 e0Var, k<? super Unit> kVar) {
        this.a = e0Var;
        this.b = kVar;
    }

    public void run() {
        this.b.u(this.a, Unit.INSTANCE);
    }
}

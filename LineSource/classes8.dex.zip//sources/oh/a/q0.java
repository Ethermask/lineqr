package oh.a;

import ka.b.q;
import ka.e.d;
import ka.h.c.p;
import kotlin.ExceptionsKt__ExceptionsKt;
import oh.a.x2.i;

public abstract class q0<T> extends i {
    public int c;

    public q0(int i) {
        this.c = i;
    }

    public void a(Object obj, Throwable th2) {
    }

    public abstract d<T> b();

    public Throwable c(Object obj) {
        if (!(obj instanceof y)) {
            obj = null;
        }
        y yVar = (y) obj;
        if (yVar != null) {
            return yVar.a;
        }
        return null;
    }

    public <T> T e(Object obj) {
        return obj;
    }

    public final void f(Throwable th2, Throwable th3) {
        if (th2 != null || th3 != null) {
            if (!(th2 == null || th3 == null)) {
                ExceptionsKt__ExceptionsKt.addSuppressed(th2, th3);
            }
            if (th2 == null) {
                th2 = th3;
            }
            p.c(th2);
            q.I1(b().getContext(), new j0("Fatal exception in coroutines machinery for " + this + ". " + "Please read KDoc to 'handleFatalException' method and report this incident to maintainers", th2));
        }
    }

    public abstract Object g();

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0083, code lost:
        if (r4.y0() != false) goto L_0x0085;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x00ae, code lost:
        if (r4.y0() != false) goto L_0x00b0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
            r10 = this;
            oh.a.x2.j r0 = r10.b
            ka.e.d r1 = r10.b()     // Catch:{ all -> 0x00bc }
            if (r1 == 0) goto L_0x00b4
            oh.a.t2.h r1 = (oh.a.t2.h) r1     // Catch:{ all -> 0x00bc }
            ka.e.d<T> r2 = r1.g     // Catch:{ all -> 0x00bc }
            java.lang.Object r1 = r1.f90e     // Catch:{ all -> 0x00bc }
            ka.e.f r3 = r2.getContext()     // Catch:{ all -> 0x00bc }
            java.lang.Object r1 = oh.a.t2.x.c(r3, r1)     // Catch:{ all -> 0x00bc }
            oh.a.t2.v r4 = oh.a.t2.x.a     // Catch:{ all -> 0x00bc }
            r5 = 0
            if (r1 == r4) goto L_0x0020
            oh.a.n2 r4 = oh.a.c0.c(r2, r3, r1)     // Catch:{ all -> 0x00bc }
            goto L_0x0021
        L_0x0020:
            r4 = r5
        L_0x0021:
            ka.e.f r6 = r2.getContext()     // Catch:{ all -> 0x00a7 }
            java.lang.Object r7 = r10.g()     // Catch:{ all -> 0x00a7 }
            java.lang.Throwable r8 = r10.c(r7)     // Catch:{ all -> 0x00a7 }
            if (r8 != 0) goto L_0x0040
            int r9 = r10.c     // Catch:{ all -> 0x00a7 }
            boolean r9 = ka.b.q.Q1(r9)     // Catch:{ all -> 0x00a7 }
            if (r9 == 0) goto L_0x0040
            oh.a.n1$a r9 = oh.a.n1.Z     // Catch:{ all -> 0x00a7 }
            ka.e.f$a r6 = r6.get(r9)     // Catch:{ all -> 0x00a7 }
            oh.a.n1 r6 = (oh.a.n1) r6     // Catch:{ all -> 0x00a7 }
            goto L_0x0041
        L_0x0040:
            r6 = r5
        L_0x0041:
            if (r6 == 0) goto L_0x005e
            boolean r9 = r6.isActive()     // Catch:{ all -> 0x00a7 }
            if (r9 != 0) goto L_0x005e
            java.util.concurrent.CancellationException r6 = r6.k()     // Catch:{ all -> 0x00a7 }
            r10.a(r7, r6)     // Catch:{ all -> 0x00a7 }
            kotlin.Result$Companion r7 = kotlin.Result.Companion     // Catch:{ all -> 0x00a7 }
            java.lang.Object r6 = kotlin.ResultKt.createFailure(r6)     // Catch:{ all -> 0x00a7 }
            java.lang.Object r6 = kotlin.Result.constructor-impl(r6)     // Catch:{ all -> 0x00a7 }
            r2.resumeWith(r6)     // Catch:{ all -> 0x00a7 }
            goto L_0x007b
        L_0x005e:
            if (r8 == 0) goto L_0x006e
            kotlin.Result$Companion r6 = kotlin.Result.Companion     // Catch:{ all -> 0x00a7 }
            java.lang.Object r6 = kotlin.ResultKt.createFailure(r8)     // Catch:{ all -> 0x00a7 }
            java.lang.Object r6 = kotlin.Result.constructor-impl(r6)     // Catch:{ all -> 0x00a7 }
            r2.resumeWith(r6)     // Catch:{ all -> 0x00a7 }
            goto L_0x007b
        L_0x006e:
            java.lang.Object r6 = r10.e(r7)     // Catch:{ all -> 0x00a7 }
            kotlin.Result$Companion r7 = kotlin.Result.Companion     // Catch:{ all -> 0x00a7 }
            java.lang.Object r6 = kotlin.Result.constructor-impl(r6)     // Catch:{ all -> 0x00a7 }
            r2.resumeWith(r6)     // Catch:{ all -> 0x00a7 }
        L_0x007b:
            kotlin.Unit r2 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x00a7 }
            if (r4 == 0) goto L_0x0085
            boolean r2 = r4.y0()     // Catch:{ all -> 0x00bc }
            if (r2 == 0) goto L_0x0088
        L_0x0085:
            oh.a.t2.x.a(r3, r1)     // Catch:{ all -> 0x00bc }
        L_0x0088:
            kotlin.Result$Companion r1 = kotlin.Result.Companion     // Catch:{ all -> 0x0094 }
            r0.W()     // Catch:{ all -> 0x0094 }
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x0094 }
            java.lang.Object r0 = kotlin.Result.constructor-impl(r0)     // Catch:{ all -> 0x0094 }
            goto L_0x009f
        L_0x0094:
            r0 = move-exception
            kotlin.Result$Companion r1 = kotlin.Result.Companion
            java.lang.Object r0 = kotlin.ResultKt.createFailure(r0)
            java.lang.Object r0 = kotlin.Result.constructor-impl(r0)
        L_0x009f:
            java.lang.Throwable r0 = kotlin.Result.exceptionOrNull-impl(r0)
            r10.f(r5, r0)
            goto L_0x00db
        L_0x00a7:
            r2 = move-exception
            if (r4 == 0) goto L_0x00b0
            boolean r4 = r4.y0()     // Catch:{ all -> 0x00bc }
            if (r4 == 0) goto L_0x00b3
        L_0x00b0:
            oh.a.t2.x.a(r3, r1)     // Catch:{ all -> 0x00bc }
        L_0x00b3:
            throw r2     // Catch:{ all -> 0x00bc }
        L_0x00b4:
            java.lang.NullPointerException r1 = new java.lang.NullPointerException     // Catch:{ all -> 0x00bc }
            java.lang.String r2 = "null cannot be cast to non-null type kotlinx.coroutines.internal.DispatchedContinuation<T>"
            r1.<init>(r2)     // Catch:{ all -> 0x00bc }
            throw r1     // Catch:{ all -> 0x00bc }
        L_0x00bc:
            r1 = move-exception
            kotlin.Result$Companion r2 = kotlin.Result.Companion     // Catch:{ all -> 0x00c9 }
            r0.W()     // Catch:{ all -> 0x00c9 }
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x00c9 }
            java.lang.Object r0 = kotlin.Result.constructor-impl(r0)     // Catch:{ all -> 0x00c9 }
            goto L_0x00d4
        L_0x00c9:
            r0 = move-exception
            kotlin.Result$Companion r2 = kotlin.Result.Companion
            java.lang.Object r0 = kotlin.ResultKt.createFailure(r0)
            java.lang.Object r0 = kotlin.Result.constructor-impl(r0)
        L_0x00d4:
            java.lang.Throwable r0 = kotlin.Result.exceptionOrNull-impl(r0)
            r10.f(r1, r0)
        L_0x00db:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.q0.run():void");
    }
}

package oh.a;

import kotlin.Unit;

public class q1 extends s1 implements w {
    public final boolean b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public q1(n1 n1Var) {
        super(true);
        s1 x;
        boolean z = true;
        Z(n1Var);
        p pVar = (p) this._parentHandle;
        q qVar = (q) (!(pVar instanceof q) ? null : pVar);
        if (qVar != null && (x = qVar.x()) != null) {
            while (true) {
                if (!x.T()) {
                    p pVar2 = (p) x._parentHandle;
                    q qVar2 = (q) (!(pVar2 instanceof q) ? null : pVar2);
                    if (qVar2 != null) {
                        x = qVar2.x();
                        if (x == null) {
                            break;
                        }
                    } else {
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        z = false;
        this.b = z;
    }

    public boolean T() {
        return this.b;
    }

    public boolean U() {
        return true;
    }

    public boolean a() {
        return d0(Unit.INSTANCE);
    }
}

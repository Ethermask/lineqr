package oh.a;

public final class h1 implements i1 {
    public final x1 a;

    public h1(x1 x1Var) {
        this.a = x1Var;
    }

    public x1 c() {
        return this.a;
    }

    public boolean isActive() {
        return false;
    }

    public String toString() {
        return super.toString();
    }
}

package oh.a;

import ka.e.f;
import ka.h.b.p;

public final class o2 implements f.a, f.b<o2> {
    public static final o2 a = new o2();

    public <R> R fold(R r, p<? super R, ? super f.a, ? extends R> pVar) {
        return f.a.a.a(this, r, pVar);
    }

    public <E extends f.a> E get(f.b<E> bVar) {
        return f.a.a.b(this, bVar);
    }

    public f.b<?> getKey() {
        return this;
    }

    public f minusKey(f.b<?> bVar) {
        return f.a.a.c(this, bVar);
    }

    public f plus(f fVar) {
        return f.a.a.d(this, fVar);
    }
}

package oh.a;

import oh.a.t2.v;

public final class m {
    public static final v a = new v("RESUME_TOKEN");
}

package oh.a;

import oh.a.t2.v;

public final class b1 {
    public static final v a = new v("REMOVED_TASK");
    public static final v b = new v("CLOSED_EMPTY");

    public static final long a(long j) {
        if (j <= 0) {
            return 0;
        }
        if (j >= 9223372036854L) {
            return Long.MAX_VALUE;
        }
        return 1000000 * j;
    }
}

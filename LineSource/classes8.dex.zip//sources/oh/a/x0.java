package oh.a;

import e.e.b.a.a;

public final class x0 implements i1 {
    public final boolean a;

    public x0(boolean z) {
        this.a = z;
    }

    public x1 c() {
        return null;
    }

    public boolean isActive() {
        return this.a;
    }

    public String toString() {
        return a.o0(a.V0("Empty{"), this.a ? "Active" : "New", '}');
    }
}

package oh.a;

import ka.b.q;
import ka.e.b;
import ka.e.d;
import ka.e.e;
import ka.e.f;
import ka.h.c.p;
import kotlin.ExperimentalStdlibApi;
import kotlin.jvm.internal.DefaultConstructorMarker;
import oh.a.t2.h;

public abstract class e0 extends ka.e.a implements e {
    public static final a a = new a((DefaultConstructorMarker) null);

    @ExperimentalStdlibApi
    public static final class a extends b<e, e0> {
        public a(DefaultConstructorMarker defaultConstructorMarker) {
            super(e.X, d0.a);
        }
    }

    public e0() {
        super(e.X);
    }

    public void b(d<?> dVar) {
        Object obj = ((h) dVar)._reusableCancellableContinuation;
        if (!(obj instanceof l)) {
            obj = null;
        }
        l lVar = (l) obj;
        if (lVar != null) {
            lVar.k();
        }
    }

    public abstract void d0(f fVar, Runnable runnable);

    public void e0(f fVar, Runnable runnable) {
        d0(fVar, runnable);
    }

    public boolean g0(f fVar) {
        return true;
    }

    public <E extends f.a> E get(f.b<E> bVar) {
        p.e(bVar, "key");
        if (bVar instanceof b) {
            f.b bVar2 = (b) bVar;
            f.b key = getKey();
            p.e(key, "key");
            if (!(key == bVar2 || bVar2.a == key)) {
                return null;
            }
            p.e(this, "element");
            E e2 = (f.a) bVar2.b.invoke(this);
            if (!(e2 instanceof f.a)) {
                return null;
            }
            return e2;
        } else if (e.X == bVar) {
            return this;
        } else {
            return null;
        }
    }

    public final <T> d<T> h(d<? super T> dVar) {
        return new h(this, dVar);
    }

    public f minusKey(f.b<?> bVar) {
        p.e(bVar, "key");
        if (bVar instanceof b) {
            f.b bVar2 = (b) bVar;
            f.b key = getKey();
            p.e(key, "key");
            if (key == bVar2 || bVar2.a == key) {
                p.e(this, "element");
                if (((f.a) bVar2.b.invoke(this)) != null) {
                    return ka.e.h.a;
                }
            }
        } else if (e.X == bVar) {
            return ka.e.h.a;
        }
        return this;
    }

    public String toString() {
        return getClass().getSimpleName() + '@' + q.q1(this);
    }
}

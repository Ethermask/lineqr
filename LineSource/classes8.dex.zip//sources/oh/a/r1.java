package oh.a;

import ka.b.q;
import ka.h.c.p;

public abstract class r1 extends a0 implements u0, i1 {
    public s1 d;

    public x1 c() {
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x001a A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:4:0x000c A[ADDED_TO_REGION] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void dispose() {
        /*
            r4 = this;
            oh.a.s1 r0 = r4.d
            if (r0 == 0) goto L_0x002a
        L_0x0004:
            java.lang.Object r1 = r0.W()
            boolean r2 = r1 instanceof oh.a.r1
            if (r2 == 0) goto L_0x001a
            if (r1 == r4) goto L_0x000f
            goto L_0x0029
        L_0x000f:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r2 = oh.a.s1.a
            oh.a.x0 r3 = oh.a.t1.g
            boolean r1 = r2.compareAndSet(r0, r1, r3)
            if (r1 == 0) goto L_0x0004
            goto L_0x0029
        L_0x001a:
            boolean r0 = r1 instanceof oh.a.i1
            if (r0 == 0) goto L_0x0029
            oh.a.i1 r1 = (oh.a.i1) r1
            oh.a.x1 r0 = r1.c()
            if (r0 == 0) goto L_0x0029
            r4.t()
        L_0x0029:
            return
        L_0x002a:
            java.lang.String r0 = "job"
            ka.h.c.p.l(r0)
            r0 = 0
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.r1.dispose():void");
    }

    public boolean isActive() {
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append('@');
        sb.append(q.q1(this));
        sb.append("[job@");
        s1 s1Var = this.d;
        if (s1Var != null) {
            sb.append(q.q1(s1Var));
            sb.append(']');
            return sb.toString();
        }
        p.l("job");
        throw null;
    }

    public final s1 x() {
        s1 s1Var = this.d;
        if (s1Var != null) {
            return s1Var;
        }
        p.l("job");
        throw null;
    }
}

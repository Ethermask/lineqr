package oh.a;

public abstract class e extends i {
}

package oh.a;

import ka.h.b.l;
import kotlin.Unit;

public abstract class j implements l<Throwable, Unit> {
    public abstract void a(Throwable th2);
}

package oh.a;

import ka.b.q;
import ka.e.d;
import ka.e.f;
import ka.h.b.l;
import ka.h.b.p;
import ka.h.c.n0;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.t2.x;

public abstract class a<T> extends s1 implements n1, d<T>, h0 {
    public final f b;
    public final f c;

    public a(f fVar, boolean z) {
        super(z);
        this.c = fVar;
        this.b = fVar.plus(this);
    }

    public String L() {
        return getClass().getSimpleName() + " was cancelled";
    }

    public final void Y(Throwable th2) {
        q.I1(this.b, th2);
    }

    public String f0() {
        c0.a(this.b);
        return super.f0();
    }

    public final f getContext() {
        return this.b;
    }

    public f getCoroutineContext() {
        return this.b;
    }

    public boolean isActive() {
        return super.isActive();
    }

    /* JADX WARNING: type inference failed for: r2v2, types: [boolean, int] */
    public final void j0(Object obj) {
        if (obj instanceof y) {
            y yVar = (y) obj;
            u0(yVar.a, yVar._handled);
            return;
        }
        v0(obj);
    }

    public final void k0() {
        w0();
    }

    public final void resumeWith(Object obj) {
        Object e0 = e0(q.U3(obj, (l) null));
        if (e0 != t1.b) {
            s0(e0);
        }
    }

    public void s0(Object obj) {
        C(obj);
    }

    public final void t0() {
        Z(this.c.get(n1.Z));
    }

    public void u0(Throwable th2, boolean z) {
    }

    public void v0(T t) {
    }

    public void w0() {
    }

    public final <R> void x0(i0 i0Var, R r, p<? super R, ? super d<? super T>, ? extends Object> pVar) {
        f context;
        Object c2;
        t0();
        int ordinal = i0Var.ordinal();
        if (ordinal == 0) {
            q.o3(pVar, r, this, (l) null, 4);
        } else if (ordinal == 1) {
        } else {
            if (ordinal == 2) {
                ka.h.c.p.e(pVar, "$this$startCoroutine");
                ka.h.c.p.e(this, "completion");
                d M1 = q.M1(q.t0(pVar, r, this));
                Unit unit = Unit.INSTANCE;
                Result.Companion companion = Result.Companion;
                M1.resumeWith(Result.constructor-impl(unit));
            } else if (ordinal == 3) {
                ka.h.c.p.e(this, "completion");
                try {
                    context = getContext();
                    c2 = x.c(context, (Object) null);
                    if (pVar != null) {
                        n0.e(pVar, 2);
                        Object invoke = pVar.invoke(r, this);
                        x.a(context, c2);
                        if (invoke != ka.e.j.a.COROUTINE_SUSPENDED) {
                            Result.Companion companion2 = Result.Companion;
                            resumeWith(Result.constructor-impl(invoke));
                            return;
                        }
                        return;
                    }
                    throw new NullPointerException("null cannot be cast to non-null type (R, kotlin.coroutines.Continuation<T>) -> kotlin.Any?");
                } catch (Throwable th2) {
                    Result.Companion companion3 = Result.Companion;
                    resumeWith(Result.constructor-impl(ResultKt.createFailure(th2)));
                }
            } else {
                throw new NoWhenBranchMatchedException();
            }
        }
    }
}

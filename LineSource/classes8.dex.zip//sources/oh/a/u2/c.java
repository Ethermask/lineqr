package oh.a.u2;

import ka.e.d;
import ka.e.k.a.e;
import oh.a.s2.f;

public final class c implements f<T> {
    public final /* synthetic */ e a;

    @e(c = "kotlinx.coroutines.reactive.FlowSubscription$consumeFlow$$inlined$collect$1", f = "ReactiveFlow.kt", l = {137}, m = "emit")
    public static final class a extends ka.e.k.a.c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ c c;
        public Object d;

        /* renamed from: e  reason: collision with root package name */
        public Object f92e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(c cVar, d dVar) {
            super(dVar);
            this.c = cVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return this.c.a((Object) null, this);
        }
    }

    public c(e eVar) {
        this.a = eVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0037  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object a(java.lang.Object r7, ka.e.d r8) {
        /*
            r6 = this;
            boolean r0 = r8 instanceof oh.a.u2.c.a
            if (r0 == 0) goto L_0x0013
            r0 = r8
            oh.a.u2.c$a r0 = (oh.a.u2.c.a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.u2.c$a r0 = new oh.a.u2.c$a
            r0.<init>(r6, r8)
        L_0x0018:
            java.lang.Object r8 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 1
            if (r2 == 0) goto L_0x0037
            if (r2 != r3) goto L_0x002f
            java.lang.Object r7 = r0.f92e
            oh.a.u2.c$a r7 = (oh.a.u2.c.a) r7
            java.lang.Object r7 = r0.d
            oh.a.u2.c r7 = (oh.a.u2.c) r7
            kotlin.ResultKt.throwOnFailure(r8)
            goto L_0x007c
        L_0x002f:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L_0x0037:
            kotlin.ResultKt.throwOnFailure(r8)
            oh.a.u2.e r8 = r6.a
            rh.e.b<? super T> r8 = r8.f93e
            r8.onNext(r7)
            oh.a.u2.e r7 = r6.a
            java.util.concurrent.atomic.AtomicLongFieldUpdater r8 = oh.a.u2.e.f
            long r7 = r8.decrementAndGet(r7)
            r4 = 0
            int r7 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r7 > 0) goto L_0x0075
            r0.d = r6
            r0.f92e = r0
            r0.b = r3
            oh.a.l r7 = new oh.a.l
            ka.e.d r8 = ka.b.q.M1(r0)
            r7.<init>(r8, r3)
            r7.D()
            oh.a.u2.e r8 = r6.a
            r8.producer = r7
            java.lang.Object r7 = r7.t()
            ka.e.j.a r8 = ka.e.j.a.COROUTINE_SUSPENDED
            if (r7 != r8) goto L_0x0072
            java.lang.String r8 = "frame"
            ka.h.c.p.e(r0, r8)
        L_0x0072:
            if (r7 != r1) goto L_0x007c
            return r1
        L_0x0075:
            oh.a.u2.e r7 = r6.a
            ka.e.f r7 = r7.b
            ka.b.q.D0(r7)
        L_0x007c:
            kotlin.Unit r7 = kotlin.Unit.INSTANCE
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.u2.c.a(java.lang.Object, ka.e.d):java.lang.Object");
    }
}

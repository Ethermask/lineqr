package oh.a.u2;

import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.e.d;
import ka.e.f;
import kotlin.Result;
import kotlin.Unit;
import kotlin._Assertions;
import rh.e.b;
import rh.e.c;

public final class e<T> extends oh.a.a<Unit> implements c {
    public static final /* synthetic */ AtomicLongFieldUpdater f;
    public static final /* synthetic */ AtomicReferenceFieldUpdater g;
    public final oh.a.s2.e<T> d;

    /* renamed from: e  reason: collision with root package name */
    public final b<? super T> f93e;
    public volatile /* synthetic */ Object producer = new d(this.b, this);
    public volatile /* synthetic */ long requested = 0;

    @ka.e.k.a.e(c = "kotlinx.coroutines.reactive.FlowSubscription", f = "ReactiveFlow.kt", l = {198}, m = "flowProcessing")
    public static final class a extends ka.e.k.a.c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ e c;
        public Object d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(e eVar, d dVar) {
            super(dVar);
            this.c = eVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return this.c.y0(this);
        }
    }

    static {
        Class<e> cls = e.class;
        f = AtomicLongFieldUpdater.newUpdater(cls, "requested");
        g = AtomicReferenceFieldUpdater.newUpdater(cls, Object.class, "producer");
    }

    public e(oh.a.s2.e<? extends T> eVar, b<? super T> bVar, f fVar) {
        super(fVar, true);
        this.d = eVar;
        this.f93e = bVar;
    }

    public void cancel() {
        c((CancellationException) null);
    }

    public void f(long j) {
        long j2;
        long j3;
        d dVar;
        if (j > 0) {
            do {
                j2 = this.requested;
                j3 = j2 + j;
                if (j3 <= 0) {
                    j3 = Long.MAX_VALUE;
                }
            } while (!f.compareAndSet(this, j2, j3));
            int i = (j2 > 0 ? 1 : (j2 == 0 ? 0 : -1));
            if (i <= 0) {
                boolean z = i == 0;
                if (!_Assertions.ENABLED || z) {
                    do {
                        dVar = (d) g.getAndSet(this, (Object) null);
                    } while (dVar == null);
                    Unit unit = Unit.INSTANCE;
                    Result.Companion companion = Result.Companion;
                    dVar.resumeWith(Result.constructor-impl(unit));
                    return;
                }
                throw new AssertionError("Assertion failed");
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object y0(ka.e.d<? super kotlin.Unit> r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof oh.a.u2.e.a
            if (r0 == 0) goto L_0x0013
            r0 = r5
            oh.a.u2.e$a r0 = (oh.a.u2.e.a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.u2.e$a r0 = new oh.a.u2.e$a
            r0.<init>(r4, r5)
        L_0x0018:
            java.lang.Object r5 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 1
            if (r2 == 0) goto L_0x0035
            if (r2 != r3) goto L_0x002d
            java.lang.Object r0 = r0.d
            oh.a.u2.e r0 = (oh.a.u2.e) r0
            kotlin.ResultKt.throwOnFailure(r5)     // Catch:{ all -> 0x002b }
            goto L_0x0052
        L_0x002b:
            r5 = move-exception
            goto L_0x005a
        L_0x002d:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L_0x0035:
            kotlin.ResultKt.throwOnFailure(r5)
            r0.d = r4     // Catch:{ all -> 0x0058 }
            r0.b = r3     // Catch:{ all -> 0x0058 }
            oh.a.s2.e<T> r5 = r4.d     // Catch:{ all -> 0x0058 }
            oh.a.u2.c r2 = new oh.a.u2.c     // Catch:{ all -> 0x0058 }
            r2.<init>(r4)     // Catch:{ all -> 0x0058 }
            java.lang.Object r5 = r5.c(r2, r0)     // Catch:{ all -> 0x0058 }
            ka.e.j.a r0 = ka.e.j.a.COROUTINE_SUSPENDED     // Catch:{ all -> 0x0058 }
            if (r5 != r0) goto L_0x004c
            goto L_0x004e
        L_0x004c:
            kotlin.Unit r5 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x0058 }
        L_0x004e:
            if (r5 != r1) goto L_0x0051
            return r1
        L_0x0051:
            r0 = r4
        L_0x0052:
            rh.e.b<? super T> r5 = r0.f93e     // Catch:{ all -> 0x002b }
            r5.onComplete()     // Catch:{ all -> 0x002b }
            goto L_0x0070
        L_0x0058:
            r5 = move-exception
            r0 = r4
        L_0x005a:
            boolean r1 = r5 instanceof java.util.concurrent.CancellationException     // Catch:{ all -> 0x006a }
            if (r1 == 0) goto L_0x0064
            rh.e.b<? super T> r5 = r0.f93e     // Catch:{ all -> 0x006a }
            r5.onComplete()     // Catch:{ all -> 0x006a }
            goto L_0x0070
        L_0x0064:
            rh.e.b<? super T> r1 = r0.f93e     // Catch:{ all -> 0x006a }
            r1.onError(r5)     // Catch:{ all -> 0x006a }
            goto L_0x0070
        L_0x006a:
            r5 = move-exception
            ka.e.f r0 = r0.b
            ka.b.q.I1(r0, r5)
        L_0x0070:
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.u2.e.y0(ka.e.d):java.lang.Object");
    }
}

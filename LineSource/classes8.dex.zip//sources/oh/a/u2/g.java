package oh.a.u2;

import e.e.b.a.a;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.h.b.l;
import oh.a.r2.n;
import rh.e.b;
import rh.e.c;

public final class g<T> extends n<T> implements b<T> {

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f94e;
    public static final /* synthetic */ AtomicIntegerFieldUpdater f;
    public volatile /* synthetic */ int _requested;
    public volatile /* synthetic */ Object _subscription;
    public final int d;

    static {
        Class<g> cls = g.class;
        f94e = AtomicReferenceFieldUpdater.newUpdater(cls, Object.class, "_subscription");
        f = AtomicIntegerFieldUpdater.newUpdater(cls, "_requested");
    }

    public g(int i) {
        super((l) null);
        this.d = i;
        if (i >= 0) {
            this._subscription = null;
            this._requested = 0;
            return;
        }
        StringBuilder V0 = a.V0("Invalid request size: ");
        V0.append(this.d);
        throw new IllegalArgumentException(V0.toString().toString());
    }

    public void C() {
        f.incrementAndGet(this);
    }

    public void D() {
        c cVar;
        int i;
        while (true) {
            int i2 = this._requested;
            cVar = (c) this._subscription;
            i = i2 - 1;
            if (cVar != null && i < 0) {
                int i3 = this.d;
                if (i2 == i3 || f.compareAndSet(this, i2, i3)) {
                    cVar.f((long) (this.d - i));
                }
            } else if (f.compareAndSet(this, i2, i)) {
                return;
            }
        }
        cVar.f((long) (this.d - i));
    }

    public void b(c cVar) {
        this._subscription = cVar;
        while (!y()) {
            int i = this._requested;
            int i2 = this.d;
            if (i < i2) {
                if (f.compareAndSet(this, i, i2)) {
                    cVar.f((long) (this.d - i));
                    return;
                }
            } else {
                return;
            }
        }
        cVar.cancel();
    }

    public void o(oh.a.t2.l lVar) {
        c cVar = (c) f94e.getAndSet(this, (Object) null);
        if (cVar != null) {
            cVar.cancel();
        }
    }

    public void onComplete() {
        w((Throwable) null);
    }

    public void onError(Throwable th2) {
        w(th2);
    }

    public void onNext(T t) {
        f.decrementAndGet(this);
        offer(t);
    }
}

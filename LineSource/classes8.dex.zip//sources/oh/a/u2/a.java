package oh.a.u2;

public interface a {
}

package oh.a.u2;

import ka.b.q;
import ka.e.f;
import ka.e.h;
import ka.e.j.b;
import ka.e.j.c;
import ka.h.b.l;
import ka.h.c.n;
import ka.h.c.p;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.t2.i;

public final class d implements ka.e.d<Unit> {
    public final /* synthetic */ f a;
    public final /* synthetic */ e b;

    public static final /* synthetic */ class a extends n implements l<ka.e.d<? super Unit>, Object> {
        public a(e eVar) {
            super(1, eVar, e.class, "flowProcessing", "flowProcessing(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
        }

        public Object invoke(Object obj) {
            return ((e) this.receiver).y0((ka.e.d) obj);
        }
    }

    public d(f fVar, e eVar) {
        this.a = fVar;
        this.b = eVar;
    }

    public f getContext() {
        return this.a;
    }

    public void resumeWith(Object obj) {
        ka.e.d dVar;
        ka.e.k.a.a aVar = new a(this.b);
        ka.e.d dVar2 = this.b;
        try {
            p.e(aVar, "$this$createCoroutineUnintercepted");
            p.e(dVar2, "completion");
            p.e(dVar2, "completion");
            if (aVar instanceof ka.e.k.a.a) {
                dVar = aVar.create(dVar2);
            } else {
                f context = dVar2.getContext();
                if (context == h.a) {
                    dVar = new b(dVar2, dVar2, aVar);
                } else {
                    dVar = new c(dVar2, context, dVar2, context, aVar);
                }
            }
            ka.e.d M1 = q.M1(dVar);
            Result.Companion companion = Result.Companion;
            i.b(M1, Result.constructor-impl(Unit.INSTANCE), (l) null, 2);
        } catch (Throwable th2) {
            Result.Companion companion2 = Result.Companion;
            dVar2.resumeWith(Result.constructor-impl(ResultKt.createFailure(th2)));
        }
    }
}

package oh.a.u2;

import java.util.ServiceLoader;
import ka.b.q;
import ka.l.y;
import oh.a.s0;
import oh.a.s2.e;
import rh.e.a;

public final class f {
    static {
        Class<a> cls = a.class;
        Object[] array = y.r(q.r(ServiceLoader.load(cls, cls.getClassLoader()).iterator())).toArray(new a[0]);
        if (array != null) {
            a[] aVarArr = (a[]) array;
            return;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
    }

    public static final <T> a<T> a(e<? extends T> eVar, ka.e.f fVar) {
        return new b(eVar, s0.b.plus(fVar));
    }
}

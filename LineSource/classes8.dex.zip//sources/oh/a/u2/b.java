package oh.a.u2;

import ka.e.f;
import oh.a.s2.e;
import rh.e.a;

public final class b<T> implements a<T> {
    public final e<T> a;
    public final f b;

    public b(e<? extends T> eVar, f fVar) {
        this.a = eVar;
        this.b = fVar;
    }

    public void a(rh.e.b<? super T> bVar) {
        if (bVar != null) {
            bVar.b(new e(this.a, bVar, this.b));
            return;
        }
        throw null;
    }
}

package oh.a;

import e.e.b.a.a;
import ka.h.b.l;
import ka.h.c.p;
import kotlin.Unit;

public final class z {
    public final Object a;
    public final l<Throwable, Unit> b;

    public z(Object obj, l<? super Throwable, Unit> lVar) {
        this.a = obj;
        this.b = lVar;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof z)) {
            return false;
        }
        z zVar = (z) obj;
        return p.b(this.a, zVar.a) && p.b(this.b, zVar.b);
    }

    public int hashCode() {
        Object obj = this.a;
        int i = 0;
        int hashCode = (obj != null ? obj.hashCode() : 0) * 31;
        l<Throwable, Unit> lVar = this.b;
        if (lVar != null) {
            i = lVar.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        StringBuilder V0 = a.V0("CompletedWithCancellation(result=");
        V0.append(this.a);
        V0.append(", onCancellation=");
        return a.E0(V0, this.b, ")");
    }
}

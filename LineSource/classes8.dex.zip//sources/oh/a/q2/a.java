package oh.a.q2;

import android.os.Handler;
import android.os.Looper;
import ka.e.f;
import ka.h.b.l;
import ka.h.c.p;
import ka.h.c.r;
import ka.k.i;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import oh.a.k;
import oh.a.o0;
import oh.a.u0;
import oh.a.w1;

public final class a extends b implements o0 {
    public volatile a _immediate;
    public final a b;
    public final Handler c;
    public final String d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f70e;

    /* renamed from: oh.a.q2.a$a  reason: collision with other inner class name */
    public static final class C0001a implements u0 {
        public final /* synthetic */ a a;
        public final /* synthetic */ Runnable b;

        public C0001a(a aVar, Runnable runnable) {
            this.a = aVar;
            this.b = runnable;
        }

        public void dispose() {
            this.a.c.removeCallbacks(this.b);
        }
    }

    public static final class b implements Runnable {
        public final /* synthetic */ a a;
        public final /* synthetic */ k b;

        public b(a aVar, k kVar) {
            this.a = aVar;
            this.b = kVar;
        }

        public final void run() {
            this.b.u(this.a, Unit.INSTANCE);
        }
    }

    public static final class c extends r implements l<Throwable, Unit> {
        public final /* synthetic */ a a;
        public final /* synthetic */ Runnable b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public c(a aVar, Runnable runnable) {
            super(1);
            this.a = aVar;
            this.b = runnable;
        }

        public Object invoke(Object obj) {
            Throwable th2 = (Throwable) obj;
            this.a.c.removeCallbacks(this.b);
            return Unit.INSTANCE;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(Handler handler, String str, boolean z) {
        super((DefaultConstructorMarker) null);
        a aVar = null;
        this.c = handler;
        this.d = str;
        this.f70e = z;
        this._immediate = z ? this : aVar;
        a aVar2 = this._immediate;
        if (aVar2 == null) {
            aVar2 = new a(this.c, this.d, true);
            this._immediate = aVar2;
            Unit unit = Unit.INSTANCE;
        }
        this.b = aVar2;
    }

    public void d(long j, k<? super Unit> kVar) {
        b bVar = new b(this, kVar);
        this.c.postDelayed(bVar, i.f(j, 4611686018427387903L));
        kVar.l(new c(this, bVar));
    }

    public void d0(f fVar, Runnable runnable) {
        this.c.post(runnable);
    }

    public boolean equals(Object obj) {
        return (obj instanceof a) && ((a) obj).c == this.c;
    }

    public boolean g0(f fVar) {
        return !this.f70e || (p.b(Looper.myLooper(), this.c.getLooper()) ^ true);
    }

    public w1 h0() {
        return this.b;
    }

    public int hashCode() {
        return System.identityHashCode(this.c);
    }

    public u0 s(long j, Runnable runnable, f fVar) {
        this.c.postDelayed(runnable, i.f(j, 4611686018427387903L));
        return new C0001a(this, runnable);
    }

    public String toString() {
        String i02 = i0();
        if (i02 != null) {
            return i02;
        }
        String str = this.d;
        if (str == null) {
            str = this.c.toString();
        }
        return this.f70e ? e.e.b.a.a.C(str, ".immediate") : str;
    }
}

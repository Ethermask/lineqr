package oh.a.q2;

import ka.b.q;
import ka.e.f;
import kotlin.jvm.internal.DefaultConstructorMarker;
import oh.a.o0;
import oh.a.u0;
import oh.a.w1;

public abstract class b extends w1 implements o0 {
    public b() {
    }

    public u0 s(long j, Runnable runnable, f fVar) {
        return q.O1(j, runnable, fVar);
    }

    public b(DefaultConstructorMarker defaultConstructorMarker) {
    }
}

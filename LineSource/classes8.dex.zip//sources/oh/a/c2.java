package oh.a;

import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;

public final class c2<T> extends r1 {

    /* renamed from: e  reason: collision with root package name */
    public final l<T> f58e;

    public c2(l<? super T> lVar) {
        this.f58e = lVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        w((Throwable) obj);
        return Unit.INSTANCE;
    }

    public void w(Throwable th2) {
        Object W = x().W();
        if (W instanceof y) {
            l<T> lVar = this.f58e;
            Throwable th3 = ((y) W).a;
            Result.Companion companion = Result.Companion;
            lVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(th3)));
            return;
        }
        l<T> lVar2 = this.f58e;
        Object a = t1.a(W);
        Result.Companion companion2 = Result.Companion;
        lVar2.resumeWith(Result.constructor-impl(a));
    }
}

package oh.a;

import kotlin.Unit;

public final class w0 extends r1 {

    /* renamed from: e  reason: collision with root package name */
    public final u0 f95e;

    public w0(u0 u0Var) {
        this.f95e = u0Var;
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        this.f95e.dispose();
        return Unit.INSTANCE;
    }

    public void w(Throwable th2) {
        this.f95e.dispose();
    }
}

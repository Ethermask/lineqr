package oh.a;

import java.util.concurrent.CancellationException;

public final class j2 extends CancellationException {
    public final n1 a;

    public j2(String str) {
        super(str);
        this.a = null;
    }

    public j2(String str, n1 n1Var) {
        super(str);
        this.a = n1Var;
    }
}

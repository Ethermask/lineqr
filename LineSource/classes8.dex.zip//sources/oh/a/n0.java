package oh.a;

import ka.e.d;
import ka.e.f;
import ka.e.k.a.c;
import ka.e.k.a.e;

public class n0<T> extends a<T> implements m0<T> {

    @e(c = "kotlinx.coroutines.DeferredCoroutine", f = "Builders.common.kt", l = {101}, m = "await$suspendImpl")
    public static final class a extends c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ n0 c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(n0 n0Var, d dVar) {
            super(dVar);
            this.c = n0Var;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return n0.y0(this.c, this);
        }
    }

    public n0(f fVar, boolean z) {
        super(fVar, z);
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object y0(oh.a.n0 r4, ka.e.d r5) {
        /*
            boolean r0 = r5 instanceof oh.a.n0.a
            if (r0 == 0) goto L_0x0013
            r0 = r5
            oh.a.n0$a r0 = (oh.a.n0.a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.n0$a r0 = new oh.a.n0$a
            r0.<init>(r4, r5)
        L_0x0018:
            java.lang.Object r5 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 1
            if (r2 == 0) goto L_0x002f
            if (r2 != r3) goto L_0x0027
            kotlin.ResultKt.throwOnFailure(r5)
            goto L_0x003b
        L_0x0027:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L_0x002f:
            kotlin.ResultKt.throwOnFailure(r5)
            r0.b = r3
            java.lang.Object r5 = r4.D(r0)
            if (r5 != r1) goto L_0x003b
            return r1
        L_0x003b:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.n0.y0(oh.a.n0, ka.e.d):java.lang.Object");
    }

    public T g() {
        return R();
    }

    public Object r(d<? super T> dVar) {
        return y0(this, dVar);
    }
}

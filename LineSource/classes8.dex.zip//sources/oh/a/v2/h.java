package oh.a.v2;

import ka.b.q;
import ka.e.f;
import mh.c.p;
import oh.a.a;

public final class h<T> extends a<T> {
    public final p<T> d;

    public h(f fVar, p<T> pVar) {
        super(fVar, true);
        this.d = pVar;
    }

    public void u0(Throwable th2, boolean z) {
        try {
            if (!this.d.c(th2)) {
                q.J1(th2, this.b);
            }
        } catch (Throwable th3) {
            q.J1(th3, this.b);
        }
    }

    public void v0(T t) {
        if (t == null) {
            try {
                this.d.a();
            } catch (Throwable th2) {
                q.J1(th2, this.b);
            }
        } else {
            this.d.b(t);
        }
    }
}

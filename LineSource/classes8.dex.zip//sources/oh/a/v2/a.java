package oh.a.v2;

import ka.b.q;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import mh.c.e;
import mh.c.j0.c;
import oh.a.k;

public final class a implements e {
    public final /* synthetic */ k a;

    public a(k kVar) {
        this.a = kVar;
    }

    public void onComplete() {
        k kVar = this.a;
        Unit unit = Unit.INSTANCE;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(unit));
    }

    public void onError(Throwable th2) {
        k kVar = this.a;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(th2)));
    }

    public void onSubscribe(c cVar) {
        q.y0(this.a, cVar);
    }
}

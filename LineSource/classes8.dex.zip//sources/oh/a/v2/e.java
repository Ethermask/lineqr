package oh.a.v2;

import java.util.concurrent.CancellationException;
import ka.b.q;
import mh.c.l0.f;
import oh.a.n1;

public final class e implements f {
    public final n1 a;

    public e(n1 n1Var) {
        this.a = n1Var;
    }

    public void cancel() {
        q.R(this.a, (CancellationException) null, 1, (Object) null);
    }
}

package oh.a.v2;

import kotlin.Result;
import kotlin.ResultKt;
import mh.c.q;
import mh.c.s;
import oh.a.k;

public final class c implements q<T> {
    public final /* synthetic */ k a;
    public final /* synthetic */ Object b;

    public c(k kVar, s sVar, Object obj) {
        this.a = kVar;
        this.b = obj;
    }

    public void onComplete() {
        k kVar = this.a;
        Object obj = this.b;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(obj));
    }

    public void onError(Throwable th2) {
        k kVar = this.a;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(th2)));
    }

    public void onSubscribe(mh.c.j0.c cVar) {
        ka.b.q.y0(this.a, cVar);
    }

    public void onSuccess(T t) {
        k kVar = this.a;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(t));
    }
}

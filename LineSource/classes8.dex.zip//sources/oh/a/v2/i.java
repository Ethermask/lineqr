package oh.a.v2;

import ka.e.f;
import ka.h.b.p;
import mh.c.m0.a.a;
import mh.c.m0.a.c;
import mh.c.m0.e.c.d;
import mh.c.r;
import oh.a.c0;
import oh.a.h0;
import oh.a.i0;

public final class i<T> implements r<T> {
    public final /* synthetic */ h0 a;
    public final /* synthetic */ f b;
    public final /* synthetic */ p c;

    public i(h0 h0Var, f fVar, p pVar) {
        this.a = h0Var;
        this.b = fVar;
        this.c = pVar;
    }

    public final void a(mh.c.p<T> pVar) {
        h hVar = new h(c0.b(this.a, this.b), pVar);
        c.i((d.a) pVar, new a(new e(hVar)));
        hVar.x0(i0.DEFAULT, hVar, this.c);
    }
}

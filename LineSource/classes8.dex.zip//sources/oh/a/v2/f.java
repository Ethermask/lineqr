package oh.a.v2;

import ka.b.q;
import kotlin.Unit;
import mh.c.d;
import oh.a.a;

public final class f extends a<Unit> {
    public final d d;

    public f(ka.e.f fVar, d dVar) {
        super(fVar, true);
        this.d = dVar;
    }

    public void u0(Throwable th2, boolean z) {
        try {
            if (!this.d.c(th2)) {
                q.J1(th2, this.b);
            }
        } catch (Throwable th3) {
            q.J1(th3, this.b);
        }
    }

    public void v0(Object obj) {
        Unit unit = (Unit) obj;
        try {
            this.d.a();
        } catch (Throwable th2) {
            q.J1(th2, this.b);
        }
    }
}

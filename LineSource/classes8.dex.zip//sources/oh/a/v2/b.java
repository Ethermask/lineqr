package oh.a.v2;

import ka.b.q;
import kotlin.Result;
import kotlin.ResultKt;
import mh.c.e0;
import mh.c.j0.c;
import oh.a.k;

public final class b implements e0<T> {
    public final /* synthetic */ k a;

    public b(k kVar) {
        this.a = kVar;
    }

    public void onError(Throwable th2) {
        k kVar = this.a;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(ResultKt.createFailure(th2)));
    }

    public void onSubscribe(c cVar) {
        q.y0(this.a, cVar);
    }

    public void onSuccess(T t) {
        k kVar = this.a;
        Result.Companion companion = Result.Companion;
        kVar.resumeWith(Result.constructor-impl(t));
    }
}

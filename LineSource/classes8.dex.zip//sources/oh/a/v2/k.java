package oh.a.v2;

import ka.e.f;
import ka.h.b.p;
import mh.c.d0;
import mh.c.f0;
import oh.a.c0;
import oh.a.h0;
import oh.a.i0;

public final class k<T> implements f0<T> {
    public final /* synthetic */ h0 a;
    public final /* synthetic */ f b;
    public final /* synthetic */ p c;

    public k(h0 h0Var, f fVar, p pVar) {
        this.a = h0Var;
        this.b = fVar;
        this.c = pVar;
    }

    public final void subscribe(d0<T> d0Var) {
        j jVar = new j(c0.b(this.a, this.b), d0Var);
        d0Var.b(new e(jVar));
        jVar.x0(i0.DEFAULT, jVar, this.c);
    }
}

package oh.a.v2;

import ka.h.b.p;
import mh.c.d;
import mh.c.f;
import mh.c.m0.a.a;
import mh.c.m0.a.c;
import mh.c.m0.e.a.c;
import oh.a.c0;
import oh.a.h0;
import oh.a.i0;

public final class g implements f {
    public final /* synthetic */ h0 a;
    public final /* synthetic */ ka.e.f b;
    public final /* synthetic */ p c;

    public g(h0 h0Var, ka.e.f fVar, p pVar) {
        this.a = h0Var;
        this.b = fVar;
        this.c = pVar;
    }

    public final void a(d dVar) {
        f fVar = new f(c0.b(this.a, this.b), dVar);
        c.i((c.a) dVar, new a(new e(fVar)));
        fVar.x0(i0.DEFAULT, fVar, this.c);
    }
}

package oh.a.v2;

import java.util.concurrent.TimeUnit;
import ka.b.q;
import ka.e.f;
import kotlin.Unit;
import mh.c.a0;
import mh.c.j0.c;
import oh.a.e0;
import oh.a.k;
import oh.a.o0;
import oh.a.u0;

public final class l extends e0 implements o0 {
    public final a0 b;

    public static final class a implements u0 {
        public final /* synthetic */ c a;

        public a(c cVar) {
            this.a = cVar;
        }

        public void dispose() {
            this.a.dispose();
        }
    }

    public static final class b implements Runnable {
        public final /* synthetic */ l a;
        public final /* synthetic */ k b;

        public b(l lVar, k kVar) {
            this.a = lVar;
            this.b = kVar;
        }

        public final void run() {
            this.b.u(this.a, Unit.INSTANCE);
        }
    }

    public l(a0 a0Var) {
        this.b = a0Var;
    }

    public void d(long j, k<? super Unit> kVar) {
        q.y0(kVar, this.b.c(new b(this, kVar), j, TimeUnit.MILLISECONDS));
    }

    public void d0(f fVar, Runnable runnable) {
        this.b.b(runnable);
    }

    public boolean equals(Object obj) {
        return (obj instanceof l) && ((l) obj).b == this.b;
    }

    public int hashCode() {
        return System.identityHashCode(this.b);
    }

    public u0 s(long j, Runnable runnable, f fVar) {
        return new a(this.b.c(runnable, j, TimeUnit.MILLISECONDS));
    }

    public String toString() {
        return this.b.toString();
    }
}

package oh.a.v2;

import ka.h.b.l;
import ka.h.c.r;
import kotlin.Unit;
import mh.c.j0.c;

public final class d extends r implements l<Throwable, Unit> {
    public final /* synthetic */ c a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public d(c cVar) {
        super(1);
        this.a = cVar;
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        this.a.dispose();
        return Unit.INSTANCE;
    }
}

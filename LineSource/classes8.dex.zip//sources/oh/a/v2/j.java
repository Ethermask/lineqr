package oh.a.v2;

import ka.b.q;
import ka.e.f;
import mh.c.d0;
import oh.a.a;

public final class j<T> extends a<T> {
    public final d0<T> d;

    public j(f fVar, d0<T> d0Var) {
        super(fVar, true);
        this.d = d0Var;
    }

    public void u0(Throwable th2, boolean z) {
        try {
            if (!this.d.a(th2)) {
                q.J1(th2, this.b);
            }
        } catch (Throwable th3) {
            q.J1(th3, this.b);
        }
    }

    public void v0(T t) {
        try {
            this.d.onSuccess(t);
        } catch (Throwable th2) {
            q.J1(th2, this.b);
        }
    }
}

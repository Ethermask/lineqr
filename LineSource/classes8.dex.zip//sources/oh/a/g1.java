package oh.a;

import ka.e.f;
import ka.e.h;

public final class g1 implements h0 {
    public static final g1 a = new g1();

    public f getCoroutineContext() {
        return h.a;
    }
}

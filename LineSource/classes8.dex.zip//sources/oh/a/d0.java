package oh.a;

import ka.e.f;
import ka.h.b.l;
import ka.h.c.r;

public final class d0 extends r implements l<f.a, e0> {
    public static final d0 a = new d0();

    public d0() {
        super(1);
    }

    public Object invoke(Object obj) {
        f.a aVar = (f.a) obj;
        if (!(aVar instanceof e0)) {
            aVar = null;
        }
        return (e0) aVar;
    }
}

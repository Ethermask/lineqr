package oh.a;

public interface z1 {
}

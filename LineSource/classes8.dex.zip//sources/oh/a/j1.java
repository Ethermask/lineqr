package oh.a;

public final class j1 {
    public final i1 a;

    public j1(i1 i1Var) {
        this.a = i1Var;
    }
}

package oh.a.x2;

public final class f extends h {
    public static final f a = new f();
}

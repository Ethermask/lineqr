package oh.a.x2;

import ka.b.q;
import oh.a.e0;
import oh.a.t2.w;

public final class b extends c {
    public static final e0 g;
    public static final b h;

    static {
        b bVar = new b();
        h = bVar;
        int i = w.a;
        g = new e(bVar, q.v3("kotlinx.coroutines.io.parallelism", 64 < i ? i : 64, 0, 0, 12, (Object) null), "Dispatchers.IO", 1);
    }

    public b() {
        super(0, 0, (String) null, 7);
    }

    public void close() {
        throw new UnsupportedOperationException("Dispatchers.Default cannot be closed");
    }

    public String toString() {
        return "Dispatchers.Default";
    }
}

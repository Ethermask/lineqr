package oh.a.x2;

public abstract class h {
}

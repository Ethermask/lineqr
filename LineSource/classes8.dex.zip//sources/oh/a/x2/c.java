package oh.a.x2;

import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import ka.e.f;
import oh.a.d1;
import oh.a.k0;

public class c extends d1 {
    public a b;
    public final int c;
    public final int d;

    /* renamed from: e  reason: collision with root package name */
    public final long f100e;
    public final String f;

    public c(int i, int i2, String str, int i3) {
        i = (i3 & 1) != 0 ? l.b : i;
        i2 = (i3 & 2) != 0 ? l.c : i2;
        String str2 = (i3 & 4) != 0 ? "DefaultDispatcher" : null;
        long j = l.d;
        this.c = i;
        this.d = i2;
        this.f100e = j;
        this.f = str2;
        this.b = new a(this.c, this.d, this.f100e, this.f);
    }

    public void d0(f fVar, Runnable runnable) {
        try {
            a.g(this.b, runnable, (j) null, false, 6);
        } catch (RejectedExecutionException unused) {
            k0.h.z0(runnable);
        }
    }

    public void e0(f fVar, Runnable runnable) {
        try {
            a.g(this.b, runnable, (j) null, true, 2);
        } catch (RejectedExecutionException unused) {
            k0.h.z0(runnable);
        }
    }

    public Executor h0() {
        return this.b;
    }
}

package oh.a.x2;

public interface j {
    void W();

    int X();
}

package oh.a.x2;

import oh.a.t2.m;

public final class d extends m<i> {
    public d() {
        super(false);
    }
}

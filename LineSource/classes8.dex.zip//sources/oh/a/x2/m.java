package oh.a.x2;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public final class m {
    public static final /* synthetic */ AtomicReferenceFieldUpdater b;
    public static final /* synthetic */ AtomicIntegerFieldUpdater c;
    public static final /* synthetic */ AtomicIntegerFieldUpdater d;

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f103e;
    public final AtomicReferenceArray<i> a = new AtomicReferenceArray<>(128);
    public volatile /* synthetic */ int blockingTasksInBuffer = 0;
    public volatile /* synthetic */ int consumerIndex = 0;
    public volatile /* synthetic */ Object lastScheduledTask = null;
    public volatile /* synthetic */ int producerIndex = 0;

    static {
        Class<m> cls = m.class;
        b = AtomicReferenceFieldUpdater.newUpdater(cls, Object.class, "lastScheduledTask");
        c = AtomicIntegerFieldUpdater.newUpdater(cls, "producerIndex");
        d = AtomicIntegerFieldUpdater.newUpdater(cls, "consumerIndex");
        f103e = AtomicIntegerFieldUpdater.newUpdater(cls, "blockingTasksInBuffer");
    }

    public final i a(i iVar, boolean z) {
        if (z) {
            return b(iVar);
        }
        i iVar2 = (i) b.getAndSet(this, iVar);
        if (iVar2 != null) {
            return b(iVar2);
        }
        return null;
    }

    public final i b(i iVar) {
        boolean z = true;
        if (iVar.b.X() != 1) {
            z = false;
        }
        if (z) {
            f103e.incrementAndGet(this);
        }
        if (c() == 127) {
            return iVar;
        }
        int i = this.producerIndex & 127;
        while (this.a.get(i) != null) {
            Thread.yield();
        }
        this.a.lazySet(i, iVar);
        c.incrementAndGet(this);
        return null;
    }

    public final int c() {
        return this.producerIndex - this.consumerIndex;
    }

    public final int d() {
        return this.lastScheduledTask != null ? c() + 1 : c();
    }

    public final i e() {
        i iVar = (i) b.getAndSet(this, (Object) null);
        return iVar != null ? iVar : f();
    }

    public final i f() {
        i andSet;
        while (true) {
            int i = this.consumerIndex;
            if (i - this.producerIndex == 0) {
                return null;
            }
            int i2 = i & 127;
            if (d.compareAndSet(this, i, i + 1) && (andSet = this.a.getAndSet(i2, (Object) null)) != null) {
                boolean z = true;
                if (andSet.b.X() != 1) {
                    z = false;
                }
                if (z) {
                    f103e.decrementAndGet(this);
                }
                return andSet;
            }
        }
    }

    public final long g(m mVar, boolean z) {
        i iVar;
        do {
            iVar = (i) mVar.lastScheduledTask;
            if (iVar == null) {
                return -2;
            }
            if (z) {
                boolean z2 = true;
                if (iVar.b.X() != 1) {
                    z2 = false;
                }
                if (!z2) {
                    return -2;
                }
            }
            if (((f) l.f102e) != null) {
                long nanoTime = System.nanoTime() - iVar.a;
                long j = l.a;
                if (nanoTime < j) {
                    return j - nanoTime;
                }
            } else {
                throw null;
            }
        } while (!b.compareAndSet(mVar, iVar, (Object) null));
        a(iVar, false);
        return -1;
    }
}

package oh.a.x2;

public final class g implements j {
    public static final g a = new g();

    public void W() {
    }

    public int X() {
        return 0;
    }
}

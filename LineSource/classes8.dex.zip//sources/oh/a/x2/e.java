package oh.a.x2;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import ka.e.f;
import oh.a.d1;
import oh.a.k0;

public final class e extends d1 implements j, Executor {
    public static final /* synthetic */ AtomicIntegerFieldUpdater g = AtomicIntegerFieldUpdater.newUpdater(e.class, "inFlightTasks");
    public final ConcurrentLinkedQueue<Runnable> b = new ConcurrentLinkedQueue<>();
    public final c c;
    public final int d;

    /* renamed from: e  reason: collision with root package name */
    public final String f101e;
    public final int f;
    public volatile /* synthetic */ int inFlightTasks = 0;

    public e(c cVar, int i, String str, int i2) {
        this.c = cVar;
        this.d = i;
        this.f101e = str;
        this.f = i2;
    }

    public void W() {
        Runnable poll = this.b.poll();
        if (poll != null) {
            c cVar = this.c;
            if (cVar != null) {
                try {
                    cVar.b.d(poll, this, true);
                } catch (RejectedExecutionException unused) {
                    k0.h.z0(cVar.b.b(poll, this));
                }
            } else {
                throw null;
            }
        } else {
            g.decrementAndGet(this);
            Runnable poll2 = this.b.poll();
            if (poll2 != null) {
                i0(poll2, true);
            }
        }
    }

    public int X() {
        return this.f;
    }

    public void close() {
        throw new IllegalStateException("Close cannot be invoked on LimitingBlockingDispatcher".toString());
    }

    public void d0(f fVar, Runnable runnable) {
        i0(runnable, false);
    }

    public void e0(f fVar, Runnable runnable) {
        i0(runnable, true);
    }

    public void execute(Runnable runnable) {
        i0(runnable, false);
    }

    public Executor h0() {
        return this;
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x0022  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void i0(java.lang.Runnable r3, boolean r4) {
        /*
            r2 = this;
        L_0x0000:
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r0 = g
            int r0 = r0.incrementAndGet(r2)
            int r1 = r2.d
            if (r0 > r1) goto L_0x0022
            oh.a.x2.c r0 = r2.c
            if (r0 == 0) goto L_0x0020
            oh.a.x2.a r1 = r0.b     // Catch:{ RejectedExecutionException -> 0x0014 }
            r1.d(r3, r2, r4)     // Catch:{ RejectedExecutionException -> 0x0014 }
            goto L_0x001f
        L_0x0014:
            oh.a.k0 r4 = oh.a.k0.h
            oh.a.x2.a r0 = r0.b
            oh.a.x2.i r3 = r0.b(r3, r2)
            r4.z0(r3)
        L_0x001f:
            return
        L_0x0020:
            r3 = 0
            throw r3
        L_0x0022:
            java.util.concurrent.ConcurrentLinkedQueue<java.lang.Runnable> r0 = r2.b
            r0.add(r3)
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r3 = g
            int r3 = r3.decrementAndGet(r2)
            int r0 = r2.d
            if (r3 < r0) goto L_0x0032
            return
        L_0x0032:
            java.util.concurrent.ConcurrentLinkedQueue<java.lang.Runnable> r3 = r2.b
            java.lang.Object r3 = r3.poll()
            java.lang.Runnable r3 = (java.lang.Runnable) r3
            if (r3 == 0) goto L_0x003d
            goto L_0x0000
        L_0x003d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.x2.e.i0(java.lang.Runnable, boolean):void");
    }

    public String toString() {
        String str = this.f101e;
        if (str != null) {
            return str;
        }
        return super.toString() + "[dispatcher = " + this.c + ']';
    }
}

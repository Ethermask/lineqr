package oh.a.x2;

public abstract class i implements Runnable {
    public long a;
    public j b;

    public i(long j, j jVar) {
        this.a = j;
        this.b = jVar;
    }

    public i() {
        g gVar = g.a;
        this.a = 0;
        this.b = gVar;
    }
}

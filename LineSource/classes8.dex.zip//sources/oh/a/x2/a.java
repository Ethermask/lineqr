package oh.a.x2;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.locks.LockSupport;
import ka.b.q;
import ka.h.c.p;
import ka.j.c;
import kotlin.Unit;
import oh.a.t2.v;

public final class a implements Executor, Closeable {
    public static final /* synthetic */ AtomicLongFieldUpdater h = AtomicLongFieldUpdater.newUpdater(a.class, "parkedWorkersStack");
    public static final /* synthetic */ AtomicLongFieldUpdater i = AtomicLongFieldUpdater.newUpdater(a.class, "controlState");
    public static final /* synthetic */ AtomicIntegerFieldUpdater j = AtomicIntegerFieldUpdater.newUpdater(a.class, "_isTerminated");
    public static final v k = new v("NOT_IN_STACK");
    public volatile /* synthetic */ int _isTerminated;
    public final d a;
    public final d b;
    public final AtomicReferenceArray<C0008a> c;
    public volatile /* synthetic */ long controlState;
    public final int d;

    /* renamed from: e  reason: collision with root package name */
    public final int f98e;
    public final long f;
    public final String g;
    public volatile /* synthetic */ long parkedWorkersStack;

    /* renamed from: oh.a.x2.a$a  reason: collision with other inner class name */
    public final class C0008a extends Thread {
        public static final /* synthetic */ AtomicIntegerFieldUpdater h = AtomicIntegerFieldUpdater.newUpdater(C0008a.class, "workerCtl");
        public final m a = new m();
        public b b = b.DORMANT;
        public long c;
        public long d;

        /* renamed from: e  reason: collision with root package name */
        public int f99e = c.b.b();
        public boolean f;
        public volatile int indexInArray;
        public volatile Object nextParkedWorker = a.k;
        public volatile /* synthetic */ int workerCtl = 0;

        public C0008a(int i) {
            setDaemon(true);
            d(i);
        }

        /* JADX WARNING: Removed duplicated region for block: B:14:0x0037  */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x006e  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final oh.a.x2.i a(boolean r11) {
            /*
                r10 = this;
                oh.a.x2.a$b r0 = r10.b
                oh.a.x2.a$b r1 = oh.a.x2.a.b.CPU_ACQUIRED
                r2 = 0
                r3 = 1
                if (r0 != r1) goto L_0x0009
                goto L_0x0032
            L_0x0009:
                oh.a.x2.a r0 = oh.a.x2.a.this
            L_0x000b:
                long r6 = r0.controlState
                r4 = 9223367638808264704(0x7ffffc0000000000, double:NaN)
                long r4 = r4 & r6
                r1 = 42
                long r4 = r4 >> r1
                int r1 = (int) r4
                if (r1 != 0) goto L_0x001b
                r0 = r2
                goto L_0x002c
            L_0x001b:
                r4 = 4398046511104(0x40000000000, double:2.1729236899484E-311)
                long r8 = r6 - r4
                java.util.concurrent.atomic.AtomicLongFieldUpdater r4 = oh.a.x2.a.i
                r5 = r0
                boolean r1 = r4.compareAndSet(r5, r6, r8)
                if (r1 == 0) goto L_0x000b
                r0 = r3
            L_0x002c:
                if (r0 == 0) goto L_0x0034
                oh.a.x2.a$b r0 = oh.a.x2.a.b.CPU_ACQUIRED
                r10.b = r0
            L_0x0032:
                r0 = r3
                goto L_0x0035
            L_0x0034:
                r0 = r2
            L_0x0035:
                if (r0 == 0) goto L_0x006e
                if (r11 == 0) goto L_0x0062
                oh.a.x2.a r11 = oh.a.x2.a.this
                int r11 = r11.d
                int r11 = r11 * 2
                int r11 = r10.b(r11)
                if (r11 != 0) goto L_0x0046
                goto L_0x0047
            L_0x0046:
                r3 = r2
            L_0x0047:
                if (r3 == 0) goto L_0x0050
                oh.a.x2.i r11 = r10.c()
                if (r11 == 0) goto L_0x0050
                goto L_0x006d
            L_0x0050:
                oh.a.x2.m r11 = r10.a
                oh.a.x2.i r11 = r11.e()
                if (r11 == 0) goto L_0x0059
                goto L_0x006d
            L_0x0059:
                if (r3 != 0) goto L_0x0069
                oh.a.x2.i r11 = r10.c()
                if (r11 == 0) goto L_0x0069
                goto L_0x006d
            L_0x0062:
                oh.a.x2.i r11 = r10.c()
                if (r11 == 0) goto L_0x0069
                goto L_0x006d
            L_0x0069:
                oh.a.x2.i r11 = r10.f(r2)
            L_0x006d:
                return r11
            L_0x006e:
                if (r11 == 0) goto L_0x0084
                oh.a.x2.m r11 = r10.a
                oh.a.x2.i r11 = r11.e()
                if (r11 == 0) goto L_0x0079
                goto L_0x008e
            L_0x0079:
                oh.a.x2.a r11 = oh.a.x2.a.this
                oh.a.x2.d r11 = r11.b
                java.lang.Object r11 = r11.d()
                oh.a.x2.i r11 = (oh.a.x2.i) r11
                goto L_0x008e
            L_0x0084:
                oh.a.x2.a r11 = oh.a.x2.a.this
                oh.a.x2.d r11 = r11.b
                java.lang.Object r11 = r11.d()
                oh.a.x2.i r11 = (oh.a.x2.i) r11
            L_0x008e:
                if (r11 == 0) goto L_0x0091
                goto L_0x0095
            L_0x0091:
                oh.a.x2.i r11 = r10.f(r3)
            L_0x0095:
                return r11
            */
            throw new UnsupportedOperationException("Method not decompiled: oh.a.x2.a.C0008a.a(boolean):oh.a.x2.i");
        }

        public final int b(int i) {
            int i2 = this.f99e;
            int i3 = i2 ^ (i2 << 13);
            int i4 = i3 ^ (i3 >> 17);
            int i5 = i4 ^ (i4 << 5);
            this.f99e = i5;
            int i6 = i - 1;
            if ((i6 & i) == 0) {
                return i5 & i6;
            }
            return (i5 & Integer.MAX_VALUE) % i;
        }

        public final i c() {
            if (b(2) == 0) {
                i iVar = (i) a.this.a.d();
                if (iVar != null) {
                    return iVar;
                }
                return (i) a.this.b.d();
            }
            i iVar2 = (i) a.this.b.d();
            if (iVar2 != null) {
                return iVar2;
            }
            return (i) a.this.a.d();
        }

        public final void d(int i) {
            StringBuilder sb = new StringBuilder();
            sb.append(a.this.g);
            sb.append("-worker-");
            sb.append(i == 0 ? "TERMINATED" : String.valueOf(i));
            setName(sb.toString());
            this.indexInArray = i;
        }

        public final boolean e(b bVar) {
            b bVar2 = this.b;
            boolean z = bVar2 == b.CPU_ACQUIRED;
            if (z) {
                a.i.addAndGet(a.this, 4398046511104L);
            }
            if (bVar2 != bVar) {
                this.b = bVar;
            }
            return z;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:29:0x0070, code lost:
            r4 = r4.g(r5, true);
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final oh.a.x2.i f(boolean r17) {
            /*
                r16 = this;
                r0 = r16
                oh.a.x2.a r1 = oh.a.x2.a.this
                long r1 = r1.controlState
                r3 = 2097151(0x1fffff, double:1.0361303E-317)
                long r1 = r1 & r3
                int r1 = (int) r1
                r2 = 2
                r3 = 0
                if (r1 >= r2) goto L_0x0010
                return r3
            L_0x0010:
                int r2 = r0.b(r1)
                r7 = 0
                r8 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
            L_0x001a:
                if (r7 >= r1) goto L_0x00ad
                r12 = 1
                int r2 = r2 + r12
                if (r2 <= r1) goto L_0x0021
                r2 = r12
            L_0x0021:
                oh.a.x2.a r13 = oh.a.x2.a.this
                java.util.concurrent.atomic.AtomicReferenceArray<oh.a.x2.a$a> r13 = r13.c
                java.lang.Object r13 = r13.get(r2)
                oh.a.x2.a$a r13 = (oh.a.x2.a.C0008a) r13
                if (r13 == 0) goto L_0x00a8
                if (r13 == r0) goto L_0x00a8
                if (r17 == 0) goto L_0x0077
                oh.a.x2.m r4 = r0.a
                oh.a.x2.m r5 = r13.a
                if (r4 == 0) goto L_0x0076
                int r13 = r5.consumerIndex
                int r10 = r5.producerIndex
                java.util.concurrent.atomic.AtomicReferenceArray<oh.a.x2.i> r11 = r5.a
            L_0x003d:
                if (r13 == r10) goto L_0x0070
                r14 = r13 & 127(0x7f, float:1.78E-43)
                int r15 = r5.blockingTasksInBuffer
                if (r15 != 0) goto L_0x0046
                goto L_0x0070
            L_0x0046:
                java.lang.Object r15 = r11.get(r14)
                oh.a.x2.i r15 = (oh.a.x2.i) r15
                if (r15 == 0) goto L_0x006d
                oh.a.x2.j r6 = r15.b
                int r6 = r6.X()
                if (r6 != r12) goto L_0x0058
                r6 = r12
                goto L_0x0059
            L_0x0058:
                r6 = 0
            L_0x0059:
                if (r6 == 0) goto L_0x006d
                boolean r6 = r11.compareAndSet(r14, r15, r3)
                if (r6 == 0) goto L_0x006d
                java.util.concurrent.atomic.AtomicIntegerFieldUpdater r6 = oh.a.x2.m.f103e
                r6.decrementAndGet(r5)
                r5 = 0
                r4.a(r15, r5)
                r4 = -1
                goto L_0x0074
            L_0x006d:
                int r13 = r13 + 1
                goto L_0x003d
            L_0x0070:
                long r4 = r4.g(r5, r12)
            L_0x0074:
                r10 = 0
                goto L_0x008f
            L_0x0076:
                throw r3
            L_0x0077:
                oh.a.x2.m r4 = r0.a
                oh.a.x2.m r5 = r13.a
                if (r4 == 0) goto L_0x00a7
                oh.a.x2.i r6 = r5.f()
                if (r6 == 0) goto L_0x008a
                r10 = 0
                r4.a(r6, r10)
                r4 = -1
                goto L_0x008f
            L_0x008a:
                r10 = 0
                long r4 = r4.g(r5, r10)
            L_0x008f:
                r11 = -1
                int r6 = (r4 > r11 ? 1 : (r4 == r11 ? 0 : -1))
                if (r6 != 0) goto L_0x009c
                oh.a.x2.m r1 = r0.a
                oh.a.x2.i r1 = r1.e()
                return r1
            L_0x009c:
                r11 = 0
                int r6 = (r4 > r11 ? 1 : (r4 == r11 ? 0 : -1))
                if (r6 <= 0) goto L_0x00a9
                long r8 = java.lang.Math.min(r8, r4)
                goto L_0x00a9
            L_0x00a7:
                throw r3
            L_0x00a8:
                r10 = 0
            L_0x00a9:
                int r7 = r7 + 1
                goto L_0x001a
            L_0x00ad:
                r4 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
                r11 = 0
                int r1 = (r8 > r4 ? 1 : (r8 == r4 ? 0 : -1))
                if (r1 == 0) goto L_0x00b9
                goto L_0x00ba
            L_0x00b9:
                r8 = r11
            L_0x00ba:
                r0.d = r8
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: oh.a.x2.a.C0008a.f(boolean):oh.a.x2.i");
        }

        public void run() {
            loop0:
            while (true) {
                boolean z = false;
                while (a.this._isTerminated == 0 && this.b != b.TERMINATED) {
                    i a2 = a(this.f);
                    long j = -2097152;
                    if (a2 == null) {
                        this.f = false;
                        if (this.d == 0) {
                            if (this.nextParkedWorker != a.k) {
                                this.workerCtl = -1;
                                while (true) {
                                    if (!(this.nextParkedWorker != a.k) || this.workerCtl != -1 || a.this._isTerminated != 0 || this.b == b.TERMINATED) {
                                        break;
                                    }
                                    e(b.PARKING);
                                    Thread.interrupted();
                                    if (this.c == 0) {
                                        this.c = System.nanoTime() + a.this.f;
                                    }
                                    LockSupport.parkNanos(a.this.f);
                                    if (System.nanoTime() - this.c >= 0) {
                                        this.c = 0;
                                        synchronized (a.this.c) {
                                            if (a.this._isTerminated == 0) {
                                                if (((int) (a.this.controlState & 2097151)) > a.this.d) {
                                                    if (h.compareAndSet(this, -1, 1)) {
                                                        int i = this.indexInArray;
                                                        d(0);
                                                        a.this.i(this, i, 0);
                                                        int andDecrement = (int) (a.i.getAndDecrement(a.this) & 2097151);
                                                        if (andDecrement != i) {
                                                            C0008a aVar = a.this.c.get(andDecrement);
                                                            p.c(aVar);
                                                            C0008a aVar2 = aVar;
                                                            a.this.c.set(i, aVar2);
                                                            aVar2.d(i);
                                                            a.this.i(aVar2, andDecrement, i);
                                                        }
                                                        a.this.c.set(andDecrement, (Object) null);
                                                        Unit unit = Unit.INSTANCE;
                                                        this.b = b.TERMINATED;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                a aVar3 = a.this;
                                if (aVar3 == null) {
                                    throw null;
                                } else if (this.nextParkedWorker == a.k) {
                                    while (true) {
                                        long j2 = aVar3.parkedWorkersStack;
                                        int i2 = this.indexInArray;
                                        this.nextParkedWorker = aVar3.c.get((int) (j2 & 2097151));
                                        if (a.h.compareAndSet(aVar3, j2, ((2097152 + j2) & j) | ((long) i2))) {
                                            break;
                                        }
                                        j = -2097152;
                                    }
                                }
                            }
                        } else if (!z) {
                            z = true;
                        } else {
                            e(b.PARKING);
                            Thread.interrupted();
                            LockSupport.parkNanos(this.d);
                            this.d = 0;
                        }
                    } else {
                        this.d = 0;
                        int X = a2.b.X();
                        this.c = 0;
                        if (this.b == b.PARKING) {
                            this.b = b.BLOCKING;
                        }
                        if (X != 0 && e(b.BLOCKING)) {
                            a.this.k();
                        }
                        a.this.j(a2);
                        if (X != 0) {
                            a.i.addAndGet(a.this, -2097152);
                            if (this.b != b.TERMINATED) {
                                this.b = b.DORMANT;
                            }
                        }
                    }
                }
            }
            e(b.TERMINATED);
        }
    }

    public enum b {
        CPU_ACQUIRED,
        BLOCKING,
        PARKING,
        DORMANT,
        TERMINATED
    }

    public a(int i2, int i3, long j2, String str) {
        this.d = i2;
        this.f98e = i3;
        this.f = j2;
        this.g = str;
        if (i2 >= 1) {
            if (this.f98e >= this.d) {
                if (this.f98e <= 2097150) {
                    if (this.f > 0) {
                        this.a = new d();
                        this.b = new d();
                        this.parkedWorkersStack = 0;
                        this.c = new AtomicReferenceArray<>(this.f98e + 1);
                        this.controlState = ((long) this.d) << 42;
                        this._isTerminated = 0;
                        return;
                    }
                    throw new IllegalArgumentException(e.e.b.a.a.b0(e.e.b.a.a.V0("Idle worker keep alive time "), this.f, " must be positive").toString());
                }
                throw new IllegalArgumentException(e.e.b.a.a.a0(e.e.b.a.a.V0("Max pool size "), this.f98e, " should not exceed maximal supported number of threads 2097150").toString());
            }
            StringBuilder V0 = e.e.b.a.a.V0("Max pool size ");
            V0.append(this.f98e);
            V0.append(" should be greater than or equals to core pool size ");
            V0.append(this.d);
            throw new IllegalArgumentException(V0.toString().toString());
        }
        throw new IllegalArgumentException(e.e.b.a.a.a0(e.e.b.a.a.V0("Core pool size "), this.d, " should be at least 1").toString());
    }

    public static /* synthetic */ void g(a aVar, Runnable runnable, j jVar, boolean z, int i2) {
        g gVar = (i2 & 2) != 0 ? g.a : null;
        if ((i2 & 4) != 0) {
            z = false;
        }
        aVar.d(runnable, gVar, z);
    }

    public final int a() {
        synchronized (this.c) {
            if (this._isTerminated != 0) {
                return -1;
            }
            long j2 = this.controlState;
            int i2 = (int) (j2 & 2097151);
            int i3 = i2 - ((int) ((j2 & 4398044413952L) >> 21));
            boolean z = false;
            if (i3 < 0) {
                i3 = 0;
            }
            if (i3 >= this.d) {
                return 0;
            }
            if (i2 >= this.f98e) {
                return 0;
            }
            int i4 = ((int) (this.controlState & 2097151)) + 1;
            if (i4 > 0 && this.c.get(i4) == null) {
                C0008a aVar = new C0008a(i4);
                this.c.set(i4, aVar);
                if (i4 == ((int) (2097151 & i.incrementAndGet(this)))) {
                    z = true;
                }
                if (z) {
                    aVar.start();
                    int i5 = i3 + 1;
                    return i5;
                }
                throw new IllegalArgumentException("Failed requirement.".toString());
            }
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
    }

    public final i b(Runnable runnable, j jVar) {
        if (((f) l.f102e) != null) {
            long nanoTime = System.nanoTime();
            if (!(runnable instanceof i)) {
                return new k(runnable, nanoTime, jVar);
            }
            i iVar = (i) runnable;
            iVar.a = nanoTime;
            iVar.b = jVar;
            return iVar;
        }
        throw null;
    }

    public final C0008a c() {
        Thread currentThread = Thread.currentThread();
        if (!(currentThread instanceof C0008a)) {
            currentThread = null;
        }
        C0008a aVar = (C0008a) currentThread;
        if (aVar == null || !p.b(a.this, this)) {
            return null;
        }
        return aVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0073, code lost:
        if (r1 != null) goto L_0x007e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void close() {
        /*
            r9 = this;
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r0 = j
            r1 = 0
            r2 = 1
            boolean r0 = r0.compareAndSet(r9, r1, r2)
            if (r0 != 0) goto L_0x000c
            goto L_0x009c
        L_0x000c:
            oh.a.x2.a$a r0 = r9.c()
            java.util.concurrent.atomic.AtomicReferenceArray<oh.a.x2.a$a> r3 = r9.c
            monitor-enter(r3)
            long r4 = r9.controlState     // Catch:{ all -> 0x009d }
            r6 = 2097151(0x1fffff, double:1.0361303E-317)
            long r4 = r4 & r6
            int r4 = (int) r4
            monitor-exit(r3)
            if (r2 > r4) goto L_0x0063
            r3 = r2
        L_0x001e:
            java.util.concurrent.atomic.AtomicReferenceArray<oh.a.x2.a$a> r5 = r9.c
            java.lang.Object r5 = r5.get(r3)
            ka.h.c.p.c(r5)
            oh.a.x2.a$a r5 = (oh.a.x2.a.C0008a) r5
            if (r5 == r0) goto L_0x005e
        L_0x002b:
            boolean r6 = r5.isAlive()
            if (r6 == 0) goto L_0x003a
            java.util.concurrent.locks.LockSupport.unpark(r5)
            r6 = 10000(0x2710, double:4.9407E-320)
            r5.join(r6)
            goto L_0x002b
        L_0x003a:
            oh.a.x2.m r5 = r5.a
            oh.a.x2.d r6 = r9.b
            r7 = 0
            if (r5 == 0) goto L_0x005d
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r8 = oh.a.x2.m.b
            java.lang.Object r7 = r8.getAndSet(r5, r7)
            oh.a.x2.i r7 = (oh.a.x2.i) r7
            if (r7 == 0) goto L_0x004e
            r6.a(r7)
        L_0x004e:
            oh.a.x2.i r7 = r5.f()
            if (r7 == 0) goto L_0x0059
            r6.a(r7)
            r7 = r2
            goto L_0x005a
        L_0x0059:
            r7 = r1
        L_0x005a:
            if (r7 == 0) goto L_0x005e
            goto L_0x004e
        L_0x005d:
            throw r7
        L_0x005e:
            if (r3 == r4) goto L_0x0063
            int r3 = r3 + 1
            goto L_0x001e
        L_0x0063:
            oh.a.x2.d r1 = r9.b
            r1.b()
            oh.a.x2.d r1 = r9.a
            r1.b()
        L_0x006d:
            if (r0 == 0) goto L_0x0076
            oh.a.x2.i r1 = r0.a(r2)
            if (r1 == 0) goto L_0x0076
            goto L_0x007e
        L_0x0076:
            oh.a.x2.d r1 = r9.a
            java.lang.Object r1 = r1.d()
            oh.a.x2.i r1 = (oh.a.x2.i) r1
        L_0x007e:
            if (r1 == 0) goto L_0x0081
            goto L_0x0089
        L_0x0081:
            oh.a.x2.d r1 = r9.b
            java.lang.Object r1 = r1.d()
            oh.a.x2.i r1 = (oh.a.x2.i) r1
        L_0x0089:
            if (r1 == 0) goto L_0x008f
            r9.j(r1)
            goto L_0x006d
        L_0x008f:
            if (r0 == 0) goto L_0x0096
            oh.a.x2.a$b r1 = oh.a.x2.a.b.TERMINATED
            r0.e(r1)
        L_0x0096:
            r0 = 0
            r9.parkedWorkersStack = r0
            r9.controlState = r0
        L_0x009c:
            return
        L_0x009d:
            r0 = move-exception
            monitor-exit(r3)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.x2.a.close():void");
    }

    public final void d(Runnable runnable, j jVar, boolean z) {
        i iVar;
        boolean z2;
        i b2 = b(runnable, jVar);
        C0008a c2 = c();
        boolean z3 = true;
        if (c2 == null || c2.b == b.TERMINATED || (b2.b.X() == 0 && c2.b == b.BLOCKING)) {
            iVar = b2;
        } else {
            c2.f = true;
            iVar = c2.a.a(b2, z);
        }
        if (iVar != null) {
            if (iVar.b.X() == 1) {
                z2 = this.b.a(iVar);
            } else {
                z2 = this.a.a(iVar);
            }
            if (!z2) {
                throw new RejectedExecutionException(e.e.b.a.a.t0(new StringBuilder(), this.g, " was terminated"));
            }
        }
        if (!z || c2 == null) {
            z3 = false;
        }
        if (b2.b.X() != 0) {
            long addAndGet = i.addAndGet(this, 2097152);
            if (!z3 && !s() && !r(addAndGet)) {
                s();
            }
        } else if (!z3) {
            k();
        }
    }

    public void execute(Runnable runnable) {
        g(this, runnable, (j) null, false, 6);
    }

    public final int h(C0008a aVar) {
        Object obj = aVar.nextParkedWorker;
        while (obj != k) {
            if (obj == null) {
                return 0;
            }
            C0008a aVar2 = (C0008a) obj;
            int i2 = aVar2.indexInArray;
            if (i2 != 0) {
                return i2;
            }
            obj = aVar2.nextParkedWorker;
        }
        return -1;
    }

    public final void i(C0008a aVar, int i2, int i3) {
        while (true) {
            long j2 = this.parkedWorkersStack;
            int i4 = (int) (2097151 & j2);
            long j3 = (2097152 + j2) & -2097152;
            if (i4 == i2) {
                i4 = i3 == 0 ? h(aVar) : i3;
            }
            if (i4 >= 0) {
                if (h.compareAndSet(this, j2, j3 | ((long) i4))) {
                    return;
                }
            }
        }
    }

    public final void j(i iVar) {
        try {
            iVar.run();
        } catch (Throwable th2) {
            Thread currentThread = Thread.currentThread();
            currentThread.getUncaughtExceptionHandler().uncaughtException(currentThread, th2);
        }
    }

    public final void k() {
        if (!s() && !r(this.controlState)) {
            s();
        }
    }

    public final boolean r(long j2) {
        int i2 = ((int) (2097151 & j2)) - ((int) ((j2 & 4398044413952L) >> 21));
        if (i2 < 0) {
            i2 = 0;
        }
        if (i2 < this.d) {
            int a2 = a();
            if (a2 == 1 && this.d > 1) {
                a();
            }
            if (a2 > 0) {
                return true;
            }
        }
        return false;
    }

    public final boolean s() {
        while (true) {
            long j2 = this.parkedWorkersStack;
            C0008a aVar = this.c.get((int) (2097151 & j2));
            if (aVar != null) {
                long j3 = (2097152 + j2) & -2097152;
                int h2 = h(aVar);
                if (h2 < 0) {
                    continue;
                } else {
                    if (h.compareAndSet(this, j2, ((long) h2) | j3)) {
                        aVar.nextParkedWorker = k;
                    } else {
                        continue;
                    }
                }
            } else {
                aVar = null;
            }
            if (aVar == null) {
                return false;
            }
            if (C0008a.h.compareAndSet(aVar, -1, 0)) {
                LockSupport.unpark(aVar);
                return true;
            }
        }
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        int length = this.c.length();
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 1; i7 < length; i7++) {
            C0008a aVar = this.c.get(i7);
            if (aVar != null) {
                int d2 = aVar.a.d();
                int ordinal = aVar.b.ordinal();
                if (ordinal == 0) {
                    i2++;
                    arrayList.add(String.valueOf(d2) + "c");
                } else if (ordinal == 1) {
                    i3++;
                    arrayList.add(String.valueOf(d2) + "b");
                } else if (ordinal == 2) {
                    i4++;
                } else if (ordinal == 3) {
                    i5++;
                    if (d2 > 0) {
                        arrayList.add(String.valueOf(d2) + "d");
                    }
                } else if (ordinal == 4) {
                    i6++;
                }
            }
        }
        long j2 = this.controlState;
        StringBuilder sb = new StringBuilder();
        sb.append(this.g);
        sb.append('@');
        sb.append(q.q1(this));
        sb.append('[');
        sb.append("Pool Size {");
        sb.append("core = ");
        e.e.b.a.a.J2(sb, this.d, ", ", "max = ");
        e.e.b.a.a.K2(sb, this.f98e, "}, ", "Worker States {", "CPU = ");
        sb.append(i2);
        sb.append(", ");
        sb.append("blocking = ");
        sb.append(i3);
        sb.append(", ");
        sb.append("parked = ");
        sb.append(i4);
        sb.append(", ");
        sb.append("dormant = ");
        sb.append(i5);
        sb.append(", ");
        sb.append("terminated = ");
        sb.append(i6);
        sb.append("}, ");
        sb.append("running workers queues = ");
        sb.append(arrayList);
        sb.append(", ");
        sb.append("global CPU queue size = ");
        sb.append(this.a.c());
        sb.append(", ");
        sb.append("global blocking queue size = ");
        sb.append(this.b.c());
        sb.append(", ");
        sb.append("Control State {");
        sb.append("created workers= ");
        e.e.b.a.a.J2(sb, (int) (2097151 & j2), ", ", "blocking tasks = ");
        e.e.b.a.a.J2(sb, (int) ((4398044413952L & j2) >> 21), ", ", "CPUs acquired = ");
        sb.append(this.d - ((int) ((9223367638808264704L & j2) >> 42)));
        sb.append("}]");
        return sb.toString();
    }
}

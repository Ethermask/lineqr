package oh.a.x2;

import e.e.b.a.a;
import ka.b.q;

public final class k extends i {
    public final Runnable c;

    public k(Runnable runnable, long j, j jVar) {
        super(j, jVar);
        this.c = runnable;
    }

    public void run() {
        try {
            this.c.run();
        } finally {
            this.b.W();
        }
    }

    public String toString() {
        StringBuilder V0 = a.V0("Task[");
        V0.append(q.n1(this.c));
        V0.append('@');
        V0.append(q.q1(this.c));
        V0.append(", ");
        V0.append(this.a);
        V0.append(", ");
        V0.append(this.b);
        V0.append(']');
        return V0.toString();
    }
}

package oh.a.x2;

import java.util.concurrent.TimeUnit;
import ka.b.q;
import ka.k.i;
import oh.a.t2.w;

public final class l {
    public static final long a = q.w3("kotlinx.coroutines.scheduler.resolution.ns", 100000, 0, 0, 12, (Object) null);
    public static final int b;
    public static final int c = q.v3("kotlinx.coroutines.scheduler.max.pool.size", i.h(w.a * 128, b, 2097150), 0, 2097150, 4, (Object) null);
    public static final long d = TimeUnit.SECONDS.toNanos(q.w3("kotlinx.coroutines.scheduler.keep.alive.sec", 60, 0, 0, 12, (Object) null));

    /* renamed from: e  reason: collision with root package name */
    public static h f102e = f.a;

    static {
        q.v3("kotlinx.coroutines.scheduler.blocking.parallelism", 16, 0, 0, 12, (Object) null);
        int i = w.a;
        b = q.v3("kotlinx.coroutines.scheduler.core.pool.size", i < 2 ? 2 : i, 1, 0, 8, (Object) null);
    }
}

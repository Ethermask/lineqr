package oh.a.s2;

import ka.b.q;
import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;

@e(c = "kotlinx.coroutines.flow.FlowKt__ReduceKt", f = "Reduce.kt", l = {182}, m = "first")
public final class s extends c {
    public /* synthetic */ Object a;
    public int b;
    public Object c;
    public Object d;

    public s(d dVar) {
        super(dVar);
    }

    public final Object invokeSuspend(Object obj) {
        this.a = obj;
        this.b |= Integer.MIN_VALUE;
        return q.V0((e) null, this);
    }
}

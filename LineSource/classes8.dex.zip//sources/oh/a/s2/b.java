package oh.a.s2;

import ka.e.d;
import ka.e.f;
import ka.e.h;
import ka.e.k.a.c;
import ka.e.k.a.e;
import ka.h.b.p;
import kotlin.Unit;
import oh.a.r2.r;

public final class b<T> extends c<T> {

    /* renamed from: e  reason: collision with root package name */
    public final p<r<? super T>, d<? super Unit>, Object> f80e;

    @e(c = "kotlinx.coroutines.flow.CallbackFlowBuilder", f = "Builders.kt", l = {358}, m = "collectTo")
    public static final class a extends c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ b c;
        public Object d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(b bVar, d dVar) {
            super(dVar);
            this.c = bVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return this.c.a((r) null, this);
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public b(p pVar, f fVar, int i, oh.a.r2.e eVar, int i2) {
        super(pVar, (i2 & 2) != 0 ? h.a : null, (i2 & 4) != 0 ? -2 : i, (i2 & 8) != 0 ? oh.a.r2.e.SUSPEND : null);
        this.f80e = pVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0033  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0050  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0053  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object a(oh.a.r2.r<? super T> r5, ka.e.d<? super kotlin.Unit> r6) {
        /*
            r4 = this;
            boolean r0 = r6 instanceof oh.a.s2.b.a
            if (r0 == 0) goto L_0x0013
            r0 = r6
            oh.a.s2.b$a r0 = (oh.a.s2.b.a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.s2.b$a r0 = new oh.a.s2.b$a
            r0.<init>(r4, r6)
        L_0x0018:
            java.lang.Object r6 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 1
            if (r2 == 0) goto L_0x0033
            if (r2 != r3) goto L_0x002b
            java.lang.Object r5 = r0.d
            oh.a.r2.r r5 = (oh.a.r2.r) r5
            kotlin.ResultKt.throwOnFailure(r6)
            goto L_0x004a
        L_0x002b:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L_0x0033:
            kotlin.ResultKt.throwOnFailure(r6)
            r0.d = r5
            r0.b = r3
            ka.h.b.p<oh.a.r2.r<? super T>, ka.e.d<? super kotlin.Unit>, java.lang.Object> r6 = r4.d
            java.lang.Object r6 = r6.invoke(r5, r0)
            ka.e.j.a r0 = ka.e.j.a.COROUTINE_SUSPENDED
            if (r6 != r0) goto L_0x0045
            goto L_0x0047
        L_0x0045:
            kotlin.Unit r6 = kotlin.Unit.INSTANCE
        L_0x0047:
            if (r6 != r1) goto L_0x004a
            return r1
        L_0x004a:
            boolean r5 = r5.y()
            if (r5 == 0) goto L_0x0053
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
            return r5
        L_0x0053:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "'awaitClose { yourCallbackOrListener.cancel() }' should be used in the end of callbackFlow block.\nOtherwise, a callback/listener may leak in case of external cancellation.\nSee callbackFlow API documentation for the details."
            r5.<init>(r6)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.b.a(oh.a.r2.r, ka.e.d):java.lang.Object");
    }

    public oh.a.s2.c0.e<T> d(f fVar, int i, oh.a.r2.e eVar) {
        return new b(this.f80e, fVar, i, eVar);
    }

    public b(p<? super r<? super T>, ? super d<? super Unit>, ? extends Object> pVar, f fVar, int i, oh.a.r2.e eVar) {
        super(pVar, fVar, i, eVar);
        this.f80e = pVar;
    }
}

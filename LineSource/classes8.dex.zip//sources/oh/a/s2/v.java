package oh.a.s2;

import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;
import ka.h.b.p;
import kotlin.Unit;

public final class v implements e<T> {
    public final /* synthetic */ e a;
    public final /* synthetic */ p b;

    public static final class a implements f<T> {
        public final /* synthetic */ f a;
        public final /* synthetic */ v b;

        @e(c = "kotlinx.coroutines.flow.FlowKt__TransformKt$onEach$$inlined$unsafeTransform$1$2", f = "Transform.kt", l = {134, 135}, m = "emit")
        /* renamed from: oh.a.s2.v$a$a  reason: collision with other inner class name */
        public static final class C0006a extends c {
            public /* synthetic */ Object a;
            public int b;
            public final /* synthetic */ a c;
            public Object d;

            /* renamed from: e  reason: collision with root package name */
            public Object f87e;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C0006a(a aVar, d dVar) {
                super(dVar);
                this.c = aVar;
            }

            public final Object invokeSuspend(Object obj) {
                this.a = obj;
                this.b |= Integer.MIN_VALUE;
                return this.c.a((Object) null, this);
            }
        }

        public a(f fVar, v vVar) {
            this.a = fVar;
            this.b = vVar;
        }

        /* JADX WARNING: Removed duplicated region for block: B:14:0x003c  */
        /* JADX WARNING: Removed duplicated region for block: B:20:0x0061 A[RETURN] */
        /* JADX WARNING: Removed duplicated region for block: B:8:0x0022  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public java.lang.Object a(java.lang.Object r6, ka.e.d r7) {
            /*
                r5 = this;
                boolean r0 = r7 instanceof oh.a.s2.v.a.C0006a
                if (r0 == 0) goto L_0x0013
                r0 = r7
                oh.a.s2.v$a$a r0 = (oh.a.s2.v.a.C0006a) r0
                int r1 = r0.b
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L_0x0013
                int r1 = r1 - r2
                r0.b = r1
                goto L_0x0018
            L_0x0013:
                oh.a.s2.v$a$a r0 = new oh.a.s2.v$a$a
                r0.<init>(r5, r7)
            L_0x0018:
                java.lang.Object r7 = r0.a
                ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
                int r2 = r0.b
                r3 = 2
                r4 = 1
                if (r2 == 0) goto L_0x003c
                if (r2 == r4) goto L_0x0032
                if (r2 != r3) goto L_0x002a
                kotlin.ResultKt.throwOnFailure(r7)
                goto L_0x0062
            L_0x002a:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r7)
                throw r6
            L_0x0032:
                java.lang.Object r6 = r0.f87e
                oh.a.s2.f r6 = (oh.a.s2.f) r6
                java.lang.Object r2 = r0.d
                kotlin.ResultKt.throwOnFailure(r7)
                goto L_0x0054
            L_0x003c:
                kotlin.ResultKt.throwOnFailure(r7)
                oh.a.s2.f r7 = r5.a
                oh.a.s2.v r2 = r5.b
                ka.h.b.p r2 = r2.b
                r0.d = r6
                r0.f87e = r7
                r0.b = r4
                java.lang.Object r2 = r2.invoke(r6, r0)
                if (r2 != r1) goto L_0x0052
                return r1
            L_0x0052:
                r2 = r6
                r6 = r7
            L_0x0054:
                r7 = 0
                r0.d = r7
                r0.f87e = r7
                r0.b = r3
                java.lang.Object r6 = r6.a(r2, r0)
                if (r6 != r1) goto L_0x0062
                return r1
            L_0x0062:
                kotlin.Unit r6 = kotlin.Unit.INSTANCE
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.v.a.a(java.lang.Object, ka.e.d):java.lang.Object");
        }
    }

    public v(e eVar, p pVar) {
        this.a = eVar;
        this.b = pVar;
    }

    public Object c(f fVar, d dVar) {
        Object c = this.a.c(new a(fVar, this), dVar);
        if (c == ka.e.j.a.COROUTINE_SUSPENDED) {
            return c;
        }
        return Unit.INSTANCE;
    }
}

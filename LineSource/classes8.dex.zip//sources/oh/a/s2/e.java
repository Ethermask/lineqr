package oh.a.s2;

import ka.e.d;
import kotlin.Unit;

public interface e<T> {
    Object c(f<? super T> fVar, d<? super Unit> dVar);
}

package oh.a.s2;

import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;

public abstract class a<T> implements e<T> {

    @e(c = "kotlinx.coroutines.flow.AbstractFlow", f = "Flow.kt", l = {212}, m = "collect")
    /* renamed from: oh.a.s2.a$a  reason: collision with other inner class name */
    public static final class C0003a extends c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ a c;
        public Object d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0003a(a aVar, d dVar) {
            super(dVar);
            this.c = aVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return this.c.c((f) null, this);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object c(oh.a.s2.f<? super T> r6, ka.e.d<? super kotlin.Unit> r7) {
        /*
            r5 = this;
            boolean r0 = r7 instanceof oh.a.s2.a.C0003a
            if (r0 == 0) goto L_0x0013
            r0 = r7
            oh.a.s2.a$a r0 = (oh.a.s2.a.C0003a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.s2.a$a r0 = new oh.a.s2.a$a
            r0.<init>(r5, r7)
        L_0x0018:
            java.lang.Object r7 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 1
            if (r2 == 0) goto L_0x0035
            if (r2 != r3) goto L_0x002d
            java.lang.Object r6 = r0.d
            oh.a.s2.c0.n r6 = (oh.a.s2.c0.n) r6
            kotlin.ResultKt.throwOnFailure(r7)     // Catch:{ all -> 0x002b }
            goto L_0x0059
        L_0x002b:
            r7 = move-exception
            goto L_0x0063
        L_0x002d:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L_0x0035:
            kotlin.ResultKt.throwOnFailure(r7)
            oh.a.s2.c0.n r7 = new oh.a.s2.c0.n
            ka.e.f r2 = r0.getContext()
            r7.<init>(r6, r2)
            r0.d = r7     // Catch:{ all -> 0x005f }
            r0.b = r3     // Catch:{ all -> 0x005f }
            r6 = r5
            oh.a.s2.x r6 = (oh.a.s2.x) r6     // Catch:{ all -> 0x005f }
            ka.h.b.p<oh.a.s2.f<? super T>, ka.e.d<? super kotlin.Unit>, java.lang.Object> r6 = r6.a     // Catch:{ all -> 0x005f }
            java.lang.Object r6 = r6.invoke(r7, r0)     // Catch:{ all -> 0x005f }
            ka.e.j.a r0 = ka.e.j.a.COROUTINE_SUSPENDED     // Catch:{ all -> 0x005f }
            if (r6 != r0) goto L_0x0053
            goto L_0x0055
        L_0x0053:
            kotlin.Unit r6 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x005f }
        L_0x0055:
            if (r6 != r1) goto L_0x0058
            return r1
        L_0x0058:
            r6 = r7
        L_0x0059:
            r6.releaseIntercepted()
            kotlin.Unit r6 = kotlin.Unit.INSTANCE
            return r6
        L_0x005f:
            r6 = move-exception
            r4 = r7
            r7 = r6
            r6 = r4
        L_0x0063:
            r6.releaseIntercepted()
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.a.c(oh.a.s2.f, ka.e.d):java.lang.Object");
    }
}

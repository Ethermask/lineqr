package oh.a.s2;

import e.e.b.a.a;
import ka.e.d;
import ka.e.f;
import ka.h.b.p;
import kotlin.Unit;
import oh.a.r2.r;
import oh.a.s2.c0.e;

public class c<T> extends e<T> {
    public final p<r<? super T>, d<? super Unit>, Object> d;

    public c(p<? super r<? super T>, ? super d<? super Unit>, ? extends Object> pVar, f fVar, int i, oh.a.r2.e eVar) {
        super(fVar, i, eVar);
        this.d = pVar;
    }

    public String toString() {
        StringBuilder V0 = a.V0("block[");
        V0.append(this.d);
        V0.append("] -> ");
        V0.append(super.toString());
        return V0.toString();
    }
}

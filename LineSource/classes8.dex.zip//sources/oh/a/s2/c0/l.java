package oh.a.s2.c0;

import ka.e.d;
import ka.e.f;
import ka.e.h;

public final class l implements d<Object> {
    public static final f a = h.a;
    public static final l b = new l();

    public f getContext() {
        return a;
    }

    public void resumeWith(Object obj) {
    }
}

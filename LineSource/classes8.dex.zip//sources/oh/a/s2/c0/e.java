package oh.a.s2.c0;

import java.util.ArrayList;
import ka.b.k;
import ka.e.d;
import ka.e.f;
import ka.e.h;
import ka.e.k.a.i;
import ka.h.b.l;
import ka.h.b.p;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.c0;
import oh.a.h0;
import oh.a.i0;
import oh.a.r2.q;
import oh.a.r2.r;

public abstract class e<T> implements k<T> {
    public final f a;
    public final int b;
    public final oh.a.r2.e c;

    @ka.e.k.a.e(c = "kotlinx.coroutines.flow.internal.ChannelFlow$collect$2", f = "ChannelFlow.kt", l = {135}, m = "invokeSuspend")
    public static final class a extends i implements p<h0, d<? super Unit>, Object> {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ e c;
        public final /* synthetic */ oh.a.s2.f d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(e eVar, oh.a.s2.f fVar, d dVar) {
            super(2, dVar);
            this.c = eVar;
            this.d = fVar;
        }

        public final d<Unit> create(Object obj, d<?> dVar) {
            a aVar = new a(this.c, this.d, dVar);
            aVar.a = obj;
            return aVar;
        }

        public final Object invoke(Object obj, Object obj2) {
            a aVar = new a(this.c, this.d, (d) obj2);
            aVar.a = obj;
            return aVar.invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            ka.e.j.a aVar = ka.e.j.a.COROUTINE_SUSPENDED;
            int i = this.b;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                h0 h0Var = (h0) this.a;
                oh.a.s2.f fVar = this.d;
                e eVar = this.c;
                f fVar2 = eVar.a;
                int i2 = eVar.b;
                if (i2 == -3) {
                    i2 = -2;
                }
                oh.a.r2.e eVar2 = eVar.c;
                i0 i0Var = i0.ATOMIC;
                f fVar3 = new f(eVar, (d) null);
                q qVar = new q(c0.b(h0Var, fVar2), ka.b.q.b(i2, eVar2, (l) null, 4));
                qVar.x0(i0Var, qVar, fVar3);
                this.b = 1;
                Object z0 = ka.b.q.z0(fVar, qVar, true, this);
                if (z0 != ka.e.j.a.COROUTINE_SUSPENDED) {
                    z0 = Unit.INSTANCE;
                }
                if (z0 == aVar) {
                    return aVar;
                }
            } else if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public e(f fVar, int i, oh.a.r2.e eVar) {
        this.a = fVar;
        this.b = i;
        this.c = eVar;
    }

    public abstract Object a(r<? super T> rVar, d<? super Unit> dVar);

    public oh.a.s2.e<T> b(f fVar, int i, oh.a.r2.e eVar) {
        f plus = fVar.plus(this.a);
        if (eVar == oh.a.r2.e.SUSPEND) {
            int i2 = this.b;
            if (i2 != -3) {
                if (i != -3) {
                    if (i2 != -2) {
                        if (i != -2 && (i2 = i2 + i) < 0) {
                            i = Integer.MAX_VALUE;
                        }
                    }
                }
                i = i2;
            }
            eVar = this.c;
        }
        if (ka.h.c.p.b(plus, this.a) && i == this.b && eVar == this.c) {
            return this;
        }
        return d(plus, i, eVar);
    }

    public Object c(oh.a.s2.f<? super T> fVar, d<? super Unit> dVar) {
        Object r0 = ka.b.q.r0(new a(this, fVar, (d) null), dVar);
        return r0 == ka.e.j.a.COROUTINE_SUSPENDED ? r0 : Unit.INSTANCE;
    }

    public abstract e<T> d(f fVar, int i, oh.a.r2.e eVar);

    public String toString() {
        ArrayList arrayList = new ArrayList(4);
        if (this.a != h.a) {
            StringBuilder V0 = e.e.b.a.a.V0("context=");
            V0.append(this.a);
            arrayList.add(V0.toString());
        }
        if (this.b != -3) {
            StringBuilder V02 = e.e.b.a.a.V0("capacity=");
            V02.append(this.b);
            arrayList.add(V02.toString());
        }
        if (this.c != oh.a.r2.e.SUSPEND) {
            StringBuilder V03 = e.e.b.a.a.V0("onBufferOverflow=");
            V03.append(this.c);
            arrayList.add(V03.toString());
        }
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append('[');
        return e.e.b.a.a.o0(sb, k.E(arrayList, ", ", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (l) null, 62), ']');
    }
}

package oh.a.s2.c0;

import ka.e.f;
import ka.h.b.p;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class j implements f.a {
    public static final a c = new a((DefaultConstructorMarker) null);
    public final f.b<?> a = c;
    public final Throwable b;

    public static final class a implements f.b<j> {
        public a(DefaultConstructorMarker defaultConstructorMarker) {
        }
    }

    public j(Throwable th2) {
        this.b = th2;
    }

    public <R> R fold(R r, p<? super R, ? super f.a, ? extends R> pVar) {
        return f.a.a.a(this, r, pVar);
    }

    public <E extends f.a> E get(f.b<E> bVar) {
        return f.a.a.b(this, bVar);
    }

    public f.b<?> getKey() {
        return this.a;
    }

    public f minusKey(f.b<?> bVar) {
        return f.a.a.c(this, bVar);
    }

    public f plus(f fVar) {
        return f.a.a.d(this, fVar);
    }
}

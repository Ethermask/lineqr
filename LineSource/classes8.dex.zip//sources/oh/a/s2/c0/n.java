package oh.a.s2.c0;

import ka.b.q;
import ka.e.f;
import ka.e.h;
import ka.e.k.a.c;
import ka.e.k.a.d;
import ka.h.b.p;
import ka.h.c.r;
import kotlin.Result;
import kotlin.Unit;
import oh.a.s2.f;

public final class n<T> extends c implements f<T>, d {
    public final int a;
    public ka.e.f b;
    public ka.e.d<? super Unit> c;
    public final f<T> d;

    /* renamed from: e  reason: collision with root package name */
    public final ka.e.f f82e;

    public static final class a extends r implements p<Integer, f.a, Integer> {
        public static final a a = new a();

        public a() {
            super(2);
        }

        public Object invoke(Object obj, Object obj2) {
            f.a aVar = (f.a) obj2;
            return Integer.valueOf(((Number) obj).intValue() + 1);
        }
    }

    public n(oh.a.s2.f<? super T> fVar, ka.e.f fVar2) {
        super(l.b, h.a);
        this.d = fVar;
        this.f82e = fVar2;
        this.a = ((Number) fVar2.fold(0, a.a)).intValue();
    }

    public Object a(T t, ka.e.d<? super Unit> dVar) {
        try {
            Object b2 = b(dVar, t);
            if (b2 == ka.e.j.a.COROUTINE_SUSPENDED) {
                ka.h.c.p.e(dVar, "frame");
            }
            if (b2 == ka.e.j.a.COROUTINE_SUSPENDED) {
                return b2;
            }
            return Unit.INSTANCE;
        } catch (Throwable th2) {
            this.b = new j(th2);
            throw th2;
        }
    }

    public final Object b(ka.e.d<? super Unit> dVar, T t) {
        j context = dVar.getContext();
        q.D0(context);
        j jVar = this.b;
        if (jVar != context) {
            if (jVar instanceof j) {
                StringBuilder V0 = e.e.b.a.a.V0("\n            Flow exception transparency is violated:\n                Previous 'emit' call has thrown exception ");
                V0.append(jVar.b);
                V0.append(", but then emission attempt of value '");
                V0.append(t);
                V0.append("' has been detected.\n                Emissions from 'catch' blocks are prohibited in order to avoid unspecified behaviour, 'Flow.catch' operator can be used instead.\n                For a more detailed explanation, please refer to Flow documentation.\n            ");
                throw new IllegalStateException(ka.m.n.c(V0.toString()).toString());
            } else if (((Number) context.fold(0, new p(this))).intValue() == this.a) {
                this.b = context;
            } else {
                StringBuilder g1 = e.e.b.a.a.g1("Flow invariant is violated:\n", "\t\tFlow was collected in ");
                g1.append(this.f82e);
                g1.append(",\n");
                g1.append("\t\tbut emission happened in ");
                g1.append(context);
                throw new IllegalStateException(e.e.b.a.a.t0(g1, ".\n", "\t\tPlease refer to 'flow' documentation or use 'flowOn' instead").toString());
            }
        }
        this.c = dVar;
        ka.h.b.q<oh.a.s2.f<Object>, Object, ka.e.d<? super Unit>, Object> qVar = o.a;
        oh.a.s2.f<T> fVar = this.d;
        if (fVar != null) {
            return qVar.invoke(fVar, t, this);
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.flow.FlowCollector<kotlin.Any?>");
    }

    public d getCallerFrame() {
        ka.e.d<? super Unit> dVar = this.c;
        if (!(dVar instanceof d)) {
            dVar = null;
        }
        return (d) dVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r0.getContext();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ka.e.f getContext() {
        /*
            r1 = this;
            ka.e.d<? super kotlin.Unit> r0 = r1.c
            if (r0 == 0) goto L_0x000b
            ka.e.f r0 = r0.getContext()
            if (r0 == 0) goto L_0x000b
            goto L_0x000d
        L_0x000b:
            ka.e.h r0 = ka.e.h.a
        L_0x000d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.c0.n.getContext():ka.e.f");
    }

    public StackTraceElement getStackTraceElement() {
        return null;
    }

    public Object invokeSuspend(Object obj) {
        Throwable r0 = Result.exceptionOrNull-impl(obj);
        if (r0 != null) {
            this.b = new j(r0);
        }
        ka.e.d<? super Unit> dVar = this.c;
        if (dVar != null) {
            dVar.resumeWith(obj);
        }
        return ka.e.j.a.COROUTINE_SUSPENDED;
    }

    public void releaseIntercepted() {
        n.super.releaseIntercepted();
    }
}

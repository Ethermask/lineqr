package oh.a.s2.c0;

public abstract class d<F> {
}

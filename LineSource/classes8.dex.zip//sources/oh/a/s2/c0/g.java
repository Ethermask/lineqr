package oh.a.s2.c0;

import ka.e.d;
import ka.e.j.a;
import ka.e.k.a.e;
import ka.e.k.a.i;
import ka.h.b.p;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.s2.f;

@e(c = "kotlinx.coroutines.flow.internal.ChannelFlowOperator$collectWithContextUndispatched$2", f = "ChannelFlow.kt", l = {164}, m = "invokeSuspend")
public final class g extends i implements p<f<? super T>, d<? super Unit>, Object> {
    public /* synthetic */ Object a;
    public int b;
    public final /* synthetic */ h c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public g(h hVar, d dVar) {
        super(2, dVar);
        this.c = hVar;
    }

    public final d<Unit> create(Object obj, d<?> dVar) {
        g gVar = new g(this.c, dVar);
        gVar.a = obj;
        return gVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        g gVar = new g(this.c, (d) obj2);
        gVar.a = obj;
        return gVar.invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.COROUTINE_SUSPENDED;
        int i = this.b;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            h hVar = this.c;
            this.b = 1;
            if (hVar.e((f) this.a, this) == aVar) {
                return aVar;
            }
        } else if (i == 1) {
            ResultKt.throwOnFailure(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }
}

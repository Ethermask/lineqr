package oh.a.s2.c0;

import java.util.concurrent.CancellationException;
import oh.a.s2.f;

public final class a extends CancellationException {
    public final f<?> a;

    public a(f<?> fVar) {
        super("Flow was aborted, no more elements needed");
        this.a = fVar;
    }

    public Throwable fillInStackTrace() {
        setStackTrace(new StackTraceElement[0]);
        return this;
    }
}

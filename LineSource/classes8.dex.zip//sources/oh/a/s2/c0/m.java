package oh.a.s2.c0;

import oh.a.t2.v;

public final class m {
    public static final v a = new v("NULL");
}

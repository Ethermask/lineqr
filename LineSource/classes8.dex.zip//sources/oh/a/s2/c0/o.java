package oh.a.s2.c0;

import ka.e.d;
import ka.h.b.q;
import ka.h.c.n;
import ka.h.c.n0;
import kotlin.Unit;
import oh.a.s2.f;

public final class o {
    public static final q<f<Object>, Object, d<? super Unit>, Object> a;

    public static final /* synthetic */ class a extends n implements q<f<? super Object>, Object, d<? super Unit>, Object> {
        public a() {
            super(3, f.class, "emit", "emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
        }

        public Object invoke(Object obj, Object obj2, Object obj3) {
            return ((f) obj).a(obj2, (d) obj3);
        }
    }

    static {
        q<f<Object>, Object, d<? super Unit>, Object> aVar = new a();
        n0.e(aVar, 3);
        a = (q) aVar;
    }
}

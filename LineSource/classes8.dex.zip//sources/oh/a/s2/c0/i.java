package oh.a.s2.c0;

import ka.e.d;
import ka.e.f;
import ka.e.h;
import ka.e.j.a;
import kotlin.Unit;
import oh.a.s2.e;

public final class i<T> extends h<T, T> {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public i(e eVar, h hVar, int i, oh.a.r2.e eVar2, int i2) {
        super(eVar, (i2 & 2) != 0 ? h.a : hVar, (i2 & 4) != 0 ? -3 : i, (i2 & 8) != 0 ? oh.a.r2.e.SUSPEND : eVar2);
    }

    public e<T> d(f fVar, int i, oh.a.r2.e eVar) {
        return new i(this.d, fVar, i, eVar);
    }

    public Object e(oh.a.s2.f<? super T> fVar, d<? super Unit> dVar) {
        Object c = this.d.c(fVar, dVar);
        if (c == a.COROUTINE_SUSPENDED) {
            return c;
        }
        return Unit.INSTANCE;
    }

    public i(e<? extends T> eVar, f fVar, int i, oh.a.r2.e eVar2) {
        super(eVar, fVar, i, eVar2);
    }
}

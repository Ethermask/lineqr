package oh.a.s2.c0;

import ka.e.d;
import ka.e.j.a;
import kotlin.Unit;
import oh.a.r2.x;
import oh.a.s2.f;

public final class q<T> implements f<T> {
    public final x<T> a;

    public q(x<? super T> xVar) {
        this.a = xVar;
    }

    public Object a(T t, d<? super Unit> dVar) {
        Object x = this.a.x(t, dVar);
        if (x == a.COROUTINE_SUSPENDED) {
            return x;
        }
        return Unit.INSTANCE;
    }
}

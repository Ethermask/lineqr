package oh.a.s2.c0;

import ka.e.f;
import ka.h.c.r;

public final class p extends r implements ka.h.b.p<Integer, f.a, Integer> {
    public final /* synthetic */ n a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public p(n nVar) {
        super(2);
        this.a = nVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x002e, code lost:
        if (r1 == null) goto L_0x0033;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object invoke(java.lang.Object r4, java.lang.Object r5) {
        /*
            r3 = this;
            java.lang.Number r4 = (java.lang.Number) r4
            int r4 = r4.intValue()
            ka.e.f$a r5 = (ka.e.f.a) r5
            ka.e.f$b r0 = r5.getKey()
            oh.a.s2.c0.n r1 = r3.a
            ka.e.f r1 = r1.f82e
            ka.e.f$a r1 = r1.get(r0)
            oh.a.n1$a r2 = oh.a.n1.Z
            if (r0 == r2) goto L_0x001d
            if (r5 == r1) goto L_0x0031
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x0033
        L_0x001d:
            oh.a.n1 r1 = (oh.a.n1) r1
            oh.a.n1 r5 = (oh.a.n1) r5
        L_0x0021:
            if (r5 != 0) goto L_0x0025
            r5 = 0
            goto L_0x002c
        L_0x0025:
            if (r5 != r1) goto L_0x0028
            goto L_0x002c
        L_0x0028:
            boolean r0 = r5 instanceof oh.a.t2.s
            if (r0 != 0) goto L_0x0066
        L_0x002c:
            if (r5 != r1) goto L_0x0038
            if (r1 != 0) goto L_0x0031
            goto L_0x0033
        L_0x0031:
            int r4 = r4 + 1
        L_0x0033:
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            return r4
        L_0x0038:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r0 = "Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n"
            r4.append(r0)
            java.lang.String r0 = "\t\tChild of "
            r4.append(r0)
            r4.append(r5)
            java.lang.String r5 = ", expected child of "
            r4.append(r5)
            r4.append(r1)
            java.lang.String r5 = ".\n"
            java.lang.String r0 = "\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n"
            java.lang.String r1 = "\t\tTo mitigate this restriction please use 'channelFlow' builder instead of 'flow'"
            java.lang.String r4 = e.e.b.a.a.v0(r4, r5, r0, r1)
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r4 = r4.toString()
            r5.<init>(r4)
            throw r5
        L_0x0066:
            oh.a.t2.s r5 = (oh.a.t2.s) r5
            ka.e.f r5 = r5.c
            oh.a.n1$a r0 = oh.a.n1.Z
            ka.e.f$a r5 = r5.get(r0)
            oh.a.n1 r5 = (oh.a.n1) r5
            goto L_0x0021
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.c0.p.invoke(java.lang.Object, java.lang.Object):java.lang.Object");
    }
}

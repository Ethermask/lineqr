package oh.a.s2.c0;

import ka.e.d;
import ka.e.j.a;
import ka.e.k.a.e;
import ka.e.k.a.i;
import ka.h.b.p;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.r2.r;

@e(c = "kotlinx.coroutines.flow.internal.ChannelFlow$collectToFun$1", f = "ChannelFlow.kt", l = {60}, m = "invokeSuspend")
public final class f extends i implements p<r<? super T>, d<? super Unit>, Object> {
    public /* synthetic */ Object a;
    public int b;
    public final /* synthetic */ e c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public f(e eVar, d dVar) {
        super(2, dVar);
        this.c = eVar;
    }

    public final d<Unit> create(Object obj, d<?> dVar) {
        f fVar = new f(this.c, dVar);
        fVar.a = obj;
        return fVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        f fVar = new f(this.c, (d) obj2);
        fVar.a = obj;
        return fVar.invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.COROUTINE_SUSPENDED;
        int i = this.b;
        if (i == 0) {
            ResultKt.throwOnFailure(obj);
            e eVar = this.c;
            this.b = 1;
            if (eVar.a((r) this.a, this) == aVar) {
                return aVar;
            }
        } else if (i == 1) {
            ResultKt.throwOnFailure(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }
}

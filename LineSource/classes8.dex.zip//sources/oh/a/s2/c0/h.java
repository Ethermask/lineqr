package oh.a.s2.c0;

import ka.b.q;
import ka.e.d;
import ka.e.f;
import ka.e.j.a;
import ka.h.c.p;
import kotlin.Unit;
import oh.a.r2.r;
import oh.a.s2.e;
import oh.a.t2.x;

public abstract class h<S, T> extends e<T> {
    public final e<S> d;

    public h(e<? extends S> eVar, f fVar, int i, oh.a.r2.e eVar2) {
        super(fVar, i, eVar2);
        this.d = eVar;
    }

    public Object a(r<? super T> rVar, d<? super Unit> dVar) {
        Object e2 = e(new q(rVar), dVar);
        return e2 == a.COROUTINE_SUSPENDED ? e2 : Unit.INSTANCE;
    }

    public Object c(oh.a.s2.f<? super T> fVar, d<? super Unit> dVar) {
        if (this.b == -3) {
            f context = dVar.getContext();
            f plus = context.plus(this.a);
            if (p.b(plus, context)) {
                Object e2 = e(fVar, dVar);
                if (e2 == a.COROUTINE_SUSPENDED) {
                    return e2;
                }
                return Unit.INSTANCE;
            } else if (p.b(plus.get(ka.e.e.X), context.get(ka.e.e.X))) {
                f context2 = dVar.getContext();
                if (!(fVar instanceof q)) {
                    fVar = new s<>(fVar, context2);
                }
                Object Z3 = q.Z3(plus, fVar, x.b(plus), new g(this, (d) null), dVar);
                if (Z3 != a.COROUTINE_SUSPENDED) {
                    Z3 = Unit.INSTANCE;
                }
                if (Z3 == a.COROUTINE_SUSPENDED) {
                    return Z3;
                }
                return Unit.INSTANCE;
            }
        }
        Object c = super.c(fVar, dVar);
        return c == a.COROUTINE_SUSPENDED ? c : Unit.INSTANCE;
    }

    public abstract Object e(oh.a.s2.f<? super T> fVar, d<? super Unit> dVar);

    public String toString() {
        return this.d + " -> " + super.toString();
    }
}

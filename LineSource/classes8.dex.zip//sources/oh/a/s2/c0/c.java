package oh.a.s2.c0;

import ka.e.d;
import kotlin.Unit;

public final class c {
    public static final d<Unit>[] a = new d[0];
}

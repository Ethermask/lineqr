package oh.a.s2.c0;

import oh.a.s2.c0.d;

public abstract class b<S extends d<?>> {
    public S[] a;
    public int b;
    public int c;
}

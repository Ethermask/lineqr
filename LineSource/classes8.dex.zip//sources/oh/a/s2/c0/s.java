package oh.a.s2.c0;

import ka.b.q;
import ka.e.d;
import ka.e.k.a.e;
import ka.e.k.a.i;
import ka.h.b.p;
import kotlin.ResultKt;
import kotlin.Unit;
import oh.a.s2.f;
import oh.a.t2.x;

public final class s<T> implements f<T> {
    public final Object a;
    public final p<T, d<? super Unit>, Object> b;
    public final ka.e.f c;

    @e(c = "kotlinx.coroutines.flow.internal.UndispatchedContextCollector$emitRef$1", f = "ChannelFlow.kt", l = {224}, m = "invokeSuspend")
    public static final class a extends i implements p<T, d<? super Unit>, Object> {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ f c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(f fVar, d dVar) {
            super(2, dVar);
            this.c = fVar;
        }

        public final d<Unit> create(Object obj, d<?> dVar) {
            a aVar = new a(this.c, dVar);
            aVar.a = obj;
            return aVar;
        }

        public final Object invoke(Object obj, Object obj2) {
            a aVar = new a(this.c, (d) obj2);
            aVar.a = obj;
            return aVar.invokeSuspend(Unit.INSTANCE);
        }

        public final Object invokeSuspend(Object obj) {
            ka.e.j.a aVar = ka.e.j.a.COROUTINE_SUSPENDED;
            int i = this.b;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                Object obj2 = this.a;
                f fVar = this.c;
                this.b = 1;
                if (fVar.a(obj2, this) == aVar) {
                    return aVar;
                }
            } else if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public s(f<? super T> fVar, ka.e.f fVar2) {
        this.c = fVar2;
        this.a = x.b(fVar2);
        this.b = new a(fVar, (d) null);
    }

    public Object a(T t, d<? super Unit> dVar) {
        Object Z3 = q.Z3(this.c, t, this.a, this.b, dVar);
        if (Z3 == ka.e.j.a.COROUTINE_SUSPENDED) {
            return Z3;
        }
        return Unit.INSTANCE;
    }
}

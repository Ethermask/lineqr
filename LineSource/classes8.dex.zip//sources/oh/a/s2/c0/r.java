package oh.a.s2.c0;

import ka.e.d;
import ka.e.f;

public final class r<T> implements d<T>, ka.e.k.a.d {
    public final d<T> a;
    public final f b;

    public r(d<? super T> dVar, f fVar) {
        this.a = dVar;
        this.b = fVar;
    }

    public ka.e.k.a.d getCallerFrame() {
        d<T> dVar = this.a;
        if (!(dVar instanceof ka.e.k.a.d)) {
            dVar = null;
        }
        return (ka.e.k.a.d) dVar;
    }

    public f getContext() {
        return this.b;
    }

    public void resumeWith(Object obj) {
        this.a.resumeWith(obj);
    }
}

package oh.a.s2.c0;

import ka.e.f;
import oh.a.s2.e;

public interface k<T> extends e<T> {
    e<T> b(f fVar, int i, oh.a.r2.e eVar);
}

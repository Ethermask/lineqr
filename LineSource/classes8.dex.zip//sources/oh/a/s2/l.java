package oh.a.s2;

import ka.h.b.p;
import ka.h.c.r;

public final /* synthetic */ class l {
    public static final ka.h.b.l<Object, Object> a = b.a;
    public static final p<Object, Object, Boolean> b = a.a;

    public static final class a extends r implements p<Object, Object, Boolean> {
        public static final a a = new a();

        public a() {
            super(2);
        }

        public Object invoke(Object obj, Object obj2) {
            return Boolean.valueOf(ka.h.c.p.b(obj, obj2));
        }
    }

    public static final class b extends r implements ka.h.b.l<Object, Object> {
        public static final b a = new b();

        public b() {
            super(1);
        }

        public final Object invoke(Object obj) {
            return obj;
        }
    }

    public static final <T> e<T> a(e<? extends T> eVar) {
        if (eVar instanceof w) {
            return eVar;
        }
        ka.h.b.l<T, Object> lVar = a;
        p<Object, Object, Boolean> pVar = b;
        if (eVar instanceof d) {
            d dVar = (d) eVar;
            if (dVar.b == lVar && dVar.c == pVar) {
                return eVar;
            }
        }
        return new d(eVar, lVar, pVar);
    }
}

package oh.a.s2;

import ka.e.d;
import ka.e.f;
import ka.e.k.a.c;
import ka.e.k.a.e;
import kotlin.Unit;
import oh.a.s2.c0.b;
import oh.a.s2.c0.i;
import oh.a.s2.c0.k;
import oh.a.s2.c0.m;

public final class y<T> extends b<a0> implements w<T>, Object<T>, k<T> {
    public volatile /* synthetic */ Object _state;
    public int d;

    @e(c = "kotlinx.coroutines.flow.StateFlowImpl", f = "StateFlow.kt", l = {336, 394, 353}, m = "collect")
    public static final class a extends c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ y c;
        public Object d;

        /* renamed from: e  reason: collision with root package name */
        public Object f88e;
        public Object f;
        public Object g;
        public Object h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(y yVar, d dVar) {
            super(dVar);
            this.c = yVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return this.c.c((f) null, this);
        }
    }

    public y(Object obj) {
        this._state = obj;
    }

    public Object a(T t, d<? super Unit> dVar) {
        if (t == null) {
            t = m.a;
        }
        d((Object) null, t);
        return Unit.INSTANCE;
    }

    public e<T> b(f fVar, int i, oh.a.r2.e eVar) {
        if ((((i < 0 || 1 < i) && i != -2) || eVar != oh.a.r2.e.DROP_OLDEST) && ((i != 0 && i != -3) || eVar != oh.a.r2.e.SUSPEND)) {
            return new i(this, fVar, i, eVar);
        }
        return this;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v18, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v10, resolved type: oh.a.s2.a0} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v19, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v9, resolved type: oh.a.s2.y} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0077  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00f3 A[Catch:{ all -> 0x0074 }] */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x010c A[Catch:{ all -> 0x0074 }] */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x010e A[Catch:{ all -> 0x0074 }] */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x0121 A[Catch:{ all -> 0x0074 }, RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0122 A[Catch:{ all -> 0x0074 }] */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x0125 A[Catch:{ all -> 0x0074 }] */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0025  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object c(oh.a.s2.f<? super T> r13, ka.e.d<? super kotlin.Unit> r14) {
        /*
            r12 = this;
            boolean r0 = r14 instanceof oh.a.s2.y.a
            if (r0 == 0) goto L_0x0013
            r0 = r14
            oh.a.s2.y$a r0 = (oh.a.s2.y.a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.s2.y$a r0 = new oh.a.s2.y$a
            r0.<init>(r12, r14)
        L_0x0018:
            java.lang.Object r14 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 2
            r4 = 3
            r5 = 0
            r6 = 0
            r7 = 1
            if (r2 == 0) goto L_0x0077
            if (r2 == r7) goto L_0x0061
            if (r2 == r3) goto L_0x004a
            if (r2 != r4) goto L_0x0042
            java.lang.Object r13 = r0.h
            java.lang.Object r2 = r0.g
            oh.a.n1 r2 = (oh.a.n1) r2
            java.lang.Object r8 = r0.f
            oh.a.s2.a0 r8 = (oh.a.s2.a0) r8
            java.lang.Object r9 = r0.f88e
            oh.a.s2.f r9 = (oh.a.s2.f) r9
            java.lang.Object r10 = r0.d
            oh.a.s2.y r10 = (oh.a.s2.y) r10
            kotlin.ResultKt.throwOnFailure(r14)     // Catch:{ all -> 0x0074 }
            goto L_0x00ef
        L_0x0042:
            java.lang.IllegalStateException r13 = new java.lang.IllegalStateException
            java.lang.String r14 = "call to 'resume' before 'invoke' with coroutine"
            r13.<init>(r14)
            throw r13
        L_0x004a:
            java.lang.Object r13 = r0.h
            java.lang.Object r2 = r0.g
            oh.a.n1 r2 = (oh.a.n1) r2
            java.lang.Object r8 = r0.f
            oh.a.s2.a0 r8 = (oh.a.s2.a0) r8
            java.lang.Object r9 = r0.f88e
            oh.a.s2.f r9 = (oh.a.s2.f) r9
            java.lang.Object r10 = r0.d
            oh.a.s2.y r10 = (oh.a.s2.y) r10
            kotlin.ResultKt.throwOnFailure(r14)     // Catch:{ all -> 0x0074 }
            goto L_0x0123
        L_0x0061:
            java.lang.Object r13 = r0.f
            r8 = r13
            oh.a.s2.a0 r8 = (oh.a.s2.a0) r8
            java.lang.Object r13 = r0.f88e
            oh.a.s2.f r13 = (oh.a.s2.f) r13
            java.lang.Object r2 = r0.d
            r10 = r2
            oh.a.s2.y r10 = (oh.a.s2.y) r10
            kotlin.ResultKt.throwOnFailure(r14)     // Catch:{ all -> 0x0074 }
            goto L_0x00e0
        L_0x0074:
            r13 = move-exception
            goto L_0x014f
        L_0x0077:
            kotlin.ResultKt.throwOnFailure(r14)
            monitor-enter(r12)
            S[] r14 = r12.a     // Catch:{ all -> 0x0182 }
            if (r14 != 0) goto L_0x0084
            oh.a.s2.a0[] r14 = new oh.a.s2.a0[r3]     // Catch:{ all -> 0x0182 }
            r12.a = r14     // Catch:{ all -> 0x0182 }
            goto L_0x009b
        L_0x0084:
            int r2 = r12.b     // Catch:{ all -> 0x0182 }
            int r8 = r14.length     // Catch:{ all -> 0x0182 }
            if (r2 < r8) goto L_0x009b
            int r2 = r14.length     // Catch:{ all -> 0x0182 }
            int r2 = r2 * r3
            java.lang.Object[] r14 = java.util.Arrays.copyOf(r14, r2)     // Catch:{ all -> 0x0182 }
            java.lang.String r2 = "java.util.Arrays.copyOf(this, newSize)"
            ka.h.c.p.d(r14, r2)     // Catch:{ all -> 0x0182 }
            r2 = r14
            oh.a.s2.c0.d[] r2 = (oh.a.s2.c0.d[]) r2     // Catch:{ all -> 0x0182 }
            r12.a = r2     // Catch:{ all -> 0x0182 }
            oh.a.s2.c0.d[] r14 = (oh.a.s2.c0.d[]) r14     // Catch:{ all -> 0x0182 }
        L_0x009b:
            int r2 = r12.c     // Catch:{ all -> 0x0182 }
        L_0x009d:
            r8 = r14[r2]     // Catch:{ all -> 0x0182 }
            if (r8 == 0) goto L_0x00a2
            goto L_0x00a9
        L_0x00a2:
            oh.a.s2.a0 r8 = new oh.a.s2.a0     // Catch:{ all -> 0x0182 }
            r8.<init>()     // Catch:{ all -> 0x0182 }
            r14[r2] = r8     // Catch:{ all -> 0x0182 }
        L_0x00a9:
            int r2 = r2 + 1
            int r9 = r14.length     // Catch:{ all -> 0x0182 }
            if (r2 < r9) goto L_0x00af
            r2 = r5
        L_0x00af:
            r9 = r8
            oh.a.s2.a0 r9 = (oh.a.s2.a0) r9     // Catch:{ all -> 0x0182 }
            java.lang.Object r10 = r9._state     // Catch:{ all -> 0x0182 }
            if (r10 == 0) goto L_0x00b8
            r9 = r5
            goto L_0x00bd
        L_0x00b8:
            oh.a.t2.v r10 = oh.a.s2.z.a     // Catch:{ all -> 0x0182 }
            r9._state = r10     // Catch:{ all -> 0x0182 }
            r9 = r7
        L_0x00bd:
            if (r9 == 0) goto L_0x009d
            r12.c = r2     // Catch:{ all -> 0x0182 }
            int r14 = r12.b     // Catch:{ all -> 0x0182 }
            int r14 = r14 + r7
            r12.b = r14     // Catch:{ all -> 0x0182 }
            monitor-exit(r12)
            oh.a.s2.a0 r8 = (oh.a.s2.a0) r8
            boolean r14 = r13 instanceof oh.a.s2.b0     // Catch:{ all -> 0x014d }
            if (r14 == 0) goto L_0x00df
            r14 = r13
            oh.a.s2.b0 r14 = (oh.a.s2.b0) r14     // Catch:{ all -> 0x014d }
            r0.d = r12     // Catch:{ all -> 0x014d }
            r0.f88e = r13     // Catch:{ all -> 0x014d }
            r0.f = r8     // Catch:{ all -> 0x014d }
            r0.b = r7     // Catch:{ all -> 0x014d }
            java.lang.Object r14 = r14.b(r0)     // Catch:{ all -> 0x014d }
            if (r14 != r1) goto L_0x00df
            return r1
        L_0x00df:
            r10 = r12
        L_0x00e0:
            ka.e.f r14 = r0.getContext()     // Catch:{ all -> 0x0074 }
            oh.a.n1$a r2 = oh.a.n1.Z     // Catch:{ all -> 0x0074 }
            ka.e.f$a r14 = r14.get(r2)     // Catch:{ all -> 0x0074 }
            r2 = r14
            oh.a.n1 r2 = (oh.a.n1) r2     // Catch:{ all -> 0x0074 }
            r9 = r13
            r13 = r6
        L_0x00ef:
            java.lang.Object r14 = r10._state     // Catch:{ all -> 0x0074 }
            if (r2 == 0) goto L_0x00ff
            boolean r11 = r2.isActive()     // Catch:{ all -> 0x0074 }
            if (r11 == 0) goto L_0x00fa
            goto L_0x00ff
        L_0x00fa:
            java.util.concurrent.CancellationException r13 = r2.k()     // Catch:{ all -> 0x0074 }
            throw r13     // Catch:{ all -> 0x0074 }
        L_0x00ff:
            if (r13 == 0) goto L_0x0108
            boolean r11 = ka.h.c.p.b(r13, r14)     // Catch:{ all -> 0x0074 }
            r11 = r11 ^ r7
            if (r11 == 0) goto L_0x0123
        L_0x0108:
            oh.a.t2.v r13 = oh.a.s2.c0.m.a     // Catch:{ all -> 0x0074 }
            if (r14 != r13) goto L_0x010e
            r13 = r6
            goto L_0x010f
        L_0x010e:
            r13 = r14
        L_0x010f:
            r0.d = r10     // Catch:{ all -> 0x0074 }
            r0.f88e = r9     // Catch:{ all -> 0x0074 }
            r0.f = r8     // Catch:{ all -> 0x0074 }
            r0.g = r2     // Catch:{ all -> 0x0074 }
            r0.h = r14     // Catch:{ all -> 0x0074 }
            r0.b = r3     // Catch:{ all -> 0x0074 }
            java.lang.Object r13 = r9.a(r13, r0)     // Catch:{ all -> 0x0074 }
            if (r13 != r1) goto L_0x0122
            return r1
        L_0x0122:
            r13 = r14
        L_0x0123:
            if (r8 == 0) goto L_0x014c
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r14 = oh.a.s2.a0.a     // Catch:{ all -> 0x0074 }
            oh.a.t2.v r11 = oh.a.s2.z.a     // Catch:{ all -> 0x0074 }
            java.lang.Object r14 = r14.getAndSet(r8, r11)     // Catch:{ all -> 0x0074 }
            ka.h.c.p.c(r14)     // Catch:{ all -> 0x0074 }
            oh.a.t2.v r11 = oh.a.s2.z.b     // Catch:{ all -> 0x0074 }
            if (r14 != r11) goto L_0x0136
            r14 = r7
            goto L_0x0137
        L_0x0136:
            r14 = r5
        L_0x0137:
            if (r14 != 0) goto L_0x00ef
            r0.d = r10     // Catch:{ all -> 0x0074 }
            r0.f88e = r9     // Catch:{ all -> 0x0074 }
            r0.f = r8     // Catch:{ all -> 0x0074 }
            r0.g = r2     // Catch:{ all -> 0x0074 }
            r0.h = r13     // Catch:{ all -> 0x0074 }
            r0.b = r4     // Catch:{ all -> 0x0074 }
            java.lang.Object r14 = r8.a(r0)     // Catch:{ all -> 0x0074 }
            if (r14 != r1) goto L_0x00ef
            return r1
        L_0x014c:
            throw r6     // Catch:{ all -> 0x0074 }
        L_0x014d:
            r13 = move-exception
            r10 = r12
        L_0x014f:
            monitor-enter(r10)
            int r14 = r10.b     // Catch:{ all -> 0x017f }
            int r14 = r14 + -1
            r10.b = r14     // Catch:{ all -> 0x017f }
            if (r14 != 0) goto L_0x015a
            r10.c = r5     // Catch:{ all -> 0x017f }
        L_0x015a:
            if (r8 == 0) goto L_0x0177
            r8._state = r6     // Catch:{ all -> 0x017f }
            ka.e.d<kotlin.Unit>[] r14 = oh.a.s2.c0.c.a     // Catch:{ all -> 0x017f }
            monitor-exit(r10)
            int r0 = r14.length
        L_0x0162:
            if (r5 >= r0) goto L_0x0176
            r1 = r14[r5]
            if (r1 == 0) goto L_0x0173
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            kotlin.Result$Companion r3 = kotlin.Result.Companion
            java.lang.Object r2 = kotlin.Result.constructor-impl(r2)
            r1.resumeWith(r2)
        L_0x0173:
            int r5 = r5 + 1
            goto L_0x0162
        L_0x0176:
            throw r13
        L_0x0177:
            java.lang.NullPointerException r13 = new java.lang.NullPointerException     // Catch:{ all -> 0x017f }
            java.lang.String r14 = "null cannot be cast to non-null type kotlinx.coroutines.flow.internal.AbstractSharedFlowSlot<kotlin.Any>"
            r13.<init>(r14)     // Catch:{ all -> 0x017f }
            throw r13     // Catch:{ all -> 0x017f }
        L_0x017f:
            r13 = move-exception
            monitor-exit(r10)
            throw r13
        L_0x0182:
            r13 = move-exception
            monitor-exit(r12)
            throw r13
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.y.c(oh.a.s2.f, ka.e.d):java.lang.Object");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x002e, code lost:
        if (r10 == null) goto L_0x0069;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0030, code lost:
        r0 = r10.length;
        r3 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0032, code lost:
        if (r3 >= r0) goto L_0x0069;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0034, code lost:
        r4 = r10[r3];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0036, code lost:
        if (r4 == null) goto L_0x0066;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0038, code lost:
        r5 = r4._state;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x003a, code lost:
        if (r5 != null) goto L_0x003d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x003f, code lost:
        if (r5 != oh.a.s2.z.b) goto L_0x0042;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0042, code lost:
        r6 = oh.a.s2.z.a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x0044, code lost:
        if (r5 != r6) goto L_0x0051;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x004e, code lost:
        if (oh.a.s2.a0.a.compareAndSet(r4, r5, oh.a.s2.z.b) == false) goto L_0x0038;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0057, code lost:
        if (oh.a.s2.a0.a.compareAndSet(r4, r5, r6) == false) goto L_0x0038;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0059, code lost:
        r4 = kotlin.Unit.INSTANCE;
        r6 = kotlin.Result.Companion;
        ((oh.a.l) r5).resumeWith(kotlin.Result.constructor-impl(r4));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0066, code lost:
        r3 = r3 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x0069, code lost:
        monitor-enter(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x006c, code lost:
        if (r8.d != r9) goto L_0x0073;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x006e, code lost:
        r8.d = r9 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x0071, code lost:
        monitor-exit(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x0072, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:?, code lost:
        r9 = r8.d;
        r10 = (oh.a.s2.a0[]) r8.a;
        r0 = kotlin.Unit.INSTANCE;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:46:0x007b, code lost:
        monitor-exit(r8);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean d(java.lang.Object r9, java.lang.Object r10) {
        /*
            r8 = this;
            S[] r0 = r8.a
            oh.a.s2.a0[] r0 = (oh.a.s2.a0[]) r0
            monitor-enter(r8)
            java.lang.Object r0 = r8._state     // Catch:{ all -> 0x0086 }
            r1 = 0
            r2 = 1
            if (r9 == 0) goto L_0x0014
            boolean r9 = ka.h.c.p.b(r0, r9)     // Catch:{ all -> 0x0086 }
            r9 = r9 ^ r2
            if (r9 == 0) goto L_0x0014
            monitor-exit(r8)
            return r1
        L_0x0014:
            boolean r9 = ka.h.c.p.b(r0, r10)     // Catch:{ all -> 0x0086 }
            if (r9 == 0) goto L_0x001c
            monitor-exit(r8)
            return r2
        L_0x001c:
            r8._state = r10     // Catch:{ all -> 0x0086 }
            int r9 = r8.d     // Catch:{ all -> 0x0086 }
            r10 = r9 & 1
            if (r10 != 0) goto L_0x0080
            int r9 = r9 + r2
            r8.d = r9     // Catch:{ all -> 0x0086 }
            S[] r10 = r8.a     // Catch:{ all -> 0x0086 }
            oh.a.s2.a0[] r10 = (oh.a.s2.a0[]) r10     // Catch:{ all -> 0x0086 }
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x0086 }
            monitor-exit(r8)
        L_0x002e:
            if (r10 == 0) goto L_0x0069
            int r0 = r10.length
            r3 = r1
        L_0x0032:
            if (r3 >= r0) goto L_0x0069
            r4 = r10[r3]
            if (r4 == 0) goto L_0x0066
        L_0x0038:
            java.lang.Object r5 = r4._state
            if (r5 != 0) goto L_0x003d
            goto L_0x0066
        L_0x003d:
            oh.a.t2.v r6 = oh.a.s2.z.b
            if (r5 != r6) goto L_0x0042
            goto L_0x0066
        L_0x0042:
            oh.a.t2.v r6 = oh.a.s2.z.a
            if (r5 != r6) goto L_0x0051
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r6 = oh.a.s2.a0.a
            oh.a.t2.v r7 = oh.a.s2.z.b
            boolean r5 = r6.compareAndSet(r4, r5, r7)
            if (r5 == 0) goto L_0x0038
            goto L_0x0066
        L_0x0051:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r7 = oh.a.s2.a0.a
            boolean r6 = r7.compareAndSet(r4, r5, r6)
            if (r6 == 0) goto L_0x0038
            oh.a.l r5 = (oh.a.l) r5
            kotlin.Unit r4 = kotlin.Unit.INSTANCE
            kotlin.Result$Companion r6 = kotlin.Result.Companion
            java.lang.Object r4 = kotlin.Result.constructor-impl(r4)
            r5.resumeWith(r4)
        L_0x0066:
            int r3 = r3 + 1
            goto L_0x0032
        L_0x0069:
            monitor-enter(r8)
            int r10 = r8.d     // Catch:{ all -> 0x007d }
            if (r10 != r9) goto L_0x0073
            int r9 = r9 + r2
            r8.d = r9     // Catch:{ all -> 0x007d }
            monitor-exit(r8)
            return r2
        L_0x0073:
            int r9 = r8.d     // Catch:{ all -> 0x007d }
            S[] r10 = r8.a     // Catch:{ all -> 0x007d }
            oh.a.s2.a0[] r10 = (oh.a.s2.a0[]) r10     // Catch:{ all -> 0x007d }
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch:{ all -> 0x007d }
            monitor-exit(r8)
            goto L_0x002e
        L_0x007d:
            r9 = move-exception
            monitor-exit(r8)
            throw r9
        L_0x0080:
            int r9 = r9 + 2
            r8.d = r9     // Catch:{ all -> 0x0086 }
            monitor-exit(r8)
            return r2
        L_0x0086:
            r9 = move-exception
            monitor-exit(r8)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.y.d(java.lang.Object, java.lang.Object):boolean");
    }

    public T getValue() {
        T t = m.a;
        T t2 = this._state;
        if (t2 == t) {
            return null;
        }
        return t2;
    }

    public void setValue(T t) {
        if (t == null) {
            t = m.a;
        }
        d((Object) null, t);
    }
}

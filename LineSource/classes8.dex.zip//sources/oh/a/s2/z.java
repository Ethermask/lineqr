package oh.a.s2;

import oh.a.t2.v;

public final class z {
    public static final v a = new v("NONE");
    public static final v b = new v("PENDING");
}

package oh.a.s2;

public interface w<T> extends w<T>, Object<T> {
    T getValue();

    void setValue(T t);
}

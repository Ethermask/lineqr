package oh.a.s2;

import ka.e.d;
import ka.e.j.a;
import kotlin.Unit;

public final class h implements e<T> {
    public final /* synthetic */ Object a;

    public h(Object obj) {
        this.a = obj;
    }

    public Object c(f fVar, d dVar) {
        Object a2 = fVar.a(this.a, dVar);
        if (a2 == a.COROUTINE_SUSPENDED) {
            return a2;
        }
        return Unit.INSTANCE;
    }
}

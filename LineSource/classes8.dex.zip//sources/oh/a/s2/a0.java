package oh.a.s2;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.b.q;
import ka.e.j.a;
import ka.h.c.p;
import kotlin.Result;
import kotlin.Unit;
import oh.a.l;
import oh.a.s2.c0.d;

public final class a0 extends d<y<?>> {
    public static final /* synthetic */ AtomicReferenceFieldUpdater a = AtomicReferenceFieldUpdater.newUpdater(a0.class, Object.class, "_state");
    public volatile /* synthetic */ Object _state = null;

    public final Object a(ka.e.d<? super Unit> dVar) {
        l lVar = new l(q.M1(dVar), 1);
        lVar.D();
        if (!a.compareAndSet(this, z.a, lVar)) {
            Unit unit = Unit.INSTANCE;
            Result.Companion companion = Result.Companion;
            lVar.resumeWith(Result.constructor-impl(unit));
        }
        Object t = lVar.t();
        if (t == a.COROUTINE_SUSPENDED) {
            p.e(dVar, "frame");
        }
        return t;
    }
}

package oh.a.s2;

import java.util.Collection;
import ka.b.q;
import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;

@e(c = "kotlinx.coroutines.flow.FlowKt__CollectionKt", f = "Collection.kt", l = {32}, m = "toCollection")
public final class k extends c {
    public /* synthetic */ Object a;
    public int b;
    public Object c;

    public k(d dVar) {
        super(dVar);
    }

    public final Object invokeSuspend(Object obj) {
        this.a = obj;
        this.b |= Integer.MIN_VALUE;
        return q.C3((e) null, (Collection) null, this);
    }
}

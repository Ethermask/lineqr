package oh.a.s2;

import ka.e.d;
import ka.e.k.a.e;
import ka.e.k.a.i;
import ka.h.b.p;
import ka.h.b.r;
import kotlin.Unit;

@e(c = "kotlinx.coroutines.flow.FlowKt__ErrorsKt$retry$3", f = "Errors.kt", l = {124}, m = "invokeSuspend")
public final class o extends i implements r<f<? super T>, Throwable, Long, d<? super Boolean>, Object> {
    public /* synthetic */ Object a;
    public /* synthetic */ long b;
    public int c;
    public final /* synthetic */ long d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ p f85e;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public o(long j, p pVar, d dVar) {
        super(4, dVar);
        this.d = j;
        this.f85e = pVar;
    }

    public final Object e(Object obj, Object obj2, Object obj3, Object obj4) {
        f fVar = (f) obj;
        long longValue = ((Number) obj3).longValue();
        o oVar = new o(this.d, this.f85e, (d) obj4);
        oVar.a = (Throwable) obj2;
        oVar.b = longValue;
        return oVar.invokeSuspend(Unit.INSTANCE);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0035, code lost:
        if (((java.lang.Boolean) r8).booleanValue() != false) goto L_0x0039;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invokeSuspend(java.lang.Object r8) {
        /*
            r7 = this;
            ka.e.j.a r0 = ka.e.j.a.COROUTINE_SUSPENDED
            int r1 = r7.c
            r2 = 1
            if (r1 == 0) goto L_0x0015
            if (r1 != r2) goto L_0x000d
            kotlin.ResultKt.throwOnFailure(r8)
            goto L_0x002f
        L_0x000d:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r0)
            throw r8
        L_0x0015:
            kotlin.ResultKt.throwOnFailure(r8)
            java.lang.Object r8 = r7.a
            java.lang.Throwable r8 = (java.lang.Throwable) r8
            long r3 = r7.b
            long r5 = r7.d
            int r1 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r1 >= 0) goto L_0x0038
            ka.h.b.p r1 = r7.f85e
            r7.c = r2
            java.lang.Object r8 = r1.invoke(r8, r7)
            if (r8 != r0) goto L_0x002f
            return r0
        L_0x002f:
            java.lang.Boolean r8 = (java.lang.Boolean) r8
            boolean r8 = r8.booleanValue()
            if (r8 == 0) goto L_0x0038
            goto L_0x0039
        L_0x0038:
            r2 = 0
        L_0x0039:
            java.lang.Boolean r8 = java.lang.Boolean.valueOf(r2)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.o.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}

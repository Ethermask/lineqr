package oh.a.s2;

import ka.b.q;
import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;

@e(c = "kotlinx.coroutines.flow.FlowKt__ReduceKt", f = "Reduce.kt", l = {148}, m = "reduce")
public final class u extends c {
    public /* synthetic */ Object a;
    public int b;
    public Object c;

    public u(d dVar) {
        super(dVar);
    }

    public final Object invokeSuspend(Object obj) {
        this.a = obj;
        this.b |= Integer.MIN_VALUE;
        return q.K2((e) null, (ka.h.b.q) null, this);
    }
}

package oh.a.s2;

import ka.e.d;
import ka.h.b.p;
import kotlin.Unit;

public final class x<T> extends a<T> {
    public final p<f<? super T>, d<? super Unit>, Object> a;

    public x(p<? super f<? super T>, ? super d<? super Unit>, ? extends Object> pVar) {
        this.a = pVar;
    }
}

package oh.a.s2;

import java.util.Collection;
import ka.e.d;
import kotlin.Unit;

public final class j implements f<T> {
    public final /* synthetic */ Collection a;

    public j(Collection collection) {
        this.a = collection;
    }

    public Object a(Object obj, d dVar) {
        this.a.add(obj);
        return Unit.INSTANCE;
    }
}

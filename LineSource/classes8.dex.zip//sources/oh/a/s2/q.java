package oh.a.s2;

import ka.e.d;
import kotlin.Unit;

public final /* synthetic */ class q {

    public static final class a implements e<T> {
        public final /* synthetic */ e a;

        /* renamed from: oh.a.s2.q$a$a  reason: collision with other inner class name */
        public static final class C0005a implements f<e<? extends T>> {
            public final /* synthetic */ f a;

            public C0005a(f fVar) {
                this.a = fVar;
            }

            public Object a(Object obj, d dVar) {
                Object c = ((e) obj).c(this.a, dVar);
                if (c == ka.e.j.a.COROUTINE_SUSPENDED) {
                    return c;
                }
                return Unit.INSTANCE;
            }
        }

        public a(e eVar) {
            this.a = eVar;
        }

        public Object c(f fVar, d dVar) {
            Object c = this.a.c(new C0005a(fVar), dVar);
            if (c == ka.e.j.a.COROUTINE_SUSPENDED) {
                return c;
            }
            return Unit.INSTANCE;
        }
    }

    static {
        ka.b.q.t3("kotlinx.coroutines.flow.defaultConcurrency", 16, 1, Integer.MAX_VALUE);
    }

    public static final <T> e<T> a(e<? extends e<? extends T>> eVar) {
        return new a(eVar);
    }
}

package oh.a.s2;

import ka.e.k.a.c;
import ka.e.k.a.e;
import ka.h.b.l;
import ka.h.b.p;
import ka.h.c.h0;
import kotlin.Unit;
import oh.a.s2.c0.m;

public final class d<T> implements e<T> {
    public final e<T> a;
    public final l<T, Object> b;
    public final p<Object, Object, Boolean> c;

    public static final class a implements f<T> {
        public final /* synthetic */ d a;
        public final /* synthetic */ h0 b;
        public final /* synthetic */ f c;

        @e(c = "kotlinx.coroutines.flow.DistinctFlowImpl$collect$$inlined$collect$1", f = "Distinct.kt", l = {137}, m = "emit")
        /* renamed from: oh.a.s2.d$a$a  reason: collision with other inner class name */
        public static final class C0004a extends c {
            public /* synthetic */ Object a;
            public int b;
            public final /* synthetic */ a c;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C0004a(a aVar, ka.e.d dVar) {
                super(dVar);
                this.c = aVar;
            }

            public final Object invokeSuspend(Object obj) {
                this.a = obj;
                this.b |= Integer.MIN_VALUE;
                return this.c.a((Object) null, this);
            }
        }

        public a(d dVar, h0 h0Var, f fVar) {
            this.a = dVar;
            this.b = h0Var;
            this.c = fVar;
        }

        /* JADX WARNING: Removed duplicated region for block: B:12:0x002f  */
        /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public java.lang.Object a(java.lang.Object r6, ka.e.d r7) {
            /*
                r5 = this;
                boolean r0 = r7 instanceof oh.a.s2.d.a.C0004a
                if (r0 == 0) goto L_0x0013
                r0 = r7
                oh.a.s2.d$a$a r0 = (oh.a.s2.d.a.C0004a) r0
                int r1 = r0.b
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L_0x0013
                int r1 = r1 - r2
                r0.b = r1
                goto L_0x0018
            L_0x0013:
                oh.a.s2.d$a$a r0 = new oh.a.s2.d$a$a
                r0.<init>(r5, r7)
            L_0x0018:
                java.lang.Object r7 = r0.a
                ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
                int r2 = r0.b
                r3 = 1
                if (r2 == 0) goto L_0x002f
                if (r2 != r3) goto L_0x0027
                kotlin.ResultKt.throwOnFailure(r7)
                goto L_0x0061
            L_0x0027:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r7)
                throw r6
            L_0x002f:
                kotlin.ResultKt.throwOnFailure(r7)
                oh.a.s2.d r7 = r5.a
                ka.h.b.l<T, java.lang.Object> r7 = r7.b
                java.lang.Object r7 = r7.invoke(r6)
                ka.h.c.h0 r2 = r5.b
                java.lang.Object r2 = r2.a
                oh.a.t2.v r4 = oh.a.s2.c0.m.a
                if (r2 == r4) goto L_0x0052
                oh.a.s2.d r4 = r5.a
                ka.h.b.p<java.lang.Object, java.lang.Object, java.lang.Boolean> r4 = r4.c
                java.lang.Object r2 = r4.invoke(r2, r7)
                java.lang.Boolean r2 = (java.lang.Boolean) r2
                boolean r2 = r2.booleanValue()
                if (r2 != 0) goto L_0x0061
            L_0x0052:
                ka.h.c.h0 r2 = r5.b
                r2.a = r7
                oh.a.s2.f r7 = r5.c
                r0.b = r3
                java.lang.Object r6 = r7.a(r6, r0)
                if (r6 != r1) goto L_0x0061
                return r1
            L_0x0061:
                kotlin.Unit r6 = kotlin.Unit.INSTANCE
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.d.a.a(java.lang.Object, ka.e.d):java.lang.Object");
        }
    }

    public d(e<? extends T> eVar, l<? super T, ? extends Object> lVar, p<Object, Object, Boolean> pVar) {
        this.a = eVar;
        this.b = lVar;
        this.c = pVar;
    }

    public Object c(f<? super T> fVar, ka.e.d<? super Unit> dVar) {
        h0 h0Var = new h0();
        h0Var.a = m.a;
        Object c2 = this.a.c(new a(this, h0Var, fVar), dVar);
        if (c2 == ka.e.j.a.COROUTINE_SUSPENDED) {
            return c2;
        }
        return Unit.INSTANCE;
    }
}

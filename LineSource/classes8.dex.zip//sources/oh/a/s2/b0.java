package oh.a.s2;

import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;
import kotlin.Unit;

public final class b0<T> implements f<T> {
    public final f<T> a;

    @e(c = "kotlinx.coroutines.flow.SubscribedFlowCollector", f = "Share.kt", l = {407, 411}, m = "onSubscription")
    public static final class a extends c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ b0 c;
        public Object d;

        /* renamed from: e  reason: collision with root package name */
        public Object f81e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(b0 b0Var, d dVar) {
            super(dVar);
            this.c = b0Var;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return this.c.b(this);
        }
    }

    public Object a(T t, d<? super Unit> dVar) {
        throw null;
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0059  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0022  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object b(ka.e.d<? super kotlin.Unit> r7) {
        /*
            r6 = this;
            boolean r0 = r7 instanceof oh.a.s2.b0.a
            if (r0 == 0) goto L_0x0013
            r0 = r7
            oh.a.s2.b0$a r0 = (oh.a.s2.b0.a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.s2.b0$a r0 = new oh.a.s2.b0$a
            r0.<init>(r6, r7)
        L_0x0018:
            java.lang.Object r7 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 1
            r4 = 0
            if (r2 == 0) goto L_0x0059
            r5 = 2
            if (r2 == r3) goto L_0x0033
            if (r2 != r5) goto L_0x002b
            kotlin.ResultKt.throwOnFailure(r7)
            goto L_0x0056
        L_0x002b:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r0)
            throw r7
        L_0x0033:
            java.lang.Object r2 = r0.f81e
            oh.a.s2.c0.n r2 = (oh.a.s2.c0.n) r2
            java.lang.Object r3 = r0.d
            oh.a.s2.b0 r3 = (oh.a.s2.b0) r3
            kotlin.ResultKt.throwOnFailure(r7)     // Catch:{ all -> 0x006c }
            r2.releaseIntercepted()
            oh.a.s2.f<T> r7 = r3.a
            boolean r2 = r7 instanceof oh.a.s2.b0
            if (r2 == 0) goto L_0x0056
            oh.a.s2.b0 r7 = (oh.a.s2.b0) r7
            r0.d = r4
            r0.f81e = r4
            r0.b = r5
            java.lang.Object r7 = r7.b(r0)
            if (r7 != r1) goto L_0x0056
            return r1
        L_0x0056:
            kotlin.Unit r7 = kotlin.Unit.INSTANCE
            return r7
        L_0x0059:
            kotlin.ResultKt.throwOnFailure(r7)
            ka.e.f r7 = r0.getContext()
            oh.a.s2.c0.n r2 = new oh.a.s2.c0.n
            r2.<init>(r4, r7)
            r0.d = r6     // Catch:{ all -> 0x006c }
            r0.f81e = r2     // Catch:{ all -> 0x006c }
            r0.b = r3     // Catch:{ all -> 0x006c }
            throw r4     // Catch:{ all -> 0x006c }
        L_0x006c:
            r7 = move-exception
            r2.releaseIntercepted()
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.b0.b(ka.e.d):java.lang.Object");
    }
}

package oh.a.s2;

import ka.e.d;
import kotlin.Unit;

public interface f<T> {
    Object a(T t, d<? super Unit> dVar);
}

package oh.a.s2;

import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;
import ka.h.b.r;

public final class p implements e<T> {
    public final /* synthetic */ e a;
    public final /* synthetic */ r b;

    @e(c = "kotlinx.coroutines.flow.FlowKt__ErrorsKt$retryWhen$$inlined$unsafeFlow$1", f = "Errors.kt", l = {117, 119}, m = "collect")
    public static final class a extends c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ p c;
        public Object d;

        /* renamed from: e  reason: collision with root package name */
        public Object f86e;
        public Object f;
        public long g;
        public int h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(p pVar, d dVar) {
            super(dVar);
            this.c = pVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return this.c.c((f) null, this);
        }
    }

    public p(e eVar, r rVar) {
        this.a = eVar;
        this.b = rVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0050  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x006d  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0077  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00a3  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00a6  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0022  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object c(oh.a.s2.f r12, ka.e.d r13) {
        /*
            r11 = this;
            boolean r0 = r13 instanceof oh.a.s2.p.a
            if (r0 == 0) goto L_0x0013
            r0 = r13
            oh.a.s2.p$a r0 = (oh.a.s2.p.a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.s2.p$a r0 = new oh.a.s2.p$a
            r0.<init>(r11, r13)
        L_0x0018:
            java.lang.Object r13 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L_0x0050
            if (r2 == r4) goto L_0x0040
            if (r2 != r3) goto L_0x0038
            long r5 = r0.g
            java.lang.Object r12 = r0.f
            java.lang.Throwable r12 = (java.lang.Throwable) r12
            java.lang.Object r2 = r0.f86e
            oh.a.s2.f r2 = (oh.a.s2.f) r2
            java.lang.Object r7 = r0.d
            oh.a.s2.p r7 = (oh.a.s2.p) r7
            kotlin.ResultKt.throwOnFailure(r13)
            goto L_0x0092
        L_0x0038:
            java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
            java.lang.String r13 = "call to 'resume' before 'invoke' with coroutine"
            r12.<init>(r13)
            throw r12
        L_0x0040:
            int r12 = r0.h
            long r5 = r0.g
            java.lang.Object r2 = r0.f86e
            oh.a.s2.f r2 = (oh.a.s2.f) r2
            java.lang.Object r7 = r0.d
            oh.a.s2.p r7 = (oh.a.s2.p) r7
            kotlin.ResultKt.throwOnFailure(r13)
            goto L_0x0073
        L_0x0050:
            kotlin.ResultKt.throwOnFailure(r13)
            r5 = 0
            r13 = r11
        L_0x0056:
            r2 = 0
            oh.a.s2.e r7 = r13.a
            r0.d = r13
            r0.f86e = r12
            r8 = 0
            r0.f = r8
            r0.g = r5
            r0.h = r2
            r0.b = r4
            java.lang.Object r7 = ka.b.q.V(r7, r12, r0)
            if (r7 != r1) goto L_0x006d
            return r1
        L_0x006d:
            r9 = r2
            r2 = r12
            r12 = r9
            r10 = r7
            r7 = r13
            r13 = r10
        L_0x0073:
            java.lang.Throwable r13 = (java.lang.Throwable) r13
            if (r13 == 0) goto L_0x00a0
            ka.h.b.r r12 = r7.b
            java.lang.Long r8 = new java.lang.Long
            r8.<init>(r5)
            r0.d = r7
            r0.f86e = r2
            r0.f = r13
            r0.g = r5
            r0.b = r3
            java.lang.Object r12 = r12.e(r2, r13, r8, r0)
            if (r12 != r1) goto L_0x008f
            return r1
        L_0x008f:
            r9 = r13
            r13 = r12
            r12 = r9
        L_0x0092:
            java.lang.Boolean r13 = (java.lang.Boolean) r13
            boolean r13 = r13.booleanValue()
            if (r13 == 0) goto L_0x009f
            r12 = 1
            long r5 = r5 + r12
            r12 = r4
            goto L_0x00a0
        L_0x009f:
            throw r12
        L_0x00a0:
            r13 = r7
            if (r12 != 0) goto L_0x00a6
            kotlin.Unit r12 = kotlin.Unit.INSTANCE
            return r12
        L_0x00a6:
            r12 = r2
            goto L_0x0056
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.p.c(oh.a.s2.f, ka.e.d):java.lang.Object");
    }
}

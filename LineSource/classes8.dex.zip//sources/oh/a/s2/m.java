package oh.a.s2;

import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;
import ka.h.c.h0;

public final class m implements f<T> {
    public final /* synthetic */ f a;
    public final /* synthetic */ h0 b;

    @e(c = "kotlinx.coroutines.flow.FlowKt__ErrorsKt$catchImpl$$inlined$collect$1", f = "Errors.kt", l = {134}, m = "emit")
    public static final class a extends c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ m c;
        public Object d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(m mVar, d dVar) {
            super(dVar);
            this.c = mVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return this.c.a((Object) null, this);
        }
    }

    public m(f fVar, h0 h0Var) {
        this.a = fVar;
        this.b = h0Var;
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object a(java.lang.Object r5, ka.e.d r6) {
        /*
            r4 = this;
            boolean r0 = r6 instanceof oh.a.s2.m.a
            if (r0 == 0) goto L_0x0013
            r0 = r6
            oh.a.s2.m$a r0 = (oh.a.s2.m.a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.s2.m$a r0 = new oh.a.s2.m$a
            r0.<init>(r4, r6)
        L_0x0018:
            java.lang.Object r6 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 1
            if (r2 == 0) goto L_0x0035
            if (r2 != r3) goto L_0x002d
            java.lang.Object r5 = r0.d
            oh.a.s2.m r5 = (oh.a.s2.m) r5
            kotlin.ResultKt.throwOnFailure(r6)     // Catch:{ all -> 0x002b }
            goto L_0x0045
        L_0x002b:
            r6 = move-exception
            goto L_0x004a
        L_0x002d:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r6)
            throw r5
        L_0x0035:
            kotlin.ResultKt.throwOnFailure(r6)
            oh.a.s2.f r6 = r4.a     // Catch:{ all -> 0x0048 }
            r0.d = r4     // Catch:{ all -> 0x0048 }
            r0.b = r3     // Catch:{ all -> 0x0048 }
            java.lang.Object r5 = r6.a(r5, r0)     // Catch:{ all -> 0x0048 }
            if (r5 != r1) goto L_0x0045
            return r1
        L_0x0045:
            kotlin.Unit r5 = kotlin.Unit.INSTANCE
            return r5
        L_0x0048:
            r6 = move-exception
            r5 = r4
        L_0x004a:
            ka.h.c.h0 r5 = r5.b
            r5.a = r6
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.m.a(java.lang.Object, ka.e.d):java.lang.Object");
    }
}

package oh.a.s2;

import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;

public final class g implements e<T> {
    public final /* synthetic */ Iterable a;

    @e(c = "kotlinx.coroutines.flow.FlowKt__BuildersKt$asFlow$$inlined$unsafeFlow$3", f = "Builders.kt", l = {115}, m = "collect")
    public static final class a extends c {
        public /* synthetic */ Object a;
        public int b;
        public final /* synthetic */ g c;
        public Object d;

        /* renamed from: e  reason: collision with root package name */
        public Object f83e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(g gVar, d dVar) {
            super(dVar);
            this.c = gVar;
        }

        public final Object invokeSuspend(Object obj) {
            this.a = obj;
            this.b |= Integer.MIN_VALUE;
            return this.c.c((f) null, this);
        }
    }

    public g(Iterable iterable) {
        this.a = iterable;
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0038  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object c(oh.a.s2.f r6, ka.e.d r7) {
        /*
            r5 = this;
            boolean r0 = r7 instanceof oh.a.s2.g.a
            if (r0 == 0) goto L_0x0013
            r0 = r7
            oh.a.s2.g$a r0 = (oh.a.s2.g.a) r0
            int r1 = r0.b
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.b = r1
            goto L_0x0018
        L_0x0013:
            oh.a.s2.g$a r0 = new oh.a.s2.g$a
            r0.<init>(r5, r7)
        L_0x0018:
            java.lang.Object r7 = r0.a
            ka.e.j.a r1 = ka.e.j.a.COROUTINE_SUSPENDED
            int r2 = r0.b
            r3 = 1
            if (r2 == 0) goto L_0x0038
            if (r2 != r3) goto L_0x0030
            java.lang.Object r6 = r0.f83e
            java.util.Iterator r6 = (java.util.Iterator) r6
            java.lang.Object r2 = r0.d
            oh.a.s2.f r2 = (oh.a.s2.f) r2
            kotlin.ResultKt.throwOnFailure(r7)
            r7 = r2
            goto L_0x0044
        L_0x0030:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L_0x0038:
            kotlin.ResultKt.throwOnFailure(r7)
            java.lang.Iterable r7 = r5.a
            java.util.Iterator r7 = r7.iterator()
            r4 = r7
            r7 = r6
            r6 = r4
        L_0x0044:
            boolean r2 = r6.hasNext()
            if (r2 == 0) goto L_0x005b
            java.lang.Object r2 = r6.next()
            r0.d = r7
            r0.f83e = r6
            r0.b = r3
            java.lang.Object r2 = r7.a(r2, r0)
            if (r2 != r1) goto L_0x0044
            return r1
        L_0x005b:
            kotlin.Unit r6 = kotlin.Unit.INSTANCE
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: oh.a.s2.g.c(oh.a.s2.f, ka.e.d):java.lang.Object");
    }
}

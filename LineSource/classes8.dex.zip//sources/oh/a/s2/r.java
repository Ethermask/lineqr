package oh.a.s2;

import ka.e.d;
import ka.h.c.h0;
import oh.a.s2.c0.a;

public final class r implements f<T> {
    public final /* synthetic */ h0 a;

    public r(h0 h0Var) {
        this.a = h0Var;
    }

    public Object a(Object obj, d dVar) {
        this.a.a = obj;
        throw new a(this);
    }
}

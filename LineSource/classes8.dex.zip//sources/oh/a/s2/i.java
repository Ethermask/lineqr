package oh.a.s2;

import ka.b.q;
import ka.e.d;
import ka.e.k.a.c;
import ka.e.k.a.e;
import oh.a.r2.t;

@e(c = "kotlinx.coroutines.flow.FlowKt__ChannelsKt", f = "Channels.kt", l = {50, 61}, m = "emitAllImpl$FlowKt__ChannelsKt")
public final class i extends c {
    public /* synthetic */ Object a;
    public int b;
    public Object c;
    public Object d;

    /* renamed from: e  reason: collision with root package name */
    public Object f84e;
    public boolean f;

    public i(d dVar) {
        super(dVar);
    }

    public final Object invokeSuspend(Object obj) {
        this.a = obj;
        this.b |= Integer.MIN_VALUE;
        return q.z0((f) null, (t) null, false, this);
    }
}

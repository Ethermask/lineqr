package oh.a;

public abstract class a1 extends y0 {
    public abstract Thread y0();
}

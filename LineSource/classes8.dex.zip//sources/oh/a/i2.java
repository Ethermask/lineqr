package oh.a;

public final class i2 {
    public static final ThreadLocal<y0> a = new ThreadLocal<>();
    public static final i2 b = null;

    public static final y0 a() {
        y0 y0Var = a.get();
        if (y0Var != null) {
            return y0Var;
        }
        g gVar = new g(Thread.currentThread());
        a.set(gVar);
        return gVar;
    }
}

package oh.a;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import ka.h.b.l;
import kotlin.Unit;

public final class l1 extends p1 {
    public static final /* synthetic */ AtomicIntegerFieldUpdater f = AtomicIntegerFieldUpdater.newUpdater(l1.class, "_invoked");
    public volatile /* synthetic */ int _invoked = 0;

    /* renamed from: e  reason: collision with root package name */
    public final l<Throwable, Unit> f63e;

    public l1(l<? super Throwable, Unit> lVar) {
        this.f63e = lVar;
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        w((Throwable) obj);
        return Unit.INSTANCE;
    }

    public void w(Throwable th2) {
        if (f.compareAndSet(this, 0, 1)) {
            this.f63e.invoke(th2);
        }
    }
}

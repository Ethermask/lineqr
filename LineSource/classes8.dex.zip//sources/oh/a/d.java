package oh.a;

import java.util.Collection;
import ka.b.q;
import ka.e.k.a.c;
import ka.e.k.a.e;

@e(c = "kotlinx.coroutines.AwaitKt", f = "Await.kt", l = {42}, m = "awaitAll")
public final class d extends c {
    public /* synthetic */ Object a;
    public int b;

    public d(ka.e.d dVar) {
        super(dVar);
    }

    public final Object invokeSuspend(Object obj) {
        this.a = obj;
        this.b |= Integer.MIN_VALUE;
        return q.z((Collection) null, this);
    }
}

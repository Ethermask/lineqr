package oh.a;

public final class j0 extends Error {
    public j0(String str, Throwable th2) {
        super(str, th2);
    }
}

package oh.a;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import ka.h.c.p;
import kotlin.Result;
import kotlin.Unit;

public final class c<T> {
    public static final /* synthetic */ AtomicIntegerFieldUpdater b = AtomicIntegerFieldUpdater.newUpdater(c.class, "notCompletedCount");
    public final m0<T>[] a;
    public volatile /* synthetic */ int notCompletedCount;

    public final class a extends r1 {
        public volatile /* synthetic */ Object _disposer = null;

        /* renamed from: e  reason: collision with root package name */
        public u0 f57e;
        public final k<List<? extends T>> f;

        public a(k<? super List<? extends T>> kVar) {
            this.f = kVar;
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            w((Throwable) obj);
            return Unit.INSTANCE;
        }

        public void w(Throwable th2) {
            if (th2 != null) {
                Object m = this.f.m(th2);
                if (m != null) {
                    this.f.z(m);
                    b bVar = (b) this._disposer;
                    if (bVar != null) {
                        bVar.b();
                        return;
                    }
                    return;
                }
                return;
            }
            if (c.b.decrementAndGet(c.this) == 0) {
                k<List<? extends T>> kVar = this.f;
                m0<T>[] m0VarArr = c.this.a;
                ArrayList arrayList = new ArrayList(m0VarArr.length);
                for (m0<T> g2 : m0VarArr) {
                    arrayList.add(g2.g());
                }
                Result.Companion companion = Result.Companion;
                kVar.resumeWith(Result.constructor-impl(arrayList));
            }
        }
    }

    public final class b extends i {
        public final c<T>.a[] a;

        public b(c cVar, c<T>.a[] aVarArr) {
            this.a = aVarArr;
        }

        public void a(Throwable th2) {
            b();
        }

        public final void b() {
            c<T>.a[] aVarArr = this.a;
            int length = aVarArr.length;
            int i = 0;
            while (i < length) {
                u0 u0Var = aVarArr[i].f57e;
                if (u0Var != null) {
                    u0Var.dispose();
                    i++;
                } else {
                    p.l("handle");
                    throw null;
                }
            }
        }

        public Object invoke(Object obj) {
            Throwable th2 = (Throwable) obj;
            b();
            return Unit.INSTANCE;
        }

        public String toString() {
            StringBuilder V0 = e.e.b.a.a.V0("DisposeHandlersOnCancel[");
            V0.append(this.a);
            V0.append(']');
            return V0.toString();
        }
    }

    public c(m0<? extends T>[] m0VarArr) {
        this.a = m0VarArr;
        this.notCompletedCount = m0VarArr.length;
    }
}

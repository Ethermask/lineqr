package oh.a;

import e.e.b.a.a;
import kotlin.Unit;
import oh.a.t2.l;

public final class b2 extends e {
    public final l a;

    public b2(l lVar) {
        this.a = lVar;
    }

    public void a(Throwable th2) {
        this.a.t();
    }

    public Object invoke(Object obj) {
        Throwable th2 = (Throwable) obj;
        this.a.t();
        return Unit.INSTANCE;
    }

    public String toString() {
        StringBuilder V0 = a.V0("RemoveOnCancel[");
        V0.append(this.a);
        V0.append(']');
        return V0.toString();
    }
}

package oh.a;

import ka.h.b.l;
import kotlin.Unit;

public final class m1 extends r1 {

    /* renamed from: e  reason: collision with root package name */
    public final l<Throwable, Unit> f65e;

    public m1(l<? super Throwable, Unit> lVar) {
        this.f65e = lVar;
    }

    public Object invoke(Object obj) {
        this.f65e.invoke((Throwable) obj);
        return Unit.INSTANCE;
    }

    public void w(Throwable th2) {
        this.f65e.invoke(th2);
    }
}

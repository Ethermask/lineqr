package oh.a;

import java.io.Closeable;
import java.util.concurrent.Executor;
import ka.e.b;
import ka.e.f;
import ka.h.c.p;
import oh.a.e0;

public abstract class d1 extends e0 implements Closeable {
    static {
        e0.a aVar = e0.a;
        c1 c1Var = c1.a;
        p.e(aVar, "baseKey");
        p.e(c1Var, "safeCast");
        if (aVar instanceof b) {
            f.b bVar = aVar.a;
        }
    }

    public abstract Executor h0();
}

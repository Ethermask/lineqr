package oh.a;

import ka.e.f;

public final class m2 extends e0 {
    public static final m2 b = new m2();

    public void d0(f fVar, Runnable runnable) {
        p2 p2Var = fVar.get(p2.b);
        if (p2Var != null) {
            p2Var.a = true;
            return;
        }
        throw new UnsupportedOperationException("Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls.");
    }

    public boolean g0(f fVar) {
        return false;
    }

    public String toString() {
        return "Dispatchers.Unconfined";
    }
}

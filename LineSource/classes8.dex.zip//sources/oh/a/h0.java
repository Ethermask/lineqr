package oh.a;

import ka.e.f;

public interface h0 {
    f getCoroutineContext();
}

package kotlin.reflect.jvm.internal.impl.serialization.deserialization;

import e.e.b.a.a;
import ka.h.c.p;
import kotlin.reflect.jvm.internal.impl.name.ClassId;

public final class IncompatibleVersionErrorData<T> {
    public final T actualVersion;
    public final ClassId classId;
    public final T expectedVersion;
    public final String filePath;

    public IncompatibleVersionErrorData(T t, T t2, String str, ClassId classId2) {
        p.e(str, "filePath");
        p.e(classId2, "classId");
        this.actualVersion = t;
        this.expectedVersion = t2;
        this.filePath = str;
        this.classId = classId2;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof IncompatibleVersionErrorData)) {
            return false;
        }
        IncompatibleVersionErrorData incompatibleVersionErrorData = (IncompatibleVersionErrorData) obj;
        return p.b(this.actualVersion, incompatibleVersionErrorData.actualVersion) && p.b(this.expectedVersion, incompatibleVersionErrorData.expectedVersion) && p.b(this.filePath, incompatibleVersionErrorData.filePath) && p.b(this.classId, incompatibleVersionErrorData.classId);
    }

    public int hashCode() {
        T t = this.actualVersion;
        int i = 0;
        int hashCode = (t == null ? 0 : t.hashCode()) * 31;
        T t2 = this.expectedVersion;
        if (t2 != null) {
            i = t2.hashCode();
        }
        return this.classId.hashCode() + a.B0(this.filePath, (hashCode + i) * 31, 31);
    }

    public String toString() {
        StringBuilder V0 = a.V0("IncompatibleVersionErrorData(actualVersion=");
        V0.append(this.actualVersion);
        V0.append(", expectedVersion=");
        V0.append(this.expectedVersion);
        V0.append(", filePath=");
        V0.append(this.filePath);
        V0.append(", classId=");
        V0.append(this.classId);
        V0.append(')');
        return V0.toString();
    }
}

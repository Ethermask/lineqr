package kotlin.reflect.jvm.internal.impl.name;

public enum State {
    BEGINNING,
    MIDDLE,
    AFTER_DOT
}

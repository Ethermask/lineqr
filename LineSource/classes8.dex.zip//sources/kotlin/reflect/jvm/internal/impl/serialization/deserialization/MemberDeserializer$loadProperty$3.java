package kotlin.reflect.jvm.internal.impl.serialization.deserialization;

import ka.h.b.a;
import ka.h.c.p;
import ka.h.c.r;
import kotlin.reflect.jvm.internal.impl.descriptors.annotations.AnnotationDescriptor;
import kotlin.reflect.jvm.internal.impl.metadata.ProtoBuf;
import kotlin.reflect.jvm.internal.impl.resolve.constants.ConstantValue;
import kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors.DeserializedPropertyDescriptor;
import kotlin.reflect.jvm.internal.impl.types.KotlinType;

public final class MemberDeserializer$loadProperty$3 extends r implements a<ConstantValue<?>> {
    public final /* synthetic */ DeserializedPropertyDescriptor $property;
    public final /* synthetic */ ProtoBuf.Property $proto;
    public final /* synthetic */ MemberDeserializer this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public MemberDeserializer$loadProperty$3(MemberDeserializer memberDeserializer, ProtoBuf.Property property, DeserializedPropertyDescriptor deserializedPropertyDescriptor) {
        super(0);
        this.this$0 = memberDeserializer;
        this.$proto = property;
        this.$property = deserializedPropertyDescriptor;
    }

    public final ConstantValue<?> invoke() {
        MemberDeserializer memberDeserializer = this.this$0;
        ProtoContainer access$asProtoContainer = memberDeserializer.asProtoContainer(memberDeserializer.c.getContainingDeclaration());
        p.c(access$asProtoContainer);
        AnnotationAndConstantLoader<AnnotationDescriptor, ConstantValue<?>> annotationAndConstantLoader = this.this$0.c.getComponents().getAnnotationAndConstantLoader();
        ProtoBuf.Property property = this.$proto;
        KotlinType returnType = this.$property.getReturnType();
        p.d(returnType, "property.returnType");
        return annotationAndConstantLoader.loadPropertyConstant(access$asProtoContainer, property, returnType);
    }
}

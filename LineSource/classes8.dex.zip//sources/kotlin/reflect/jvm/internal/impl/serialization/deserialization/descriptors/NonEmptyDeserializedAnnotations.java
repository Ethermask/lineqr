package kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors;

import java.util.List;
import ka.h.b.a;
import ka.h.c.p;
import kotlin.reflect.jvm.internal.impl.descriptors.annotations.AnnotationDescriptor;
import kotlin.reflect.jvm.internal.impl.storage.StorageManager;

public final class NonEmptyDeserializedAnnotations extends DeserializedAnnotations {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NonEmptyDeserializedAnnotations(StorageManager storageManager, a<? extends List<? extends AnnotationDescriptor>> aVar) {
        super(storageManager, aVar);
        p.e(storageManager, "storageManager");
        p.e(aVar, "compute");
    }

    public boolean isEmpty() {
        return false;
    }
}

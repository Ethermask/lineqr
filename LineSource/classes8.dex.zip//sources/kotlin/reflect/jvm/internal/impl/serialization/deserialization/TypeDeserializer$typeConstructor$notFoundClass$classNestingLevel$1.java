package kotlin.reflect.jvm.internal.impl.serialization.deserialization;

import ka.a.g;
import ka.h.b.l;
import ka.h.c.i0;
import ka.h.c.m;
import ka.h.c.p;
import kotlin.reflect.jvm.internal.impl.name.ClassId;

public /* synthetic */ class TypeDeserializer$typeConstructor$notFoundClass$classNestingLevel$1 extends m implements l<ClassId, ClassId> {
    public static final TypeDeserializer$typeConstructor$notFoundClass$classNestingLevel$1 INSTANCE = new TypeDeserializer$typeConstructor$notFoundClass$classNestingLevel$1();

    public TypeDeserializer$typeConstructor$notFoundClass$classNestingLevel$1() {
        super(1);
    }

    public final String getName() {
        return "getOuterClassId";
    }

    public final g getOwner() {
        return i0.a(ClassId.class);
    }

    public final String getSignature() {
        return "getOuterClassId()Lorg/jetbrains/kotlin/name/ClassId;";
    }

    public final ClassId invoke(ClassId classId) {
        p.e(classId, "p0");
        return classId.getOuterClassId();
    }
}

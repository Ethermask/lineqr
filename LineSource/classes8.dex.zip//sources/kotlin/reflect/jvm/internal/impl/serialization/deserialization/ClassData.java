package kotlin.reflect.jvm.internal.impl.serialization.deserialization;

import e.e.b.a.a;
import ka.h.c.p;
import kotlin.reflect.jvm.internal.impl.descriptors.SourceElement;
import kotlin.reflect.jvm.internal.impl.metadata.ProtoBuf;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.BinaryVersion;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.NameResolver;

public final class ClassData {
    public final ProtoBuf.Class classProto;
    public final BinaryVersion metadataVersion;
    public final NameResolver nameResolver;
    public final SourceElement sourceElement;

    public ClassData(NameResolver nameResolver2, ProtoBuf.Class classR, BinaryVersion binaryVersion, SourceElement sourceElement2) {
        p.e(nameResolver2, "nameResolver");
        p.e(classR, "classProto");
        p.e(binaryVersion, "metadataVersion");
        p.e(sourceElement2, "sourceElement");
        this.nameResolver = nameResolver2;
        this.classProto = classR;
        this.metadataVersion = binaryVersion;
        this.sourceElement = sourceElement2;
    }

    public final NameResolver component1() {
        return this.nameResolver;
    }

    public final ProtoBuf.Class component2() {
        return this.classProto;
    }

    public final BinaryVersion component3() {
        return this.metadataVersion;
    }

    public final SourceElement component4() {
        return this.sourceElement;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ClassData)) {
            return false;
        }
        ClassData classData = (ClassData) obj;
        return p.b(this.nameResolver, classData.nameResolver) && p.b(this.classProto, classData.classProto) && p.b(this.metadataVersion, classData.metadataVersion) && p.b(this.sourceElement, classData.sourceElement);
    }

    public int hashCode() {
        int hashCode = this.classProto.hashCode();
        int hashCode2 = this.metadataVersion.hashCode();
        return this.sourceElement.hashCode() + ((hashCode2 + ((hashCode + (this.nameResolver.hashCode() * 31)) * 31)) * 31);
    }

    public String toString() {
        StringBuilder V0 = a.V0("ClassData(nameResolver=");
        V0.append(this.nameResolver);
        V0.append(", classProto=");
        V0.append(this.classProto);
        V0.append(", metadataVersion=");
        V0.append(this.metadataVersion);
        V0.append(", sourceElement=");
        V0.append(this.sourceElement);
        V0.append(')');
        return V0.toString();
    }
}

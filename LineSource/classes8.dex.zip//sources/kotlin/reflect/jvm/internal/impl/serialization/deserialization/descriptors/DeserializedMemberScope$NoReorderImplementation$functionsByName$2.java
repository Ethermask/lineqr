package kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import ka.h.b.a;
import ka.h.c.p;
import ka.h.c.r;
import kotlin.reflect.jvm.internal.impl.descriptors.SimpleFunctionDescriptor;
import kotlin.reflect.jvm.internal.impl.name.Name;
import kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors.DeserializedMemberScope;

public final class DeserializedMemberScope$NoReorderImplementation$functionsByName$2 extends r implements a<Map<Name, ? extends List<? extends SimpleFunctionDescriptor>>> {
    public final /* synthetic */ DeserializedMemberScope.NoReorderImplementation this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DeserializedMemberScope$NoReorderImplementation$functionsByName$2(DeserializedMemberScope.NoReorderImplementation noReorderImplementation) {
        super(0);
        this.this$0 = noReorderImplementation;
    }

    public final Map<Name, List<SimpleFunctionDescriptor>> invoke() {
        List access$getAllFunctions = this.this$0.getAllFunctions();
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (Object next : access$getAllFunctions) {
            Name name = ((SimpleFunctionDescriptor) next).getName();
            p.d(name, "it.name");
            Object obj = linkedHashMap.get(name);
            if (obj == null) {
                obj = new ArrayList();
                linkedHashMap.put(name, obj);
            }
            ((List) obj).add(next);
        }
        return linkedHashMap;
    }
}

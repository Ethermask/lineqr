package kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors;

import ka.h.b.a;
import ka.h.c.r;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassConstructorDescriptor;

public final class DeserializedClassDescriptor$primaryConstructor$1 extends r implements a<ClassConstructorDescriptor> {
    public final /* synthetic */ DeserializedClassDescriptor this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DeserializedClassDescriptor$primaryConstructor$1(DeserializedClassDescriptor deserializedClassDescriptor) {
        super(0);
        this.this$0 = deserializedClassDescriptor;
    }

    public final ClassConstructorDescriptor invoke() {
        return this.this$0.computePrimaryConstructor();
    }
}

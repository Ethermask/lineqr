package kotlin.reflect.jvm.internal.impl.name;

import ka.h.c.p;
import ka.m.g;

public final class NameUtils {
    public static final NameUtils INSTANCE = new NameUtils();
    public static final g SANITIZE_AS_JAVA_INVALID_CHARACTERS = new g("[^\\p{L}\\p{Digit}]");

    public static final String sanitizeAsJavaIdentifier(String str) {
        p.e(str, "name");
        return SANITIZE_AS_JAVA_INVALID_CHARACTERS.f(str, "_");
    }
}

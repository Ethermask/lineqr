package kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors;

import ka.h.b.a;
import ka.h.c.r;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassDescriptor;

public final class DeserializedClassDescriptor$companionObjectDescriptor$1 extends r implements a<ClassDescriptor> {
    public final /* synthetic */ DeserializedClassDescriptor this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DeserializedClassDescriptor$companionObjectDescriptor$1(DeserializedClassDescriptor deserializedClassDescriptor) {
        super(0);
        this.this$0 = deserializedClassDescriptor;
    }

    public final ClassDescriptor invoke() {
        return this.this$0.computeCompanionObjectDescriptor();
    }
}

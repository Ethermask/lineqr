package kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors;

import java.util.Collection;
import ka.h.b.a;
import ka.h.c.r;
import kotlin.reflect.jvm.internal.impl.descriptors.ClassDescriptor;

public final class DeserializedClassDescriptor$sealedSubclasses$1 extends r implements a<Collection<? extends ClassDescriptor>> {
    public final /* synthetic */ DeserializedClassDescriptor this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DeserializedClassDescriptor$sealedSubclasses$1(DeserializedClassDescriptor deserializedClassDescriptor) {
        super(0);
        this.this$0 = deserializedClassDescriptor;
    }

    public final Collection<ClassDescriptor> invoke() {
        return this.this$0.computeSubclassesForSealedClass();
    }
}

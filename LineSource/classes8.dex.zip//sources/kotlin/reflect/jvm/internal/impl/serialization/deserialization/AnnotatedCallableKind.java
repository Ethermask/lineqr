package kotlin.reflect.jvm.internal.impl.serialization.deserialization;

public enum AnnotatedCallableKind {
    FUNCTION,
    PROPERTY,
    PROPERTY_GETTER,
    PROPERTY_SETTER
}

package kotlin.reflect.jvm.internal.impl.name;

import ka.h.c.p;
import ka.m.r;

public final class FqNamesUtilKt {

    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[State.values().length];
            State state = State.BEGINNING;
            iArr[0] = 1;
            State state2 = State.AFTER_DOT;
            iArr[2] = 2;
            State state3 = State.MIDDLE;
            iArr[1] = 3;
            $EnumSwitchMapping$0 = iArr;
        }
    }

    public static final boolean isSubpackageOf(FqName fqName, FqName fqName2) {
        p.e(fqName, "<this>");
        p.e(fqName2, "packageName");
        if (p.b(fqName, fqName2) || fqName2.isRoot()) {
            return true;
        }
        String asString = fqName.asString();
        p.d(asString, "this.asString()");
        String asString2 = fqName2.asString();
        p.d(asString2, "packageName.asString()");
        return isSubpackageOf(asString, asString2);
    }

    public static final boolean isValidJavaFqName(String str) {
        if (str == null) {
            return false;
        }
        State state = State.BEGINNING;
        int i = 0;
        while (i < str.length()) {
            char charAt = str.charAt(i);
            i++;
            int ordinal = state.ordinal();
            if (ordinal != 0) {
                if (ordinal != 1) {
                    if (ordinal != 2) {
                        continue;
                    }
                } else if (charAt == '.') {
                    state = State.AFTER_DOT;
                } else if (!Character.isJavaIdentifierPart(charAt)) {
                    return false;
                }
            }
            if (!Character.isJavaIdentifierPart(charAt)) {
                return false;
            }
            state = State.MIDDLE;
        }
        if (state != State.AFTER_DOT) {
            return true;
        }
        return false;
    }

    public static final FqName tail(FqName fqName, FqName fqName2) {
        p.e(fqName, "<this>");
        p.e(fqName2, "prefix");
        if (!isSubpackageOf(fqName, fqName2) || fqName2.isRoot()) {
            return fqName;
        }
        if (p.b(fqName, fqName2)) {
            FqName fqName3 = FqName.ROOT;
            p.d(fqName3, "ROOT");
            return fqName3;
        }
        String asString = fqName.asString();
        p.d(asString, "asString()");
        String substring = asString.substring(fqName2.asString().length() + 1);
        p.d(substring, "(this as java.lang.String).substring(startIndex)");
        return new FqName(substring);
    }

    public static final boolean isSubpackageOf(String str, String str2) {
        return r.H(str, str2, false, 2) && str.charAt(str2.length()) == '.';
    }
}

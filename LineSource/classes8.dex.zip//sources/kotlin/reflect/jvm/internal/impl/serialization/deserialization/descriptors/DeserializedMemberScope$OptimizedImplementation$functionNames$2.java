package kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors;

import java.util.Set;
import ka.b.q;
import ka.h.b.a;
import ka.h.c.r;
import kotlin.reflect.jvm.internal.impl.name.Name;
import kotlin.reflect.jvm.internal.impl.serialization.deserialization.descriptors.DeserializedMemberScope;

public final class DeserializedMemberScope$OptimizedImplementation$functionNames$2 extends r implements a<Set<? extends Name>> {
    public final /* synthetic */ DeserializedMemberScope.OptimizedImplementation this$0;
    public final /* synthetic */ DeserializedMemberScope this$1;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public DeserializedMemberScope$OptimizedImplementation$functionNames$2(DeserializedMemberScope.OptimizedImplementation optimizedImplementation, DeserializedMemberScope deserializedMemberScope) {
        super(0);
        this.this$0 = optimizedImplementation;
        this.this$1 = deserializedMemberScope;
    }

    public final Set<Name> invoke() {
        return q.z2(this.this$0.functionProtosBytes.keySet(), this.this$1.getNonDeclaredFunctionNames());
    }
}

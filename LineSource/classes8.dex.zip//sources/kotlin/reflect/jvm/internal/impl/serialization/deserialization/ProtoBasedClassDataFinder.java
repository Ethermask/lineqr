package kotlin.reflect.jvm.internal.impl.serialization.deserialization;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import ka.b.q;
import ka.h.b.l;
import ka.h.c.p;
import kotlin.reflect.jvm.internal.impl.descriptors.SourceElement;
import kotlin.reflect.jvm.internal.impl.metadata.ProtoBuf;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.BinaryVersion;
import kotlin.reflect.jvm.internal.impl.metadata.deserialization.NameResolver;
import kotlin.reflect.jvm.internal.impl.name.ClassId;

public final class ProtoBasedClassDataFinder implements ClassDataFinder {
    public final Map<ClassId, ProtoBuf.Class> classIdToProto;
    public final l<ClassId, SourceElement> classSource;
    public final BinaryVersion metadataVersion;
    public final NameResolver nameResolver;

    public ProtoBasedClassDataFinder(ProtoBuf.PackageFragment packageFragment, NameResolver nameResolver2, BinaryVersion binaryVersion, l<? super ClassId, ? extends SourceElement> lVar) {
        p.e(packageFragment, "proto");
        p.e(nameResolver2, "nameResolver");
        p.e(binaryVersion, "metadataVersion");
        p.e(lVar, "classSource");
        this.nameResolver = nameResolver2;
        this.metadataVersion = binaryVersion;
        this.classSource = lVar;
        List<ProtoBuf.Class> class_List = packageFragment.getClass_List();
        p.d(class_List, "proto.class_List");
        int g2 = q.g2(q.i0(class_List, 10));
        LinkedHashMap linkedHashMap = new LinkedHashMap(g2 < 16 ? 16 : g2);
        for (T next : class_List) {
            linkedHashMap.put(NameResolverUtilKt.getClassId(this.nameResolver, ((ProtoBuf.Class) next).getFqName()), next);
        }
        this.classIdToProto = linkedHashMap;
    }

    public ClassData findClassData(ClassId classId) {
        p.e(classId, "classId");
        ProtoBuf.Class classR = this.classIdToProto.get(classId);
        if (classR == null) {
            return null;
        }
        return new ClassData(this.nameResolver, classR, this.metadataVersion, (SourceElement) this.classSource.invoke(classId));
    }

    public final Collection<ClassId> getAllClassIds() {
        return this.classIdToProto.keySet();
    }
}

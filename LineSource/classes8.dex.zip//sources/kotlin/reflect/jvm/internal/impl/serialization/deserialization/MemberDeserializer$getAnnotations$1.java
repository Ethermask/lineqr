package kotlin.reflect.jvm.internal.impl.serialization.deserialization;

import java.util.List;
import ka.b.k;
import ka.b.v;
import ka.h.b.a;
import ka.h.c.r;
import kotlin.reflect.jvm.internal.impl.descriptors.annotations.AnnotationDescriptor;
import kotlin.reflect.jvm.internal.impl.protobuf.MessageLite;

public final class MemberDeserializer$getAnnotations$1 extends r implements a<List<? extends AnnotationDescriptor>> {
    public final /* synthetic */ AnnotatedCallableKind $kind;
    public final /* synthetic */ MessageLite $proto;
    public final /* synthetic */ MemberDeserializer this$0;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public MemberDeserializer$getAnnotations$1(MemberDeserializer memberDeserializer, MessageLite messageLite, AnnotatedCallableKind annotatedCallableKind) {
        super(0);
        this.this$0 = memberDeserializer;
        this.$proto = messageLite;
        this.$kind = annotatedCallableKind;
    }

    public final List<AnnotationDescriptor> invoke() {
        List<AnnotationDescriptor> list;
        MemberDeserializer memberDeserializer = this.this$0;
        ProtoContainer access$asProtoContainer = memberDeserializer.asProtoContainer(memberDeserializer.c.getContainingDeclaration());
        if (access$asProtoContainer == null) {
            list = null;
        } else {
            list = k.r0(this.this$0.c.getComponents().getAnnotationAndConstantLoader().loadCallableAnnotations(access$asProtoContainer, this.$proto, this.$kind));
        }
        return list != null ? list : v.a;
    }
}

from linepy import *
client = LINE(appType='CHROMEOS')
print(client.accessToken)
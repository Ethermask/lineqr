__all__ = ['ttypes', 'constants', 'SecondaryQrCodeLoginPermitNoticeService', 'SecondaryQrCodeLoginService']
